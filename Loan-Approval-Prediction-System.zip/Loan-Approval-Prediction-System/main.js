
// ============================================
// MAIN INTERACTION SCRIPT
// Loan Approval Prediction System Website
// ============================================

document.addEventListener('DOMContentLoaded', () => {

    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');

    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            const icon = mobileMenuBtn.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
            }
        });

        // Close menu on link click
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                if (icon) {
                    icon.classList.add('fa-bars');
                    icon.classList.remove('fa-times');
                }
            });
        });
    }

    // Navbar scroll effect
    const navbar = document.querySelector('.navbar');
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;

        if (currentScroll > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        lastScroll = currentScroll;
    });

    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);

    document.querySelectorAll('.animate-on-scroll').forEach(el => {
        observer.observe(el);
    });

    // Typing effect for hero subtitle (if element exists)
    const typingElement = document.querySelector('.typing-text');
    if (typingElement) {
        const text = typingElement.getAttribute('data-text') || typingElement.textContent;
        typingElement.textContent = '';
        let i = 0;

        function typeWriter() {
            if (i < text.length) {
                typingElement.textContent += text.charAt(i);
                i++;
                setTimeout(typeWriter, 50);
            }
        }

        setTimeout(typeWriter, 1000);
    }

    // ============================================
    // DEMO FORM SIMULATION
    // ============================================
    const predictForm = document.getElementById('predict-form');
    const resultCard = document.getElementById('result-card');

    if (predictForm && resultCard) {
        predictForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const formData = new FormData(predictForm);
            const data = Object.fromEntries(formData);

            // Simple simulation logic based on the actual model features
            let score = 50;

            // Credit history
            if (parseFloat(data.credit_history) === 1.0) score += 25;
            else score -= 20;

            // Income
            const income = parseInt(data.applicant_income) || 0;
            const coIncome = parseInt(data.coapplicant_income) || 0;
            const totalIncome = income + coIncome;
            if (totalIncome > 8000) score += 15;
            else if (totalIncome > 5000) score += 8;
            else score -= 10;

            // Education
            if (data.education === 'Graduate') score += 10;

            // Property area
            if (data.property_area === 'Urban' || data.property_area === 'Semiurban') score += 5;

            // Loan ratio
            const loan = parseInt(data.loan_amount) || 0;
            if (totalIncome > 0) {
                const ratio = loan / totalIncome;
                if (ratio < 0.15) score += 10;
                else if (ratio > 0.3) score -= 15;
            }

            // Married status
            if (data.married === 'Yes') score += 3;

            score = Math.max(0, Math.min(100, score));

            const approved = score >= 60;
            const probability = approved ? (score / 100) : (1 - score / 100);

            // Display result
            resultCard.className = 'result-card glass-panel show';
            if (approved) {
                resultCard.classList.add('result-approved');
                resultCard.innerHTML = `
                    <div class="result-title">✅ LOAN APPROVED</div>
                    <p style="font-size: 1.2rem; color: var(--text-primary); margin: 10px 0;">
                        Confidence: <span style="color: var(--secondary); font-weight: bold;">${(probability * 100).toFixed(1)}%</span>
                    </p>
                    <p style="color: var(--text-secondary);">
                        Health Score: <span style="color: var(--primary); font-weight: bold;">${score}/100</span>
                    </p>
                    <div style="margin-top: 1.5rem; padding: 1rem; background: rgba(0,0,0,0.3); border-radius: 10px; text-align: left;">
                        <p style="color: var(--text-secondary); font-size: 0.9rem; margin: 0;">
                            <strong style="color: var(--secondary);">AI Analysis:</strong> 
                            ${data.name || 'Applicant'}'s profile demonstrates ${score > 80 ? 'strong' : 'moderate'} financial credibility. 
                            ${parseFloat(data.credit_history) === 1.0 ? 'Positive credit history significantly boosts approval confidence.' : ''}
                            ${totalIncome > 6000 ? 'Combined household income indicates solid repayment capacity.' : ''}
                        </p>
                    </div>
                `;
            } else {
                resultCard.classList.add('result-rejected');
                resultCard.innerHTML = `
                    <div class="result-title">❌ LOAN REJECTED</div>
                    <p style="font-size: 1.2rem; color: var(--text-primary); margin: 10px 0;">
                        Confidence: <span style="color: var(--danger); font-weight: bold;">${(probability * 100).toFixed(1)}%</span>
                    </p>
                    <p style="color: var(--text-secondary);">
                        Health Score: <span style="color: var(--primary); font-weight: bold;">${score}/100</span>
                    </p>
                    <div style="margin-top: 1.5rem; padding: 1rem; background: rgba(0,0,0,0.3); border-radius: 10px; text-align: left;">
                        <p style="color: var(--text-secondary); font-size: 0.9rem; margin: 0;">
                            <strong style="color: var(--danger);">AI Analysis:</strong> 
                            ${data.name || 'Applicant'}'s profile presents elevated risk indicators.
                            ${parseFloat(data.credit_history) === 0.0 ? 'Absence of credit history raises uncertainty about repayment behavior.' : ''}
                            ${totalIncome < 4000 ? 'Household income falls below optimal thresholds for the requested loan amount.' : ''}
                        </p>
                    </div>
                `;
            }

            // Scroll to result
            resultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
    }

    // Counter animation for stats
    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000;
        const increment = target / (duration / 16);
        let current = 0;

        const updateCounter = () => {
            current += increment;
            if (current < target) {
                counter.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        };

        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    counterObserver.unobserve(entry.target);
                }
            });
        });

        counterObserver.observe(counter);
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // 3D Tilt effect for cards (desktop only)
    if (window.innerWidth > 768) {
        document.querySelectorAll('.tilt-card').forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                const centerX = rect.width / 2;
                const centerY = rect.height / 2;

                const rotateX = (y - centerY) / 20;
                const rotateY = (centerX - x) / 20;

                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)';
            });
        });
    }

    // Parallax effect for hero elements
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('.parallax');

        parallaxElements.forEach(el => {
            const speed = el.getAttribute('data-speed') || 0.5;
            el.style.transform = `translateY(${scrolled * speed}px)`;
        });
    });

    console.log('🚀 Loan Approval Prediction System Website Loaded');
});
