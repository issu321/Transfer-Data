<div align="center">

# 💰 LOAN APPROVAL PREDICTION SYSTEM

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.11+-00f0ff?style=for-the-badge&logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/Streamlit-1.28+-00ff88?style=for-the-badge&logo=streamlit&logoColor=white" />
  <img src="https://img.shields.io/badge/scikit--learn-1.3+-ffd700?style=for-the-badge&logo=scikit-learn&logoColor=white" />
  <img src="https://img.shields.io/badge/Plotly-5.15+-ff8c00?style=for-the-badge&logo=plotly&logoColor=white" />
</p>

<h3>🤖 AI-Powered Financial Intelligence Platform</h3>

<p style="color: #8b949e;">
  Predict loan approvals with machine learning. Compare models. Visualize analytics. Make data-driven decisions.
</p>

<p>
  <a href="https://github.com/issu321/Loan-Approval-Prediction-System">
    <img src="https://img.shields.io/badge/GitHub-issu321-00f0ff?style=flat-square&logo=github" />
  </a>
  <a href="#installation">
    <img src="https://img.shields.io/badge/Get%20Started-00ff88?style=flat-square" />
  </a>
</p>

<div style="height: 2px; background: linear-gradient(90deg, transparent, #00f0ff, #00ff88, transparent); margin: 20px 0;"></div>

</div>

---

## 🌌 Introduction

Welcome to the **Loan Approval Prediction System** — a cutting-edge, AI-powered financial intelligence platform built for the modern era. This system leverages advanced machine learning algorithms to predict loan approval outcomes with high accuracy, providing banks, financial institutions, and fintech startups with a powerful decision-support tool.

In an age where data drives every critical decision, this project demonstrates the power of **scikit-learn**, **Streamlit**, and **Plotly** working in harmony to deliver real-time predictions, comprehensive model comparisons, and stunning interactive visualizations.

> *"Transform raw applicant data into actionable financial intelligence in seconds."*

---

## ✨ Features

### 🔮 Real-Time Prediction Engine
- **Single Applicant Mode**: Enter applicant details manually with full name and receive instant approval predictions
- **Batch Processing**: Upload CSV files with multiple applicants (including names) for bulk predictions
- **AI Explanation Engine**: Human-readable explanations personalized with applicant names

### 🤖 Multi-Model Comparison
- **Logistic Regression** — Baseline linear classifier
- **Decision Tree** — Interpretable rule-based model
- **Random Forest** — Ensemble method with feature importance
- **Support Vector Machine** — Kernel-based classifier

Automatic best-model selection based on **F1 Score**.

### 📊 Interactive Visualizations
- Approval distribution charts
- Income vs loan amount scatter plots
- Feature importance rankings
- Confusion matrices for all models
- Correlation heatmaps
- Box plots and histograms

### 🎨 Modern Cyberpunk UI
- Dark futuristic theme with neon accents
- Responsive sidebar navigation
- Animated metric cards
- Terminal-style data displays
- Glowing buttons and panels

### 💾 Production-Ready Pipeline
- Automated preprocessing (imputation, encoding, scaling)
- Stratified train-test split
- Model serialization with **joblib**
- No data leakage — full pipeline architecture

---

## 🚀 Installation

### Prerequisites
- Python 3.11 or higher
- pip package manager

### Linux / macOS

```bash
git clone https://github.com/issu321/Loan-Approval-Prediction-System.git
cd Loan-Approval-Prediction-System
chmod +x install.sh
./install.sh
```

### Windows

```cmd
git clone https://github.com/issu321/Loan-Approval-Prediction-System.git
cd Loan-Approval-Prediction-System
install.bat
```

### Manual Installation

```bash
python -m venv venv
source venv/bin/activate  # Linux/macOS
# venv\Scripts\activate  # Windows

pip install -r requirements.txt
python -m streamlit run app.py
```

---

## 📖 Usage Guide

### 1. Launch the Application

After installation, the application will open automatically in your browser at:
```
http://localhost:8501
```

### 2. Train the Models

Navigate to **🤖 Model Training** from the sidebar and click:
```
🚀 TRAIN ALL MODELS
```

This will:
- Preprocess the dataset
- Train 4 ML models
- Compare performance metrics
- Save the best model automatically

### 3. Make Predictions

Go to **🔮 Predictions** and choose:
- **📝 Manual Entry** — Fill the applicant form (including Name)
- **📁 Batch Upload** — Upload a CSV file with Name column

### 4. Explore Analytics

Visit **📈 Analytics** for deep-dive visualizations:
- Income analysis by approval status
- Property area breakdowns
- Approval factor correlations

---

## 📸 Screenshots

> *Placeholder sections for screenshots. After running the app, capture images of:*

| Module | Preview |
|--------|---------|
| 🏠 Dashboard | *Animated metrics and distribution charts* |
| 📊 Data Explorer | *Raw data table with statistics* |
| 🤖 Model Training | *Model comparison table and confusion matrices* |
| 🔮 Predictions | *Applicant form with Name field and AI explanation* |
| 📈 Analytics | *Interactive Plotly visualizations* |

---

## 🛠️ Technologies Used

| Technology | Purpose |
|------------|---------|
| **Python 3.11+** | Core language |
| **Streamlit** | Frontend web application |
| **scikit-learn** | Machine learning pipeline |
| **pandas** | Data manipulation |
| **numpy** | Numerical computing |
| **plotly** | Interactive visualizations |
| **matplotlib** | Static chart rendering |
| **joblib** | Model serialization |

---

## 📁 Folder Structure

```
Loan-Approval-Prediction-System/
│
├── app.py                 # Main Streamlit application (backend + frontend)
├── requirements.txt       # Python dependencies
├── README.md              # Project documentation
├── install.sh             # Linux/macOS installer
├── install.bat            # Windows installer
├── inputguide.md          # Input format guide and troubleshooting
├── dataset.csv            # Training dataset (250 realistic Indian records with names)
├── .gitignore             # Git ignore rules
│
└── assets/
    └── styles.css         # Custom cyberpunk theme stylesheet
```

---

## 📋 Example Predictions

### Scenario A: Strong Applicant

| Field | Value |
|-------|-------|
| Name | Rajesh Kumar |
| Gender | Male |
| Married | Yes |
| Education | Graduate |
| Self Employed | No |
| Applicant Income | ₹8,000 |
| Coapplicant Income | ₹3,000 |
| Loan Amount | ₹150k |
| Loan Term | 360 months |
| Credit History | Good (1.0) |
| Property Area | Urban |

**Prediction:** ✅ **APPROVED** — Confidence: 92%  
**Risk Class:** Very Low Risk | **Health Score:** 95/100

> *"Rajesh Kumar's profile demonstrates strong financial credibility. A positive credit history significantly boosts approval confidence. Combined household income exceeds typical thresholds, indicating solid repayment capacity."*

---

### Scenario B: Risky Applicant

| Field | Value |
|-------|-------|
| Name | Suresh Yadav |
| Gender | Male |
| Married | No |
| Education | Not Graduate |
| Self Employed | No |
| Applicant Income | ₹2,000 |
| Coapplicant Income | ₹0 |
| Loan Amount | ₹250k |
| Loan Term | 120 months |
| Credit History | Bad (0.0) |
| Property Area | Rural |

**Prediction:** ❌ **REJECTED** — Confidence: 88%  
**Risk Class:** Very High Risk | **Health Score:** 25/100

> *"Suresh Yadav's profile presents elevated risk indicators. Absence of credit history raises uncertainty about repayment behavior. Household income falls below optimal thresholds for the requested loan amount."*

---

## 🧠 Model Comparison Explanation

The system evaluates four distinct algorithms:

### 1. Logistic Regression
A probabilistic linear model that estimates the log-odds of approval. Fast, interpretable, and serves as a strong baseline.

### 2. Decision Tree
A tree-structured model that splits data based on feature thresholds. Highly interpretable but prone to overfitting without regularization.

### 3. Random Forest
An ensemble of decision trees that reduces overfitting through bagging and feature randomness. Typically delivers the highest accuracy and provides feature importance rankings.

### 4. Support Vector Machine (SVM)
A kernel-based classifier that finds optimal hyperplanes in high-dimensional space. Effective with smaller datasets but computationally intensive.

### Selection Criteria
The **best model** is automatically selected based on **F1 Score** — the harmonic mean of precision and recall. This balances the trade-off between false positives (approving risky loans) and false negatives (rejecting good applicants).

| Metric | Description |
|--------|-------------|
| **Accuracy** | Overall correct predictions |
| **Precision** | Of approved predictions, how many were correct |
| **Recall** | Of actual approvals, how many were caught |
| **F1 Score** | Balanced measure of precision and recall |

---

## 🔮 Future Improvements

- [ ] **Neural Network Integration** — Add TensorFlow/PyTorch deep learning models
- [ ] **Hyperparameter Tuning** — Implement GridSearchCV and Bayesian optimization
- [ ] **Explainability (SHAP/LIME)** — Feature-level contribution breakdowns
- [ ] **API Endpoint** — FastAPI backend for microservice deployment
- [ ] **Database Integration** — PostgreSQL/MySQL for persistent storage
- [ ] **Authentication** — User login and role-based access control
- [ ] **Real-time Monitoring** — Model drift detection and retraining triggers
- [ ] **Docker Containerization** — One-command deployment anywhere

---

## 🤝 Contribution Guide

Contributions are welcome! Follow these steps:

1. **Fork** the repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/Loan-Approval-Prediction-System.git`
3. **Create** a feature branch: `git checkout -b feature/amazing-feature`
4. **Commit** your changes: `git commit -m "Add amazing feature"`
5. **Push** to the branch: `git push origin feature/amazing-feature`
6. **Open** a Pull Request

### Code Standards
- Follow PEP 8 style guidelines
- Add docstrings to all functions
- Include type hints where applicable
- Write unit tests for new features
- Update README.md with changes

---

## 📄 License

This project is licensed under the **MIT License**.

```
MIT License

Copyright (c) 2024 issu321

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

<div align="center">

## 👨‍💻 Developed by [issu321](https://github.com/issu321)

**Repository:** [github.com/issu321/Loan-Approval-Prediction-System](https://github.com/issu321/Loan-Approval-Prediction-System)

<p style="color: #484f58;">
  Built with Python · scikit-learn · Streamlit · Plotly
</p>

<div style="height: 2px; background: linear-gradient(90deg, transparent, #00f0ff, #00ff88, transparent); margin: 20px 0;"></div>

</div>
