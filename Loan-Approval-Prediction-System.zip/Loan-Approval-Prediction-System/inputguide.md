# 📋 Input Guide

> **Loan Approval Prediction System**  
> Developed by [issu321](https://github.com/issu321)  
> Repository: [Loan-Approval-Prediction-System](https://github.com/issu321/Loan-Approval-Prediction-System)

---

## 📌 Supported Input Fields

### Text Fields (Manual Entry)

| Field | Example | Description |
|-------|---------|-------------|
| **Name** | `Rahul Sharma` | Applicant full name (required) |
| **Gender** | `Male` / `Female` | Applicant gender |
| **Married** | `Yes` / `No` | Marital status |
| **Education** | `Graduate` / `Not Graduate` | Highest education level |
| **Self_Employed** | `Yes` / `No` | Whether applicant is self-employed |
| **Property_Area** | `Urban` / `Semiurban` / `Rural` | Location of property |
| **Credit_History** | `1.0` (Good) / `0.0` (Bad) | Credit repayment history |
| **Loan_Term** | `360` | Repayment term in months |

### Numerical Fields

| Field | Range | Description |
|-------|-------|-------------|
| **ApplicantIncome** | 0 - 50,000 | Monthly income of applicant (INR) |
| **CoapplicantIncome** | 0 - 30,000 | Monthly income of co-applicant (INR) |
| **LoanAmount** | 1 - 700 | Loan amount requested (in thousands) |

---

## 👤 Example Applicant Data

### Example 1: High Approval Likelihood

```
Name:             Rahul Sharma
Gender:           Male
Married:          Yes
Education:        Graduate
Self_Employed:    No
ApplicantIncome:  8000
CoapplicantIncome: 3000
LoanAmount:       150
Loan_Amount_Term: 360
Credit_History:   1.0
Property_Area:    Urban
```

**Expected:** ✅ Approved (High Confidence)

---

### Example 2: Moderate Risk

```
Name:             Priya Patel
Gender:           Female
Married:          No
Education:        Graduate
Self_Employed:    Yes
ApplicantIncome:  3500
CoapplicantIncome: 0
LoanAmount:       180
Loan_Amount_Term: 240
Credit_History:   1.0
Property_Area:    Semiurban
```

**Expected:** ⚠️ Moderate Approval Probability

---

### Example 3: Likely Rejection

```
Name:             Suresh Yadav
Gender:           Male
Married:          No
Education:        Not Graduate
Self_Employed:    No
ApplicantIncome:  2000
CoapplicantIncome: 0
LoanAmount:       250
Loan_Amount_Term: 120
Credit_History:   0.0
Property_Area:    Rural
```

**Expected:** ❌ Rejected (High Confidence)

---

## 📁 CSV Upload Format

For batch predictions, upload a CSV file with the following exact columns:

```csv
Name,Gender,Married,Education,Self_Employed,ApplicantIncome,CoapplicantIncome,LoanAmount,Loan_Amount_Term,Credit_History,Property_Area
Rahul Sharma,Male,Yes,Graduate,No,8000,3000,150,360,1.0,Urban
Priya Patel,Female,No,Graduate,Yes,3500,0,180,240,1.0,Semiurban
Suresh Yadav,Male,No,Not Graduate,No,2000,0,250,120,0.0,Rural
```

### CSV Requirements
- Header row is **mandatory**
- Column names must match exactly (case-sensitive)
- **Name column is required** for batch processing
- No missing values in required fields
- `Credit_History` must be `1.0` or `0.0`
- `Loan_Amount_Term` must be one of: `120`, `180`, `240`, `300`, `360`, `480`

---

## 🛠️ Troubleshooting

| Issue | Solution |
|-------|----------|
| `ModuleNotFoundError` | Run `install.sh` (Linux) or `install.bat` (Windows) to install dependencies |
| Model not found | Navigate to **🤖 Model Training** and click **TRAIN ALL MODELS** |
| CSV upload fails | Verify column names match exactly and no missing values exist |
| Streamlit not found | Use `python -m streamlit run app.py` instead of `streamlit run app.py` |
| Port already in use | Run with custom port: `streamlit run app.py --server.port 8502` |

---

## 🚀 Quick Start

1. Install dependencies: `./install.sh` (Linux) or `install.bat` (Windows)
2. Train models: Go to **🤖 Model Training** → Click **TRAIN ALL MODELS**
3. Make predictions: Go to **🔮 Predictions** → Enter applicant data or upload CSV

---

<p align="center">
  <b>Developed by <a href="https://github.com/issu321">issu321</a></b>
</p>
