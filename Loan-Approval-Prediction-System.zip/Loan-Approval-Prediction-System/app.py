import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import matplotlib.pyplot as plt
import joblib
import os
import base64
from io import BytesIO

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

# ============================================================
# PAGE CONFIG
# ============================================================
st.set_page_config(
    page_title="Loan Approval Prediction System",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================
# CUSTOM CSS - CYBERPUNK THEME
# ============================================================
def load_css():
    css_path = os.path.join(os.path.dirname(__file__), "assets", "styles.css")
    if os.path.exists(css_path):
        with open(css_path, "r") as f:
            css = f.read()
        st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)
    else:
        st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Rajdhani:wght@300;500;700&display=swap');
        .main { background: linear-gradient(135deg, #0a0a0a 0%, #0d1117 50%, #0a0a0a 100%); color: #e6edf3; font-family: 'Rajdhani', sans-serif; }
        h1, h2, h3 { font-family: 'Orbitron', sans-serif; color: #00f0ff; text-shadow: 0 0 10px rgba(0, 240, 255, 0.3); }
        .stButton>button { background: linear-gradient(135deg, #00f0ff, #00ff88); color: #000; border: none; border-radius: 8px; padding: 12px 24px; font-family: 'Orbitron', sans-serif; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; box-shadow: 0 0 15px rgba(0, 240, 255, 0.4); transition: all 0.3s ease; }
        .stButton>button:hover { box-shadow: 0 0 25px rgba(0, 240, 255, 0.7); transform: translateY(-2px); }
        .metric-card { background: rgba(13, 17, 23, 0.8); border: 1px solid rgba(0, 240, 255, 0.2); border-radius: 12px; padding: 20px; box-shadow: 0 0 15px rgba(0, 240, 255, 0.1); margin-bottom: 15px; }
        .glow-text { color: #00ff88; text-shadow: 0 0 10px rgba(0, 255, 136, 0.5); }
        .terminal-box { background: #0d1117; border: 1px solid #30363d; border-radius: 8px; padding: 15px; font-family: 'Courier New', monospace; color: #00ff88; }
        .footer { text-align: center; padding: 20px; color: #8b949e; border-top: 1px solid rgba(0, 240, 255, 0.1); margin-top: 40px; }
        .prediction-approved { background: rgba(0, 255, 136, 0.1); border: 2px solid #00ff88; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 0 20px rgba(0, 255, 136, 0.3); }
        .prediction-rejected { background: rgba(255, 0, 80, 0.1); border: 2px solid #ff0050; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 0 20px rgba(255, 0, 80, 0.3); }
        </style>
        """, unsafe_allow_html=True)

load_css()

# ============================================================
# HEADER
# ============================================================
st.markdown("""
<div style="text-align: center; padding: 20px 0;">
    <h1 style="font-size: 2.5rem; margin-bottom: 0;">💰 LOAN APPROVAL PREDICTION SYSTEM</h1>
    <p style="color: #8b949e; font-size: 1.1rem; margin-top: 5px;">AI-Powered Financial Intelligence Platform</p>
    <div style="height: 2px; background: linear-gradient(90deg, transparent, #00f0ff, #00ff88, transparent); margin: 15px 0;"></div>
</div>
""", unsafe_allow_html=True)

# ============================================================
# SESSION STATE
# ============================================================
if 'df' not in st.session_state:
    st.session_state.df = None
if 'model_trained' not in st.session_state:
    st.session_state.model_trained = False
if 'results' not in st.session_state:
    st.session_state.results = None
if 'best_name' not in st.session_state:
    st.session_state.best_name = None
if 'model' not in st.session_state:
    st.session_state.model = None

# ============================================================
# SIDEBAR NAVIGATION
# ============================================================
st.sidebar.markdown("""
<div style="text-align: center; margin-bottom: 20px;">
    <h2 style="color: #00f0ff; font-size: 1.3rem;">🧭 NAVIGATION</h2>
</div>
""", unsafe_allow_html=True)

page = st.sidebar.radio(
    "Select Module",
    ["🏠 Dashboard", "📊 Data Explorer", "🤖 Model Training", "🔮 Predictions", "📈 Analytics"]
)

# Quick stats from session state or default
if st.session_state.df is not None:
    df_stats = st.session_state.df
    total_records = len(df_stats)
    approved_count = len(df_stats[df_stats['Loan_Status']=='Y'])
    rejected_count = len(df_stats[df_stats['Loan_Status']=='N'])
else:
    total_records = 0
    approved_count = 0
    rejected_count = 0

st.sidebar.markdown("""
<div style="margin-top: 30px; padding: 15px; border: 1px solid rgba(0, 240, 255, 0.2); border-radius: 10px;">
    <h4 style="color: #00ff88; margin-bottom: 10px;">⚡ Quick Stats</h4>
    <p style="font-size: 0.9rem; margin: 5px 0;">Total Records: <span style="color: #00f0ff;">{}</span></p>
    <p style="font-size: 0.9rem; margin: 5px 0;">Approved: <span style="color: #00ff88;">{}</span></p>
    <p style="font-size: 0.9rem; margin: 5px 0;">Rejected: <span style="color: #ff0050;">{}</span></p>
    <p style="font-size: 0.9rem; margin: 5px 0;">Model Status: <span style="color: {};">{}</span></p>
</div>
""".format(
    total_records, approved_count, rejected_count,
    "#00ff88" if st.session_state.model_trained else "#ff0050",
    "✅ Trained" if st.session_state.model_trained else "❌ Not Trained"
), unsafe_allow_html=True)

st.sidebar.markdown("""
<div class="footer" style="margin-top: 40px; font-size: 0.8rem;">
    <p>Developed by <a href="https://github.com/issu321" target="_blank" style="color: #00f0ff; text-decoration: none;">issu321</a></p>
    <p style="font-size: 0.7rem; margin-top: 5px;">Loan-Approval-Prediction-System v2.0</p>
</div>
""", unsafe_allow_html=True)

# ============================================================
# ML PIPELINE FUNCTIONS
# ============================================================
MODEL_PATH = "best_model.joblib"

def get_preprocessor():
    categorical_features = ['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area']
    numerical_features = ['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term', 'Credit_History']

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])

    numerical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_transformer, numerical_features),
            ('cat', categorical_transformer, categorical_features)
        ]
    )
    return preprocessor, numerical_features, categorical_features

def train_models(df):
    X = df.drop(['Loan_Status', 'Name'], axis=1)
    y = df['Loan_Status'].map({'Y': 1, 'N': 0})

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    preprocessor, num_features, cat_features = get_preprocessor()

    models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Decision Tree': DecisionTreeClassifier(random_state=42, max_depth=10, min_samples_split=5),
        'Random Forest': RandomForestClassifier(n_estimators=150, random_state=42, max_depth=12),
        'Support Vector Machine': SVC(probability=True, random_state=42, kernel='rbf')
    }

    results = {}
    trained_pipes = {}

    for name, model in models.items():
        pipe = Pipeline(steps=[
            ('preprocessor', preprocessor),
            ('classifier', model)
        ])

        pipe.fit(X_train, y_train)
        y_pred = pipe.predict(X_test)
        y_prob = pipe.predict_proba(X_test)[:, 1] if hasattr(pipe, "predict_proba") else None

        results[name] = {
            'Accuracy': accuracy_score(y_test, y_pred),
            'Precision': precision_score(y_test, y_pred, zero_division=0),
            'Recall': recall_score(y_test, y_pred, zero_division=0),
            'F1 Score': f1_score(y_test, y_pred, zero_division=0),
            'pipeline': pipe,
            'y_test': y_test,
            'y_pred': y_pred,
            'y_prob': y_prob
        }
        trained_pipes[name] = pipe

    best_name = max(results, key=lambda k: results[k]['F1 Score'])
    best_pipe = trained_pipes[best_name]

    joblib.dump(best_pipe, MODEL_PATH)

    return results, best_name, X_test, y_test

def load_best_model():
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    return None

# ============================================================
# EXPLANATION ENGINE
# ============================================================
def generate_explanation(input_data, prediction, probability):
    parts = []

    credit = input_data.get('Credit_History', 0)
    income = input_data.get('ApplicantIncome', 0)
    co_income = input_data.get('CoapplicantIncome', 0)
    total_income = income + co_income
    loan = input_data.get('LoanAmount', 0)
    education = input_data.get('Education', '')
    married = input_data.get('Married', '')
    area = input_data.get('Property_Area', '')
    name = input_data.get('Name', 'Applicant')

    if prediction == 1:
        parts.append(f"{name}'s profile demonstrates strong financial credibility.")
        if credit == 1.0:
            parts.append("A positive credit history significantly boosts approval confidence.")
        if total_income > 6000:
            parts.append("Combined household income exceeds typical thresholds, indicating solid repayment capacity.")
        if education == 'Graduate':
            parts.append("Higher education background correlates with stable employment and income streams.")
        if area in ['Urban', 'Semiurban']:
            parts.append("Property location in a developed area adds collateral security value.")
        if loan < total_income * 0.15:
            parts.append("The requested loan amount is conservative relative to income, minimizing default risk.")
        parts.append(f"Overall approval confidence stands at {probability*100:.1f}%.")
    else:
        parts.append(f"{name}'s profile presents elevated risk indicators.")
        if credit == 0.0:
            parts.append("Absence of credit history raises uncertainty about repayment behavior.")
        if total_income < 4000:
            parts.append("Household income falls below optimal thresholds for the requested loan amount.")
        if loan > total_income * 0.25:
            parts.append("The loan-to-income ratio is high, suggesting potential repayment strain.")
        if education == 'Not Graduate':
            parts.append("Limited formal education may correlate with income volatility in this dataset.")
        parts.append(f"Rejection confidence is {probability*100:.1f}%.")

    return " ".join(parts)

def risk_classification(probability):
    if probability >= 0.85:
        return "Very Low Risk", "#00ff88"
    elif probability >= 0.70:
        return "Low Risk", "#00f0ff"
    elif probability >= 0.55:
        return "Moderate Risk", "#ffd700"
    elif probability >= 0.40:
        return "High Risk", "#ff8c00"
    else:
        return "Very High Risk", "#ff0050"

def health_score(input_data):
    score = 50
    if input_data.get('Credit_History') == 1.0:
        score += 20
    income = input_data.get('ApplicantIncome', 0)
    if income > 5000:
        score += 15
    elif income > 3000:
        score += 8
    if input_data.get('Education') == 'Graduate':
        score += 10
    if input_data.get('Property_Area') in ['Urban', 'Semiurban']:
        score += 5
    loan = input_data.get('LoanAmount', 0)
    total = income + input_data.get('CoapplicantIncome', 0)
    if total > 0 and loan / total < 0.15:
        score += 10
    return min(100, score)

# ============================================================
# DOWNLOAD HELPER
# ============================================================
def get_download_link(df_download, filename="predictions.csv"):
    csv = df_download.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    return f'<a href="data:file/csv;base64,{b64}" download="{filename}" style="text-decoration: none;"><button style="background: linear-gradient(145deg, #0077b6, #0096c7); color: #fff; border: 1px solid rgba(0,180,216,0.5); border-radius: 10px; padding: 12px 28px; font-family: Orbitron; font-weight: 700; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; cursor: pointer; text-shadow: 0 1px 4px rgba(0,0,0,0.6); box-shadow: 0 6px 20px rgba(0,119,182,0.35), 0 2px 6px rgba(0,0,0,0.3); transition: all 0.3s ease;">⬇️ Download Results</button></a>'

# ============================================================
# PAGE: DASHBOARD
# ============================================================
if page == "🏠 Dashboard":
    st.markdown("""
    <div style="text-align: center; margin-bottom: 30px;">
        <h2>🎯 MISSION CONTROL</h2>
        <p style="color: #8b949e;">Real-time loan analytics and system overview</p>
    </div>
    """, unsafe_allow_html=True)

    if st.session_state.df is not None:
        df = st.session_state.df
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.markdown(f"""
            <div class="metric-card" style="text-align: center;">
                <h3 style="color: #00f0ff; margin: 0;">{len(df)}</h3>
                <p style="color: #8b949e; margin: 5px 0 0 0;">Total Applicants</p>
            </div>
            """, unsafe_allow_html=True)

        with col2:
            approval_rate = len(df[df['Loan_Status']=='Y']) / len(df) * 100
            st.markdown(f"""
            <div class="metric-card" style="text-align: center;">
                <h3 style="color: #00ff88; margin: 0;">{approval_rate:.1f}%</h3>
                <p style="color: #8b949e; margin: 5px 0 0 0;">Approval Rate</p>
            </div>
            """, unsafe_allow_html=True)

        with col3:
            avg_income = df['ApplicantIncome'].mean()
            st.markdown(f"""
            <div class="metric-card" style="text-align: center;">
                <h3 style="color: #ffd700; margin: 0;">₹{avg_income:,.0f}</h3>
                <p style="color: #8b949e; margin: 5px 0 0 0;">Avg Income</p>
            </div>
            """, unsafe_allow_html=True)

        with col4:
            avg_loan = df['LoanAmount'].mean()
            st.markdown(f"""
            <div class="metric-card" style="text-align: center;">
                <h3 style="color: #ff8c00; margin: 0;">₹{avg_loan:,.0f}k</h3>
                <p style="color: #8b949e; margin: 5px 0 0 0;">Avg Loan</p>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">👤 Recent Applicants</h4></div>""", unsafe_allow_html=True)
        recent_df = df[['Name', 'Gender', 'ApplicantIncome', 'LoanAmount', 'Loan_Status']].head(8)
        recent_df['Loan_Status'] = recent_df['Loan_Status'].map({'Y': '✅ Approved', 'N': '❌ Rejected'})
        st.dataframe(recent_df, use_container_width=True, hide_index=True)

        st.markdown("<br>", unsafe_allow_html=True)

        col_left, col_right = st.columns(2)

        with col_left:
            st.markdown("""
            <div class="metric-card">
                <h4 style="color: #00f0ff;">📊 Approval Distribution</h4>
            </div>
            """, unsafe_allow_html=True)

            status_counts = df['Loan_Status'].value_counts().reset_index()
            status_counts.columns = ['Status', 'Count']
            status_counts['Status'] = status_counts['Status'].map({'Y': 'Approved', 'N': 'Rejected'})

            fig = px.pie(
                status_counts, values='Count', names='Status',
                color='Status',
                color_discrete_map={'Approved': '#00ff88', 'Rejected': '#ff0050'},
                template='plotly_dark'
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3'),
                showlegend=True,
                margin=dict(t=10, b=10, l=10, r=10)
            )
            st.plotly_chart(fig, use_container_width=True)

        with col_right:
            st.markdown("""
            <div class="metric-card">
                <h4 style="color: #00f0ff;">💵 Income vs Loan Amount</h4>
            </div>
            """, unsafe_allow_html=True)

            fig2 = px.scatter(
                df, x='ApplicantIncome', y='LoanAmount',
                color='Loan_Status',
                color_discrete_map={'Y': '#00ff88', 'N': '#ff0050'},
                template='plotly_dark',
                opacity=0.7,
                labels={'ApplicantIncome': 'Applicant Income (₹)', 'LoanAmount': 'Loan Amount (₹k)'}
            )
            fig2.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3'),
                margin=dict(t=10, b=10, l=10, r=10)
            )
            st.plotly_chart(fig2, use_container_width=True)
    else:
        st.info("📁 Please upload a CSV dataset in the **🤖 Model Training** section to get started.")

    st.markdown("""
    <div class="metric-card" style="margin-top: 20px;">
        <h4 style="color: #00f0ff;">🚀 System Capabilities</h4>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 15px;">
            <div class="terminal-box">
                <span style="color: #00f0ff;">$</span> Upload CSV & Auto-Train Models<br>
                <span style="color: #00f0ff;">$</span> Multi-Model Comparison<br>
                <span style="color: #00f0ff;">$</span> Automated Preprocessing
            </div>
            <div class="terminal-box">
                <span style="color: #00ff88;">$</span> Batch CSV Processing<br>
                <span style="color: #00ff88;">$</span> AI Explanation Engine<br>
                <span style="color: #00ff88;">$</span> Interactive Visualizations
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# ============================================================
# PAGE: DATA EXPLORER
# ============================================================
elif page == "📊 Data Explorer":
    st.markdown("""
    <div style="text-align: center; margin-bottom: 20px;">
        <h2>🔍 DATA EXPLORER</h2>
        <p style="color: #8b949e;">Inspect and analyze the training dataset</p>
    </div>
    """, unsafe_allow_html=True)

    if st.session_state.df is not None:
        df = st.session_state.df
        tab1, tab2, tab3 = st.tabs(["📋 Raw Data", "📈 Statistics", "🗺️ Distributions"])

        with tab1:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Dataset Preview</h4></div>""", unsafe_allow_html=True)
            st.dataframe(df, use_container_width=True, height=400)

            col1, col2 = st.columns(2)
            with col1:
                st.download_button(
                    "⬇️ Download Dataset",
                    df.to_csv(index=False),
                    "dataset.csv",
                    "text/csv",
                    use_container_width=True
                )
            with col2:
                st.markdown(f"""
                <div class="terminal-box" style="text-align: center;">
                    Shape: {df.shape[0]} rows × {df.shape[1]} columns | Missing: {df.isnull().sum().sum()} values
                </div>
                """, unsafe_allow_html=True)

        with tab2:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Descriptive Statistics</h4></div>""", unsafe_allow_html=True)
            st.dataframe(df.describe(), use_container_width=True)

            st.markdown("<br>", unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                st.markdown("""<div class="metric-card"><h5 style="color: #00ff88;">Categorical Value Counts</h5></div>""", unsafe_allow_html=True)
                cat_col = st.selectbox("Select Column", ['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area', 'Loan_Status'])
                counts = df[cat_col].value_counts().reset_index()
                counts.columns = [cat_col, 'Count']
                fig = px.bar(counts, x=cat_col, y='Count', template='plotly_dark', color='Count',
                            color_continuous_scale=['#00f0ff', '#00ff88'])
                fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font=dict(color='#e6edf3'))
                st.plotly_chart(fig, use_container_width=True)

            with col2:
                st.markdown("""<div class="metric-card"><h5 style="color: #00ff88;">Correlation Heatmap (Numeric)</h5></div>""", unsafe_allow_html=True)
                numeric_df = df.select_dtypes(include=[np.number])
                corr = numeric_df.corr()
                fig = px.imshow(corr, text_auto=True, aspect="auto", template='plotly_dark',
                               color_continuous_scale=['#ff0050', '#0d1117', '#00ff88'])
                fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font=dict(color='#e6edf3'))
                st.plotly_chart(fig, use_container_width=True)

        with tab3:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Feature Distributions</h4></div>""", unsafe_allow_html=True)

            num_col = st.selectbox("Select Numeric Feature", ['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term'])

            fig = px.histogram(
                df, x=num_col, color='Loan_Status',
                color_discrete_map={'Y': '#00ff88', 'N': '#ff0050'},
                template='plotly_dark', nbins=30, opacity=0.7,
                marginal="box"
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3'), barmode='overlay'
            )
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("⚠️ No dataset loaded. Please upload a CSV in **🤖 Model Training** first.")

# ============================================================
# PAGE: MODEL TRAINING - CSV UPLOAD + AUTO TRAIN
# ============================================================
elif page == "🤖 Model Training":
    st.markdown("""
    <div style="text-align: center; margin-bottom: 20px;">
        <h2>🤖 MODEL TRAINING</h2>
        <p style="color: #8b949e;">Upload your CSV dataset and train all models automatically</p>
    </div>
    """, unsafe_allow_html=True)

    # STEP 1: CSV UPLOAD
    st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">📁 Step 1: Upload Training Dataset</h4></div>""", unsafe_allow_html=True)

    uploaded_train = st.file_uploader(
        "Upload your loan dataset CSV (must include Name, Gender, Married, Education, Self_Employed, ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term, Credit_History, Property_Area, Loan_Status)",
        type=['csv'],
        key="train_upload"
    )

    if uploaded_train is not None:
        try:
            df_uploaded = pd.read_csv(uploaded_train)

            required_cols = ['Name', 'Gender', 'Married', 'Education', 'Self_Employed',
                            'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
                            'Loan_Amount_Term', 'Credit_History', 'Property_Area', 'Loan_Status']

            missing = [c for c in required_cols if c not in df_uploaded.columns]

            if missing:
                st.error(f"❌ Missing required columns: {', '.join(missing)}")
                st.markdown("""
                <div class="terminal-box">
                    <b>Required columns:</b> Name, Gender, Married, Education, Self_Employed, ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term, Credit_History, Property_Area, Loan_Status<br><br>
                    <b>Loan_Status</b> must be 'Y' (Approved) or 'N' (Rejected)
                </div>
                """, unsafe_allow_html=True)
            else:
                st.success(f"✅ Dataset loaded successfully! {len(df_uploaded)} rows × {len(df_uploaded.columns)} columns")

                # Show preview
                st.markdown("""<div class="metric-card"><h5 style="color: #00ff88;">Dataset Preview</h5></div>""", unsafe_allow_html=True)
                st.dataframe(df_uploaded.head(10), use_container_width=True, hide_index=True)

                # Stats
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Total Records", len(df_uploaded))
                with col2:
                    approved = len(df_uploaded[df_uploaded['Loan_Status']=='Y'])
                    st.metric("Approved", approved)
                with col3:
                    rejected = len(df_uploaded[df_uploaded['Loan_Status']=='N'])
                    st.metric("Rejected", rejected)

                # Save to session state
                st.session_state.df = df_uploaded

                # STEP 2: AUTO TRAIN
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">🚀 Step 2: Train All Models</h4></div>""", unsafe_allow_html=True)

                if st.button("🚀 TRAIN ALL MODELS AUTOMATICALLY", use_container_width=True):
                    with st.spinner("Training in progress... Please wait. This may take a moment."):
                        results, best_name, X_test, y_test = train_models(df_uploaded)
                        st.session_state.results = results
                        st.session_state.best_name = best_name
                        st.session_state.model_trained = True
                        st.session_state.model = load_best_model()

                    st.success(f"✅ Training complete! Best Model: **{best_name}**")
                    st.balloons()

                    # Results table
                    st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">📊 Model Comparison Results</h4></div>""", unsafe_allow_html=True)

                    results_df = pd.DataFrame({
                        'Model': list(results.keys()),
                        'Accuracy': [results[m]['Accuracy'] for m in results],
                        'Precision': [results[m]['Precision'] for m in results],
                        'Recall': [results[m]['Recall'] for m in results],
                        'F1 Score': [results[m]['F1 Score'] for m in results]
                    })

                    def highlight_best(s):
                        is_best = s == s.max()
                        return ['background-color: rgba(0, 255, 136, 0.2)' if v else '' for v in is_best]

                    st.dataframe(
                        results_df.style.format({
                            'Accuracy': '{:.3f}', 'Precision': '{:.3f}',
                            'Recall': '{:.3f}', 'F1 Score': '{:.3f}'
                        }).apply(highlight_best, subset=['Accuracy', 'Precision', 'Recall', 'F1 Score']),
                        use_container_width=True
                    )

                    # Bar chart comparison
                    fig = go.Figure()
                    metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
                    colors = ['#00f0ff', '#00ff88', '#ffd700', '#ff8c00']

                    for i, metric in enumerate(metrics):
                        fig.add_trace(go.Bar(
                            name=metric,
                            x=list(results.keys()),
                            y=[results[m][metric] for m in results],
                            marker_color=colors[i],
                            opacity=0.85
                        ))

                    fig.update_layout(
                        barmode='group',
                        template='plotly_dark',
                        paper_bgcolor='rgba(0,0,0,0)',
                        plot_bgcolor='rgba(0,0,0,0)',
                        font=dict(color='#e6edf3'),
                        legend=dict(orientation='h', yanchor='bottom', y=1.02, xanchor='right', x=1)
                    )
                    st.plotly_chart(fig, use_container_width=True)

                    # Confusion matrices
                    st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">🧮 Confusion Matrices</h4></div>""", unsafe_allow_html=True)

                    cols = st.columns(2)
                    for idx, (name, res) in enumerate(results.items()):
                        with cols[idx % 2]:
                            cm = confusion_matrix(res['y_test'], res['y_pred'])
                            fig_cm = px.imshow(
                                cm, text_auto=True,
                                labels=dict(x="Predicted", y="Actual"),
                                x=['Rejected', 'Approved'],
                                y=['Rejected', 'Approved'],
                                template='plotly_dark',
                                color_continuous_scale=['#0d1117', '#00f0ff']
                            )
                            fig_cm.update_layout(
                                title=dict(text=f"<b>{name}</b>", font=dict(color='#00f0ff', size=14)),
                                paper_bgcolor='rgba(0,0,0,0)',
                                plot_bgcolor='rgba(0,0,0,0)',
                                font=dict(color='#e6edf3'),
                                width=350, height=300
                            )
                            st.plotly_chart(fig_cm, use_container_width=True)

                    # Feature importance (Random Forest)
                    if 'Random Forest' in results:
                        st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">🔥 Feature Importance (Random Forest)</h4></div>""", unsafe_allow_html=True)

                        rf_pipe = results['Random Forest']['pipeline']
                        try:
                            rf_model = rf_pipe.named_steps['classifier']
                            preprocessor = rf_pipe.named_steps['preprocessor']

                            feature_names = (preprocessor.transformers_[0][2] + 
                                list(preprocessor.named_transformers_['cat'].named_steps['onehot'].get_feature_names_out(
                                    ['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area'])))

                            importance_df = pd.DataFrame({
                                'Feature': feature_names,
                                'Importance': rf_model.feature_importances_
                            }).sort_values('Importance', ascending=True)

                            fig_imp = px.bar(
                                importance_df, x='Importance', y='Feature',
                                orientation='h', template='plotly_dark',
                                color='Importance', color_continuous_scale=['#0d1117', '#00ff88']
                            )
                            fig_imp.update_layout(
                                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                                font=dict(color='#e6edf3'), yaxis=dict(tickfont=dict(size=10))
                            )
                            st.plotly_chart(fig_imp, use_container_width=True)
                        except Exception as e:
                            st.warning(f"Could not extract feature importance: {e}")

                    # Download trained model
                    with open(MODEL_PATH, "rb") as f:
                        model_bytes = f.read()
                    st.download_button(
                        "⬇️ Download Trained Model (joblib)",
                        model_bytes,
                        "best_model.joblib",
                        "application/octet-stream",
                        use_container_width=True
                    )
        except Exception as e:
            st.error(f"❌ Error loading CSV: {str(e)}")

    else:
        # Show template/example
        st.info("👆 Upload a CSV file to begin training. Use the example below as a template.")

        st.markdown("""
        <div class="metric-card">
            <h4 style="color: #00f0ff;">📋 CSV Template Format</h4>
            <div class="terminal-box" style="margin-top: 10px;">
Name,Gender,Married,Education,Self_Employed,ApplicantIncome,CoapplicantIncome,LoanAmount,Loan_Amount_Term,Credit_History,Property_Area,Loan_Status<br>
Rajesh Kumar,Male,Yes,Graduate,No,8000,3000,150,360,1.0,Urban,Y<br>
Priya Patel,Female,No,Graduate,Yes,3500,0,180,240,1.0,Semiurban,N<br>
Suresh Yadav,Male,No,Not Graduate,No,2000,0,250,120,0.0,Rural,N<br>
Anjali Gupta,Female,Yes,Graduate,No,12000,5000,300,360,1.0,Urban,Y<br>
Vikram Singh,Male,Yes,Graduate,Yes,15000,8000,500,480,1.0,Urban,Y
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("""
        <div class="metric-card">
            <h4 style="color: #00f0ff;">🧠 Pipeline Architecture</h4>
            <div class="terminal-box" style="margin-top: 10px;">
                <span style="color: #00f0ff;">[1]</span> Upload CSV → Auto-validate columns<br>
                <span style="color: #00f0ff;">[2]</span> Preprocessing → Imputer + Encoder + Scaler<br>
                <span style="color: #00f0ff;">[3]</span> Model Training → LR | DT | RF | SVM<br>
                <span style="color: #00f0ff;">[4]</span> Evaluation → Accuracy | Precision | Recall | F1<br>
                <span style="color: #00f0ff;">[5]</span> Auto-Select → Best F1 Score model saved as joblib
            </div>
        </div>
        """, unsafe_allow_html=True)

# ============================================================
# PAGE: PREDICTIONS
# ============================================================
elif page == "🔮 Predictions":
    st.markdown("""
    <div style="text-align: center; margin-bottom: 20px;">
        <h2>🔮 PREDICTION ENGINE</h2>
        <p style="color: #8b949e;">Real-time loan approval prediction with AI explanations</p>
    </div>
    """, unsafe_allow_html=True)

    model = st.session_state.model if st.session_state.model_trained else load_best_model()

    if model is None:
        st.warning("⚠️ No trained model found. Please go to **🤖 Model Training**, upload a CSV, and train the models first.")
    else:
        tab1, tab2 = st.tabs(["📝 Manual Entry", "📁 Batch Upload"])

        with tab1:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Applicant Information</h4></div>""", unsafe_allow_html=True)

            def normalize_gender(val):
                v = str(val).strip().lower()
                if v in ['male', 'm', 'boy', 'man', '1']:
                    return 'Male'
                elif v in ['female', 'f', 'girl', 'woman', '0', '2']:
                    return 'Female'
                return 'Male'

            def normalize_yesno(val):
                v = str(val).strip().lower()
                if v in ['yes', 'y', 'true', '1', 'married', 'employed']:
                    return 'Yes'
                elif v in ['no', 'n', 'false', '0', 'single', 'unemployed']:
                    return 'No'
                return 'No'

            def normalize_education(val):
                v = str(val).strip().lower()
                if v in ['graduate', 'grad', 'g', 'postgraduate', 'pg', 'master', 'phd', 'degree']:
                    return 'Graduate'
                elif v in ['not graduate', 'not grad', 'undergraduate', 'ug', 'bachelor', 'dropout', '12th', 'school']:
                    return 'Not Graduate'
                return 'Graduate'

            def normalize_area(val):
                v = str(val).strip().lower().replace(' ', '').replace('-', '')
                if v in ['urban', 'u', 'city', 'metro', 'town']:
                    return 'Urban'
                elif v in ['semiurban', 'semi', 'suburban', 's']:
                    return 'Semiurban'
                elif v in ['rural', 'r', 'village', 'countryside']:
                    return 'Rural'
                return 'Urban'

            def normalize_credit(val):
                v = str(val).strip().lower()
                if v in ['1', '1.0', 'good', 'yes', 'y', 'true', 'positive', 'clear']:
                    return 1.0
                elif v in ['0', '0.0', 'bad', 'no', 'n', 'false', 'negative', 'default']:
                    return 0.0
                return 1.0

            def normalize_term(val):
                v = str(val).strip()
                valid = [120, 180, 240, 300, 360, 480]
                try:
                    num = int(v)
                    return min(valid, key=lambda x: abs(x - num))
                except:
                    return 360

            applicant_name = st.text_input("👤 Applicant Full Name", value="Rahul Sharma", placeholder="Enter applicant full name", help="Enter the applicant's full name as per records")

            col1, col2, col3 = st.columns(3)

            with col1:
                gender_raw = st.text_input("Gender", value="Male", placeholder="Type: Male or Female", help="Enter Male or Female")
                married_raw = st.text_input("Marital Status", value="Yes", placeholder="Type: Yes or No", help="Enter Yes or No")
                education_raw = st.text_input("Education", value="Graduate", placeholder="Type: Graduate or Not Graduate", help="Enter Graduate or Not Graduate")

            with col2:
                self_employed_raw = st.text_input("Self Employed", value="No", placeholder="Type: Yes or No", help="Enter Yes or No")
                property_area_raw = st.text_input("Property Area", value="Urban", placeholder="Type: Urban / Semiurban / Rural", help="Enter Urban, Semiurban, or Rural")
                credit_history_raw = st.text_input("Credit History", value="1.0", placeholder="Type: 1.0 (Good) or 0.0 (Bad)", help="Enter 1.0 for Good or 0.0 for Bad")

            with col3:
                applicant_income = st.number_input("Applicant Income (₹)", min_value=0, max_value=50000, value=4000, step=100)
                coapplicant_income = st.number_input("Coapplicant Income (₹)", min_value=0, max_value=30000, value=1500, step=100)
                loan_amount = st.number_input("Loan Amount (₹k)", min_value=1, max_value=700, value=120, step=5)
                loan_term_raw = st.text_input("Loan Term (months)", value="360", placeholder="Type: 120 / 180 / 240 / 300 / 360 / 480", help="Enter loan term in months")

            gender = normalize_gender(gender_raw)
            married = normalize_yesno(married_raw)
            education = normalize_education(education_raw)
            self_employed = normalize_yesno(self_employed_raw)
            property_area = normalize_area(property_area_raw)
            credit_history = normalize_credit(credit_history_raw)
            loan_term = normalize_term(loan_term_raw)

            with st.expander("🔍 Verify Normalized Inputs (Banking Safety Check)"):
                verify_cols = st.columns(3)
                with verify_cols[0]:
                    st.markdown(f"**Name:** `{applicant_name}`")
                    st.markdown(f"**Gender:** `{gender}`")
                    st.markdown(f"**Married:** `{married}`")
                with verify_cols[1]:
                    st.markdown(f"**Education:** `{education}`")
                    st.markdown(f"**Self Employed:** `{self_employed}`")
                    st.markdown(f"**Property Area:** `{property_area}`")
                with verify_cols[2]:
                    st.markdown(f"**Credit History:** `{credit_history}`")
                    st.markdown(f"**Income:** `₹{applicant_income:,}`")
                    st.markdown(f"**Co-Income:** `₹{coapplicant_income:,}`")
                    st.markdown(f"**Loan:** `₹{loan_amount}k` | **Term:** `{loan_term}mo`")

            if st.button("🔮 PREDICT LOAN STATUS", use_container_width=True):
                input_data = pd.DataFrame({
                    'Gender': [gender],
                    'Married': [married],
                    'Education': [education],
                    'Self_Employed': [self_employed],
                    'ApplicantIncome': [applicant_income],
                    'CoapplicantIncome': [coapplicant_income],
                    'LoanAmount': [loan_amount],
                    'Loan_Amount_Term': [loan_term],
                    'Credit_History': [credit_history],
                    'Property_Area': [property_area]
                })

                prediction = model.predict(input_data)[0]
                probability = model.predict_proba(input_data)[0][1]

                risk_label, risk_color = risk_classification(probability)
                h_score = health_score(input_data.iloc[0].to_dict())

                st.markdown("<br>", unsafe_allow_html=True)

                st.markdown(f"""
                <div style="text-align: center; margin-bottom: 20px;">
                    <h3 style="color: #00f0ff; margin: 0;">👤 {applicant_name}</h3>
                    <p style="color: #8b949e; font-size: 0.9rem;">Applicant Profile Analysis</p>
                </div>
                """, unsafe_allow_html=True)

                if prediction == 1:
                    st.markdown(f"""
                    <div class="prediction-approved">
                        <h2 style="color: #00ff88; margin: 0;">✅ LOAN APPROVED</h2>
                        <p style="font-size: 1.2rem; color: #e6edf3; margin: 10px 0;">
                            Confidence: <span style="color: #00ff88; font-weight: bold;">{probability*100:.1f}%</span>
                        </p>
                        <p style="font-size: 1rem; color: #8b949e;">
                            Risk Class: <span style="color: {risk_color}; font-weight: bold;">{risk_label}</span> | 
                            Health Score: <span style="color: #00f0ff; font-weight: bold;">{h_score}/100</span>
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="prediction-rejected">
                        <h2 style="color: #ff0050; margin: 0;">❌ LOAN REJECTED</h2>
                        <p style="font-size: 1.2rem; color: #e6edf3; margin: 10px 0;">
                            Confidence: <span style="color: #ff0050; font-weight: bold;">{(1-probability)*100:.1f}%</span>
                        </p>
                        <p style="font-size: 1rem; color: #8b949e;">
                            Risk Class: <span style="color: {risk_color}; font-weight: bold;">{risk_label}</span> | 
                            Health Score: <span style="color: #00f0ff; font-weight: bold;">{h_score}/100</span>
                        </p>
                    </div>
                    """, unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)

                st.markdown("""
                <div class="metric-card">
                    <h4 style="color: #00f0ff;">🧠 AI Explanation</h4>
                </div>
                """, unsafe_allow_html=True)

                explanation = generate_explanation({**input_data.iloc[0].to_dict(), 'Name': applicant_name}, prediction, probability if prediction==1 else 1-probability)
                st.markdown(f"""
                <div class="terminal-box">
                    {explanation}
                </div>
                """, unsafe_allow_html=True)

        with tab2:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Batch Prediction (CSV Upload)</h4></div>""", unsafe_allow_html=True)

            st.markdown("""
            <div class="terminal-box" style="margin-bottom: 15px;">
                <b>Required CSV Columns:</b><br>
                Name, Gender, Married, Education, Self_Employed, ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term, Credit_History, Property_Area<br><br>
                <b>Note:</b> Name column is required for batch processing.
            </div>
            """, unsafe_allow_html=True)

            uploaded_file = st.file_uploader("Upload CSV with applicant data", type=['csv'], key="batch_predict")

            if uploaded_file is not None:
                batch_df = pd.read_csv(uploaded_file)

                required_cols = ['Name', 'Gender', 'Married', 'Education', 'Self_Employed',
                                'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
                                'Loan_Amount_Term', 'Credit_History', 'Property_Area']

                missing = [c for c in required_cols if c not in batch_df.columns]

                if missing:
                    st.error(f"❌ Missing columns: {', '.join(missing)}")
                else:
                    with st.spinner("Processing batch predictions..."):
                        batch_df['Prediction'] = model.predict(batch_df[required_cols[1:]])
                        proba = model.predict_proba(batch_df[required_cols[1:]])
                        batch_df['Approval_Probability'] = proba[:, 1]
                        batch_df['Prediction_Label'] = batch_df['Prediction'].map({1: 'Approved', 0: 'Rejected'})
                        batch_df['Risk_Class'] = batch_df['Approval_Probability'].apply(
                            lambda p: risk_classification(p)[0]
                        )

                    st.success(f"✅ Processed {len(batch_df)} records")

                    st.dataframe(batch_df[['Name', 'Gender', 'Married', 'ApplicantIncome', 'LoanAmount',
                                          'Credit_History', 'Prediction_Label', 'Approval_Probability', 'Risk_Class']],
                                use_container_width=True)

                    st.markdown(get_download_link(batch_df, "batch_predictions.csv"), unsafe_allow_html=True)

                    pred_counts = batch_df['Prediction_Label'].value_counts().reset_index()
                    pred_counts.columns = ['Status', 'Count']

                    fig = px.bar(
                        pred_counts, x='Status', y='Count', color='Status',
                        color_discrete_map={'Approved': '#00ff88', 'Rejected': '#ff0050'},
                        template='plotly_dark'
                    )
                    fig.update_layout(
                        paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                        font=dict(color='#e6edf3'), title="Batch Prediction Summary"
                    )
                    st.plotly_chart(fig, use_container_width=True)

# ============================================================
# PAGE: ANALYTICS
# ============================================================
elif page == "📈 Analytics":
    st.markdown("""
    <div style="text-align: center; margin-bottom: 20px;">
        <h2>📈 ADVANCED ANALYTICS</h2>
        <p style="color: #8b949e;">Deep-dive visualizations and insights</p>
    </div>
    """, unsafe_allow_html=True)

    if st.session_state.df is not None:
        df = st.session_state.df
        tab1, tab2, tab3 = st.tabs(["💵 Income Analysis", "🏠 Property Analysis", "📊 Approval Factors"])

        with tab1:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Income Distribution by Approval Status</h4></div>""", unsafe_allow_html=True)

            fig = px.box(
                df, x='Loan_Status', y='ApplicantIncome',
                color='Loan_Status',
                color_discrete_map={'Y': '#00ff88', 'N': '#ff0050'},
                template='plotly_dark',
                labels={'Loan_Status': 'Loan Status', 'ApplicantIncome': 'Applicant Income (₹)'}
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3')
            )
            st.plotly_chart(fig, use_container_width=True)

            df['TotalIncome'] = df['ApplicantIncome'] + df['CoapplicantIncome']
            fig2 = px.histogram(
                df, x='TotalIncome', color='Loan_Status',
                color_discrete_map={'Y': '#00ff88', 'N': '#ff0050'},
                template='plotly_dark', nbins=40, opacity=0.7,
                labels={'TotalIncome': 'Total Household Income (₹)'}
            )
            fig2.update_layout(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3'), barmode='overlay'
            )
            st.plotly_chart(fig2, use_container_width=True)

        with tab2:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Approval Rate by Property Area</h4></div>""", unsafe_allow_html=True)

            area_stats = df.groupby('Property_Area')['Loan_Status'].apply(
                lambda x: (x == 'Y').mean() * 100
            ).reset_index()
            area_stats.columns = ['Property_Area', 'Approval_Rate']

            fig = px.bar(
                area_stats, x='Property_Area', y='Approval_Rate',
                template='plotly_dark', color='Approval_Rate',
                color_continuous_scale=['#ff0050', '#00ff88'],
                labels={'Approval_Rate': 'Approval Rate (%)', 'Property_Area': 'Property Area'}
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3')
            )
            st.plotly_chart(fig, use_container_width=True)

            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Loan Amount vs Term by Area</h4></div>""", unsafe_allow_html=True)

            fig2 = px.scatter(
                df, x='LoanAmount', y='Loan_Amount_Term',
                color='Property_Area', size='ApplicantIncome',
                template='plotly_dark', opacity=0.7,
                labels={'LoanAmount': 'Loan Amount (₹k)', 'Loan_Amount_Term': 'Term (months)'}
            )
            fig2.update_layout(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3')
            )
            st.plotly_chart(fig2, use_container_width=True)

        with tab3:
            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Approval Rate by Credit History</h4></div>""", unsafe_allow_html=True)

            credit_stats = df.groupby('Credit_History')['Loan_Status'].apply(
                lambda x: (x == 'Y').mean() * 100
            ).reset_index()
            credit_stats.columns = ['Credit_History', 'Approval_Rate']
            credit_stats['Credit_History'] = credit_stats['Credit_History'].map({1.0: 'Good', 0.0: 'Bad'})

            fig = px.bar(
                credit_stats, x='Credit_History', y='Approval_Rate',
                template='plotly_dark', color='Approval_Rate',
                color_continuous_scale=['#ff0050', '#00ff88'],
                labels={'Approval_Rate': 'Approval Rate (%)', 'Credit_History': 'Credit History'}
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3')
            )
            st.plotly_chart(fig, use_container_width=True)

            st.markdown("""<div class="metric-card"><h4 style="color: #00f0ff;">Approval Rate by Education & Gender</h4></div>""", unsafe_allow_html=True)

            edu_gender = df.groupby(['Education', 'Gender'])['Loan_Status'].apply(
                lambda x: (x == 'Y').mean() * 100
            ).reset_index()
            edu_gender.columns = ['Education', 'Gender', 'Approval_Rate']

            fig2 = px.bar(
                edu_gender, x='Education', y='Approval_Rate', color='Gender',
                barmode='group', template='plotly_dark',
                color_discrete_map={'Male': '#00f0ff', 'Female': '#ff69b4'},
                labels={'Approval_Rate': 'Approval Rate (%)'}
            )
            fig2.update_layout(
                paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                font=dict(color='#e6edf3')
            )
            st.plotly_chart(fig2, use_container_width=True)
    else:
        st.warning("⚠️ No dataset loaded. Please upload a CSV in **🤖 Model Training** first.")

# ============================================================
# FOOTER
# ============================================================
st.markdown("""
<div class="footer">
    <div style="height: 1px; background: linear-gradient(90deg, transparent, #00f0ff, transparent); margin-bottom: 15px;"></div>
    <p style="font-size: 0.9rem;">
        <span style="color: #00f0ff;">Loan-Approval-Prediction-System</span> | 
        Developed by <a href="https://github.com/issu321" target="_blank" style="color: #00ff88; text-decoration: none; font-weight: bold;">issu321</a>
    </p>
    <p style="font-size: 0.75rem; color: #484f58;">
        Powered by Python · scikit-learn · Streamlit · Plotly
    </p>
</div>
""", unsafe_allow_html=True)
