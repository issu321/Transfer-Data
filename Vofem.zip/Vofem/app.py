"""
VOXFEM (C2G) - Main Flask Application
Women and Youth Empowerment Platform
"""

import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect

# Import configuration
from config import config

# Import database and models
from models import db, User, Event, Workshop, Feedback, Questionnaire, Question
from models import QuestionResponse, ContactMessage, PaymentOrder, NewsletterSubscriber
from models import EventRegistration, WorkshopEnrollment, ChatMessage

# Import forms
from forms import (
    LoginForm, RegistrationForm, ProfileForm, EventForm, WorkshopForm,
    FeedbackForm, QuestionnaireForm, QuestionForm, ContactForm,
    NewsletterForm, ChatForm, PaymentForm, AdminUserEditForm
)

# Import utilities
from utils import (
    admin_required, save_uploaded_file, get_file_url, truncate_text,
    format_price, format_datetime, format_date, get_star_rating,
    paginate, get_dashboard_stats, get_public_stats, seed_database
)

# Import AI Assistant
from ai_assistant import get_career_assistant

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create Flask app
def create_app(config_name='default'):
    """Application factory pattern."""
    app = Flask(__name__, 
                static_folder='static',
                template_folder='templates')
    
    # Load configuration
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    db.init_app(app)
    
    # CSRF Protection
    csrf = CSRFProtect(app)
    
    # Login Manager
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'warning'
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Create database tables
    with app.app_context():
        db.create_all()
        # Seed database if empty
        seed_database()
    
    # ============================================================
    # CONTEXT PROCESSORS
    # ============================================================
    
    @app.context_processor
    def inject_globals():
        """Inject global variables into all templates."""
        return {
            'APP_NAME': app.config.get('APP_NAME', 'VOXFEM (C2G)'),
            'APP_TAGLINE': app.config.get('APP_TAGLINE', ''),
            'current_year': datetime.now().year,
            'current_user': current_user,
            'format_price': format_price,
            'format_datetime': format_datetime,
            'format_date': format_date,
            'truncate_text': truncate_text,
            'get_star_rating': get_star_rating,
        }
    
    # ============================================================
    # ERROR HANDLERS
    # ============================================================
    
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('404.html'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('500.html'), 500
    
    @app.errorhandler(403)
    def forbidden_error(error):
        flash('You do not have permission to access this resource.', 'danger')
        return redirect(url_for('dashboard'))
    
    # ============================================================
    # AUTHENTICATION ROUTES
    # ============================================================
    
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        """User registration page."""
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        
        form = RegistrationForm()
        if form.validate_on_submit():
            try:
                user = User(
                    full_name=form.full_name.data,
                    email=form.email.data.lower().strip(),
                    phone=form.phone.data,
                    interests=form.interests.data
                )
                user.set_password(form.password.data)
                db.session.add(user)
                db.session.commit()
                
                # Log user in
                login_user(user, remember=True)
                flash('Welcome to VOXFEM! Your account has been created successfully.', 'success')
                return redirect(url_for('dashboard'))
            except Exception as e:
                db.session.rollback()
                logger.error(f'Registration error: {e}')
                flash('An error occurred. Please try again.', 'danger')
        
        return render_template('register.html', form=form)
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """User login page."""
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        
        form = LoginForm()
        if form.validate_on_submit():
            try:
                user = User.query.filter_by(email=form.email.data.lower().strip()).first()
                if user and user.check_password(form.password.data):
                    login_user(user, remember=form.remember.data)
                    next_page = request.args.get('next')
                    flash(f'Welcome back, {user.full_name}!', 'success')
                    return redirect(next_page) if next_page else redirect(url_for('dashboard'))
                else:
                    flash('Invalid email or password. Please try again.', 'danger')
            except Exception as e:
                logger.error(f'Login error: {e}')
                flash('An error occurred. Please try again.', 'danger')
        
        return render_template('login.html', form=form)
    
    @app.route('/logout')
    @login_required
    def logout():
        """User logout."""
        logout_user()
        flash('You have been logged out successfully.', 'info')
        return redirect(url_for('home'))
    
    # ============================================================
    # MAIN PUBLIC ROUTES
    # ============================================================
    
    @app.route('/')
    def home():
        """Landing page."""
        stats = get_public_stats()
        upcoming_events = Event.query.filter_by(is_active=True).order_by(Event.date).limit(3).all()
        workshops = Workshop.query.filter_by(is_active=True).order_by(Workshop.created_at.desc()).limit(3).all()
        testimonials = get_testimonials()
        return render_template('home.html', 
                             stats=stats, 
                             upcoming_events=upcoming_events,
                             workshops=workshops,
                             testimonials=testimonials)
    
    @app.route('/about')
    def about():
        """About page."""
        return render_template('about.html')
    
    @app.route('/founders')
    def founders():
        """Founders page."""
        return render_template('founders.html')
    
    @app.route('/contact', methods=['GET', 'POST'])
    def contact():
        """Contact page with form."""
        form = ContactForm()
        if form.validate_on_submit():
            try:
                message = ContactMessage(
                    name=form.name.data,
                    email=form.email.data,
                    phone=form.phone.data,
                    subject=form.subject.data,
                    message=form.message.data
                )
                db.session.add(message)
                db.session.commit()
                flash('Thank you for your message! We will get back to you soon.', 'success')
                return redirect(url_for('contact'))
            except Exception as e:
                db.session.rollback()
                logger.error(f'Contact form error: {e}')
                flash('An error occurred. Please try again.', 'danger')
        
        return render_template('contact.html', form=form)
    
    @app.route('/newsletter/subscribe', methods=['POST'])
    def newsletter_subscribe():
        """Newsletter subscription endpoint."""
        form = NewsletterForm()
        if form.validate_on_submit():
            try:
                # Check if already subscribed
                existing = NewsletterSubscriber.query.filter_by(email=form.email.data.lower().strip()).first()
                if existing:
                    flash('You are already subscribed to our newsletter!', 'info')
                else:
                    subscriber = NewsletterSubscriber(email=form.email.data.lower().strip())
                    db.session.add(subscriber)
                    db.session.commit()
                    flash('Thank you for subscribing to our newsletter!', 'success')
            except Exception as e:
                db.session.rollback()
                logger.error(f'Newsletter error: {e}')
                flash('An error occurred. Please try again.', 'danger')
        else:
            flash('Please enter a valid email address.', 'warning')
        return redirect(request.referrer or url_for('home'))
    
    # ============================================================
    # USER DASHBOARD ROUTES
    # ============================================================
    
    @app.route('/dashboard')
    @login_required
    def dashboard():
        """User dashboard."""
        # Get user's registrations and enrollments
        event_regs = EventRegistration.query.filter_by(user_id=current_user.id).order_by(EventRegistration.registered_at.desc()).limit(5).all()
        workshop_enrolls = WorkshopEnrollment.query.filter_by(user_id=current_user.id).order_by(WorkshopEnrollment.enrolled_at.desc()).limit(5).all()
        
        # Get upcoming events and workshops
        upcoming_events = Event.query.filter_by(is_active=True).order_by(Event.date).limit(3).all()
        upcoming_workshops = Workshop.query.filter_by(is_active=True).order_by(Workshop.schedule).limit(3).all()
        
        # Get user stats
        total_events = EventRegistration.query.filter_by(user_id=current_user.id).count()
        total_workshops = WorkshopEnrollment.query.filter_by(user_id=current_user.id).count()
        
        return render_template('dashboard.html',
                             event_regs=event_regs,
                             workshop_enrolls=workshop_enrolls,
                             upcoming_events=upcoming_events,
                             upcoming_workshops=upcoming_workshops,
                             total_events=total_events,
                             total_workshops=total_workshops)
    
    @app.route('/profile', methods=['GET', 'POST'])
    @login_required
    def profile():
        """User profile page."""
        form = ProfileForm(obj=current_user)
        if form.validate_on_submit():
            try:
                current_user.full_name = form.full_name.data
                current_user.email = form.email.data.lower().strip()
                current_user.phone = form.phone.data
                current_user.bio = form.bio.data
                current_user.interests = form.interests.data
                current_user.updated_at = datetime.utcnow()
                db.session.commit()
                flash('Profile updated successfully!', 'success')
                return redirect(url_for('profile'))
            except Exception as e:
                db.session.rollback()
                logger.error(f'Profile update error: {e}')
                flash('An error occurred. Please try again.', 'danger')
        
        return render_template('profile.html', form=form)
    
    @app.route('/profile/upload-image', methods=['POST'])
    @login_required
    def upload_profile_image():
        """Upload profile image."""
        if 'profile_image' not in request.files:
            flash('No file selected.', 'warning')
            return redirect(url_for('profile'))
        
        file = request.files['profile_image']
        if file.filename == '':
            flash('No file selected.', 'warning')
            return redirect(url_for('profile'))
        
        filepath = save_uploaded_file(file, folder='profiles')
        if filepath:
            # Delete old image if exists
            if current_user.profile_image:
                old_path = os.path.join(app.config['UPLOAD_FOLDER'], '..', current_user.profile_image)
                if os.path.exists(old_path):
                    os.remove(old_path)
            
            current_user.profile_image = filepath
            db.session.commit()
            flash('Profile image updated!', 'success')
        else:
            flash('Invalid file type. Please upload an image.', 'danger')
        
        return redirect(url_for('profile'))
    
    # ============================================================
    # EVENTS ROUTES
    # ============================================================
    
    @app.route('/events')
    def events():
        """Events listing page."""
        page = request.args.get('page', 1, type=int)
        events_query = Event.query.filter_by(is_active=True).order_by(Event.date)
        pagination = paginate(events_query, page=page, per_page=9)
        return render_template('events.html', pagination=pagination)
    
    @app.route('/events/<int:event_id>')
    def event_detail(event_id):
        """Event detail page."""
        event = Event.query.get_or_404(event_id)
        is_registered = False
        if current_user.is_authenticated:
            is_registered = EventRegistration.query.filter_by(
                user_id=current_user.id, event_id=event_id
            ).first() is not None
        return render_template('event_detail.html', event=event, is_registered=is_registered)
    
    @app.route('/events/<int:event_id>/register', methods=['POST'])
    @login_required
    def register_event(event_id):
        """Register for an event."""
        event = Event.query.get_or_404(event_id)
        
        # Check if already registered
        existing = EventRegistration.query.filter_by(
            user_id=current_user.id, event_id=event_id
        ).first()
        
        if existing:
            flash('You are already registered for this event!', 'info')
            return redirect(url_for('event_detail', event_id=event_id))
        
        # Check if event is full
        if event.is_full:
            flash('Sorry, this event is fully booked.', 'warning')
            return redirect(url_for('event_detail', event_id=event_id))
        
        try:
            registration = EventRegistration(user_id=current_user.id, event_id=event_id)
            db.session.add(registration)
            db.session.commit()
            flash(f'Successfully registered for "{event.title}"!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Event registration error: {e}')
            flash('An error occurred. Please try again.', 'danger')
        
        return redirect(url_for('event_detail', event_id=event_id))
    
    # ============================================================
    # WORKSHOPS ROUTES
    # ============================================================
    
    @app.route('/workshops')
    def workshops():
        """Workshops listing page."""
        page = request.args.get('page', 1, type=int)
        category = request.args.get('category', '', type=str)
        
        query = Workshop.query.filter_by(is_active=True)
        if category:
            query = query.filter_by(category=category)
        
        query = query.order_by(Workshop.schedule)
        pagination = paginate(query, page=page, per_page=9)
        
        # Get unique categories for filter
        categories = db.session.query(Workshop.category).distinct().all()
        categories = [c[0] for c in categories if c[0]]
        
        return render_template('workshops.html', 
                             pagination=pagination, 
                             categories=categories,
                             current_category=category)
    
    @app.route('/workshops/<int:workshop_id>')
    def workshop_detail(workshop_id):
        """Workshop detail page."""
        workshop = Workshop.query.get_or_404(workshop_id)
        is_enrolled = False
        if current_user.is_authenticated:
            is_enrolled = WorkshopEnrollment.query.filter_by(
                user_id=current_user.id, workshop_id=workshop_id
            ).first() is not None
        return render_template('workshop_detail.html', 
                             workshop=workshop, 
                             is_enrolled=is_enrolled)
    
    @app.route('/workshops/<int:workshop_id>/enroll', methods=['POST'])
    @login_required
    def enroll_workshop(workshop_id):
        """Enroll in a workshop."""
        workshop = Workshop.query.get_or_404(workshop_id)
        
        # Check if already enrolled
        existing = WorkshopEnrollment.query.filter_by(
            user_id=current_user.id, workshop_id=workshop_id
        ).first()
        
        if existing:
            flash('You are already enrolled in this workshop!', 'info')
            return redirect(url_for('workshop_detail', workshop_id=workshop_id))
        
        # Check if workshop is full
        if workshop.available_seats <= 0:
            flash('Sorry, this workshop is fully booked.', 'warning')
            return redirect(url_for('workshop_detail', workshop_id=workshop_id))
        
        try:
            # If paid workshop, redirect to payment
            if not workshop.is_free:
                return redirect(url_for('payment_workshop', workshop_id=workshop_id))
            
            # Free workshop - enroll directly
            enrollment = WorkshopEnrollment(
                user_id=current_user.id, 
                workshop_id=workshop_id,
                payment_status='paid'
            )
            db.session.add(enrollment)
            db.session.commit()
            flash(f'Successfully enrolled in "{workshop.title}"!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Workshop enrollment error: {e}')
            flash('An error occurred. Please try again.', 'danger')
        
        return redirect(url_for('workshop_detail', workshop_id=workshop_id))
    
    # ============================================================
    # PAYMENT ROUTES
    # ============================================================
    
    @app.route('/payments')
    @login_required
    def payments():
        """Payment history page."""
        payment_orders = PaymentOrder.query.filter_by(user_id=current_user.id).order_by(PaymentOrder.created_at.desc()).all()
        return render_template('payments.html', payments=payment_orders)
    
    @app.route('/payments/workshop/<int:workshop_id>')
    @login_required
    def payment_workshop(workshop_id):
        """Payment page for workshop enrollment."""
        workshop = Workshop.query.get_or_404(workshop_id)
        
        # Check if already enrolled
        existing = WorkshopEnrollment.query.filter_by(
            user_id=current_user.id, workshop_id=workshop_id
        ).first()
        
        if existing:
            flash('You are already enrolled in this workshop!', 'info')
            return redirect(url_for('workshop_detail', workshop_id=workshop_id))
        
        # Check if workshop is full
        if workshop.available_seats <= 0:
            flash('Sorry, this workshop is fully booked.', 'warning')
            return redirect(url_for('workshop_detail', workshop_id=workshop_id))
        
        # Create payment order (placeholder for Razorpay integration)
        try:
            order = PaymentOrder(
                user_id=current_user.id,
                workshop_id=workshop_id,
                amount=workshop.price,
                currency='INR',
                status='created'
            )
            db.session.add(order)
            db.session.commit()
            
            return render_template('payment_workshop.html', 
                                 workshop=workshop, 
                                 order=order,
                                 razorpay_key=app.config.get('RAZORPAY_KEY_ID', ''))
        except Exception as e:
            db.session.rollback()
            logger.error(f'Payment creation error: {e}')
            flash('An error occurred. Please try again.', 'danger')
            return redirect(url_for('workshop_detail', workshop_id=workshop_id))
    
    @app.route('/payments/verify', methods=['POST'])
    @login_required
    def verify_payment():
        """Verify payment and complete enrollment (placeholder for Razorpay)."""
        data = request.get_json() or {}
        order_id = data.get('order_id')
        
        try:
            order = PaymentOrder.query.get_or_404(order_id)
            
            # Verify payment (placeholder - implement Razorpay verification here)
            # In production, verify signature using Razorpay SDK
            order.status = 'paid'
            order.razorpay_payment_id = data.get('razorpay_payment_id', 'placeholder')
            order.razorpay_signature = data.get('razorpay_signature', 'placeholder')
            db.session.commit()
            
            # Create workshop enrollment
            enrollment = WorkshopEnrollment(
                user_id=current_user.id,
                workshop_id=order.workshop_id,
                payment_status='paid'
            )
            db.session.add(enrollment)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Payment successful! You are now enrolled.'})
        except Exception as e:
            db.session.rollback()
            logger.error(f'Payment verification error: {e}')
            return jsonify({'success': False, 'message': 'Payment verification failed.'}), 400
    
    # ============================================================
    # FEEDBACK ROUTES
    # ============================================================
    
    @app.route('/feedback', methods=['GET', 'POST'])
    def feedback():
        """Feedback form page."""
        form = FeedbackForm()
        if form.validate_on_submit():
            try:
                feedback_entry = Feedback(
                    user_id=current_user.id if current_user.is_authenticated else None,
                    name=form.name.data,
                    email=form.email.data,
                    rating=int(form.rating.data),
                    category=form.category.data,
                    comments=form.comments.data,
                    suggestions=form.suggestions.data
                )
                db.session.add(feedback_entry)
                db.session.commit()
                flash('Thank you for your feedback! We appreciate your input.', 'success')
                return redirect(url_for('feedback'))
            except Exception as e:
                db.session.rollback()
                logger.error(f'Feedback submission error: {e}')
                flash('An error occurred. Please try again.', 'danger')
        
        return render_template('feedback.html', form=form)
    
    # ============================================================
    # QUESTIONNAIRE ROUTES
    # ============================================================
    
    @app.route('/questionnaire')
    @login_required
    def questionnaire():
        """Active questionnaire page."""
        active_q = Questionnaire.query.filter_by(is_active=True).first()
        if not active_q:
            flash('No active questionnaire available at the moment.', 'info')
            return redirect(url_for('dashboard'))
        
        questions = Question.query.filter_by(questionnaire_id=active_q.id).order_by(Question.order).all()
        
        # Check if user already submitted
        already_submitted = QuestionResponse.query.filter_by(
            user_id=current_user.id
        ).join(Question).filter(Question.questionnaire_id == active_q.id).first() is not None
        
        return render_template('questionnaire.html', 
                             questionnaire=active_q, 
                             questions=questions,
                             already_submitted=already_submitted)
    
    @app.route('/questionnaire/submit', methods=['POST'])
    @login_required
    def submit_questionnaire():
        """Submit questionnaire responses."""
        try:
            questionnaire_id = request.form.get('questionnaire_id', type=int)
            if not questionnaire_id:
                flash('Invalid questionnaire.', 'danger')
                return redirect(url_for('questionnaire'))
            
            questions = Question.query.filter_by(questionnaire_id=questionnaire_id).all()
            
            for question in questions:
                response_text = request.form.get(f'question_{question.id}', '').strip()
                if response_text:
                    response = QuestionResponse(
                        user_id=current_user.id,
                        question_id=question.id,
                        response=response_text
                    )
                    db.session.add(response)
            
            db.session.commit()
            flash('Thank you for completing the questionnaire!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Questionnaire submission error: {e}')
            flash('An error occurred. Please try again.', 'danger')
        
        return redirect(url_for('dashboard'))
    
    # ============================================================
    # AI CHATBOT ROUTES
    # ============================================================
    
    @app.route('/chatbot')
    @login_required
    def chatbot():
        """AI Career Assistant chat interface."""
        # Get chat history
        chat_history = ChatMessage.query.filter_by(user_id=current_user.id).order_by(ChatMessage.created_at).limit(50).all()
        
        # If no history, add greeting
        if not chat_history:
            ai = get_career_assistant()
            greeting = ChatMessage(
                user_id=current_user.id,
                role='ai',
                content=ai.get_greeting()
            )
            db.session.add(greeting)
            db.session.commit()
            chat_history = [greeting]
        
        suggested_prompts = get_career_assistant().get_suggested_prompts()
        return render_template('chatbot.html', 
                             chat_history=chat_history,
                             suggested_prompts=suggested_prompts)
    
    @app.route('/chatbot/ask', methods=['POST'])
    @login_required
    def chatbot_ask():
        """Handle AI chat message."""
        data = request.get_json() or {}
        message = data.get('message', '').strip()
        
        if not message:
            return jsonify({'success': False, 'message': 'Please enter a message.'}), 400
        
        try:
            # Save user message
            user_msg = ChatMessage(
                user_id=current_user.id,
                role='user',
                content=message
            )
            db.session.add(user_msg)
            db.session.commit()
            
            # Get AI response
            ai = get_career_assistant()
            response = ai.get_response(message)
            
            # Save AI response
            ai_msg = ChatMessage(
                user_id=current_user.id,
                role='ai',
                content=response
            )
            db.session.add(ai_msg)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'response': response,
                'timestamp': ai_msg.created_at.isoformat()
            })
        except Exception as e:
            db.session.rollback()
            logger.error(f'Chatbot error: {e}')
            return jsonify({'success': False, 'message': 'An error occurred. Please try again.'}), 500
    
    # ============================================================
    # ADMIN ROUTES
    # ============================================================
    
    @app.route('/admin')
    @admin_required
    def admin_dashboard():
        """Admin dashboard."""
        stats = get_dashboard_stats()
        return render_template('admin/dashboard.html', stats=stats)
    
    @app.route('/admin/users')
    @admin_required
    def admin_users():
        """User management."""
        page = request.args.get('page', 1, type=int)
        search = request.args.get('search', '', type=str)
        
        query = User.query
        if search:
            query = query.filter(
                db.or_(
                    User.full_name.ilike(f'%{search}%'),
                    User.email.ilike(f'%{search}%')
                )
            )
        
        query = query.order_by(User.created_at.desc())
        pagination = paginate(query, page=page, per_page=20)
        return render_template('admin/users.html', pagination=pagination, search=search)
    
    @app.route('/admin/users/<int:user_id>/toggle-admin', methods=['POST'])
    @admin_required
    def admin_toggle_user_admin(user_id):
        """Toggle admin status for a user."""
        user = User.query.get_or_404(user_id)
        
        # Prevent self-demotion
        if user.id == current_user.id:
            flash('You cannot change your own admin status.', 'warning')
            return redirect(url_for('admin_users'))
        
        try:
            user.is_admin = not user.is_admin
            db.session.commit()
            status = 'granted' if user.is_admin else 'revoked'
            flash(f'Admin privileges {status} for {user.full_name}.', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Admin toggle error: {e}')
            flash('An error occurred.', 'danger')
        
        return redirect(url_for('admin_users'))
    
    @app.route('/admin/events', methods=['GET', 'POST'])
    @admin_required
    def admin_events():
        """Event management."""
        form = EventForm()
        if form.validate_on_submit():
            try:
                event = Event(
                    title=form.title.data,
                    description=form.description.data,
                    date=form.date.data,
                    time=form.time.data,
                    location=form.location.data,
                    speaker=form.speaker.data,
                    speaker_bio=form.speaker_bio.data,
                    max_attendees=form.max_attendees.data,
                    is_active=form.is_active.data
                )
                db.session.add(event)
                db.session.commit()
                flash('Event created successfully!', 'success')
                return redirect(url_for('admin_events'))
            except Exception as e:
                db.session.rollback()
                logger.error(f'Event creation error: {e}')
                flash('An error occurred.', 'danger')
        
        page = request.args.get('page', 1, type=int)
        events_query = Event.query.order_by(Event.created_at.desc())
        pagination = paginate(events_query, page=page, per_page=15)
        
        return render_template('admin/events.html', form=form, pagination=pagination)
    
    @app.route('/admin/events/<int:event_id>/edit', methods=['POST'])
    @admin_required
    def admin_edit_event(event_id):
        """Edit an event."""
        event = Event.query.get_or_404(event_id)
        form = EventForm(obj=event)
        
        if form.validate_on_submit():
            try:
                event.title = form.title.data
                event.description = form.description.data
                event.date = form.date.data
                event.time = form.time.data
                event.location = form.location.data
                event.speaker = form.speaker.data
                event.speaker_bio = form.speaker_bio.data
                event.max_attendees = form.max_attendees.data
                event.is_active = form.is_active.data
                db.session.commit()
                flash('Event updated successfully!', 'success')
            except Exception as e:
                db.session.rollback()
                logger.error(f'Event edit error: {e}')
                flash('An error occurred.', 'danger')
        
        return redirect(url_for('admin_events'))
    
    @app.route('/admin/events/<int:event_id>/delete', methods=['POST'])
    @admin_required
    def admin_delete_event(event_id):
        """Delete an event."""
        event = Event.query.get_or_404(event_id)
        try:
            db.session.delete(event)
            db.session.commit()
            flash('Event deleted successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Event deletion error: {e}')
            flash('An error occurred.', 'danger')
        
        return redirect(url_for('admin_events'))
    
    @app.route('/admin/workshops', methods=['GET', 'POST'])
    @admin_required
    def admin_workshops():
        """Workshop management."""
        form = WorkshopForm()
        if form.validate_on_submit():
            try:
                workshop = Workshop(
                    title=form.title.data,
                    description=form.description.data,
                    instructor=form.instructor.data,
                    category=form.category.data,
                    duration=form.duration.data,
                    schedule=datetime.combine(form.schedule.data, datetime.min.time()) if form.schedule.data else None,
                    price=form.price.data,
                    max_seats=form.max_seats.data,
                    is_active=form.is_active.data
                )
                db.session.add(workshop)
                db.session.commit()
                flash('Workshop created successfully!', 'success')
                return redirect(url_for('admin_workshops'))
            except Exception as e:
                db.session.rollback()
                logger.error(f'Workshop creation error: {e}')
                flash('An error occurred.', 'danger')
        
        page = request.args.get('page', 1, type=int)
        workshops_query = Workshop.query.order_by(Workshop.created_at.desc())
        pagination = paginate(workshops_query, page=page, per_page=15)
        
        return render_template('admin/workshops.html', form=form, pagination=pagination)
    
    @app.route('/admin/workshops/<int:workshop_id>/edit', methods=['POST'])
    @admin_required
    def admin_edit_workshop(workshop_id):
        """Edit a workshop."""
        workshop = Workshop.query.get_or_404(workshop_id)
        form = WorkshopForm(obj=workshop)
        
        if form.validate_on_submit():
            try:
                workshop.title = form.title.data
                workshop.description = form.description.data
                workshop.instructor = form.instructor.data
                workshop.category = form.category.data
                workshop.duration = form.duration.data
                workshop.schedule = datetime.combine(form.schedule.data, datetime.min.time()) if form.schedule.data else None
                workshop.price = form.price.data
                workshop.max_seats = form.max_seats.data
                workshop.is_active = form.is_active.data
                db.session.commit()
                flash('Workshop updated successfully!', 'success')
            except Exception as e:
                db.session.rollback()
                logger.error(f'Workshop edit error: {e}')
                flash('An error occurred.', 'danger')
        
        return redirect(url_for('admin_workshops'))
    
    @app.route('/admin/workshops/<int:workshop_id>/delete', methods=['POST'])
    @admin_required
    def admin_delete_workshop(workshop_id):
        """Delete a workshop."""
        workshop = Workshop.query.get_or_404(workshop_id)
        try:
            db.session.delete(workshop)
            db.session.commit()
            flash('Workshop deleted successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Workshop deletion error: {e}')
            flash('An error occurred.', 'danger')
        
        return redirect(url_for('admin_workshops'))
    
    @app.route('/admin/feedback')
    @admin_required
    def admin_feedback():
        """Feedback management."""
        page = request.args.get('page', 1, type=int)
        feedback_query = Feedback.query.order_by(Feedback.created_at.desc())
        pagination = paginate(feedback_query, page=page, per_page=20)
        
        # Calculate average rating
        avg_rating = db.session.query(db.func.avg(Feedback.rating)).scalar() or 0
        
        return render_template('admin/feedback.html', 
                             pagination=pagination, 
                             avg_rating=round(avg_rating, 1))
    
    @app.route('/admin/questionnaires', methods=['GET', 'POST'])
    @admin_required
    def admin_questionnaires():
        """Questionnaire management."""
        form = QuestionnaireForm()
        if form.validate_on_submit():
            try:
                questionnaire = Questionnaire(
                    title=form.title.data,
                    description=form.description.data
                )
                db.session.add(questionnaire)
                db.session.commit()
                flash('Questionnaire created successfully!', 'success')
                return redirect(url_for('admin_questionnaires'))
            except Exception as e:
                db.session.rollback()
                logger.error(f'Questionnaire creation error: {e}')
                flash('An error occurred.', 'danger')
        
        questionnaires = Questionnaire.query.order_by(Questionnaire.created_at.desc()).all()
        return render_template('admin/questionnaires.html', 
                             form=form, 
                             questionnaires=questionnaires)
    
    @app.route('/admin/questionnaires/<int:q_id>/questions', methods=['POST'])
    @admin_required
    def admin_add_question(q_id):
        """Add a question to a questionnaire."""
        questionnaire = Questionnaire.query.get_or_404(q_id)
        form = QuestionForm()
        
        if form.validate_on_submit():
            try:
                question = Question(
                    questionnaire_id=q_id,
                    question_text=form.question_text.data,
                    question_type=form.question_type.data,
                    options=form.options.data,
                    order=form.order.data
                )
                db.session.add(question)
                db.session.commit()
                flash('Question added successfully!', 'success')
            except Exception as e:
                db.session.rollback()
                logger.error(f'Question addition error: {e}')
                flash('An error occurred.', 'danger')
        
        return redirect(url_for('admin_questionnaires'))
    
    @app.route('/admin/questionnaires/<int:q_id>/toggle', methods=['POST'])
    @admin_required
    def admin_toggle_questionnaire(q_id):
        """Toggle questionnaire active status."""
        questionnaire = Questionnaire.query.get_or_404(q_id)
        try:
            questionnaire.is_active = not questionnaire.is_active
            db.session.commit()
            status = 'activated' if questionnaire.is_active else 'deactivated'
            flash(f'Questionnaire {status}!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f'Questionnaire toggle error: {e}')
            flash('An error occurred.', 'danger')
        
        return redirect(url_for('admin_questionnaires'))
    
    @app.route('/admin/database')
    @admin_required
    def admin_database():
        """Database viewer."""
        table = request.args.get('table', 'users')
        page = request.args.get('page', 1, type=int)
        search = request.args.get('search', '', type=str)
        
        # Map table names to models
        table_map = {
            'users': User,
            'events': Event,
            'workshops': Workshop,
            'feedback': Feedback,
            'event_registrations': EventRegistration,
            'workshop_enrollments': WorkshopEnrollment,
            'contact_messages': ContactMessage,
            'payment_orders': PaymentOrder,
            'questionnaires': Questionnaire,
            'questions': Question,
            'question_responses': QuestionResponse,
            'newsletter_subscribers': NewsletterSubscriber,
            'chat_messages': ChatMessage
        }
        
        model = table_map.get(table, User)
        query = model.query
        
        # Apply search if applicable
        if search and hasattr(model, 'full_name'):
            query = query.filter(model.full_name.ilike(f'%{search}%'))
        elif search and hasattr(model, 'name'):
            query = query.filter(model.name.ilike(f'%{search}%'))
        elif search and hasattr(model, 'email'):
            query = query.filter(model.email.ilike(f'%{search}%'))
        elif search and hasattr(model, 'title'):
            query = query.filter(model.title.ilike(f'%{search}%'))
        
        pagination = paginate(query.order_by(model.id.desc()), page=page, per_page=25)
        
        # Get column names
        columns = [col.name for col in model.__table__.columns]
        
        return render_template('admin/database.html',
                             table=table,
                             tables=list(table_map.keys()),
                             columns=columns,
                             pagination=pagination,
                             search=search)
    
    @app.route('/admin/stats')
    @admin_required
    def admin_stats():
        """Get statistics as JSON for charts."""
        from models import db
        
        # User growth by month
        user_growth = db.session.query(
            db.func.strftime('%Y-%m', User.created_at).label('month'),
            db.func.count(User.id).label('count')
        ).group_by('month').order_by('month').limit(12).all()
        
        # Workshop enrollment by category
        category_enrollments = db.session.query(
            Workshop.category,
            db.func.count(WorkshopEnrollment.id).label('count')
        ).join(WorkshopEnrollment).group_by(Workshop.category).all()
        
        # Event registrations over time
        event_regs = db.session.query(
            db.func.strftime('%Y-%m', EventRegistration.registered_at).label('month'),
            db.func.count(EventRegistration.id).label('count')
        ).group_by('month').order_by('month').limit(12).all()
        
        # Rating distribution
        rating_dist = db.session.query(
            Feedback.rating,
            db.func.count(Feedback.id).label('count')
        ).group_by(Feedback.rating).order_by(Feedback.rating).all()
        
        return jsonify({
            'user_growth': [{'month': m[0], 'count': m[1]} for m in user_growth],
            'category_enrollments': [{'category': c[0] or 'Other', 'count': c[1]} for c in category_enrollments],
            'event_registrations': [{'month': m[0], 'count': m[1]} for m in event_regs],
            'rating_distribution': [{'rating': r[0], 'count': r[1]} for r in rating_dist]
        })
    
    # ============================================================
    # API ROUTES
    # ============================================================
    
    @app.route('/api/stats')
    def api_stats():
        """Public statistics API."""
        return jsonify(get_public_stats())
    
    @app.route('/api/events')
    def api_events():
        """Events JSON API."""
        events = Event.query.filter_by(is_active=True).order_by(Event.date).all()
        return jsonify([e.to_dict() for e in events])
    
    @app.route('/api/workshops')
    def api_workshops():
        """Workshops JSON API."""
        workshops = Workshop.query.filter_by(is_active=True).order_by(Workshop.schedule).all()
        return jsonify([w.to_dict() for w in workshops])
    
    @app.route('/api/feedback/recent')
    def api_recent_feedback():
        """Recent feedback API."""
        feedback_items = Feedback.query.order_by(Feedback.created_at.desc()).limit(5).all()
        return jsonify([f.to_dict() for f in feedback_items])
    
    # ============================================================
    # UPLOADS ROUTE
    # ============================================================
    
    @app.route('/uploads/<path:filename>')
    def uploaded_file(filename):
        """Serve uploaded files."""
        from flask import send_from_directory
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    
    return app


# ============================================================
# TESTIMONIALS DATA
# ============================================================

def get_testimonials():
    """Get testimonial data."""
    return [
        {
            'name': 'Priya Sharma',
            'role': 'Student, Bangalore',
            'quote': 'VOXFEM transformed my career trajectory. The LinkedIn optimization workshop helped me land my dream internship at a top tech company!',
            'rating': 5,
            'initials': 'PS'
        },
        {
            'name': 'Ananya Reddy',
            'role': 'Entrepreneur, Hyderabad',
            'quote': 'The entrepreneurship workshop gave me the confidence to start my own business. Fiza Khan mentorship is truly invaluable for aspiring founders.',
            'rating': 5,
            'initials': 'AR'
        },
        {
            'name': 'Meera Patel',
            'role': 'Software Engineer, Pune',
            'quote': 'I was struggling with interviews until I attended the Interview Preparation workshop. The STAR method changed everything for me!',
            'rating': 5,
            'initials': 'MP'
        },
        {
            'name': 'Kavya Nair',
            'role': 'Marketing Professional, Mumbai',
            'quote': 'The personal branding session helped me establish myself as a thought leader in my industry. Highly recommend VOXFEM to every professional woman!',
            'rating': 5,
            'initials': 'KN'
        }
    ]


# ============================================================
# APPLICATION ENTRY POINT
# ============================================================

app = create_app(os.getenv('FLASK_ENV', 'development'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=True)
