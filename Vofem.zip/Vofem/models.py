"""
VOXFEM (C2G) - Database Models
SQLAlchemy ORM models for the application.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """User model for authentication and profile management."""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True, index=True)
    phone = db.Column(db.String(20))
    password_hash = db.Column(db.String(256), nullable=False)
    interests = db.Column(db.String(500))
    bio = db.Column(db.Text)
    profile_image = db.Column(db.String(200))
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    event_registrations = db.relationship('EventRegistration', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    workshop_enrollments = db.relationship('WorkshopEnrollment', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    question_responses = db.relationship('QuestionResponse', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    payments = db.relationship('PaymentOrder', backref='user', lazy='dynamic', cascade='all, delete-orphan')

    def set_password(self, password):
        """Hash and set user password."""
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)

    def check_password(self, password):
        """Verify password against hash."""
        return check_password_hash(self.password_hash, password)

    def get_initials(self):
        """Get user initials from full name."""
        names = self.full_name.strip().split()
        if len(names) >= 2:
            return (names[0][0] + names[-1][0]).upper()
        return names[0][0].upper() if names else '?'

    def to_dict(self):
        """Serialize user to dictionary."""
        return {
            'id': self.id,
            'full_name': self.full_name,
            'email': self.email,
            'phone': self.phone,
            'interests': self.interests,
            'bio': self.bio,
            'profile_image': self.profile_image,
            'is_admin': self.is_admin,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

    def __repr__(self):
        return f'<User {self.email}>'


class Event(db.Model):
    """Event model for community events."""
    __tablename__ = 'events'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time)
    location = db.Column(db.String(200))
    speaker = db.Column(db.String(100))
    speaker_bio = db.Column(db.Text)
    banner_image = db.Column(db.String(200))
    max_attendees = db.Column(db.Integer, default=100)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    registrations = db.relationship('EventRegistration', backref='event', lazy='dynamic', cascade='all, delete-orphan')

    @property
    def attendee_count(self):
        """Get current number of registered attendees."""
        return self.registrations.count()

    @property
    def is_full(self):
        """Check if event has reached max capacity."""
        return self.attendee_count >= self.max_attendees

    def to_dict(self):
        """Serialize event to dictionary."""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'date': self.date.isoformat() if self.date else None,
            'time': self.time.strftime('%H:%M') if self.time else None,
            'location': self.location,
            'speaker': self.speaker,
            'speaker_bio': self.speaker_bio,
            'banner_image': self.banner_image,
            'max_attendees': self.max_attendees,
            'attendee_count': self.attendee_count,
            'is_active': self.is_active,
            'is_full': self.is_full,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<Event {self.title}>'


class EventRegistration(db.Model):
    """Event registration linking users to events."""
    __tablename__ = 'event_registrations'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)
    attended = db.Column(db.Boolean, default=False)

    # Ensure a user can only register once per event
    __table_args__ = (db.UniqueConstraint('user_id', 'event_id', name='unique_event_registration'),)

    def __repr__(self):
        return f'<EventRegistration user={self.user_id} event={self.event_id}>'


class Workshop(db.Model):
    """Workshop model for educational workshops."""
    __tablename__ = 'workshops'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    instructor = db.Column(db.String(100), default='Fiza Khan')
    category = db.Column(db.String(50))
    duration = db.Column(db.String(50))
    schedule = db.Column(db.DateTime)
    price = db.Column(db.Float, default=0)
    max_seats = db.Column(db.Integer, default=30)
    image = db.Column(db.String(200))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    enrollments = db.relationship('WorkshopEnrollment', backref='workshop', lazy='dynamic', cascade='all, delete-orphan')

    @property
    def enrolled_count(self):
        """Get current number of enrolled participants."""
        return self.enrollments.filter_by(payment_status='paid').count()

    @property
    def available_seats(self):
        """Get remaining available seats."""
        return max(0, self.max_seats - self.enrolled_count)

    @property
    def is_free(self):
        """Check if workshop is free."""
        return self.price <= 0

    def to_dict(self):
        """Serialize workshop to dictionary."""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'instructor': self.instructor,
            'category': self.category,
            'duration': self.duration,
            'schedule': self.schedule.isoformat() if self.schedule else None,
            'price': self.price,
            'max_seats': self.max_seats,
            'enrolled_count': self.enrolled_count,
            'available_seats': self.available_seats,
            'image': self.image,
            'is_active': self.is_active,
            'is_free': self.is_free,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<Workshop {self.title}>'


class WorkshopEnrollment(db.Model):
    """Workshop enrollment linking users to workshops."""
    __tablename__ = 'workshop_enrollments'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    workshop_id = db.Column(db.Integer, db.ForeignKey('workshops.id'), nullable=False)
    enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)
    payment_status = db.Column(db.String(20), default='pending')
    progress = db.Column(db.Integer, default=0)

    # Ensure a user can only enroll once per workshop
    __table_args__ = (db.UniqueConstraint('user_id', 'workshop_id', name='unique_workshop_enrollment'),)

    def __repr__(self):
        return f'<WorkshopEnrollment user={self.user_id} workshop={self.workshop_id}>'


class Feedback(db.Model):
    """Feedback model for user feedback collection."""
    __tablename__ = 'feedback'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    category = db.Column(db.String(50))
    comments = db.Column(db.Text, nullable=False)
    suggestions = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationship
    user = db.relationship('User', backref='feedback_entries', lazy=True)

    def to_dict(self):
        """Serialize feedback to dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'rating': self.rating,
            'category': self.category,
            'comments': self.comments,
            'suggestions': self.suggestions,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<Feedback {self.name}>'


class Questionnaire(db.Model):
    """Questionnaire model for creating surveys."""
    __tablename__ = 'questionnaires'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    questions = db.relationship('Question', backref='questionnaire', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self):
        """Serialize questionnaire to dictionary."""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<Questionnaire {self.title}>'


class Question(db.Model):
    """Individual question within a questionnaire."""
    __tablename__ = 'questions'

    id = db.Column(db.Integer, primary_key=True)
    questionnaire_id = db.Column(db.Integer, db.ForeignKey('questionnaires.id'), nullable=False)
    question_text = db.Column(db.Text, nullable=False)
    question_type = db.Column(db.String(20), default='text')
    options = db.Column(db.Text)
    order = db.Column(db.Integer, default=0)

    # Relationships
    responses = db.relationship('QuestionResponse', backref='question', lazy='dynamic', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Question {self.id}>'


class QuestionResponse(db.Model):
    """User response to a question."""
    __tablename__ = 'question_responses'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey('questions.id'), nullable=False)
    response = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<QuestionResponse user={self.user_id} question={self.question_id}>'


class ContactMessage(db.Model):
    """Contact form message model."""
    __tablename__ = 'contact_messages'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20))
    subject = db.Column(db.String(100))
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        """Serialize contact message to dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'subject': self.subject,
            'message': self.message,
            'is_read': self.is_read,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<ContactMessage {self.name}>'


class PaymentOrder(db.Model):
    """Payment order model for workshop payments."""
    __tablename__ = 'payment_orders'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    workshop_id = db.Column(db.Integer, db.ForeignKey('workshops.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(10), default='INR')
    razorpay_order_id = db.Column(db.String(100))
    razorpay_payment_id = db.Column(db.String(100))
    razorpay_signature = db.Column(db.String(256))
    status = db.Column(db.String(20), default='created')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationship
    workshop = db.relationship('Workshop', backref='payment_orders', lazy=True)

    def to_dict(self):
        """Serialize payment order to dictionary."""
        return {
            'id': self.id,
            'amount': self.amount,
            'currency': self.currency,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<PaymentOrder {self.id}>'


class NewsletterSubscriber(db.Model):
    """Newsletter subscriber model."""
    __tablename__ = 'newsletter_subscribers'

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), nullable=False, unique=True)
    subscribed_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<NewsletterSubscriber {self.email}>'


class ChatMessage(db.Model):
    """Chat message history for AI assistant."""
    __tablename__ = 'chat_messages'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'user' or 'ai'
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<ChatMessage {self.role}>'
