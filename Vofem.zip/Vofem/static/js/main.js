/**
 * VOXFEM (C2G) - Main JavaScript
 * Women and Youth Empowerment Platform
 */

(function() {
    'use strict';

    // ============================================
    // FLASH MESSAGE AUTO-DISMISS
    // ============================================
    
    function initFlashMessages() {
        const messages = document.querySelectorAll('.flash-message[data-auto-dismiss]');
        messages.forEach(function(msg) {
            const delay = parseInt(msg.dataset.autoDismiss) || 4000;
            setTimeout(function() {
                msg.style.opacity = '0';
                msg.style.transform = 'translateX(100%)';
                msg.style.transition = 'all 0.3s ease';
                setTimeout(function() { msg.remove(); }, 300);
            }, delay);
        });
    }

    // ============================================
    // NAVBAR SCROLL EFFECT
    // ============================================
    
    function initNavbar() {
        const nav = document.getElementById('main-nav');
        if (!nav) return;
        
        let ticking = false;
        
        function updateNav() {
            if (window.scrollY > 50) {
                nav.style.background = 'rgba(255, 255, 255, 0.9)';
                nav.style.backdropFilter = 'blur(20px)';
                nav.style.webkitBackdropFilter = 'blur(20px)';
                nav.style.borderBottom = '1px solid rgba(0, 0, 0, 0.05)';
                nav.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.05)';
            } else {
                nav.style.background = 'transparent';
                nav.style.backdropFilter = 'none';
                nav.style.webkitBackdropFilter = 'none';
                nav.style.borderBottom = '1px solid transparent';
                nav.style.boxShadow = 'none';
            }
            ticking = false;
        }
        
        window.addEventListener('scroll', function() {
            if (!ticking) {
                requestAnimationFrame(updateNav);
                ticking = true;
            }
        });
        
        // Initial state
        updateNav();
    }

    // ============================================
    // MOBILE MENU
    // ============================================
    
    function initMobileMenu() {
        const menuBtn = document.getElementById('mobile-menu-btn');
        const drawer = document.getElementById('mobile-drawer');
        const overlay = document.getElementById('mobile-overlay');
        const closeBtn = document.getElementById('mobile-close-btn');
        
        if (!menuBtn || !drawer || !overlay) return;
        
        function open() {
            drawer.style.transform = 'translateX(0)';
            overlay.classList.remove('hidden');
            requestAnimationFrame(function() {
                overlay.style.opacity = '1';
            });
            document.body.style.overflow = 'hidden';
        }
        
        function close() {
            drawer.style.transform = 'translateX(100%)';
            overlay.style.opacity = '0';
            setTimeout(function() {
                overlay.classList.add('hidden');
            }, 300);
            document.body.style.overflow = '';
        }
        
        menuBtn.addEventListener('click', open);
        if (closeBtn) closeBtn.addEventListener('click', close);
        overlay.addEventListener('click', close);
        
        // Close on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && !overlay.classList.contains('hidden')) {
                close();
            }
        });
    }

    // ============================================
    // SMOOTH SCROLL FOR ANCHOR LINKS
    // ============================================
    
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
            anchor.addEventListener('click', function(e) {
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    const navHeight = document.getElementById('main-nav')?.offsetHeight || 72;
                    const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navHeight;
                    
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    // ============================================
    // ANIMATED COUNTERS
    // ============================================
    
    function initCounters() {
        const counters = document.querySelectorAll('.counter[data-target]');
        if (counters.length === 0) return;
        
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const counter = entry.target;
                    const target = parseInt(counter.dataset.target);
                    const duration = 2000;
                    const start = performance.now();
                    
                    function update(now) {
                        const elapsed = now - start;
                        const progress = Math.min(elapsed / duration, 1);
                        // easeOutCubic
                        const easeProgress = 1 - Math.pow(1 - progress, 3);
                        const current = Math.floor(easeProgress * target);
                        counter.textContent = current.toLocaleString() + '+';
                        
                        if (progress < 1) {
                            requestAnimationFrame(update);
                        }
                    }
                    
                    requestAnimationFrame(update);
                    observer.unobserve(counter);
                }
            });
        }, { threshold: 0.5 });
        
        counters.forEach(function(counter) {
            observer.observe(counter);
        });
    }

    // ============================================
    // VIDEO BACKGROUND SLIDESHOW
    // ============================================
    
    function initVideoSlideshow() {
        const videos = document.querySelectorAll('#video-bg video');
        if (videos.length === 0) return;
        
        let currentIdx = 0;
        const interval = 8000; // 8 seconds
        
        setInterval(function() {
            videos[currentIdx].style.opacity = '0';
            currentIdx = (currentIdx + 1) % videos.length;
            videos[currentIdx].style.opacity = '1';
        }, interval);
    }

    // ============================================
    // SCROLL REVEAL ANIMATION
    // ============================================
    
    function initScrollReveal() {
        const revealElements = document.querySelectorAll('.reveal');
        if (revealElements.length === 0) return;
        
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
        
        revealElements.forEach(function(el) {
            observer.observe(el);
        });
    }

    // ============================================
    // BACK TO TOP BUTTON
    // ============================================
    
    function initBackToTop() {
        const btn = document.getElementById('back-to-top');
        if (!btn) return;
        
        window.addEventListener('scroll', function() {
            if (window.scrollY > 500) {
                btn.classList.remove('hidden');
                btn.style.opacity = '1';
            } else {
                btn.style.opacity = '0';
                setTimeout(function() {
                    if (window.scrollY <= 500) {
                        btn.classList.add('hidden');
                    }
                }, 300);
            }
        });
        
        btn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // ============================================
    // FORM VALIDATION ENHANCEMENT
    // ============================================
    
    function initFormValidation() {
        document.querySelectorAll('form').forEach(function(form) {
            form.addEventListener('submit', function(e) {
                const requiredFields = form.querySelectorAll('[required]');
                let isValid = true;
                
                requiredFields.forEach(function(field) {
                    if (!field.value.trim()) {
                        isValid = false;
                        field.classList.add('border-red-300');
                        field.classList.add('ring-1');
                        field.classList.add('ring-red-200');
                    } else {
                        field.classList.remove('border-red-300');
                        field.classList.remove('ring-1');
                        field.classList.remove('ring-red-200');
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                }
            });
            
            // Clear validation on input
            form.querySelectorAll('input, textarea, select').forEach(function(field) {
                field.addEventListener('input', function() {
                    this.classList.remove('border-red-300');
                    this.classList.remove('ring-1');
                    this.classList.remove('ring-red-200');
                });
            });
        });
    }

    // ============================================
    // LAZY LOADING IMAGES
    // ============================================
    
    function initLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');
        if (images.length === 0) return;
        
        const imageObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(function(img) {
            imageObserver.observe(img);
        });
    }

    // ============================================
    // INITIALIZE ALL
    // ============================================
    
    document.addEventListener('DOMContentLoaded', function() {
        initFlashMessages();
        initNavbar();
        initMobileMenu();
        initSmoothScroll();
        initCounters();
        initVideoSlideshow();
        initScrollReveal();
        initBackToTop();
        initFormValidation();
        initLazyLoading();
    });

})();
