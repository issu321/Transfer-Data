"""
VOXFEM (C2G) - AI Career Assistant
Offline rule-based AI system for career guidance.
No external APIs required.
"""

import random
import re


class CareerAssistant:
    """Offline rule-based AI career assistant."""

    # Keyword mapping to categories
    KEYWORD_MAP = {
        'career_suggestions': [
            'career', 'job', 'work', 'profession', 'occupation', 'employment',
            'role', 'position', 'field', 'industry', 'path', 'course',
            'future', 'goal', 'ambition', 'aspiration', 'direction',
            'what should i do', 'career path', 'job search', 'finding job',
            'which career', 'best career', 'career option', 'career advice'
        ],
        'resume_tips': [
            'resume', 'cv', 'curriculum vitae', 'portfolio', 'profile',
            'document', 'biodata', 'summary', 'experience section',
            'skills section', 'format', 'template', 'resume writing',
            'make resume', 'build resume', 'improve resume', 'resume tips'
        ],
        'linkedin_tips': [
            'linkedin', 'networking', 'connection', 'professional network',
            'profile optimization', 'social media professional',
            'linkedin profile', 'linkedin summary', 'endorsement',
            'recommendation', 'connect', 'network', 'linked in'
        ],
        'interview_tips': [
            'interview', 'preparation', 'question', 'answer', 'hr',
            'hiring', 'recruitment', 'selection', 'panel',
            'prepare', 'interview question', 'interview tips',
            'phone interview', 'video interview', 'group discussion',
            'gd', 'mock interview', 'interview preparation'
        ],
        'communication_skills': [
            'communication', 'speak', 'speaking', 'presentation',
            'public speaking', 'talk', 'conversation', 'verbal',
            'written', 'email', 'message', 'articulate',
            'confidence', 'nervous', 'stage fear', 'fluency',
            'body language', 'tone', 'voice', 'expression'
        ],
        'leadership_tips': [
            'leadership', 'leader', 'manage', 'management', 'team',
            'delegate', 'vision', 'motivate', 'inspire', 'guide',
            'team building', 'conflict resolution', 'decision making',
            'strategic thinking', 'emotional intelligence', 'empathy',
            'team leader', 'project manager', 'supervisor'
        ],
        'entrepreneurship_guidance': [
            'entrepreneur', 'startup', 'business', 'company', 'founder',
            'venture', 'enterprise', 'initiative', 'idea', 'product',
            'service', 'market', 'customer', 'revenue', 'funding',
            'investment', 'pitch', 'deck', 'business plan', 'mvp',
            'minimum viable product', 'scaling', 'growth'
        ]
    }

    # Response templates for each category
    RESPONSES = {
        'career_suggestions': [
            "That's a great question about your career! Here are some suggestions:\n\n"
            "1. **Self-Assessment**: Identify your strengths, interests, and values. What activities make you lose track of time?\n"
            "2. **Research Industries**: Look into growing fields like AI, Data Science, Digital Marketing, UX Design, and Sustainability.\n"
            "3. **Informational Interviews**: Talk to professionals in fields you're curious about.\n"
            "4. **Skill Gaps**: Identify skills needed for your target role and start learning them.\n"
            "5. **Mentorship**: Find a mentor who can guide you based on their experience.\n\n"
            "Remember: There's no single 'right' path. Your career is a journey of continuous learning and adaptation!",

            "Great question about career direction! Here's my advice:\n\n"
            "**Explore Before You Commit:**\n"
            "- Try internships, volunteer work, or freelance projects\n"
            "- Take online courses in different fields\n"
            "- Attend industry events and webinars\n\n"
            "**Top Growing Fields for Women \u0026 Youth:**\n"
            "- Technology (AI, Web Development, Data Analytics)\n"
            "- Digital Marketing \u0026 Content Creation\n"
            "- Healthcare \u0026 Wellness\n"
            "- Sustainability \u0026 Social Impact\n"
            "- Entrepreneurship\n\n"
            "What specific industries interest you? I'd be happy to share more targeted advice!",

            "Career planning is so important! Here's a structured approach:\n\n"
            "**Step 1: Know Yourself**\n"
            "List your top 5 skills, 3 passions, and your core values.\n\n"
            "**Step 2: Market Research**\n"
            "Use LinkedIn, Glassdoor, and industry reports to understand job trends and salaries.\n\n"
            "**Step 3: Build a Portfolio**\n"
            "Create projects that demonstrate your skills, even if you're just starting.\n\n"
            "**Step 4: Network Strategically**\n"
            "Connect with 5 new professionals in your target field every week.\n\n"
            "**Step 5: Stay Adaptable**\n"
            "The job market changes rapidly. Keep learning and be open to pivoting!\n\n"
            "Would you like specific advice for any particular field?",

            "I'd love to help you find the right career path! Consider these questions:\n\n"
            "1. What problems do you enjoy solving?\n"
            "2. What skills do people often compliment you on?\n"
            "3. What would you do even if you weren't paid?\n\n"
            "**Emerging Career Paths:**\n"
            "- AI Prompt Engineer\n"
            "- Sustainability Consultant\n"
            "- UX/UI Designer\n"
            "- Digital Content Strategist\n"
            "- Community Manager\n"
            "- Data Analyst\n\n"
            "The best career is one that aligns your strengths with market demand. Let's discuss what excites you!"
        ],
        'resume_tips': [
            "Here are some powerful resume tips to help you stand out:\n\n"
            "**Format \u0026 Structure:**\n"
            "- Keep it to 1 page (2 pages max for experienced professionals)\n"
            "- Use clean, professional fonts (Arial, Calibri, or Helvetica)\n"
            "- Use bullet points, not paragraphs\n"
            "- Save as PDF to preserve formatting\n\n"
            "**Content That Matters:**\n"
            "- Use action verbs: Led, Created, Developed, Managed, Increased\n"
            "- Quantify achievements: 'Increased sales by 25%' not 'Helped increase sales'\n"
            "- Tailor for each job application using keywords from the job description\n"
            "- Include a strong summary statement at the top\n\n"
            "**Sections to Include:**\n"
            "Contact Info → Summary → Skills → Experience → Education → Projects/Certifications",

            "Let me help you craft a winning resume!\n\n"
            "**The STAR Method for Experience:**\n"
            "Structure each bullet as: **S**ituation → **T**ask → **A**ction → **R**esult\n\n"
            "Example: *Led a team of 5 students (Situation) to organize a college fest (Task) by delegating roles and conducting weekly meetings (Action), resulting in 500+ attendees and 20% budget savings (Result).*\n\n"
            "**Common Mistakes to Avoid:**\n"
            "- Spelling or grammar errors\n"
            "- Using unprofessional email addresses\n"
            "- Including irrelevant hobbies\n"
            "- Lying or exaggerating\n"
            "- Using a generic objective statement\n\n"
            "**Pro Tip:** Use tools like Canva for beautiful resume templates, and get feedback from mentors before submitting!",

            "Resume writing is an art! Here's how to master it:\n\n"
            "**Top Section Priority:**\n"
            "Your name (large, bold) → Professional title → Contact info → LinkedIn URL\n\n"
            "**Skills Section Tips:**\n"
            "- Include both hard skills (Python, Excel, Photoshop) and soft skills (Leadership, Communication)\n"
            "- Match skills mentioned in the job description\n"
            "- Be honest about proficiency levels\n\n"
            "**For Students/Recent Grads:**\n"
            "- Highlight academic projects with real-world impact\n"
            "- Include volunteer work and extracurriculars\n"
            "- Add relevant coursework and certifications\n\n"
            "**ATS-Friendly Tips:**\n"
            "- Avoid tables, columns, and graphics ( Applicant Tracking Systems can't read them)\n"
            "- Use standard section headings\n"
            "- Include keywords naturally throughout\n\n"
            "Would you like me to review a specific section of your resume?"
        ],
        'linkedin_tips': [
            "LinkedIn is your digital professional identity! Here's how to optimize it:\n\n"
            "**Profile Photo:**\n"
            "- Use a professional headshot with good lighting\n"
            "- Dress professionally, smile genuinely\n"
            "- Ensure your face takes up 60% of the frame\n\n"
            "**Headline (Beyond Your Job Title):**\n"
            "Instead of 'Student at XYZ University', try:\n"
            "'Aspiring Data Scientist | Python & ML Enthusiast | Building AI Solutions for Social Good'\n\n"
            "**About Section:**\n"
            "- Tell your professional story in first person\n"
            "- Include your mission, skills, and what you're looking for\n"
            "- Add a call-to-action (e.g., 'Let's connect!')\n\n"
            "**Engagement Strategy:**\n"
            "- Post 2-3 times per week about your learning journey\n"
            "- Comment thoughtfully on posts in your industry\n"
            "- Share articles, insights, and achievements",

            "LinkedIn optimization is crucial for career growth! Here are my top strategies:\n\n"
            "**Networking Best Practices:**\n\n"
            "1. **Personalize Connection Requests**: Always add a note mentioning how you know them or why you want to connect.\n"
            "2. **Engage Before You Ask**: Like and comment on their posts before requesting help.\n"
            "3. **Follow Industry Leaders**: Learn from their content and engage authentically.\n"
            "4. **Join Relevant Groups**: Participate in communities related to your field.\n\n"
            "**Content Ideas for Students:**\n"
            "- Share what you're learning and key takeaways\n"
            "- Write about projects you've completed\n"
            "- Celebrate achievements and certifications\n"
            "- Share your career journey and lessons learned\n\n"
            "**The LinkedIn Algorithm Loves:**\n"
            "- Posts with images or videos\n"
            "- Comments within the first hour\n"
            "- Content that sparks conversations\n\n"
            "Pro tip: Consistency beats perfection. Start posting today!",

            "Let me help you build a powerful LinkedIn presence!\n\n"
            "**Profile Optimization Checklist:**\n\n"
            "- [ ] Professional photo uploaded\n"
            "- [ ] Compelling headline with keywords\n"
            "- [ ] Complete About section (min 3 paragraphs)\n"
            "- [ ] All experience entries with descriptions\n"
            "- [ ] Education details filled\n"
            "- [ ] 5+ skills added and endorsed\n"
            "- [ ] Custom LinkedIn URL set\n"
            "- [ ] Featured section with projects/posts\n\n"
            "**Building Your Network:**\n\n"
            "- Connect with classmates, professors, and colleagues\n"
            "- Reach out to alumni from your school\n"
            "- Follow companies you're interested in\n"
            "- Send 5-10 personalized connection requests daily\n\n"
            "**Creating Valuable Content:**\n\n"
            "- Document your learning journey\n"
            "- Share book summaries and course takeaways\n"
            "- Ask thoughtful questions to your network\n"
            "- Celebrate wins (big and small!)\n\n"
            "Remember: Your network is your net worth. Invest time in building genuine relationships!"
        ],
        'interview_tips': [
            "Interview preparation is key to landing your dream role! Here's my comprehensive guide:\n\n"
            "**Before the Interview:**\n\n"
            "1. **Research the Company**: Know their products, culture, recent news, and competitors\n"
            "2. **Know the Job Description**: Prepare examples for each required skill\n"
            "3. **Prepare Your Stories**: Use STAR method (Situation, Task, Action, Result)\n"
            "4. **Practice Common Questions**: Tell me about yourself, strengths/weaknesses, why this company\n"
            "5. **Prepare Questions to Ask**: Show your interest and curiosity\n\n"
            "**Common Questions \u0026 How to Answer:**\n\n"
            "*'Tell me about yourself'* → Brief professional summary highlighting relevant experience\n"
            "*'What are your weaknesses?'* → Choose a real weakness + how you're improving\n"
            "*'Why should we hire you?'* → Connect your skills to their specific needs\n\n"
            "**Dress Code**: When in doubt, dress one level above the company's standard.",

            "Let me help you ace that interview!\n\n"
            "**The 'Tell Me About Yourself' Formula:**\n\n"
            "'I'm a [your role] with [X years] of experience in [key skills]. Currently, I'm [what you're doing now], where I've [specific achievement with numbers]. I'm particularly passionate about [relevant interest], which is why I'm so excited about this opportunity at [Company Name].'\n\n"
            "**Behavioral Questions (STAR Method):**\n\n"
            "- **S**ituation: Set the context briefly\n"
            "- **T**ask: What was your responsibility?\n"
            "- **A**ction: What did YOU do specifically?\n"
            "- **R**esult: What was the outcome? (Use numbers!)\n\n"
            "**During the Interview:**\n\n"
            "- Make eye contact and smile (even on video calls)\n"
            "- Take a breath before answering tough questions\n"
            "- It's okay to ask for a moment to think\n"
            "- Show enthusiasm and genuine interest\n\n"
            "**Questions to Ask Them:**\n"
            "- 'What does success look like in this role in the first 6 months?'\n"
            "- 'What do you enjoy most about working here?'\n"
            "- 'What are the team's biggest challenges right now?'",

            "Interview success is all about preparation and confidence! Here's more advice:\n\n"
            "**Technical Interview Tips:**\n\n"
            "- Review fundamental concepts in your field\n"
            "- Practice problem-solving out loud\n"
            "- Ask clarifying questions before diving into solutions\n"
            "- It's okay to not know everything – show your learning approach\n\n"
            "**Body Language Matters:**\n\n"
            "- Firm handshake (in-person)\n"
            "- Sit up straight and lean slightly forward\n"
            "- Use hand gestures naturally\n"
            "- Mirror the interviewer's energy level\n\n"
            "**Virtual Interview Specifics:**\n\n"
            "- Test your tech 15 minutes before\n"
            "- Ensure good lighting (face a window or use a ring light)\n"
            "- Look at the camera, not the screen\n"
            "- Minimize background distractions\n\n"
            "**Follow-Up:**\n\n"
            "Always send a thank-you email within 24 hours. Reference specific conversation points and reiterate your enthusiasm!\n\n"
            "You've got this! Believe in yourself and your preparation."
        ],
        'communication_skills': [
            "Communication is one of the most important skills for career success! Here's how to improve:\n\n"
            "**Public Speaking Tips:**\n\n"
            "1. **Practice Regularly**: Join a Toastmasters club or practice in front of a mirror\n"
            "2. **Know Your Audience**: Tailor your message to who you're speaking to\n"
            "3. **Structure Your Content**: Opening hook → Key points → Call to action\n"
            "4. **Use Stories**: People remember stories 22x more than facts alone\n"
            "5. **Manage Nerves**: Deep breathing, positive visualization, and preparation\n\n"
            "**Effective Writing:**\n\n"
            "- Be concise – remove unnecessary words\n"
            "- Use active voice\n"
            "- Structure with clear headings and bullet points\n"
            "- Proofread everything (use Grammarly!)\n\n"
            "**Active Listening:**\n\n"
            "- Maintain eye contact\n"
            "- Ask clarifying questions\n"
            "- Summarize what you heard\n"
            "- Avoid interrupting",

            "Great question about communication skills! Let me share some powerful techniques:\n\n"
            "**The PREP Method for Impromptu Speaking:**\n\n"
            "- **P**oint: State your main point clearly\n"
            "- **R**eason: Explain why you believe this\n"
            "- **E**xample: Share a relevant example or story\n"
            "- **P**oint: Restate your main point\n\n"
            "**Improving Confidence:**\n\n"
            "- Record yourself speaking and review\n"
            "- Practice power poses before important meetings\n"
            "- Focus on your breathing\n"
            "- Replace 'um' and 'uh' with purposeful pauses\n\n"
            "**Email Communication:**\n\n"
            "- Subject lines: Be specific and actionable\n"
            "- Opening: Get to the point quickly\n"
            "- Body: Use bullet points for multiple items\n"
            "- Closing: Clear next steps or call to action\n\n"
            "**Non-Verbal Communication:**\n\n"
            "- 55% of communication is body language\n"
            "- 38% is tone of voice\n"
            "- Only 7% is the actual words\n\n"
            "Be mindful of what your body is saying!",

            "Communication skills can transform your career! Here's more advice:\n\n"
            "**Presentation Skills:**\n\n"
            "- Start with a compelling story or surprising statistic\n"
            "- Use the 10-20-30 rule: 10 slides, 20 minutes, 30pt font\n"
            "- One idea per slide\n"
            "- Use visuals over text whenever possible\n"
            "- End with a clear takeaway and call to action\n\n"
            "**Difficult Conversations:**\n\n"
            "- Choose the right time and place\n"
            "- Use 'I' statements instead of 'You' statements\n"
            "- Focus on the issue, not the person\n"
            "- Seek to understand before being understood\n"
            "- Agree on next steps\n\n"
            "**Building Rapport:**\n\n"
            "- Remember and use people's names\n"
            "- Find common ground\n"
            "- Show genuine curiosity about others\n"
            "- Follow up on previous conversations\n\n"
            "The best communicators are also the best listeners. Practice listening to understand, not just to respond!"
        ],
        'leadership_tips': [
            "Leadership is about influence, not authority! Here's how to develop leadership skills:\n\n"
            "**Core Leadership Principles:**\n\n"
            "1. **Lead by Example**: Your actions speak louder than words\n"
            "2. **Empower Others**: Great leaders create more leaders, not followers\n"
            "3. **Communicate Vision**: Help your team understand the 'why' behind the work\n"
            "4. **Embrace Accountability**: Take responsibility for failures, share credit for successes\n"
            "5. **Continuous Learning**: The best leaders are lifelong learners\n\n"
            "**Leadership Styles:**\n\n"
            "- **Democratic**: Collaborative decision-making\n"
            "- **Transformational**: Inspiring and motivating change\n"
            "- **Servant**: Putting team's needs first\n"
            "- **Situational**: Adapting style to the situation\n\n"
            "**For Aspiring Leaders:**\n\n"
            "- Volunteer to lead projects, even small ones\n"
            "- Seek feedback and act on it\n"
            "- Develop emotional intelligence\n"
            "- Learn to delegate effectively\n\n"
            "Leadership is a skill, not a trait. It can be learned and developed!",

            "Developing leadership skills is one of the best investments you can make! Here's more:\n\n"
            "**Emotional Intelligence for Leaders:**\n\n"
            "**Self-Awareness**: Understand your emotions, strengths, and triggers\n"
            "**Self-Regulation**: Manage your emotions under pressure\n"
            "**Motivation**: Stay driven and inspire that drive in others\n"
            "**Empathy**: Understand and share the feelings of your team\n"
            "**Social Skills**: Build relationships and manage conflicts\n\n"
            "**Team Management Tips:**\n\n"
            "- Set clear expectations and goals\n"
            "- Provide regular feedback (both positive and constructive)\n"
            "- Recognize and celebrate achievements\n"
            "- Address issues promptly and privately\n"
            "- Create psychological safety for your team\n\n"
            "**Decision-Making Framework:**\n\n"
            "1. Define the problem clearly\n"
            "2. Gather relevant information\n"
            "3. Consider alternatives\n"
            "4. Weigh pros and cons\n"
            "5. Make the decision and commit\n"
            "6. Evaluate and learn\n\n"
            "Remember: Not making a decision is also a decision. Be decisive!",

            "Let me share more leadership wisdom:\n\n"
            "**Leading Without Authority:**\n\n"
            "You don't need a title to be a leader! Here's how:\n\n"
            "- **Build Relationships**: Invest in people genuinely\n"
            "- **Add Value**: Help others succeed in their goals\n"
            "- **Be Reliable**: Follow through on commitments\n"
            "- **Share Credit**: Recognize contributions publicly\n"
            "- **Take Initiative**: See a problem? Propose a solution\n\n"
            "**Conflict Resolution:**\n\n"
            "- Address conflicts early, don't let them fester\n"
            "- Listen to all sides without judgment\n"
            "- Focus on interests, not positions\n"
            "- Brainstorm solutions together\n"
            "- Find win-win outcomes when possible\n\n"
            "**Developing Future Leaders:**\n\n"
            "- Delegate challenging assignments\n"
            "- Provide mentorship and coaching\n"
            "- Create opportunities for visibility\n"
            "- Encourage risk-taking and learning from failure\n"
            "- Share your knowledge generously\n\n"
            "The measure of a great leader is not what they accomplish alone, but what they enable others to achieve!"
        ],
        'entrepreneurship_guidance': [
            "Entrepreneurship is an exciting journey! Here's how to get started:\n\n"
            "**Idea Validation:**\n\n"
            "1. **Problem Identification**: What painful problem are you solving?\n"
            "2. **Market Research**: Who else is solving this? How big is the market?\n"
            "3. **Customer Interviews**: Talk to 20+ potential customers before building\n"
            "4. **MVP**: Build the simplest version that solves the core problem\n"
            "5. **Iterate**: Launch fast, learn, and improve continuously\n\n"
            "**Business Model Canvas:**\n\n"
            "- Value Proposition: What value do you create?\n"
            "- Customer Segments: Who are your target customers?\n"
            "- Revenue Streams: How will you make money?\n"
            "- Channels: How will you reach customers?\n"
            "- Key Resources: What do you need to operate?\n\n"
            "**Funding Options for Startups:**\n\n"
            "- Bootstrapping (self-funding)\n"
            "- Friends and Family\n"
            "- Angel Investors\n"
            "- Startup Accelerators\n"
            "- Crowdfunding\n"
            "- Government Grants",

            "Building a business is challenging but rewarding! Here's more guidance:\n\n"
            "**From Idea to Launch:**\n\n"
            "**Step 1: Validate Your Idea**\n"
            "Don't build in secret! Share your idea, get feedback, and iterate.\n\n"
            "**Step 2: Build Your MVP**\n"
            "Minimum Viable Product – the simplest version that delivers value. Use no-code tools when possible!\n\n"
            "**Step 3: Get Your First Customers**\n"
            "- Start with your network\n"
            "- Offer free trials or heavy discounts\n"
            "- Get testimonials and case studies\n"
            "- Iterate based on feedback\n\n"
            "**Step 4: Scale Sustainably**\n"
            "- Focus on unit economics\n"
            "- Build systems and processes\n"
            "- Hire for culture fit and growth mindset\n"
            "- Keep customer acquisition costs low\n\n"
            "**Essential Skills for Entrepreneurs:**\n"
            "- Sales and marketing\n"
            "- Financial literacy\n"
            "- Time management\n"
            "- Resilience and grit\n"
            "- Networking\n\n"
            "Remember: Every big company started small. Start where you are, use what you have!",

            "Let me share more entrepreneurship insights:\n\n"
            "**Creating Your Business Plan:**\n\n"
            "**Executive Summary**: Your business in a nutshell\n"
            "**Market Analysis**: Industry trends, target market, competition\n"
            "**Product/Service**: What you offer and why it's unique\n"
            "**Marketing Strategy**: How you'll attract and retain customers\n"
            "**Operations**: How your business will run day-to-day\n"
            "**Financial Projections**: Revenue, expenses, break-even analysis\n"
            "**Team**: Key people and their roles\n\n"
            "**Common Mistakes to Avoid:**\n\n"
            "- Trying to serve everyone (niche down!)\n"
            "- Perfectionism (launch imperfect, iterate fast)\n"
            "- Ignoring cash flow\n"
            "- Not listening to customer feedback\n"
            "- Trying to do everything alone\n\n"
            "**Resources for Women Entrepreneurs:**\n\n"
            "- NSIC – National Small Industries Corporation\n"
            "- Mudra Loans for women\n"
            "- Stand-Up India Scheme\n"
            "- Women Entrepreneurship Platform (WEP)\n"
            "- Various state-level schemes\n\n"
            "The world needs more women entrepreneurs. Your unique perspective is your superpower!"
        ]
    }

    # Greeting messages
    GREETINGS = [
        "Hello! I'm your VOXFEM Career Assistant. I can help you with career suggestions, resume tips, LinkedIn optimization, interview preparation, communication skills, leadership development, and entrepreneurship guidance. What would you like to explore today?",
        
        "Hi there! Welcome to VOXFEM Career Assistant. I'm here to support your professional growth. Whether you need help with your career path, resume, LinkedIn profile, interviews, or leadership skills – just ask! What can I help you with?",
        
        "Welcome! I'm your AI Career Assistant at VOXFEM. I'm passionate about helping you succeed in your career journey. I can provide guidance on careers, resumes, LinkedIn, interviews, communication, leadership, and starting a business. What brings you here today?"
    ]

    # Fallback responses when no category matches
    FALLBACK_RESPONSES = [
        "That's an interesting question! While I specialize in career guidance, resume tips, LinkedIn optimization, interview preparation, communication skills, leadership, and entrepreneurship, I'd love to help however I can. Could you rephrase your question, or would you like advice on one of these topics?",
        
        "I appreciate you reaching out! I'm designed to help with career-related topics like job searching, resume building, LinkedIn profiles, interview prep, communication, leadership, and entrepreneurship. Is there a specific area I can assist you with?",
        
        "Great question! I focus on empowering your professional journey through career guidance, resume and LinkedIn tips, interview preparation, communication skills, leadership development, and entrepreneurship advice. Which of these would you like to explore?"
    ]

    def __init__(self):
        """Initialize the career assistant."""
        pass

    def get_greeting(self):
        """Get a random greeting message."""
        return random.choice(self.GREETINGS)

    def categorize_message(self, message):
        """Categorize a user message based on keywords.
        
        Args:
            message: User's input message
            
        Returns:
            str: Category name or None if no match
        """
        message_lower = message.lower()
        scores = {}
        
        for category, keywords in self.KEYWORD_MAP.items():
            score = sum(1 for keyword in keywords if keyword in message_lower)
            if score > 0:
                scores[category] = score
        
        if not scores:
            return None
        
        # Return category with highest score
        return max(scores, key=scores.get)

    def get_response(self, message):
        """Get a response for a user message.
        
        Args:
            message: User's input message
            
        Returns:
            str: AI response
        """
        # Check for greetings
        greeting_patterns = ['hello', 'hi', 'hey', 'namaste', 'good morning', 'good afternoon', 'good evening', 'greetings']
        if any(pattern in message.lower() for pattern in greeting_patterns) and len(message.split()) <= 3:
            return self.get_greeting()
        
        # Categorize the message
        category = self.categorize_message(message)
        
        if category and category in self.RESPONSES:
            return random.choice(self.RESPONSES[category])
        
        # Return fallback response
        return random.choice(self.FALLBACK_RESPONSES)

    def get_suggested_prompts(self):
        """Get list of suggested prompt buttons.
        
        Returns:
            list: Suggested prompt strings
        """
        return [
            "Career Suggestions",
            "Resume Tips",
            "LinkedIn Tips",
            "Interview Tips",
            "Communication Skills",
            "Leadership Tips",
            "Entrepreneurship Guidance"
        ]


# Global instance
assistant = CareerAssistant()


def get_career_assistant():
    """Get the global career assistant instance."""
    return assistant
