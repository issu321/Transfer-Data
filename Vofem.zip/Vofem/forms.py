"""
VOXFEM (C2G) - Forms
WTForms classes for form validation and rendering.
"""

from flask_wtf import FlaskForm
from wtforms import (
    StringField, PasswordField, TextAreaField, EmailField, TelField,
    SelectField, IntegerField, FloatField, DateField, TimeField,
    BooleanField, HiddenField, FileField, RadioField
)
from wtforms.validators import (
    DataRequired, Email, Length, EqualTo, Optional, NumberRange,
    ValidationError, Regexp
)
from models import User


class LoginForm(FlaskForm):
    """User login form."""
    email = EmailField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address')
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Password is required')
    ])
    remember = BooleanField('Remember me')


class RegistrationForm(FlaskForm):
    """User registration form."""
    full_name = StringField('Full Name', validators=[
        DataRequired(message='Full name is required'),
        Length(min=2, max=100, message='Name must be between 2 and 100 characters')
    ])
    email = EmailField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address'),
        Length(max=120)
    ])
    phone = TelField('Phone Number', validators=[
        Optional(),
        Regexp(r'^[0-9\-\+\s]{10,20}$', message='Please enter a valid phone number')
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Password is required'),
        Length(min=6, message='Password must be at least 6 characters')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(message='Please confirm your password'),
        EqualTo('password', message='Passwords do not match')
    ])
    interests = StringField('Interests', validators=[Optional()])
    agree_terms = BooleanField('I agree to the Terms of Service and Privacy Policy', validators=[
        DataRequired(message='You must agree to the terms')
    ])

    def validate_email(self, email):
        """Check if email already exists."""
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('This email is already registered. Please use a different email or login.')


class ProfileForm(FlaskForm):
    """User profile edit form."""
    full_name = StringField('Full Name', validators=[
        DataRequired(message='Full name is required'),
        Length(min=2, max=100)
    ])
    email = EmailField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email address')
    ])
    phone = TelField('Phone Number', validators=[Optional()])
    bio = TextAreaField('Bio', validators=[Optional(), Length(max=500)])
    interests = StringField('Interests', validators=[Optional()])


class EventForm(FlaskForm):
    """Event creation/editing form (admin)."""
    title = StringField('Event Title', validators=[
        DataRequired(message='Title is required'),
        Length(max=200)
    ])
    description = TextAreaField('Description', validators=[DataRequired(message='Description is required')])
    date = DateField('Date', validators=[DataRequired(message='Date is required')], format='%Y-%m-%d')
    time = TimeField('Time', validators=[Optional()], format='%H:%M')
    location = StringField('Location', validators=[Optional(), Length(max=200)])
    speaker = StringField('Speaker', validators=[Optional(), Length(max=100)])
    speaker_bio = TextAreaField('Speaker Bio', validators=[Optional()])
    max_attendees = IntegerField('Max Attendees', validators=[
        Optional(),
        NumberRange(min=1, max=10000, message='Must be between 1 and 10000')
    ], default=100)
    is_active = BooleanField('Active', default=True)


class WorkshopForm(FlaskForm):
    """Workshop creation/editing form (admin)."""
    title = StringField('Workshop Title', validators=[
        DataRequired(message='Title is required'),
        Length(max=200)
    ])
    description = TextAreaField('Description', validators=[DataRequired(message='Description is required')])
    instructor = StringField('Instructor', validators=[Optional(), Length(max=100)], default='Fiza Khan')
    category = SelectField('Category', choices=[
        ('', 'Select Category'),
        ('LinkedIn', 'LinkedIn Optimization'),
        ('Branding', 'Personal Branding'),
        ('AI', 'AI Literacy'),
        ('Leadership', 'Leadership'),
        ('Entrepreneurship', 'Entrepreneurship'),
        ('Communication', 'Communication Skills'),
        ('Portfolio', 'Portfolio Development'),
        ('Networking', 'Networking'),
        ('Other', 'Other')
    ], validators=[Optional()])
    duration = StringField('Duration', validators=[Optional(), Length(max=50)], default='2 hours')
    schedule = DateField('Schedule Date', validators=[Optional()], format='%Y-%m-%d')
    price = FloatField('Price (INR)', validators=[
        Optional(),
        NumberRange(min=0, message='Price cannot be negative')
    ], default=0)
    max_seats = IntegerField('Max Seats', validators=[
        Optional(),
        NumberRange(min=1, max=1000, message='Must be between 1 and 1000')
    ], default=30)
    is_active = BooleanField('Active', default=True)


class FeedbackForm(FlaskForm):
    """Feedback submission form."""
    name = StringField('Your Name', validators=[
        DataRequired(message='Name is required'),
        Length(max=100)
    ])
    email = EmailField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email')
    ])
    rating = RadioField('Rating', choices=[
        ('5', 'Excellent'),
        ('4', 'Very Good'),
        ('3', 'Good'),
        ('2', 'Fair'),
        ('1', 'Poor')
    ], validators=[DataRequired(message='Please select a rating')])
    category = SelectField('Category', choices=[
        ('', 'Select Category'),
        ('Workshop', 'Workshop'),
        ('Event', 'Event'),
        ('Platform', 'Platform'),
        ('AI Assistant', 'AI Assistant'),
        ('General', 'General'),
        ('Other', 'Other')
    ], validators=[Optional()])
    comments = TextAreaField('Comments', validators=[
        DataRequired(message='Please share your feedback'),
        Length(max=2000)
    ])
    suggestions = TextAreaField('Suggestions for Improvement', validators=[Optional(), Length(max=2000)])


class QuestionnaireForm(FlaskForm):
    """Questionnaire creation form (admin)."""
    title = StringField('Questionnaire Title', validators=[
        DataRequired(message='Title is required'),
        Length(max=200)
    ])
    description = TextAreaField('Description', validators=[Optional()])


class QuestionForm(FlaskForm):
    """Question creation form (admin)."""
    question_text = TextAreaField('Question', validators=[DataRequired(message='Question text is required')])
    question_type = SelectField('Type', choices=[
        ('text', 'Text Answer'),
        ('choice', 'Multiple Choice'),
        ('rating', 'Rating (1-5)')
    ], validators=[DataRequired()])
    options = TextAreaField('Options (comma-separated for choices)', validators=[Optional()])
    order = IntegerField('Order', validators=[Optional()], default=0)


class ContactForm(FlaskForm):
    """Contact form."""
    name = StringField('Your Name', validators=[
        DataRequired(message='Name is required'),
        Length(max=100)
    ])
    email = EmailField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email')
    ])
    phone = TelField('Phone', validators=[Optional()])
    subject = SelectField('Subject', choices=[
        ('', 'Select Subject'),
        ('General Inquiry', 'General Inquiry'),
        ('Workshop', 'Workshop Inquiry'),
        ('Event', 'Event Inquiry'),
        ('Partnership', 'Partnership'),
        ('Feedback', 'Feedback'),
        ('Other', 'Other')
    ], validators=[Optional()])
    message = TextAreaField('Message', validators=[
        DataRequired(message='Please enter your message'),
        Length(max=3000)
    ])


class NewsletterForm(FlaskForm):
    """Newsletter subscription form."""
    email = EmailField('Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Please enter a valid email')
    ])


class ChatForm(FlaskForm):
    """AI chat message form."""
    message = TextAreaField('Message', validators=[
        DataRequired(message='Please enter a message'),
        Length(max=1000)
    ])


class PaymentForm(FlaskForm):
    """Payment form (Razorpay-ready)."""
    workshop_id = HiddenField('Workshop ID', validators=[DataRequired()])
    amount = HiddenField('Amount', validators=[DataRequired()])


class AdminUserEditForm(FlaskForm):
    """Admin user editing form."""
    full_name = StringField('Full Name', validators=[DataRequired(), Length(max=100)])
    email = EmailField('Email', validators=[DataRequired(), Email()])
    phone = TelField('Phone', validators=[Optional()])
    is_admin = BooleanField('Admin Status')
    bio = TextAreaField('Bio', validators=[Optional()])
    interests = StringField('Interests', validators=[Optional()])
