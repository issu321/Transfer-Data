# VOXFEM (C2G) - Empowering Voices, Shaping Leaders

A professional women and youth empowerment platform built with Flask. VOXFEM serves as a community platform, event management system, workshop management system, leadership development hub, career growth platform, AI assistance platform, and student development platform.

## Features

### Core Platform
- **Community Platform** - Join a vibrant community of learners and leaders
- **Event Management** - Browse, register, and manage community events
- **Workshop Management** - Enroll in professional development workshops
- **Leadership Development** - Build leadership skills through curated content
- **Career Growth** - AI-powered career assistance and guidance
- **Student Development** - Tailored programs for student growth

### Authentication & Profiles
- User Registration with email validation
- Secure Login with Remember Me functionality
- Profile Management with image upload
- Password Hashing with PBKDF2-SHA256
- Session Management with secure cookies
- Admin role management

### Events System
- Create and manage community events
- Event registration with attendance tracking
- Speaker profiles and event details
- Capacity management with waitlist support

### Workshop System
- Browse workshops by category
- Workshop enrollment (free and paid)
- Seat availability tracking
- Progress tracking for enrolled workshops

### AI Career Assistant
- Offline rule-based AI system (no APIs required)
- Career suggestions and guidance
- Resume and CV tips
- LinkedIn profile optimization
- Interview preparation tips
- Communication skills guidance
- Leadership development advice
- Entrepreneurship guidance

### Payment System
- Payment-ready architecture for Razorpay integration
- Workshop enrollment payments
- Event registration payments
- Donation support
- Payment history tracking

### Feedback System
- Star rating system (1-5 stars)
- Category-based feedback
- Comments and suggestions
- Admin analytics dashboard

### Questionnaire System
- Create custom questionnaires
- Multiple question types (text, rating, choice)
- Response collection and viewing
- Active/inactive status management

### Admin Panel
- Dashboard with statistics and charts
- User management with search
- Event management (CRUD operations)
- Workshop management (CRUD operations)
- Feedback viewing and analytics
- Questionnaire management
- Database viewer for all tables
- Role-based access control

### Security
- CSRF Protection on all forms
- Input validation and sanitization
- SQL injection prevention via ORM
- XSS protection via template escaping
- Secure session cookies (HttpOnly, SameSite)
- Password hashing with salt

## Technology Stack

| Technology | Purpose |
|------------|---------|
| Flask 3.0 | Web framework |
| SQLAlchemy | ORM for database |
| Flask-Login | User session management |
| Flask-WTF | Form handling with CSRF |
| SQLite | Database (auto-creates on launch) |
| Tailwind CSS | Utility-first CSS framework |
| Lucide Icons | Icon library |
| Chart.js | Admin dashboard charts |
| Gunicorn | Production WSGI server |

## Project Structure

```
VOXFEM/
├── app.py                      # Main Flask application
├── ai_assistant.py             # AI career assistant engine
├── forms.py                    # WTForms form classes
├── utils.py                    # Utility functions & seed data
├── models.py                   # SQLAlchemy database models
├── config.py                   # Configuration settings
├── voxfem.db                   # SQLite database (auto-created)
├── requirements.txt            # Python dependencies
├── Dockerfile                  # Docker container config
├── install.sh                  # Linux/macOS installer
├── install.bat                 # Windows installer
├── README.md                   # Project documentation
├── uploads/                    # User uploads
│   ├── profiles/               # Profile images
│   ├── events/                 # Event banners
│   └── workshops/              # Workshop images
├── static/
│   ├── css/style.css           # Custom styles
│   ├── js/main.js              # JavaScript functionality
│   ├── assets/videos/          # Video backgrounds
│   └── images/                 # Static images
└── templates/
    ├── base.html               # Base layout
    ├── home.html               # Landing page
    ├── about.html              # About page
    ├── founders.html           # Founders page
    ├── login.html              # Login page
    ├── register.html           # Registration page
    ├── dashboard.html          # User dashboard
    ├── profile.html            # User profile
    ├── workshops.html          # Workshops listing
    ├── events.html             # Events listing
    ├── event_detail.html       # Event details
    ├── workshop_detail.html    # Workshop details
    ├── feedback.html           # Feedback form
    ├── questionnaire.html      # Questionnaire page
    ├── payments.html           # Payment history
    ├── payment_workshop.html   # Workshop payment
    ├── contact.html            # Contact page
    ├── chatbot.html            # AI chat interface
    ├── 404.html                # Not found page
    ├── 500.html                # Server error page
    ├── includes/               # Reusable components
    │   ├── nav.html
    │   ├── footer.html
    │   └── flash_messages.html
    └── admin/                  # Admin panel
        ├── base.html
        ├── dashboard.html
        ├── users.html
        ├── events.html
        ├── workshops.html
        ├── feedback.html
        ├── questionnaires.html
        └── database.html
```

## Installation

### Quick Start - Linux/macOS

```bash
# Clone or extract the project
cd VOXFEM

# Run the installer
bash install.sh

# Activate virtual environment
source venv/bin/activate

# Run the application
python app.py
```

### Quick Start - Windows

```cmd
:: Extract the project
cd VOXFEM

:: Run the installer
install.bat

:: Activate virtual environment
venv\Scripts\activate.bat

:: Run the application
python app.py
```

### Manual Installation

```bash
# Create virtual environment
python -m venv venv

# Activate (Linux/macOS)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate.bat

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

### Docker Deployment

```bash
# Build the image
docker build -t voxfem .

# Run the container
docker run -p 5000:5000 -v $(pwd)/uploads:/app/uploads -v $(pwd)/voxfem.db:/app/voxfem.db voxfem
```

### Hugging Face Spaces Deployment

1. Create a new Space on Hugging Face
2. Select "Docker" as the SDK
3. Upload all project files
4. The Dockerfile will handle the rest

## Default Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@voxfem.com | admin123 |
| Founder | fiza@voxfem.com | fiza123 |
| Co-Founder | noor@voxfem.com | noor123 |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | (dev fallback) | Flask secret key |
| `DATABASE_URL` | `sqlite:///voxfem.db` | Database connection |
| `FLASK_ENV` | `development` | Environment mode |
| `RAZORPAY_KEY_ID` | (placeholder) | Razorpay API key |
| `RAZORPAY_KEY_SECRET` | (placeholder) | Razorpay API secret |
| `PORT` | `5000` | Server port |

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/stats` | GET | Public statistics |
| `/api/events` | GET | Events JSON |
| `/api/workshops` | GET | Workshops JSON |
| `/api/feedback/recent` | GET | Recent feedback |
| `/chatbot/ask` | POST | AI assistant chat |

## Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Primary Pink | `#ec4899` | Buttons, accents, links |
| Light Pink | `#f9a8d4` | Secondary accents |
| Rose | `#fb7185` | Tags, badges |
| Soft Lavender | `#e9d5ff` | Gradients, backgrounds |
| Background | `#fff7fb` | Page background |
| Dark Text | `#111827` | Primary text |

## Contact

- **Location**: Bengaluru, India
- **Email**: fiza.speakofficial@gmail.com
- **Instagram**: [@fiza.speaksofficial](https://www.instagram.com/fiza.speaksofficial)
- **YouTube**: [@fizakhanum-636](https://www.youtube.com/@fizakhanum-636)
- **WhatsApp**: [Join Community](https://chat.whatsapp.com/Eaxt81A7NG5BAQ94KEVWhl)
- **Founder**: +91 6360386637
- **Co-Founder**: +91 9606239322

## License

This project is proprietary software built for VOXFEM (C2G).

## Acknowledgments

Built with passion for empowering women and youth. Special thanks to the entire VOXFEM community for their continuous support and feedback.

**Connect. Create. Grow.**
