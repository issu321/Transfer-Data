"""
VOXFEM (C2G) - Utilities
Helper functions, decorators, and utility classes.
"""

import os
import secrets
from functools import wraps
from flask import flash, redirect, url_for, current_app
from flask_login import current_user
from werkzeug.utils import secure_filename


# Allowed file extensions for uploads
ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
ALLOWED_VIDEO_EXTENSIONS = {'mp4', 'webm', 'ogg'}


def admin_required(f):
    """Decorator to restrict route access to admin users only."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login', next=current_app.request.path if hasattr(current_app, 'request') else None))
        if not current_user.is_admin:
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


def allowed_file(filename, allowed_extensions):
    """Check if a file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


def save_uploaded_file(file, folder='profiles'):
    """Save an uploaded file with a secure random filename.
    
    Args:
        file: The uploaded file object from request.files
        folder: Subfolder within UPLOAD_FOLDER (profiles, events, workshops)
    
    Returns:
        str: The relative path to the saved file, or None if failed
    """
    if file and allowed_file(file.filename, ALLOWED_IMAGE_EXTENSIONS):
        # Generate secure random filename
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = secure_filename(f"{secrets.token_hex(16)}.{ext}")
        upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], folder)
        os.makedirs(upload_dir, exist_ok=True)
        filepath = os.path.join(upload_dir, filename)
        file.save(filepath)
        return os.path.join('uploads', folder, filename)
    return None


def get_file_url(filepath):
    """Get the URL path for a file.
    
    Args:
        filepath: Relative path like 'uploads/profiles/abc.jpg'
    
    Returns:
        str: URL path like '/uploads/profiles/abc.jpg'
    """
    if filepath:
        return '/' + filepath.replace(os.sep, '/')
    return None


def generate_unique_filename(original_filename):
    """Generate a unique secure filename."""
    ext = original_filename.rsplit('.', 1)[1].lower() if '.' in original_filename else ''
    return f"{secrets.token_hex(12)}.{ext}"


def truncate_text(text, max_length=100, suffix='...'):
    """Truncate text to specified length."""
    if not text:
        return ''
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)].rsplit(' ', 1)[0] + suffix


def format_price(amount, currency='INR'):
    """Format price with currency symbol."""
    if amount <= 0:
        return 'Free'
    symbols = {'INR': '₹', 'USD': '$', 'EUR': '€'}
    symbol = symbols.get(currency, '₹')
    return f"{symbol}{amount:,.0f}"


def format_datetime(dt, format_str='%d %b %Y, %I:%M %p'):
    """Format datetime object to string."""
    if not dt:
        return 'TBA'
    return dt.strftime(format_str)


def format_date(d, format_str='%d %b %Y'):
    """Format date object to string."""
    if not d:
        return 'TBA'
    return d.strftime(format_str)


def get_star_rating(rating):
    """Get star characters for a numeric rating.
    
    Args:
        rating: Integer 1-5
    
    Returns:
        str: Star characters (filled and empty)
    """
    if not rating:
        return '☆☆☆☆☆'
    filled = min(5, max(1, int(rating)))
    return '★' * filled + '☆' * (5 - filled)


def paginate(query, page=1, per_page=10):
    """Paginate a SQLAlchemy query.
    
    Args:
        query: SQLAlchemy query object
        page: Current page number (1-indexed)
        per_page: Items per page
    
    Returns:
        Pagination object with items, has_next, has_prev, pages, etc.
    """
    return query.paginate(page=page, per_page=per_page, error_out=False)


def get_dashboard_stats():
    """Get statistics for admin dashboard.
    
    Returns:
        dict: Various statistics
    """
    from models import (
        User, Event, Workshop, Feedback, EventRegistration,
        WorkshopEnrollment, ContactMessage, PaymentOrder, db
    )
    
    return {
        'total_users': User.query.count(),
        'total_events': Event.query.filter_by(is_active=True).count(),
        'total_workshops': Workshop.query.filter_by(is_active=True).count(),
        'total_feedback': Feedback.query.count(),
        'total_event_registrations': EventRegistration.query.count(),
        'total_workshop_enrollments': WorkshopEnrollment.query.count(),
        'total_contact_messages': ContactMessage.query.count(),
        'unread_messages': ContactMessage.query.filter_by(is_read=False).count(),
        'avg_rating': db.session.query(db.func.avg(Feedback.rating)).scalar() or 0,
        'total_revenue': db.session.query(db.func.sum(PaymentOrder.amount)).filter_by(status='paid').scalar() or 0,
        'recent_users': User.query.order_by(User.created_at.desc()).limit(5).all(),
        'recent_feedback': Feedback.query.order_by(Feedback.created_at.desc()).limit(5).all(),
        'recent_messages': ContactMessage.query.order_by(ContactMessage.created_at.desc()).limit(5).all(),
    }


def get_public_stats():
    """Get public-facing statistics for landing page.
    
    Returns:
        dict: Public statistics
    """
    from models import User, Event, Workshop, Feedback, EventRegistration, db
    
    return {
        'total_members': User.query.count(),
        'total_workshops': Workshop.query.filter_by(is_active=True).count(),
        'total_events': Event.query.filter_by(is_active=True).count(),
        'satisfaction_rate': 100,
        'avg_rating': round(db.session.query(db.func.avg(Feedback.rating)).scalar() or 5.0, 1),
    }


def seed_database():
    """Seed the database with initial data if empty."""
    from models import (
        User, Event, Workshop, Questionnaire, Question, db
    )
    from werkzeug.security import generate_password_hash
    from datetime import datetime, timedelta
    import random
    
    # Check if already seeded
    if User.query.first():
        return
    
    # Create admin user
    admin = User(
        full_name='VOXFEM Admin',
        email='admin@voxfem.com',
        phone='6360386637',
        is_admin=True,
        bio='Platform Administrator for VOXFEM.',
        interests='Leadership,Education,Community Building'
    )
    admin.set_password('admin123')
    db.session.add(admin)
    
    # Create founder user
    founder = User(
        full_name='Fiza Khan',
        email='fiza@voxfem.com',
        phone='6360386637',
        is_admin=True,
        bio='Founder of VOXFEM. Passionate about empowering students and women.',
        interests='LinkedIn,Branding,AI,Leadership,Entrepreneurship'
    )
    founder.set_password('fiza123')
    db.session.add(founder)
    
    # Create co-founder user
    cofounder = User(
        full_name='Noor Hoorain',
        email='noor@voxfem.com',
        phone='9606239322',
        bio='Co-Founder of VOXFEM. Committed to driving meaningful change.',
        interests='Leadership,Innovation,Community,Education'
    )
    cofounder.set_password('noor123')
    db.session.add(cofounder)
    
    # Create sample events
    events_data = [
        {
            'title': 'Leadership Summit 2024',
            'description': 'An inspiring summit featuring industry leaders sharing their journeys and insights on leadership in the modern workplace. Learn from the best and connect with like-minded individuals.',
            'date': datetime.now().date() + timedelta(days=15),
            'time': datetime.strptime('14:00', '%H:%M').time(),
            'location': 'Bengaluru Convention Center',
            'speaker': 'Fiza Khan',
            'speaker_bio': 'Founder of VOXFEM, leadership coach, and youth empowerment advocate with 5+ years of experience.',
            'max_attendees': 200
        },
        {
            'title': 'AI for Women Workshop',
            'description': 'Discover how artificial intelligence is transforming industries and learn practical AI skills to boost your career. No prior technical experience required.',
            'date': datetime.now().date() + timedelta(days=30),
            'time': datetime.strptime('10:00', '%H:%M').time(),
            'location': 'VOXFEM Studio, Bengaluru',
            'speaker': 'Noor Hoorain',
            'speaker_bio': 'Co-Founder of VOXFEM, AI enthusiast, and innovation strategist.',
            'max_attendees': 50
        },
        {
            'title': 'Networking Mixer 2024',
            'description': 'Connect with professionals, mentors, and peers in a relaxed, supportive environment. Build meaningful relationships that will help you grow personally and professionally.',
            'date': datetime.now().date() + timedelta(days=45),
            'time': datetime.strptime('18:00', '%H:%M').time(),
            'location': 'The Social, Bengaluru',
            'speaker': 'Fiza Khan & Team',
            'speaker_bio': 'Join the VOXFEM team for an evening of meaningful connections.',
            'max_attendees': 100
        }
    ]
    
    for event_data in events_data:
        event = Event(**event_data)
        db.session.add(event)
    
    # Create sample workshops
    workshops_data = [
        {
            'title': 'LinkedIn Mastery',
            'description': 'Transform your LinkedIn profile into a powerful career tool. Learn profile optimization, content strategy, networking techniques, and how to leverage LinkedIn for job opportunities and personal branding.',
            'instructor': 'Fiza Khan',
            'category': 'LinkedIn',
            'duration': '3 hours',
            'schedule': datetime.now() + timedelta(days=10),
            'price': 499,
            'max_seats': 30
        },
        {
            'title': 'Personal Branding Essentials',
            'description': 'Build a strong personal brand that sets you apart. Discover your unique value proposition, create a consistent brand identity, and learn strategies to establish yourself as a thought leader in your field.',
            'instructor': 'Fiza Khan',
            'category': 'Branding',
            'duration': '2 hours',
            'schedule': datetime.now() + timedelta(days=20),
            'price': 399,
            'max_seats': 25
        },
        {
            'title': 'AI Literacy for Beginners',
            'description': 'Get started with artificial intelligence in this beginner-friendly workshop. Understand AI concepts, explore popular AI tools, and learn how to use AI to enhance your productivity and creativity.',
            'instructor': 'Noor Hoorain',
            'category': 'AI',
            'duration': '2.5 hours',
            'schedule': datetime.now() + timedelta(days=25),
            'price': 299,
            'max_seats': 40
        },
        {
            'title': 'Leadership Fundamentals',
            'description': 'Develop core leadership skills including communication, team management, decision-making, and emotional intelligence. Perfect for aspiring leaders and those looking to enhance their leadership capabilities.',
            'instructor': 'Fiza Khan',
            'category': 'Leadership',
            'duration': '4 hours',
            'schedule': datetime.now() + timedelta(days=35),
            'price': 599,
            'max_seats': 20
        },
        {
            'title': 'Entrepreneurship 101',
            'description': 'Learn the fundamentals of starting and growing a business. From ideation and validation to business planning and funding, this workshop covers everything you need to kickstart your entrepreneurial journey.',
            'instructor': 'Fiza Khan',
            'category': 'Entrepreneurship',
            'duration': '3 hours',
            'schedule': datetime.now() + timedelta(days=40),
            'price': 699,
            'max_seats': 25
        },
        {
            'title': 'Communication Skills Masterclass',
            'description': 'Enhance your communication skills for professional success. Learn public speaking, presentation skills, effective writing, and interpersonal communication techniques that will help you excel in any setting.',
            'instructor': 'Noor Hoorain',
            'category': 'Communication',
            'duration': '2 hours',
            'schedule': datetime.now() + timedelta(days=50),
            'price': 0,
            'max_seats': 50
        }
    ]
    
    for workshop_data in workshops_data:
        workshop = Workshop(**workshop_data)
        db.session.add(workshop)
    
    # Create sample questionnaire
    questionnaire = Questionnaire(
        title='Community Skill Assessment',
        description='Help us understand your skills and interests so we can tailor our workshops and events to your needs.',
        is_active=True
    )
    db.session.add(questionnaire)
    db.session.flush()  # Get the questionnaire ID
    
    # Add sample questions
    questions_data = [
        {
            'questionnaire_id': questionnaire.id,
            'question_text': 'What is your current profession or academic status?',
            'question_type': 'text',
            'order': 1
        },
        {
            'questionnaire_id': questionnaire.id,
            'question_text': 'Which areas are you most interested in developing? (Select all that apply)',
            'question_type': 'choice',
            'options': 'LinkedIn Optimization,Personal Branding,AI Literacy,Leadership,Entrepreneurship,Communication Skills,Portfolio Development,Networking',
            'order': 2
        },
        {
            'questionnaire_id': questionnaire.id,
            'question_text': 'How would you rate your current confidence in professional settings?',
            'question_type': 'rating',
            'order': 3
        },
        {
            'questionnaire_id': questionnaire.id,
            'question_text': 'What are your career goals for the next 1-2 years?',
            'question_type': 'text',
            'order': 4
        },
        {
            'questionnaire_id': questionnaire.id,
            'question_text': 'How did you hear about VOXFEM?',
            'question_type': 'choice',
            'options': 'Instagram,YouTube,WhatsApp,Friend/Family,Search Engine,Other',
            'order': 5
        }
    ]
    
    for question_data in questions_data:
        question = Question(**question_data)
        db.session.add(question)
    
    db.session.commit()
