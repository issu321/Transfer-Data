#!/bin/bash
# ============================================================================
# VOXFEM (C2G) - Linux/macOS Installation Script
# Women and Youth Empowerment Platform
# ============================================================================

set -e

echo "=========================================="
echo "  VOXFEM (C2G) - Installer"
echo "  Empowering Voices, Shaping Leaders"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check Python version
PYTHON_VERSION=$(python3 --version 2>/dev/null | awk '{print $2}' | cut -d. -f1,2)
REQUIRED_VERSION="3.11"

if [ -z "$PYTHON_VERSION" ]; then
    echo -e "${RED}Error: Python 3 is not installed.${NC}"
    echo "Please install Python 3.11 or higher."
    exit 1
fi

echo -e "${BLUE}Found Python $PYTHON_VERSION${NC}"

# Check if Python version is >= 3.11
if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo -e "${YELLOW}Warning: Python $PYTHON_VERSION detected. Python 3.11+ recommended.${NC}"
fi

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Create virtual environment
echo -e "${BLUE}Creating virtual environment...${NC}"
if [ -d "venv" ]; then
    echo -e "${YELLOW}Virtual environment already exists. Removing old one...${NC}"
    rm -rf venv
fi

python3 -m venv venv
echo -e "${GREEN}Virtual environment created.${NC}"

# Activate virtual environment
echo -e "${BLUE}Activating virtual environment...${NC}"
source venv/bin/activate

# Upgrade pip
echo -e "${BLUE}Upgrading pip...${NC}"
pip install --upgrade pip

# Install requirements
echo -e "${BLUE}Installing dependencies...${NC}"
pip install -r requirements.txt

echo -e "${GREEN}Dependencies installed successfully.${NC}"

# Create necessary directories
echo -e "${BLUE}Creating directories...${NC}"
mkdir -p uploads/profiles uploads/events uploads/workshops reports static/assets/videos

# Set permissions
chmod -R 755 uploads reports

echo -e "${GREEN}Directories created.${NC}"

# Initialize database
echo -e "${BLUE}Initializing database...${NC}"
python3 -c "
from app import app
from models import db
with app.app_context():
    db.create_all()
    print('Database initialized.')
"

echo -e "${GREEN}Database initialized with seed data.${NC}"

echo ""
echo "=========================================="
echo -e "${GREEN}  Installation Complete!${NC}"
echo "=========================================="
echo ""
echo "To start the application:"
echo ""
echo "  1. Activate virtual environment:"
echo "     source venv/bin/activate"
echo ""
echo "  2. Run the application:"
echo "     python app.py"
echo ""
echo "  Or use Gunicorn (production):"
echo "     gunicorn --bind 0.0.0.0:5000 --workers 4 app:app"
echo ""
echo "The application will be available at:"
echo "  http://localhost:5000"
echo ""
echo "Default admin credentials:"
echo "  Email: admin@voxfem.com"
echo "  Password: admin123"
echo ""
echo "=========================================="
