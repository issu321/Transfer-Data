@echo off
REM ============================================================================
REM VOXFEM (C2G) - Windows Installation Script
REM Women and Youth Empowerment Platform
REM ============================================================================

echo ==========================================
echo   VOXFEM (C2G) - Installer
echo   Empowering Voices, Shaping Leaders
echo ==========================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH.
    echo Please install Python 3.11 or higher from https://python.org
    pause
    exit /b 1
)

for /f "tokens=2" %%a in ('python --version') do set PYTHON_VERSION=%%a
echo Found Python %PYTHON_VERSION%

REM Create virtual environment
echo.
echo Creating virtual environment...
if exist "venv" (
    echo Virtual environment already exists. Removing old one...
    rmdir /s /q venv
)

python -m venv venv
if errorlevel 1 (
    echo Error: Failed to create virtual environment.
    pause
    exit /b 1
)
echo Virtual environment created.

REM Activate and install
echo.
echo Activating virtual environment...
call venv\Scripts\activate.bat

echo.
echo Upgrading pip...
python -m pip install --upgrade pip

echo.
echo Installing dependencies...
pip install -r requirements.txt
if errorlevel 1 (
    echo Error: Failed to install dependencies.
    pause
    exit /b 1
)
echo Dependencies installed successfully.

REM Create directories
echo.
echo Creating directories...
if not exist "uploads" mkdir uploads
if not exist "uploads\profiles" mkdir uploads\profiles
if not exist "uploads\events" mkdir uploads\events
if not exist "uploads\workshops" mkdir uploads\workshops
if not exist "reports" mkdir reports
if not exist "static\assets\videos" mkdir static\assets\videos
echo Directories created.

REM Initialize database
echo.
echo Initializing database...
python -c "from app import app; from models import db; from utils import seed_database; app.app_context().push(); db.create_all(); seed_database(); print('Database initialized.')"

echo.
echo ==========================================
echo   Installation Complete!
echo ==========================================
echo.
echo To start the application:
echo.
echo   1. Activate virtual environment:
echo      venv\Scripts\activate.bat
echo.
echo   2. Run the application:
echo      python app.py
echo.
echo The application will be available at:
echo   http://localhost:5000
echo.
echo Default admin credentials:
echo   Email: admin@voxfem.com
echo   Password: admin123
echo.
pause
