"""Admin / event-coordinator routes: dashboard, events, venues, registrations,
attendance, notifications, reports and students."""

import io
from datetime import datetime

from openpyxl import Workbook

from flask import (Blueprint, Response, abort, flash, jsonify, redirect,
                   render_template, request, url_for)
from flask_login import current_user, login_required
from sqlalchemy import func

from app import db
from app.decorators import admin_required
from app.models import (Attendance, Event, Notification, NotificationRead,
                        Registration, User, Venue)

admin_bp = Blueprint('admin', __name__)

CATEGORIES = ['Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Fest', 'Competition', 'Other']
def _xlsx_response(filename, header, data):
    """Build an .xlsx workbook (styled header + auto column widths) and
    return it as a downloadable response."""
    wb = Workbook()
    ws = wb.active
    ws.title = filename.rsplit('.', 1)[0][:28] or 'Export'
    ws.append(header)
    for c in ws[1]:
        c.font = c.font.copy(bold=True, color='FFFFFF')
        c.fill = c.fill.copy(fgColor='4472C4')
    for row in data:
        ws.append([str(v) if v is not None else '' for v in row])
    for col_idx, cell in enumerate(ws[1], start=1):
        width = max(
            [len(str(cell.value or ''))] +
            [len(str(row[col_idx - 1])) for row in ws.iter_rows(min_row=2, values_only=True)]
        ) + 2
        ws.column_dimensions[cell.column_letter].width = min(width, 50)
    ws.freeze_panes = 'A2'

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return Response(
        buf.read(),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': f'attachment; filename={filename}'},
    )


# --------------------------------------------------------------------------
# Sorting helper
# --------------------------------------------------------------------------
STATUSES = ['Upcoming', 'Ongoing', 'Completed', 'Cancelled']


# --------------------------------------------------------------------------
# Sorting helper
# --------------------------------------------------------------------------
def apply_sort(query, sort_map, sort, order, default_column, default_order='asc'):
    """Order a query by a whitelisted sort column.
    `default_column` + `default_order` are used when no/invalid sort key given."""
    order = 'desc' if str(order).lower() == 'desc' else 'asc'
    if sort in sort_map:
        column = sort_map[sort]
    else:
        column = default_column
        order = default_order
    return query.order_by(column.desc() if order == 'desc' else column.asc())


def sort_args(args):
    """Extract (sort, order) from request.args."""
    sort = args.get('sort', '').strip()
    order = args.get('order', 'asc').strip()
    order = 'desc' if order == 'desc' else 'asc'
    return sort, order


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def parse_date(value):
    """Convert an HTML date string ('YYYY-MM-DD') to a date object."""
    if not value:
        return None
    try:
        return datetime.strptime(value, '%Y-%m-%d').date()
    except ValueError:
        return None


def parse_time(value):
    """Convert an HTML time string ('HH:MM') to a time object."""
    if not value:
        return None
    try:
        return datetime.strptime(value, '%H:%M').time()
    except ValueError:
        return None


def validate_event_form(form):
    """Return an error message string, or None if everything is valid."""
    title = form.get('title', '').strip()
    description = form.get('description', '').strip()
    event_date = parse_date(form.get('event_date'))
    start_time = parse_time(form.get('start_time'))
    end_time = parse_time(form.get('end_time'))
    venue_id = form.get('venue_id', '')
    category = form.get('category', '').strip()
    capacity = form.get('capacity', '')
    status = form.get('status', '').strip()

    if not title:
        return 'Event title is required.'
    if not description:
        return 'Description is required.'
    if not event_date:
        return 'A valid event date is required.'
    if not start_time:
        return 'A valid start time is required.'
    if not end_time:
        return 'A valid end time is required.'
    if end_time <= start_time:
        return 'End time must be later than start time.'
    if not venue_id or not Venue.query.get(venue_id):
        return 'Please select a valid venue.'
    if category not in CATEGORIES:
        return 'Please select a valid category.'
    try:
        capacity = int(capacity)
        if capacity <= 0:
            raise ValueError
    except (TypeError, ValueError):
        return 'Capacity must be a positive number.'
    if status not in STATUSES:
        return 'Please select a valid status.'

    deadline = form.get('registration_deadline', '').strip()
    if deadline:
        deadline_date = parse_date(deadline)
        if not deadline_date:
            return 'Registration deadline must be a valid date.'
        if deadline_date > event_date:
            return 'Registration deadline must be on or before the event date.'
    return None


def build_event_from_form(form):
    """Create an Event object from validated form data."""
    return Event(
        title=form.get('title', '').strip(),
        description=form.get('description', '').strip(),
        event_date=parse_date(form.get('event_date')),
        start_time=parse_time(form.get('start_time')),
        end_time=parse_time(form.get('end_time')),
        venue_id=int(form.get('venue_id')),
        category=form.get('category', '').strip(),
        capacity=int(form.get('capacity')),
        registration_deadline=parse_date(form.get('registration_deadline')),
        status=form.get('status', '').strip(),
    )


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------
@admin_bp.route('/admin/dashboard')
@login_required
@admin_required
def dashboard():
    total_events = Event.query.count()
    upcoming_events = Event.query.filter_by(status='Upcoming').count()
    total_students = User.query.filter_by(role='student').count()
    total_registrations = Registration.query.filter(
        Registration.status != 'Cancelled'
    ).count()
    total_venues = Venue.query.count()
    upcoming_event_registrations = Registration.query.join(Event).filter(
        Event.status == 'Upcoming', Registration.status != 'Cancelled'
    ).count()

    recent_events = Event.query.order_by(
        Event.created_at.desc()
    ).limit(5).all()

    # Chart 1 - number of events for each category
    category_rows = db.session.query(
        Event.category, func.count(Event.id)
    ).group_by(Event.category).all()
    category_labels = [row[0] for row in category_rows]
    category_values = [row[1] for row in category_rows]

    # Chart 2 - number of registrations for each event
    reg_rows = db.session.query(
        Event.title, func.count(Registration.id)
    ).join(Registration, Registration.event_id == Event.id).filter(
        Registration.status != 'Cancelled'
    ).group_by(Event.id).order_by(func.count(Registration.id).desc()).all()
    reg_labels = [row[0] for row in reg_rows]
    reg_values = [row[1] for row in reg_rows]

    return render_template(
        'admin/dashboard.html',
        total_events=total_events,
        upcoming_events=upcoming_events,
        total_students=total_students,
        total_registrations=total_registrations,
        total_venues=total_venues,
        upcoming_event_registrations=upcoming_event_registrations,
        recent_events=recent_events,
        category_labels=category_labels,
        category_values=category_values,
        reg_labels=reg_labels,
        reg_values=reg_values,
    )


@admin_bp.route('/admin/api/stats')
@login_required
@admin_required
def api_stats():
    """JSON endpoint used by the dashboard's live auto-refresh."""
    return jsonify({
        'total_events': Event.query.count(),
        'upcoming_events': Event.query.filter_by(status='Upcoming').count(),
        'total_students': User.query.filter_by(role='student').count(),
        'total_registrations': Registration.query.filter(
            Registration.status != 'Cancelled'
        ).count(),
        'total_venues': Venue.query.count(),
        'upcoming_event_registrations': Registration.query.join(Event).filter(
            Event.status == 'Upcoming', Registration.status != 'Cancelled'
        ).count(),
    })


# --------------------------------------------------------------------------
# Event management
# --------------------------------------------------------------------------
@admin_bp.route('/admin/events')
@login_required
@admin_required
def events():
    q = request.args.get('q', '').strip()
    category = request.args.get('category', '').strip()
    status = request.args.get('status', '').strip()
    sort, order = sort_args(request.args)

    query = Event.query
    if q:
        query = query.filter(Event.title.ilike(f'%{q}%'))
    if category:
        query = query.filter(Event.category == category)
    if status:
        query = query.filter(Event.status == status)

    sort_map = {
        'title': Event.title,
        'date': Event.event_date,
        'category': Event.category,
        'capacity': Event.capacity,
        'status': Event.status,
        'venue': Event.venue_id,
    }
    query = apply_sort(query, sort_map, sort, order,
                       default_column=Event.event_date, default_order='desc')
    events = query.all()
    venues = Venue.query.order_by(Venue.name).all()

    return render_template(
        'admin/events.html',
        events=events,
        venues=venues,
        categories=CATEGORIES,
        statuses=STATUSES,
        q=q,
        category=category,
        status=status,
        sort=sort,
        order=order,
        bulk_url=url_for('admin.bulk_action', entity='events'),
        export_url=url_for('admin.export_list', entity='events', **request.args),
        bulk_actions=[
            {'key': 'status', 'label': 'Mark Upcoming', 'value': 'Upcoming'},
            {'key': 'status', 'label': 'Mark Ongoing', 'value': 'Ongoing'},
            {'key': 'status', 'label': 'Mark Completed', 'value': 'Completed'},
            {'key': 'status', 'label': 'Mark Cancelled', 'value': 'Cancelled'},
        ],
    )


@admin_bp.route('/admin/events/<int:event_id>')
@login_required
@admin_required
def event_detail(event_id):
    """Admin view of one event plus its registered students."""
    event = Event.query.get_or_404(event_id)
    registrations = Registration.query.filter_by(
        event_id=event.id, status='Confirmed'
    ).join(User).order_by(User.name).all()
    return render_template(
        'admin/event_detail.html', event=event, registrations=registrations
    )


@admin_bp.route('/admin/events/new', methods=['GET', 'POST'])
@login_required
@admin_required
def create_event():
    venues = Venue.query.order_by(Venue.name).all()

    if request.method == 'POST':
        error = validate_event_form(request.form)
        if error:
            flash(error, 'danger')
            return render_template(
                'admin/event_form.html', venues=venues,
                categories=CATEGORIES, statuses=STATUSES, form=request.form, event=None
            )
        event = build_event_from_form(request.form)
        db.session.add(event)
        db.session.commit()
        flash('Event created successfully.', 'success')
        return redirect(url_for('admin.events'))

    return render_template(
        'admin/event_form.html', venues=venues,
        categories=CATEGORIES, statuses=STATUSES, form=None, event=None
    )


@admin_bp.route('/admin/events/<int:event_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_event(event_id):
    event = Event.query.get_or_404(event_id)
    venues = Venue.query.order_by(Venue.name).all()

    if request.method == 'POST':
        error = validate_event_form(request.form)
        if error:
            flash(error, 'danger')
            return render_template(
                'admin/event_form.html', venues=venues,
                categories=CATEGORIES, statuses=STATUSES,
                form=request.form, event=event
            )
        data = build_event_from_form(request.form)
        event.title = data.title
        event.description = data.description
        event.event_date = data.event_date
        event.start_time = data.start_time
        event.end_time = data.end_time
        event.venue_id = data.venue_id
        event.category = data.category
        event.capacity = data.capacity
        event.registration_deadline = data.registration_deadline
        event.status = data.status
        db.session.commit()
        flash('Event updated successfully.', 'success')
        return redirect(url_for('admin.events'))

    return render_template(
        'admin/event_form.html', venues=venues,
        categories=CATEGORIES, statuses=STATUSES, form=None, event=event
    )


@admin_bp.route('/admin/events/<int:event_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_event(event_id):
    event = Event.query.get_or_404(event_id)
    # Remove child records first to keep the database clean.
    Notification.query.filter_by(event_id=event.id).delete()
    Attendance.query.filter_by(event_id=event.id).delete()
    Registration.query.filter_by(event_id=event.id).delete()
    db.session.delete(event)
    db.session.commit()
    flash('Event deleted successfully.', 'success')
    return redirect(url_for('admin.events'))


# --------------------------------------------------------------------------
# Venue management
# --------------------------------------------------------------------------
def _validate_venue_form(form):
    name = form.get('name', '').strip()
    location = form.get('location', '').strip()
    capacity = form.get('capacity', '')
    if not name:
        return 'Venue name is required.'
    if not location:
        return 'Venue location is required.'
    try:
        capacity = int(capacity)
        if capacity <= 0:
            raise ValueError
    except (TypeError, ValueError):
        return 'Capacity must be a positive number.'
    return None


@admin_bp.route('/admin/venues')
@login_required
@admin_required
def venues():
    sort, order = sort_args(request.args)
    sort_map = {
        'name': Venue.name,
        'location': Venue.location,
        'capacity': Venue.capacity,
    }
    venues = apply_sort(Venue.query, sort_map, sort, order,
                        default_column=Venue.name).all()
    return render_template(
        'admin/venues.html', venues=venues,
        sort=sort, order=order,
        bulk_url=url_for('admin.bulk_action', entity='venues'),
        export_url=url_for('admin.export_list', entity='venues'),
        bulk_actions=[],
    )


@admin_bp.route('/admin/venues/new', methods=['GET', 'POST'])
@login_required
@admin_required
def create_venue():
    if request.method == 'POST':
        error = _validate_venue_form(request.form)
        if error:
            flash(error, 'danger')
            return render_template('admin/venue_form.html', form=request.form)
        venue = Venue(
            name=request.form.get('name', '').strip(),
            location=request.form.get('location', '').strip(),
            capacity=int(request.form.get('capacity')),
            description=request.form.get('description', '').strip(),
        )
        db.session.add(venue)
        db.session.commit()
        flash('Venue added successfully.', 'success')
        return redirect(url_for('admin.venues'))
    return render_template('admin/venue_form.html', form=None)


@admin_bp.route('/admin/venues/<int:venue_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_venue(venue_id):
    venue = Venue.query.get_or_404(venue_id)
    if request.method == 'POST':
        error = _validate_venue_form(request.form)
        if error:
            flash(error, 'danger')
            return render_template('admin/venue_form.html', venue=venue, form=request.form)
        venue.name = request.form.get('name', '').strip()
        venue.location = request.form.get('location', '').strip()
        venue.capacity = int(request.form.get('capacity'))
        venue.description = request.form.get('description', '').strip()
        db.session.commit()
        flash('Venue updated successfully.', 'success')
        return redirect(url_for('admin.venues'))
    return render_template('admin/venue_form.html', venue=venue, form=None)


@admin_bp.route('/admin/venues/<int:venue_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_venue(venue_id):
    venue = Venue.query.get_or_404(venue_id)
    event_count = Event.query.filter_by(venue_id=venue.id).count()
    if event_count:
        flash(f'Cannot delete this venue — {event_count} event(s) use it.', 'danger')
    else:
        db.session.delete(venue)
        db.session.commit()
        flash('Venue deleted successfully.', 'success')
    return redirect(url_for('admin.venues'))


# --------------------------------------------------------------------------
# Registrations
# --------------------------------------------------------------------------
@admin_bp.route('/admin/registrations')
@login_required
@admin_required
def registrations():
    q = request.args.get('q', '').strip()
    event_id = request.args.get('event', '').strip()
    sort, order = sort_args(request.args)

    query = Registration.query.join(User).join(Event)
    if q:
        query = query.filter(
            db.or_(
                Event.title.ilike(f'%{q}%'),
                User.name.ilike(f'%{q}%'),
                User.email.ilike(f'%{q}%'),
            )
        )
    if event_id:
        query = query.filter(Registration.event_id == int(event_id))

    sort_map = {
        'student': User.name,
        'event': Event.title,
        'date': Event.event_date,
        'registered_at': Registration.registered_at,
        'status': Registration.status,
    }
    query = apply_sort(query, sort_map, sort, order,
                       default_column=Registration.registered_at,
                       default_order='desc')
    regs = query.all()
    events = Event.query.order_by(Event.title).all()
    return render_template(
        'admin/registrations.html', registrations=regs,
        events=events, q=q, event_id=event_id,
        sort=sort, order=order,
        bulk_url=url_for('admin.bulk_action', entity='registrations'),
        export_url=url_for('admin.export_list', entity='registrations', **request.args),
        bulk_actions=[
            {'key': 'cancel', 'label': 'Cancel selected'},
            {'key': 'restore', 'label': 'Restore selected'},
        ],
    )


@admin_bp.route('/admin/registrations/<int:registration_id>/cancel', methods=['POST'])
@login_required
@admin_required
def cancel_registration(registration_id):
    registration = Registration.query.get_or_404(registration_id)
    if registration.status == 'Cancelled':
        flash('This registration is already cancelled.', 'warning')
    else:
        registration.status = 'Cancelled'
        db.session.commit()
        flash('Registration cancelled.', 'success')
    return redirect(request.referrer or url_for('admin.registrations'))


@admin_bp.route('/admin/registrations/<int:registration_id>/restore', methods=['POST'])
@login_required
@admin_required
def restore_registration(registration_id):
    registration = Registration.query.get_or_404(registration_id)
    event = registration.event
    if registration.status == 'Cancelled' and not event.is_full():
        registration.status = 'Confirmed'
        db.session.commit()
        flash('Registration restored.', 'success')
    else:
        flash('Could not restore registration.', 'danger')
    return redirect(request.referrer or url_for('admin.registrations'))


@admin_bp.route('/admin/registrations/<int:registration_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_registration(registration_id):
    registration = Registration.query.get_or_404(registration_id)
    Attendance.query.filter_by(
        event_id=registration.event_id, student_id=registration.student_id
    ).delete()
    db.session.delete(registration)
    db.session.commit()
    flash('Registration record deleted.', 'success')
    return redirect(request.referrer or url_for('admin.registrations'))


# --------------------------------------------------------------------------
# Attendance management
# --------------------------------------------------------------------------
@admin_bp.route('/admin/attendance')
@login_required
@admin_required
def attendance():
    events = Event.query.order_by(Event.event_date.desc()).all()
    return render_template('admin/attendance.html', events=events)


@admin_bp.route('/admin/attendance/<int:event_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def attendance_event(event_id):
    event = Event.query.get_or_404(event_id)

    if request.method == 'POST':
        students = Registration.query.filter_by(
            event_id=event.id, status='Confirmed'
        ).all()
        for reg in students:
            value = request.form.get(f'status_{reg.student_id}')
            if value not in ('Present', 'Absent'):
                continue
            record = Attendance.query.filter_by(
                event_id=event.id, student_id=reg.student_id
            ).first()
            if record:
                record.status = value
                record.marked_at = datetime.now()
            else:
                db.session.add(Attendance(
                    event_id=event.id, student_id=reg.student_id, status=value
                ))
        db.session.commit()
        flash('Attendance updated successfully.', 'success')
        return redirect(url_for('admin.attendance_event', event_id=event.id))

    regs = Registration.query.filter_by(
        event_id=event.id, status='Confirmed'
    ).join(User).order_by(User.name).all()

    attendance_map = {
        record.student_id: record for record in
        Attendance.query.filter_by(event_id=event.id).all()
    }
    return render_template(
        'admin/attendance_event.html', event=event,
        registrations=regs, attendance_map=attendance_map,
    )


# --------------------------------------------------------------------------
# Notifications
# --------------------------------------------------------------------------
@admin_bp.route('/admin/notifications')
@login_required
@admin_required
def notifications():
    sort, order = sort_args(request.args)
    sort_map = {
        'event': Notification.event_id,
        'title': Notification.title,
        'created_at': Notification.created_at,
    }
    notifications = apply_sort(Notification.query, sort_map, sort, order,
                               default_column=Notification.created_at,
                               default_order='desc').all()
    # Mark every shown notification as read for this admin.
    _mark_notifications_read(current_user.id, notifications)
    return render_template(
        'admin/notifications.html', notifications=notifications,
        sort=sort, order=order,
        bulk_url=url_for('admin.bulk_action', entity='notifications'),
        export_url=url_for('admin.export_list', entity='notifications'),
        bulk_actions=[],
    )


def _mark_notifications_read(user_id, notifications):
    """Insert NotificationRead rows for the given notifications & user."""
    existing = {
        r.notification_id for r in NotificationRead.query.filter_by(
            user_id=user_id
        ).all()
    }
    added = 0
    for n in notifications:
        if n.id not in existing:
            db.session.add(NotificationRead(user_id=user_id, notification_id=n.id))
            added += 1
    if added:
        db.session.commit()


@admin_bp.route('/admin/notifications/new', methods=['GET', 'POST'])
@login_required
@admin_required
def create_notification():
    events = Event.query.order_by(Event.event_date.desc()).all()
    if request.method == 'POST':
        event_id = request.form.get('event_id', '')
        title = request.form.get('title', '').strip()
        message = request.form.get('message', '').strip()
        if not event_id or not Event.query.get(event_id):
            flash('Please select an event.', 'danger')
        elif not title or not message:
            flash('Notification title and message are required.', 'danger')
        else:
            db.session.add(Notification(
                event_id=int(event_id), title=title, message=message
            ))
            db.session.commit()
            flash('Notification created successfully.', 'success')
            return redirect(url_for('admin.notifications'))
    return render_template(
        'admin/notification_form.html', events=events
    )


@admin_bp.route('/admin/notifications/<int:notification_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_notification(notification_id):
    notification = Notification.query.get_or_404(notification_id)
    db.session.delete(notification)
    db.session.commit()
    flash('Notification deleted.', 'success')
    return redirect(url_for('admin.notifications'))


# --------------------------------------------------------------------------
# Reports
# --------------------------------------------------------------------------
def _participant_rows(event_id=None):
    """Rows for the participant report (student, email, event, dates, attendance)."""
    query = Registration.query.join(User).join(Event)
    if event_id:
        query = query.filter(Registration.event_id == int(event_id))
    regs = query.order_by(Event.event_date.desc(), User.name).all()

    attendance_map = {}
    for record in Attendance.query.all():
        attendance_map[(record.event_id, record.student_id)] = record.status

    rows = []
    for reg in regs:
        rows.append({
            'student_name': reg.student.name,
            'email': reg.student.email,
            'event': reg.event.title,
            'event_date': reg.event.event_date,
            'registered_at': reg.registered_at,
            'attendance': attendance_map.get((reg.event_id, reg.student_id), 'Not Marked'),
        })
    return rows


def _event_report_rows(category=None, status=None, q=None):
    query = Event.query
    if category:
        query = query.filter(Event.category == category)
    if status:
        query = query.filter(Event.status == status)
    if q:
        query = query.filter(Event.title.ilike(f'%{q}%'))
    events = query.order_by(Event.event_date.desc()).all()

    return [{
        'event': e.title,
        'date': e.event_date,
        'venue': e.venue.name if e.venue else '-',
        'category': e.category,
        'registrations': e.registration_count(),
        'capacity': e.capacity,
        'status': e.status,
    } for e in events]


def _attendance_report_rows(event_id=None):
    query = Attendance.query.join(User).join(Event)
    if event_id:
        query = query.filter(Attendance.event_id == int(event_id))
    records = query.order_by(Event.event_date.desc(), User.name).all()
    return [{
        'event': r.event.title,
        'student': r.student.name,
        'status': r.status,
        'marked_at': r.marked_at,
    } for r in records]


@admin_bp.route('/admin/reports')
@login_required
@admin_required
def reports():
    report_type = request.args.get('type', 'event')
    events = Event.query.order_by(Event.title).all()

    if report_type == 'event':
        event_rows = _event_report_rows(
            category=request.args.get('category', '').strip() or None,
            status=request.args.get('status', '').strip() or None,
            q=request.args.get('q', '').strip() or None,
        )
        participant_rows = []
        attendance_rows = []
    elif report_type == 'participant':
        event_rows = []
        participant_rows = _participant_rows(request.args.get('event', '').strip() or None)
        attendance_rows = []
    elif report_type == 'attendance':
        event_rows = []
        participant_rows = []
        attendance_rows = _attendance_report_rows(request.args.get('event', '').strip() or None)
    else:
        event_rows = []
        participant_rows = []
        attendance_rows = []

    export_url = url_for('admin.export_report', **request.args)

    return render_template(
        'admin/reports.html',
        report_type=report_type,
        events=events,
        event_rows=event_rows,
        participant_rows=participant_rows,
        attendance_rows=attendance_rows,
        categories=CATEGORIES,
        statuses=STATUSES,
        request_args=request.args,
        export_url=export_url,
    )


@admin_bp.route('/admin/reports/export')
@login_required
@admin_required
def export_report():
    """Excel export of the currently selected report."""
    report_type = request.args.get('type', 'event')

    if report_type == 'participant':
        rows = _participant_rows(request.args.get('event', '').strip() or None)
        header = ['Student Name', 'Email', 'Event', 'Event Date', 'Registered At', 'Attendance']
        data = [(
            r['student_name'], r['email'], r['event'],
            r['event_date'].strftime('%d %b %Y'),
            r['registered_at'].strftime('%d %b %Y %I:%M %p'),
            r['attendance'],
        ) for r in rows]
        filename = 'participant_report.xlsx'
    elif report_type == 'attendance':
        rows = _attendance_report_rows(request.args.get('event', '').strip() or None)
        header = ['Event', 'Student', 'Attendance Status', 'Marked At']
        data = [(
            r['event'], r['student'], r['status'],
            r['marked_at'].strftime('%d %b %Y %I:%M %p'),
        ) for r in rows]
        filename = 'attendance_report.xlsx'
    else:
        rows = _event_report_rows(
            category=request.args.get('category', '').strip() or None,
            status=request.args.get('status', '').strip() or None,
            q=request.args.get('q', '').strip() or None,
        )
        header = ['Event', 'Date', 'Venue', 'Category', 'Registrations', 'Capacity', 'Status']
        data = [(
            r['event'], r['date'].strftime('%d %b %Y'), r['venue'],
            r['category'], r['registrations'], r['capacity'], r['status'],
        ) for r in rows]
        filename = 'event_report.xlsx'

    return _xlsx_response(filename, header, data)


# --------------------------------------------------------------------------
# Students
# --------------------------------------------------------------------------
@admin_bp.route('/admin/students')
@login_required
@admin_required
def students():
    q = request.args.get('q', '').strip()
    sort, order = sort_args(request.args)
    query = User.query.filter_by(role='student')
    if q:
        query = query.filter(
            db.or_(User.name.ilike(f'%{q}%'), User.email.ilike(f'%{q}%'))
        )
    sort_map = {
        'name': User.name,
        'email': User.email,
        'created_at': User.created_at,
    }
    query = apply_sort(query, sort_map, sort, order,
                       default_column=User.created_at, default_order='desc')
    students = query.all()

    registration_counts = dict(
        db.session.query(Registration.student_id, func.count(Registration.id))
        .filter(Registration.status != 'Cancelled')
        .group_by(Registration.student_id).all()
    )
    return render_template(
        'admin/students.html', students=students,
        registration_counts=registration_counts, q=q,
        sort=sort, order=order,
        bulk_url=url_for('admin.bulk_action', entity='students'),
        export_url=url_for('admin.export_list', entity='students', **request.args),
        bulk_actions=[],
    )


@admin_bp.route('/admin/students/<int:student_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_student(student_id):
    student = User.query.get_or_404(student_id)
    if student.role != 'student':
        flash('Cannot delete an admin account.', 'danger')
        return redirect(url_for('admin.students'))
    Registration.query.filter_by(student_id=student.id).delete()
    Attendance.query.filter_by(student_id=student.id).delete()
    db.session.delete(student)
    db.session.commit()
    flash(f'Student "{student.name}" deleted successfully.', 'success')
    return redirect(url_for('admin.students'))


# --------------------------------------------------------------------------
# Bulk actions (select rows -> run an action: status/cancel/restore/delete)
# --------------------------------------------------------------------------
BULK_ENTITIES = {'events', 'registrations', 'venues', 'students', 'notifications'}


@admin_bp.route('/admin/bulk/<entity>', methods=['POST'])
@login_required
@admin_required
def bulk_action(entity):
    """Run a bulk action on the selected records of an entity.

    Form fields: ids[] (selected ids), action, optional value.
    Supported per-entity actions:
      events        -> delete | status (value = new status)
      registrations -> delete | cancel | restore
      venues        -> delete
      students      -> delete
      notifications -> delete
    """
    if entity not in BULK_ENTITIES:
        abort(404)

    action = request.form.get('action', 'delete').strip()
    value = request.form.get('value', '').strip()
    ids = [int(i) for i in request.form.getlist('ids') if str(i).strip().isdigit()]
    if not ids:
        flash('No items were selected.', 'warning')
        return redirect(request.referrer or url_for('admin.dashboard'))

    deleted = updated = skipped = 0

    if entity == 'events':
        if action == 'status' and value in STATUSES:
            for eid in ids:
                event = Event.query.get(eid)
                if event:
                    event.status = value
                    updated += 1
        elif action == 'delete':
            for eid in ids:
                event = Event.query.get(eid)
                if event:
                    Notification.query.filter_by(event_id=eid).delete()
                    Attendance.query.filter_by(event_id=eid).delete()
                    Registration.query.filter_by(event_id=eid).delete()
                    db.session.delete(event)
                    deleted += 1
        else:
            flash('Unknown bulk action.', 'danger')
            return redirect(request.referrer or url_for('admin.events'))
    elif entity == 'registrations':
        if action == 'cancel':
            for rid in ids:
                reg = Registration.query.get(rid)
                if reg:
                    reg.status = 'Cancelled'
                    updated += 1
        elif action == 'restore':
            for rid in ids:
                reg = Registration.query.get(rid)
                if reg and reg.status == 'Cancelled' and not reg.event.is_full():
                    reg.status = 'Confirmed'
                    updated += 1
                else:
                    skipped += 1
        elif action == 'delete':
            for rid in ids:
                reg = Registration.query.get(rid)
                if reg:
                    Attendance.query.filter_by(
                        event_id=reg.event_id, student_id=reg.student_id
                    ).delete()
                    db.session.delete(reg)
                    deleted += 1
        else:
            flash('Unknown bulk action.', 'danger')
            return redirect(request.referrer or url_for('admin.registrations'))
    elif entity == 'venues' and action == 'delete':
        for vid in ids:
            venue = Venue.query.get(vid)
            if venue and not Event.query.filter_by(venue_id=vid).count():
                db.session.delete(venue)
                deleted += 1
            elif venue:
                skipped += 1
    elif entity == 'students' and action == 'delete':
        for sid in ids:
            student = User.query.get(sid)
            if student and student.role == 'student':
                Registration.query.filter_by(student_id=sid).delete()
                Attendance.query.filter_by(student_id=sid).delete()
                db.session.delete(student)
                deleted += 1
    elif entity == 'notifications' and action == 'delete':
        Notification.query.filter(Notification.id.in_(ids)).delete(
            synchronize_session=False
        )
        deleted = len(ids)
    else:
        flash('That action is not supported for this list.', 'danger')
        return redirect(request.referrer or url_for('admin.dashboard'))

    db.session.commit()

    messages = []
    if deleted:
        messages.append(f'{deleted} deleted')
    if updated:
        messages.append(f'{updated} updated')
    if skipped:
        messages.append(f'{skipped} skipped')
    flash(', '.join(messages) + '.', 'success' if (deleted or updated) else 'warning')
    return redirect(request.referrer or url_for('admin.dashboard'))


# --------------------------------------------------------------------------
# Export current (filtered) list to CSV
# --------------------------------------------------------------------------
@admin_bp.route('/admin/export/<entity>')
@login_required
@admin_required
def export_list(entity):
    """Export the currently filtered/sorted rows of a list page as Excel."""
    if entity not in BULK_ENTITIES:
        abort(404)

    if entity == 'events':
        q = request.args.get('q', '').strip()
        category = request.args.get('category', '').strip()
        status = request.args.get('status', '').strip()
        query = Event.query
        if q:
            query = query.filter(Event.title.ilike(f'%{q}%'))
        if category:
            query = query.filter(Event.category == category)
        if status:
            query = query.filter(Event.status == status)
        rows = query.order_by(Event.event_date.desc()).all()
        header = ['Title', 'Date', 'Venue', 'Category', 'Capacity',
                  'Registrations', 'Status']
        data = [(e.title, e.event_date.strftime('%d %b %Y'),
                 e.venue.name if e.venue else '-', e.category, e.capacity,
                 e.registration_count(), e.status) for e in rows]
    elif entity == 'registrations':
        q = request.args.get('q', '').strip()
        event_id = request.args.get('event', '').strip()
        query = Registration.query.join(User).join(Event)
        if q:
            query = query.filter(db.or_(
                Event.title.ilike(f'%{q}%'), User.name.ilike(f'%{q}%'),
                User.email.ilike(f'%{q}%')))
        if event_id:
            query = query.filter(Registration.event_id == int(event_id))
        rows = query.order_by(Registration.registered_at.desc()).all()
        header = ['Student', 'Email', 'Event', 'Event Date',
                  'Registered On', 'Status']
        data = [(r.student.name, r.student.email, r.event.title,
                 r.event.event_date.strftime('%d %b %Y'),
                 r.registered_at.strftime('%d %b %Y %I:%M %p'),
                 r.status) for r in rows]
    elif entity == 'venues':
        rows = Venue.query.order_by(Venue.name).all()
        header = ['Name', 'Location', 'Capacity', 'Description', 'Events']
        data = [(v.name, v.location, v.capacity, v.description or '',
                 v.events.count()) for v in rows]
    elif entity == 'students':
        q = request.args.get('q', '').strip()
        query = User.query.filter_by(role='student')
        if q:
            query = query.filter(db.or_(
                User.name.ilike(f'%{q}%'), User.email.ilike(f'%{q}%')))
        rows = query.order_by(User.created_at.desc()).all()
        counts = dict(db.session.query(
            Registration.student_id, func.count(Registration.id)
        ).filter(Registration.status != 'Cancelled')
            .group_by(Registration.student_id).all())
        header = ['Name', 'Email', 'Registrations', 'Joined On']
        data = [(s.name, s.email, counts.get(s.id, 0),
                 s.created_at.strftime('%d %b %Y')) for s in rows]
    elif entity == 'notifications':
        rows = Notification.query.order_by(Notification.created_at.desc()).all()
        header = ['Event', 'Title', 'Message', 'Created On']
        data = [(n.event.title, n.title, n.message,
                 n.created_at.strftime('%d %b %Y %I:%M %p')) for n in rows]

    return _xlsx_response(f'{entity}.xlsx', header, data)