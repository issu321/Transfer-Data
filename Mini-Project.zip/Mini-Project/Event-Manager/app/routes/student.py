"""Student dashboard, my-events and notifications routes."""

from flask import (Blueprint, jsonify, render_template, request)
from flask_login import current_user, login_required

from app import db
from app.models import (Attendance, Event, Notification, NotificationRead,
                        Registration)
from app.decorators import student_required

student_bp = Blueprint('student', __name__)


@student_bp.route('/student/dashboard')
@login_required
@student_required
def dashboard():
    upcoming = Event.query.filter(
        Event.status.in_(['Upcoming', 'Ongoing'])
    ).order_by(Event.event_date.asc()).limit(6).all()

    my_events = Event.query.join(Registration).filter(
        Registration.student_id == current_user.id,
        Registration.status == 'Confirmed',
    ).order_by(Event.event_date.asc()).all()

    total_registrations = Registration.query.filter_by(
        student_id=current_user.id, status='Confirmed'
    ).count()

    recent_notifications = Notification.query.order_by(
        Notification.created_at.desc()
    ).limit(5).all()

    registered_ids = {
        r.event_id for r in Registration.query.filter_by(
            student_id=current_user.id, status='Confirmed'
        ).all()
    }

    return render_template(
        'student/dashboard.html',
        upcoming=upcoming,
        my_events=my_events,
        total_registrations=total_registrations,
        notifications=recent_notifications,
        registered_ids=registered_ids,
    )


@student_bp.route('/student/my-events')
@login_required
@student_required
def my_events():
    """Registrations belonging to the logged-in student only."""
    registrations = Registration.query.filter_by(
        student_id=current_user.id
    ).order_by(Registration.registered_at.desc()).all()

    # Attendance status for each registration (may be None / not marked yet).
    attendance_map = {
        a.event_id: a.status for a in Attendance.query.filter_by(
            student_id=current_user.id
        ).all()
    }

    return render_template(
        'student/my_events.html',
        registrations=registrations,
        attendance_map=attendance_map,
    )


@student_bp.route('/student/notifications')
@login_required
@student_required
def notifications():
    notifications = Notification.query.order_by(
        Notification.created_at.desc()
    ).all()
    # Mark all as read when the student opens the notifications page.
    existing = {
        r.notification_id for r in NotificationRead.query.filter_by(
            user_id=current_user.id
        ).all()
    }
    for n in notifications:
        if n.id not in existing:
            db.session.add(NotificationRead(user_id=current_user.id,
                                            notification_id=n.id))
    db.session.commit()
    return render_template(
        'student/notifications.html', notifications=notifications
    )


def _unread_for(user_id):
    """Return (unread_count, latest_unread_notifications)."""
    read_ids = {r.notification_id for r in NotificationRead.query.filter_by(
        user_id=user_id
    ).all()}
    recent = Notification.query.order_by(
        Notification.created_at.desc()
    ).limit(30).all()
    unread = [n for n in recent if n.id not in read_ids]
    return len(unread), unread


@student_bp.route('/api/notifications/unread')
@login_required
def unread_notifications():
    """Live unread-notification feed for the topbar bell (any logged-in user)."""
    count, unread = _unread_for(current_user.id)
    items = [{
        'id': n.id,
        'title': n.title,
        'message': n.message,
        'event': n.event.title,
        'created_at': n.created_at.strftime('%d %b %Y, %I:%M %p'),
    } for n in unread[:6]]
    return jsonify({'count': count, 'items': items})


@student_bp.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def mark_notification_read():
    """Mark a single notification read for the current user."""
    notification_id = request.form.get('notification_id', '').strip()
    if notification_id and notification_id.isdigit():
        notification_id = int(notification_id)
        exists = Notification.query.get(notification_id)
        already = NotificationRead.query.filter_by(
            user_id=current_user.id, notification_id=notification_id
        ).first()
        if exists and not already:
            db.session.add(NotificationRead(
                user_id=current_user.id, notification_id=notification_id
            ))
            db.session.commit()
    return jsonify({'ok': True})