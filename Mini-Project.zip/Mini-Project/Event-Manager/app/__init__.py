"""Flask application factory.

Creates the app, the database, Flask-Login and registers all blueprints.
"""

from flask import Flask, render_template
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy

from config import Config

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Please login to continue.'
login_manager.login_message_category = 'warning'


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)

    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.events import events_bp
    from app.routes.student import student_bp
    from app.routes.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(events_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(admin_bp)

    from app.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @app.context_processor
    def inject_globals():
        from datetime import datetime
        return {
            'current_year': datetime.now().year,
            'today': datetime.now,
        }

    # Error pages
    @app.errorhandler(404)
    def not_found(error):
        return render_template('errors/404.html'), 404

    @app.errorhandler(403)
    def forbidden(error):
        return render_template('errors/403.html'), 403

    # Create tables automatically on first run (schema only, no demo data)
    with app.app_context():
        db.create_all()
        _ensure_default_accounts()

    return app


def _ensure_default_accounts():
    """Create the default admin + a demo student on a fresh database so
    the documented demo credentials always work, even after resetting the
    DB file. Uses the same credentials as seed.py."""
    from werkzeug.security import generate_password_hash
    from app.models import User

    if User.query.filter_by(role='admin').count() == 0:
        db.session.add(User(
            name='Event Coordinator',
            email='admin@college.edu',
            password_hash=generate_password_hash('admin123'),
            role='admin',
        ))

    if User.query.filter_by(email='student@college.edu').count() == 0:
        db.session.add(User(
            name='Demo Student',
            email='student@college.edu',
            password_hash=generate_password_hash('student123'),
            role='student',
        ))

    db.session.commit()