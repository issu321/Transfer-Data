/* ==========================================================================
   College Event Management System — animated front-end (vanilla JS)
   ========================================================================== */
(function () {
  'use strict';

  // -------------------------------------------------------------------
  // Sidebar toggle (works on desktop + mobile)
  // -------------------------------------------------------------------
  var sidebarToggle = document.getElementById('sidebarToggle');

  if (sidebarToggle) {
    sidebarToggle.addEventListener('click', function () {
      if (window.innerWidth >= 992) {
        document.body.classList.toggle('sidebar-collapsed');
      } else {
        document.body.classList.toggle('sidebar-open');
      }
    });
  }

  var sidebarBackdrop = document.getElementById('sidebarBackdrop');
  if (sidebarBackdrop) {
    sidebarBackdrop.addEventListener('click', function () {
      document.body.classList.remove('sidebar-open');
    });
  }

  // Close mobile sidebar automatically after clicking a nav link.
  document.querySelectorAll('.sidebar-nav a').forEach(function (link) {
    link.addEventListener('click', function () {
      if (window.innerWidth < 992) {
        document.body.classList.remove('sidebar-open');
      }
    });
  });

  // -------------------------------------------------------------------
  // Auto-dismiss flash alerts after 5 seconds
  // -------------------------------------------------------------------
  document.querySelectorAll('.flash-alert').forEach(function (alert) {
    setTimeout(function () {
      var bootstrapAlert = bootstrap.Alert.getOrCreateInstance(alert);
      bootstrapAlert.close();
    }, 5000);
  });

  // -------------------------------------------------------------------
  // Confirm dialogs for dangerous forms (data-confirm attribute)
  // -------------------------------------------------------------------
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      var message = form.getAttribute('data-confirm') ||
        'Are you sure you want to do this?';
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  });

  // -------------------------------------------------------------------
  // Reports page: show/hide filter fields depending on report type
  // -------------------------------------------------------------------
  var reportTypeSelect = document.getElementById('reportTypeSelect');
  if (reportTypeSelect) {
    var toggleReportFilters = function () {
      var isEvent = reportTypeSelect.value === 'event';
      document.querySelectorAll('.filter-for-event').forEach(function (el) {
        el.style.display = isEvent ? '' : 'none';
      });
      document.querySelectorAll('.filter-for-other').forEach(function (el) {
        el.style.display = isEvent ? 'none' : '';
      });
    };
    reportTypeSelect.addEventListener('change', function () {
      toggleReportFilters();
      reportTypeSelect.form.submit();
    });
    toggleReportFilters();
  }

  // =====================================================================
  // ANIMATIONS
  // =====================================================================

  // -------------------------------------------------------------------
  // 1. Count-up animation for dashboard stat numbers
  // -------------------------------------------------------------------
  function animateCountUp(el) {
    var end = parseFloat(el.textContent.replace(/,/g, ''));
    if (isNaN(end)) return;
    var duration = 900;
    var startTime = null;
    var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var progress = Math.min((timestamp - startTime) / duration, 1);
      var value = Math.round(easeOut(progress) * end);
      el.textContent = value.toLocaleString();
      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.textContent = end.toLocaleString();
      }
    }
    requestAnimationFrame(step);
  }

  document.querySelectorAll('.stat-number').forEach(function (el) {
    animateCountUp(el);
  });

  // -------------------------------------------------------------------
  // 2. Scroll-reveal animation using IntersectionObserver
  // -------------------------------------------------------------------
  var revealTargets = document.querySelectorAll(
    '.card.form-card, .card.table-card, .card.filter-card, ' +
    '.card.chart-card, .card.event-card, .welcome-banner, .registration-panel, ' +
    '.stat-mini, .card.profile-card'
  );

  if ('IntersectionObserver' in window) {
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });

    revealTargets.forEach(function (el) {
      el.classList.add('reveal');
      revealObserver.observe(el);
    });
  }

  // -------------------------------------------------------------------
  // 3. Ripple effect on buttons
  // -------------------------------------------------------------------
  document.querySelectorAll('.btn').forEach(function (btn) {
    btn.addEventListener('click', function (event) {
      if (btn.classList.contains('disabled') || btn.disabled) return;
      var rect = btn.getBoundingClientRect();
      var diameter = Math.max(rect.width, rect.height) * 1.1;
      var ripple = document.createElement('span');
      ripple.className = 'ripple';
      ripple.style.width = ripple.style.height = diameter + 'px';
      ripple.style.left = (event.clientX - rect.left - diameter / 2) + 'px';
      ripple.style.top = (event.clientY - rect.top - diameter / 2) + 'px';
      btn.appendChild(ripple);
      setTimeout(function () { ripple.remove(); }, 650);
    });
  });

  // -------------------------------------------------------------------
  // 4. Subtle 3D tilt on event cards (desktop only)
  // -------------------------------------------------------------------
  if (window.matchMedia('(min-width: 992px)').matches &&
      window.matchMedia('(hover: hover)').matches) {
    document.querySelectorAll('.event-card').forEach(function (card) {
      card.addEventListener('mousemove', function (event) {
        var rect = card.getBoundingClientRect();
        var x = (event.clientX - rect.left) / rect.width - 0.5;
        var y = (event.clientY - rect.top) / rect.height - 0.5;
        card.style.transform = 'perspective(700px) rotateY(' + (x * 6) +
          'deg) rotateX(' + (-y * 6) + 'deg) translateY(-6px)';
      });
      card.addEventListener('mouseleave', function () {
        card.style.transform = '';
      });
    });
  }

  // -------------------------------------------------------------------
  // 5. Confetti celebration on success flash messages
  // -------------------------------------------------------------------
  var CONFETTI_COLORS = ['#ec4899', '#d946ef', '#a855f7', '#f472b6', '#c084fc', '#f0abfc'];

  function fireConfetti(amount) {
    amount = amount || 70;
    for (var i = 0; i < amount; i++) {
      (function () {
        var piece = document.createElement('div');
        piece.className = 'confetti-piece';
        piece.style.left = Math.random() * 100 + 'vw';
        piece.style.background = CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)];
        piece.style.animationDuration = (2.2 + Math.random() * 2.2) + 's';
        piece.style.animationDelay = (Math.random() * 0.8) + 's';
        var size = 6 + Math.random() * 8;
        piece.style.width = size + 'px';
        piece.style.height = (size * 1.4) + 'px';
        if (Math.random() > 0.5) {
          piece.style.borderRadius = '50%';
        }
        document.body.appendChild(piece);
        setTimeout(function () { piece.remove(); }, 5200);
      })();
    }
  }

  // Celebrate on registration/login success messages
  document.querySelectorAll('.flash-alert').forEach(function (alert) {
    var text = alert.textContent || '';
    if (/successfully registered|successfully|welcome back|account created/i.test(text)) {
      fireConfetti(90);
    }
  });

  // -------------------------------------------------------------------
  // 6. Toast helper (reusable, pink themed)
  // -------------------------------------------------------------------
  window.showToast = function (message, type) {
    var container = document.getElementById('toastContainer');
    if (!container) return;
    type = type || 'success';
    var colors = {
      success: 'text-bg-success',
      danger: 'text-bg-danger',
      warning: 'text-bg-warning',
      info: 'text-bg-info'
    };
    var el = document.createElement('div');
    el.className = 'toast align-items-center border-0 ' + (colors[type] || colors.success);
    el.setAttribute('role', 'alert');
    el.innerHTML = '<div class="d-flex"><div class="toast-body">' + message +
      '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" ' +
      'data-bs-dismiss="toast"></button></div>';
    container.appendChild(el);
    var toast = new bootstrap.Toast(el, { delay: 3500 });
    toast.show();
    el.addEventListener('hidden.bs.toast', function () { el.remove(); });
  };

  // -------------------------------------------------------------------
  // 7. Client-side form validation styling for event forms
  // -------------------------------------------------------------------
  document.querySelectorAll('form#eventForm').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });

  // =====================================================================
  // BULK SELECTION (checkbox rows + "select all" + selected-row actions)
  // =====================================================================
  function allRowCheckboxes() {
    return Array.prototype.slice.call(
      document.querySelectorAll('tbody .row-checkbox')
    );
  }

  function setAllSelected(checked) {
    allRowCheckboxes().forEach(function (cb) { cb.checked = checked; });
    // Keep the header checkbox + toolbar toggle in sync.
    document.querySelectorAll('.select-all-checkbox').forEach(function (el) {
      el.checked = checked;
    });
    document.querySelectorAll('#selectAllToggle').forEach(function (el) {
      el.checked = checked;
    });
    updateBulkBar();
  }

  function updateBulkBar() {
    var rows = allRowCheckboxes();
    var rowsTotal = rows.length;
    var checked = rows.filter(function (cb) { return cb.checked; }).length;
    var allChecked = rowsTotal > 0 && checked === rowsTotal;
    var hasSelection = checked > 0;

    document.querySelectorAll('.bulk-selected-count').forEach(function (el) {
      el.textContent = checked;
    });
    document.querySelectorAll('.bulk-selected-total').forEach(function (el) {
      el.textContent = rowsTotal;
    });

    // Header checkbox + toolbar toggle should reflect "all selected".
    document.querySelectorAll('.select-all-checkbox').forEach(function (el) {
      el.checked = allChecked;
      el.indeterminate = checked > 0 && !allChecked;
    });
    document.querySelectorAll('#selectAllToggle').forEach(function (el) {
      el.checked = allChecked;
      el.indeterminate = checked > 0 && !allChecked;
    });

    // Buttons stay enabled; instead the whole bar "lights up" on selection
    // and the hint is replaced by the live count.
    var bar = document.getElementById('bulkActionBar');
    if (bar) {
      bar.classList.toggle('has-selection', hasSelection);
    }
    document.querySelectorAll('.bulk-hint').forEach(function (hint) {
      hint.style.display = hasSelection ? 'none' : '';
    });
  }

  // Header / toolbar "select all" toggles both drive setAllSelected.
  document.querySelectorAll('.select-all-checkbox').forEach(function (sel) {
    sel.addEventListener('change', function () {
      setAllSelected(sel.checked);
    });
  });
  document.querySelectorAll('#selectAllToggle').forEach(function (el) {
    el.addEventListener('change', function () {
      setAllSelected(el.checked);
    });
  });

  // A single row toggle re-evaluates the state bar.
  allRowCheckboxes().forEach(function (cb) {
    cb.addEventListener('change', updateBulkBar);
  });

  // Pro UX: click anywhere on a row to toggle its selection checkbox.
  document.querySelectorAll('table.selectable tbody tr').forEach(function (tr) {
    tr.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON' ||
          e.target.tagName === 'INPUT' || e.target.closest &&
          e.target.closest('a,button,form,input,label')) {
        return; // let links/buttons/forms behave normally
      }
      var cb = tr.querySelector('.row-checkbox');
      if (cb) {
        cb.checked = !cb.checked;
        updateBulkBar();
      }
    });
  });

  // Gather selected ids from the row checkboxes.
  function selectedIds() {
    var ids = [];
    document.querySelectorAll('.row-checkbox:checked').forEach(function (cb) {
      ids.push(cb.value);
    });
    return ids;
  }

  // Submit the hidden bulk form to a given URL with action/value.
  function submitBulk(actionUrl, action, value, confirmMessage) {
    var ids = selectedIds();
    if (!ids.length) {
      window.showToast('Select at least one row first.', 'warning');
      return;
    }
    if (confirmMessage && !window.confirm(confirmMessage)) {
      return;
    }
    var form = document.getElementById('bulkActionForm');
    form.action = actionUrl;
    form.innerHTML = '';
    var set = function (name, val) {
      var input = document.createElement('input');
      input.type = 'hidden';
      input.name = name;
      input.value = val;
      form.appendChild(input);
    };
    set('action', action);
    if (value) { set('value', value); }
    ids.forEach(function (id) { set('ids', id); });
    form.submit();
  }

  window.bulkDelete = function (actionUrl) {
    submitBulk(actionUrl, 'delete', '',
      'Delete ' + selectedIds().length + ' selected record(s)? ' +
      'This action cannot be undone.');
  };

  window.bulkAction = function (actionUrl, key, value) {
    var label = 'Apply this action to ' + selectedIds().length +
      ' selected record(s)?';
    submitBulk(actionUrl, key, value, label);
  };

  window.clearSelection = function () {
    allRowCheckboxes().forEach(function (cb) { cb.checked = false; });
    document.querySelectorAll('.select-all-checkbox').forEach(function (el) {
      el.checked = false; el.indeterminate = false;
    });
    document.querySelectorAll('#selectAllToggle').forEach(function (el) {
      el.checked = false; el.indeterminate = false;
    });
    updateBulkBar();
  };

  // -------------------------------------------------------------------
  // Server-side sorting: keep current filters, toggle sort column/order.
  // -------------------------------------------------------------------
  window.sortBy = function (key) {
    var params = new URLSearchParams(window.location.search);
    var cur = params.get('sort') || '';
    var order = params.get('order') || 'asc';
    order = (cur === key && order === 'asc') ? 'desc' : 'asc';
    params.set('sort', key);
    params.set('order', order);
    window.location.search = params.toString();
  };

  // -------------------------------------------------------------------
  // Live notification bell (topbar): poll unread count + dropdown items.
  // -------------------------------------------------------------------
  var notifBadge = document.getElementById('notifBadge');
  function refreshNotifications() {
    fetch('/api/notifications/unread', { headers: { 'Accept': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        var count = Number(data.count || 0);
        var items = data.items || [];
        if (notifBadge) {
          notifBadge.classList.toggle('d-none', count === 0);
          document.getElementById('notifCount').textContent = count > 99 ? '99+' : count;
        }
        var mc = document.getElementById('notifMenuCount');
        if (mc) { mc.textContent = count === 0 ? 'All caught up' : count + ' unread'; }
        var box = document.getElementById('notifItems');
        if (!box) return;
        if (count === 0) {
          box.innerHTML = '<p class="text-muted small text-center py-3">You are all caught up. 🎉</p>';
          return;
        }
        box.innerHTML = items.map(function (n) {
          return '<div class="notif-item">' +
            '<div class="notif-item-title"><i class="fa-solid fa-bell text-warning me-2"></i>' +
            window.escapeHtml(n.title) + '</div>' +
            '<div class="notif-item-msg">' +
            (n.event ? '<span class="badge badge-category">' + window.escapeHtml(n.event) + '</span> ' : '') +
            window.escapeHtml(n.message) + '</div>' +
            '<div class="notif-item-time"><i class="fa-regular fa-clock me-1"></i>' +
            window.escapeHtml(n.created_at) + '</div>' +
            '<button class="btn btn-xs btn-outline-secondary float-end" ' +
            'onclick="markNotificationRead(' + n.id + ', this)">Mark read</button>' +
            '</div>';
        }).join('');
      })
      .catch(function () { /* ignore transient errors */ });
  }

  window.escapeHtml = function (t) {
    return String(t).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  };

  window.markNotificationRead = function (nid, btn) {
    var body = 'notification_id=' + encodeURIComponent(nid);
    fetch('/api/notifications/mark-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    }).then(function () {
      if (btn) { btn.closest('.notif-item').remove(); }
      refreshNotifications();
    });
  };

  // Open the dropdown -> refresh right away.
  var notifDropdown = document.getElementById('notifDropdown');
  if (notifDropdown) {
    notifDropdown.addEventListener('show.bs.dropdown', refreshNotifications);
  }
  // Poll every 30s even while not open.
  refreshNotifications();
  setInterval(refreshNotifications, 30000);
})();