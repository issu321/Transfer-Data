"""SQLAlchemy models — one class per database table."""

from datetime import date, datetime

from flask_login import UserMixin

from app import db


class User(UserMixin, db.Model):
    """A user of the system. Role is either 'admin' or 'student'."""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)  # never store plaintext
    role = db.Column(db.String(20), nullable=False, default='student')
    created_at = db.Column(db.DateTime, default=datetime.now)

    registrations = db.relationship('Registration', backref='student', lazy='dynamic')
    attendance_records = db.relationship('Attendance', backref='student', lazy='dynamic')

    def is_admin(self):
        return self.role == 'admin'

    def __repr__(self):
        return f'<User {self.email}>'


class Venue(db.Model):
    """A college venue where events are held."""
    __tablename__ = 'venues'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(150), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text)

    events = db.relationship('Event', backref='venue', lazy='dynamic')

    def __repr__(self):
        return self.name


class Event(db.Model):
    """A college event."""
    __tablename__ = 'events'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    event_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    venue_id = db.Column(db.Integer, db.ForeignKey('venues.id'), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    registration_deadline = db.Column(db.Date, nullable=True)
    status = db.Column(db.String(20), nullable=False, default='Upcoming')
    created_at = db.Column(db.DateTime, default=datetime.now)

    registrations = db.relationship('Registration', backref='event', lazy='dynamic')
    attendance = db.relationship('Attendance', backref='event', lazy='dynamic')
    notifications = db.relationship('Notification', backref='event', lazy='dynamic')

    def registration_count(self):
        """Number of students currently registered (cancelled excluded)."""
        return self.registrations.filter(Registration.status != 'Cancelled').count()

    def is_full(self):
        return self.registration_count() >= self.capacity

    def deadline_passed(self):
        if not self.registration_deadline:
            return False
        return self.registration_deadline < date.today()

    def __repr__(self):
        return self.title


class Registration(db.Model):
    """A student registering for an event."""
    __tablename__ = 'registrations'

    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    registered_at = db.Column(db.DateTime, default=datetime.now)
    status = db.Column(db.String(20), nullable=False, default='Confirmed')

    # A student can register for the same event only once.
    __table_args__ = (
        db.UniqueConstraint('event_id', 'student_id', name='uq_event_student'),
    )

    def __repr__(self):
        return f'<Registration event={self.event_id} student={self.student_id}>'


class Attendance(db.Model):
    """Attendance record for a student in an event."""
    __tablename__ = 'attendance'

    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='Absent')  # Present / Absent
    marked_at = db.Column(db.DateTime, default=datetime.now)

    __table_args__ = (
        db.UniqueConstraint('event_id', 'student_id', name='uq_attendance_event_student'),
    )

    def __repr__(self):
        return f'<Attendance {self.status}>'


class Notification(db.Model):
    """A notification created by the admin for an event."""
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

    def __repr__(self):
        return f'<Notification {self.title}>'


class NotificationRead(db.Model):
    """Tracks which notification a user has read (per-user read receipts)."""
    __tablename__ = 'notification_reads'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    notification_id = db.Column(db.Integer, db.ForeignKey('notifications.id'), nullable=False)
    read_at = db.Column(db.DateTime, default=datetime.now)

    __table_args__ = (
        db.UniqueConstraint('user_id', 'notification_id', name='uq_user_notification_read'),
    )

    def __repr__(self):
        return f'<NotificationRead user={self.user_id} notif={self.notification_id}>'