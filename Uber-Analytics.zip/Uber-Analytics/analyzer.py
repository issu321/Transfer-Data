#!/usr/bin/env python3
"""
analyzer.py - Trip Analyzer Module
Comprehensive analytics for transportation data
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class TripAnalyzer:
    """Comprehensive transportation data analyzer"""
    
    def __init__(self, dataset_path):
        """Initialize with dataset"""
        self.dataset_path = dataset_path
        self.dataset = pd.read_csv(dataset_path)
        self._prepare_data()
    
    def _prepare_data(self):
        """Prepare data for analysis"""
        # Parse datetime if exists
        if 'pickup_datetime' in self.dataset.columns:
            self.dataset['pickup_datetime'] = pd.to_datetime(self.dataset['pickup_datetime'])
            self.dataset['pickup_hour'] = self.dataset['pickup_datetime'].dt.hour
            self.dataset['pickup_date'] = self.dataset['pickup_datetime'].dt.date
            self.dataset['day_of_week'] = self.dataset['pickup_datetime'].dt.dayofweek
        
        # Ensure numeric columns
        for col in ['distance', 'fare', 'passenger_count']:
            if col in self.dataset.columns:
                self.dataset[col] = pd.to_numeric(self.dataset[col], errors='coerce')
    
    # ==================== DEMAND ANALYSIS ====================
    
    def calculate_demand(self, pickup_date, pickup_time):
        """Calculate demand level for given date/time"""
        if not pickup_date or not pickup_time:
            return 'moderate'
        
        # Parse time
        hour = int(pickup_time.split(':')[0]) if ':' in str(pickup_time) else 12
        
        # Peak hours: 7-9 AM, 5-8 PM
        peak_hours = [7, 8, 9, 17, 18, 19]
        
        if hour in peak_hours:
            return 'high'
        elif hour in [12, 13, 14]:  # Lunch hours
            return 'moderate'
        else:
            return 'low'
    
    def calculate_surge_probability(self, demand_level, pickup_time):
        """Calculate surge pricing probability"""
        base_prob = 0.1
        
        if demand_level == 'high':
            base_prob = 0.6
        elif demand_level == 'moderate':
            base_prob = 0.3
        
        # Time factor
        hour = int(pickup_time.split(':')[0]) if ':' in str(pickup_time) else 12
        if hour in [7, 8, 17, 18]:
            base_prob += 0.2
        
        return min(base_prob, 1.0)
    
    def get_demand_heatmap(self):
        """Get demand heatmap data"""
        if 'pickup_hour' not in self.dataset.columns:
            # Create hourly demand
            hourly_demand = self.dataset.groupby('pickup_hour').size() if 'pickup_hour' in self.dataset.columns else pd.Series()
        else:
            hourly_demand = self.dataset.groupby('pickup_hour').size()
        
        return {
            'hourly_demand': hourly_demand.to_dict(),
            'peak_hours': [7, 8, 9, 17, 18, 19],
            'low_hours': [1, 2, 3, 4, 5, 6]
        }
    
    # ==================== FORECASTING ====================
    
    def forecast_next_hour_demand(self):
        """Predict next hour demand"""
        if 'pickup_hour' not in self.dataset.columns:
            return {'forecast': 'moderate', 'confidence': 0.7, 'trend': 'stable'}
        
        # Simple forecast based on historical data
        current_hour = datetime.now().hour
        historical_demand = self.dataset[self.dataset['pickup_hour'] == current_hour]
        
        if historical_demand.empty:
            return {'forecast': 'moderate', 'confidence': 0.5, 'trend': 'stable'}
        
        avg_demand = historical_demand.shape[0]
        forecast_level = 'high' if avg_demand > 50 else 'moderate' if avg_demand > 20 else 'low'
        
        return {
            'forecast': forecast_level,
            'confidence': 0.75,
            'trend': 'increasing' if avg_demand > 30 else 'stable',
            'predicted_value': int(avg_demand)
        }
    
    def forecast_daily_demand(self):
        """Predict daily demand"""
        if 'pickup_date' not in self.dataset.columns:
            return {'forecast': 'moderate', 'confidence': 0.6, 'trend': 'stable'}
        
        daily_counts = self.dataset.groupby('pickup_date').size()
        avg_daily = daily_counts.mean()
        
        forecast_level = 'high' if avg_daily > 500 else 'moderate' if avg_daily > 200 else 'low'
        
        return {
            'forecast': forecast_level,
            'confidence': 0.7,
            'trend': 'increasing' if avg_daily > 300 else 'stable',
            'predicted_value': int(avg_daily)
        }
    
    # ==================== LOCATION ANALYTICS ====================
    
    def get_popular_pickup_areas(self):
        """Get most popular pickup areas"""
        if 'pickup_location' not in self.dataset.columns:
            return []
        
        popular = self.dataset.groupby('pickup_location').size().reset_index(name='count')
        popular = popular.sort_values('count', ascending=False).head(10)
        
        return popular.to_dict('records')
    
    def get_popular_drop_areas(self):
        """Get most popular drop areas"""
        if 'drop_location' not in self.dataset.columns:
            return []
        
        popular = self.dataset.groupby('drop_location').size().reset_index(name='count')
        popular = popular.sort_values('count', ascending=False).head(10)
        
        return popular.to_dict('records')
    
    def get_revenue_zones(self):
        """Get high/low revenue zones"""
        if 'pickup_location' not in self.dataset.columns or 'fare' not in self.dataset.columns:
            return {'high_revenue': [], 'low_revenue': []}
        
        revenue_by_location = self.dataset.groupby('pickup_location')['fare'].sum()
        revenue_by_location = revenue_by_location.sort_values(ascending=False)
        
        high_revenue = revenue_by_location.head(5).to_dict()
        low_revenue = revenue_by_location.tail(5).to_dict()
        
        return {
            'high_revenue': high_revenue,
            'low_revenue': low_revenue
        }
    
    # ==================== ROUTE INTELLIGENCE ====================
    
    def get_top_routes(self):
        """Get top routes by frequency"""
        if 'pickup_location' not in self.dataset.columns or 'drop_location' not in self.dataset.columns:
            return []
        
        routes = self.dataset.groupby(['pickup_location', 'drop_location']).size()
        routes = routes.reset_index(name='count')
        routes = routes.sort_values('count', ascending=False).head(10)
        
        return routes.to_dict('records')
    
    def get_longest_routes(self):
        """Get longest routes"""
        if 'distance' not in self.dataset.columns:
            return []
        
        longest = self.dataset.nlargest(10, 'distance')
        
        return longest.to_dict('records')
    
    def get_shortest_routes(self):
        """Get shortest routes"""
        if 'distance' not in self.dataset.columns:
            return []
        
        shortest = self.dataset.nsmallest(10, 'distance')
        
        return shortest.to_dict('records')
    
    # ==================== RECOMMENDATIONS ====================
    
    def get_best_pickup_locations(self):
        """Get best pickup locations"""
        if 'pickup_location' not in self.dataset.columns:
            return []
        
        # Locations with high demand and revenue
        location_stats = self.dataset.groupby('pickup_location').agg({
            'fare': 'mean',
            'pickup_hour': 'count'
        })
        
        best = location_stats.sort_values('fare', ascending=False).head(5)
        
        return best.to_dict('records')
    
    def get_revenue_optimization_suggestions(self):
        """Get revenue optimization suggestions"""
        suggestions = []
        
        if 'fare' in self.dataset.columns:
            avg_fare = self.dataset['fare'].mean()
            suggestions.append({
                'type': 'pricing',
                'suggestion': f'Average fare is {avg_fare:.2f}. Consider dynamic pricing during peak hours',
                'impact': 'high'
            })
        
        if 'pickup_hour' in self.dataset.columns:
            peak_demand_hour = self.dataset.groupby('pickup_hour').size().idxmax()
            suggestions.append({
                'type': 'fleet',
                'suggestion': f'Peak demand at hour {peak_demand_hour}. Increase fleet size during this time',
                'impact': 'high'
            })
        
        return suggestions
    
    # ==================== EXECUTIVE KPI ====================
    
    def get_executive_kpi(self):
        """Get executive dashboard KPIs"""
        kpi = {
            'total_trips': len(self.dataset),
            'total_revenue': self.dataset['fare'].sum() if 'fare' in self.dataset.columns else 0,
            'average_fare': self.dataset['fare'].mean() if 'fare' in self.dataset.columns else 0,
            'average_distance': self.dataset['distance'].mean() if 'distance' in self.dataset.columns else 0,
            'peak_hour_revenue': 0,
            'passenger_trend': 'stable',
            'route_utilization': 0.75,
            'demand_growth': 0.15
        }
        
        # Peak hour revenue
        if 'pickup_hour' in self.dataset.columns and 'fare' in self.dataset.columns:
            peak_hour = self.dataset.groupby('pickup_hour')['fare'].sum().idxmax()
            kpi['peak_hour_revenue'] = self.dataset[self.dataset['pickup_hour'] == peak_hour]['fare'].sum()
        
        return kpi
    
    def get_all_analytics(self):
        """Get all analytics for reports"""
        return {
            'kpi': self.get_executive_kpi(),
            'demand_forecast': self.forecast_next_hour_demand(),
            'popular_pickup': self.get_popular_pickup_areas(),
            'popular_drop': self.get_popular_drop_areas(),
            'revenue_zones': self.get_revenue_zones(),
            'top_routes': self.get_top_routes(),
            'recommendations': self.get_revenue_optimization_suggestions()
        }
    
    # ==================== CORRELATION ====================
    
    def get_correlation_matrix(self):
        """Get correlation matrix"""
        numeric_cols = self.dataset.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) < 2:
            return {}
        
        correlation = self.dataset[numeric_cols].corr()
        
        return correlation.to_dict()
    
    # ==================== SEARCH ====================
    
    def search_locations(self, query):
        """Search locations"""
        if 'pickup_location' not in self.dataset.columns:
            return []
        
        results = self.dataset[self.dataset['pickup_location'].str.contains(query, case=False)]
        
        return results['pickup_location'].unique().tolist()
    
    def search_routes(self, query):
        """Search routes"""
        if 'pickup_location' not in self.dataset.columns or 'drop_location' not in self.dataset.columns:
            return []
        
        results = self.dataset[
            self.dataset['pickup_location'].str.contains(query, case=False) |
            self.dataset['drop_location'].str.contains(query, case=False)
        ]
        
        return results.to_dict('records')
    
    # ==================== UTILITY ====================
    
    def get_dataset_summary(self):
        """Get dataset summary"""
        return {
            'total_records': len(self.dataset),
            'columns': self.dataset.columns.tolist(),
            'numeric_columns': self.dataset.select_dtypes(include=[np.number]).columns.tolist()
        }