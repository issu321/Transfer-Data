#!/usr/bin/env python3
"""
app.py - Transportation Intelligence Platform Main Application
Production-ready Flask application with all routes and features
"""

import os
import sys
from flask import Flask, render_template, request, jsonify, url_for, redirect, session
from flask_cors import CORS
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from geopy.geocoders import Nominatim

# Import modules
from analyzer import TripAnalyzer
from geospatial import GeospatialEngine
from utils import DataManager, ReportGenerator

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
app.config['DEBUG'] = False
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

# Initialize managers
data_manager = DataManager()
analyzer = None
geospatial = GeospatialEngine()
report_generator = ReportGenerator()

# Load dataset if exists
dataset_path = 'data/trips.csv'
if os.path.exists(dataset_path):
    analyzer = TripAnalyzer(dataset_path)
    data_manager.load_dataset(dataset_path)

# ==================== ROUTES ====================

@app.route('/')
def home():
    """Home page"""
    return render_template('home.html', 
                         total_trips=data_manager.total_trips if data_manager.dataset else 0,
                         total_revenue=data_manager.total_revenue if data_manager.dataset else 0)

@app.route('/trip-planner')
def trip_planner():
    """Trip Planner page"""
    return render_template('trip_planner.html')

@app.route('/map-dashboard')
def map_dashboard():
    """Interactive Map Dashboard page"""
    return render_template('map_dashboard.html')

@app.route('/location-analytics')
def location_analytics():
    """Location Analytics page"""
    return render_template('location_analytics.html')

@app.route('/route-intelligence')
def route_intelligence():
    """Route Intelligence page"""
    return render_template('route_intelligence.html')

@app.route('/demand-forecasting')
def demand_forecasting():
    """AI Demand Forecasting page"""
    return render_template('demand_forecasting.html')

@app.route('/recommendations')
def recommendations():
    """AI Recommendations page"""
    return render_template('recommendations.html')

@app.route('/executive-dashboard')
def executive_dashboard():
    """Executive Business Dashboard page"""
    return render_template('executive_dashboard.html')

@app.route('/visualization-center')
def visualization_center():
    """Advanced Visualization Center page"""
    return render_template('visualization_center.html')

@app.route('/dataset-comparison')
def dataset_comparison():
    """Dataset Comparison Engine page"""
    return render_template('dataset_comparison.html')

@app.route('/insights')
def insights():
    """Automated Insight Generator page"""
    return render_template('insights.html')

@app.route('/real-time-analytics')
def real_time_analytics():
    """Real-Time Analytics Dashboard page"""
    return render_template('real_time_analytics.html')

@app.route('/search-filter')
def search_filter():
    """Search & Filter Center page"""
    return render_template('search_filter.html')

@app.route('/reports')
def reports():
    """Report Center page"""
    return render_template('reports.html')

# ==================== API ENDPOINTS ====================

@app.route('/api/trip-planner/calculate', methods=['POST'])
def calculate_trip():
    """Calculate trip details: distance, time, fare, demand, surge"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    data = request.json
    from_loc = data.get('from_location')
    to_loc = data.get('to_location')
    pickup_date = data.get('pickup_date')
    pickup_time = data.get('pickup_time')
    passenger_count = data.get('passenger_count', 1)
    
    # Get coordinates
    from_coords = geospatial.get_coordinates(from_loc)
    to_coords = geospatial.get_coordinates(to_loc)
    
    if not from_coords or not to_coords:
        return jsonify({'error': 'Could not locate addresses'}), 400
    
    # Calculate distance (Haversine)
    distance = geospatial.calculate_distance(from_coords, to_coords)
    
    # Estimate travel time (average speed 40 km/h)
    avg_speed = 40.0  # km/h
    travel_time = distance / avg_speed * 60  # minutes
    
    # Calculate fare range
    base_fare = 20.0
    per_km_fare = 12.0
    fare_min = base_fare + per_km_fare * distance * 0.9
    fare_max = base_fare + per_km_fare * distance * 1.1
    
    # Calculate demand level
    demand_level = analyzer.calculate_demand(pickup_date, pickup_time)
    
    # Calculate surge probability
    surge_prob = analyzer.calculate_surge_probability(demand_level, pickup_time)
    
    return jsonify({
        'distance': round(distance, 2),
        'travel_time': round(travel_time, 1),
        'fare_min': round(fare_min, 2),
        'fare_max': round(fare_max, 2),
        'demand_level': demand_level,
        'surge_probability': round(surge_prob, 2),
        'from_coords': from_coords,
        'to_coords': to_coords
    })

@app.route('/api/map/get-route', methods=['POST'])
def get_route():
    """Get route between two points for map visualization"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    data = request.json
    from_coords = data.get('from_coords')
    to_coords = data.get('to_coords')
    
    route = geospatial.generate_route(from_coords, to_coords)
    
    return jsonify({
        'route': route,
        'distance': geospatial.calculate_distance(from_coords, to_coords)
    })

@app.route('/api/map/demand-heatmap', methods=['GET'])
def get_demand_heatmap():
    """Get demand heatmap data"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    heatmap_data = analyzer.get_demand_heatmap()
    
    return jsonify(heatmap_data)

@app.route('/api/location/popular-uploads', methods=['GET'])
def get_popular_pickup_areas():
    """Get most popular pickup areas"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    areas = analyzer.get_popular_pickup_areas()
    
    return jsonify(areas)

@app.route('/api/location/popular-drops', methods=['GET'])
def get_popular_drop_areas():
    """Get most popular drop areas"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    areas = analyzer.get_popular_drop_areas()
    
    return jsonify(areas)

@app.route('/api/location/revenue-zones', methods=['GET'])
def get_revenue_zones():
    """Get high/low revenue zones"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    zones = analyzer.get_revenue_zones()
    
    return jsonify(zones)

@app.route('/api/routes/top-routes', methods=['GET'])
def get_top_routes():
    """Get top routes"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    routes = analyzer.get_top_routes()
    
    return jsonify(routes)

@app.route('/api/routes/longest-routes', methods=['GET'])
def get_longest_routes():
    """Get longest routes"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    routes = analyzer.get_longest_routes()
    
    return jsonify(routes)

@app.route('/api/routes/shortest-routes', methods=['GET'])
def get_shortest_routes():
    """Get shortest routes"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    routes = analyzer.get_shortest_routes()
    
    return jsonify(routes)

@app.route('/api/forecast/next-hour', methods=['GET'])
def forecast_next_hour():
    """Predict next hour demand"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    forecast = analyzer.forecast_next_hour_demand()
    
    return jsonify(forecast)

@app.route('/api/forecast/daily', methods=['GET'])
def forecast_daily():
    """Predict daily demand"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    forecast = analyzer.forecast_daily_demand()
    
    return jsonify(forecast)

@app.route('/api/recommendations/best-pickup', methods=['GET'])
def get_best_pickup_locations():
    """Get best pickup locations"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    locations = analyzer.get_best_pickup_locations()
    
    return jsonify(locations)

@app.route('/api/recommendations/revenue-optimization', methods=['GET'])
def get_revenue_optimization():
    """Get revenue optimization suggestions"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    suggestions = analyzer.get_revenue_optimization_suggestions()
    
    return jsonify(suggestions)

@app.route('/api/dashboard/kpi', methods=['GET'])
def get_dashboard_kpi():
    """Get executive dashboard KPIs"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    kpi = analyzer.get_executive_kpi()
    
    return jsonify(kpi)

@app.route('/api/visualization/correlation', methods=['GET'])
def get_correlation_heatmap():
    """Get correlation heatmap data"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    correlation = analyzer.get_correlation_matrix()
    
    return jsonify(correlation)

@app.route('/api/reports/generate', methods=['POST'])
def generate_report():
    """Generate downloadable report"""
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    data = request.json
    report_type = data.get('type', 'pdf')
    report_data = analyzer.get_all_analytics()
    
    report = report_generator.generate_report(report_type, report_data)
    
    return jsonify({
        'report_url': report['url'],
        'format': report_type
    })

@app.route('/api/search/locations', methods=['GET'])
def search_locations():
    """Search locations"""
    query = request.args.get('query', '')
    
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    results = analyzer.search_locations(query)
    
    return jsonify(results)

@app.route('/api/search/routes', methods=['GET'])
def search_routes():
    """Search routes"""
    query = request.args.get('query', '')
    
    if not analyzer:
        return jsonify({'error': 'No dataset loaded'}), 400
    
    results = analyzer.search_routes(query)
    
    return jsonify(results)

@app.route('/api/datasets/upload', methods=['POST'])
def upload_dataset():
    """Upload dataset for comparison"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    dataset_path = f'data/uploaded_{file.filename}'
    file.save(dataset_path)
    
    # Load dataset
    new_analyzer = TripAnalyzer(dataset_path)
    
    return jsonify({
        'message': 'Dataset uploaded successfully',
        'path': dataset_path,
        'records': new_analyzer.dataset.shape[0]
    })

@app.route('/api/analytics/realtime', methods=['GET'])
def get_realtime_analytics():
    """Get real-time analytics status"""
    return jsonify({
        'active_dataset': data_manager.dataset_name if data_manager.dataset else 'None',
        'records_loaded': data_manager.total_records if data_manager.dataset else 0,
        'processing_status': 'Complete',
        'analysis_progress': 100,
        'map_status': 'Ready',
        'report_status': 'Ready'
    })

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500

# ==================== MAIN ====================

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    os.makedirs('data', exist_ok=True)
    os.makedirs('output', exist_ok=True)
    
    # Run Flask app
    app.run(host='0.0.0.0', port=5000, debug=False)