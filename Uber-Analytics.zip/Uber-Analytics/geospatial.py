#!/usr/bin/env python3
"""
geospatial.py - Geospatial Engine Module
Geospatial calculations, routing, and map generation
"""

import math
from geopy.geocoders import Nominatim
from geopy import Point
import folium
from folium.plugins import HeatMap, MarkerCluster
import json

class GeospatialEngine:
    """Geospatial calculations and map generation"""
    
    def __init__(self):
        """Initialize geospatial engine"""
        self.geocoder = Nominatim(user_agent='transportation-intelligence-platform')
        self.earth_radius = 6371.0  # km
    
    # ==================== COORDINATES ====================
    
    def get_coordinates(self, location_name):
        """Get coordinates for location name"""
        if not location_name:
            return None
        
        try:
            location = self.geocoder.geocode(location_name)
            if location:
                return (location.latitude, location.longitude)
        except Exception as e:
            pass
        
        return None
    
    def reverse_geocode(self, coords):
        """Get location name from coordinates"""
        if not coords:
            return None
        
        try:
            location = self.geocoder.reverse(coords)
            return location.address if location else None
        except Exception as e:
            return None
    
    # ==================== DISTANCE CALCULATIONS ====================
    
    def calculate_distance(self, coords1, coords2):
        """Calculate distance between two coordinates using Haversine formula"""
        if not coords1 or not coords2:
            return 0
        
        lat1, lon1 = coords1
        lat2, lon2 = coords2
        
        # Haversine formula
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lon = math.radians(lon2 - lon1)
        
        a = math.sin(delta_lat / 2) ** 2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lon / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        
        distance = self.earth_radius * c
        
        return distance
    
    def calculate_distance_haversine(self, coords1, coords2):
        """Alternative Haversine distance calculation"""
        return self.calculate_distance(coords1, coords2)
    
    # ==================== ROUTING ====================
    
    def generate_route(self, from_coords, to_coords):
        """Generate route between two points"""
        if not from_coords or not to_coords:
            return []
        
        # Simple route generation (straight line with intermediate points)
        route = []
        num_points = 10
        
        for i in range(num_points + 1):
            lat = from_coords[0] + (to_coords[0] - from_coords[0]) * i / num_points
            lon = from_coords[1] + (to_coords[1] - from_coords[1]) * i / num_points
            route.append([lat, lon])
        
        return route
    
    def estimate_route_distance(self, from_coords, to_coords):
        """Estimate actual route distance (not straight line)"""
        # Add 1.3x factor for actual road distance
        straight_distance = self.calculate_distance(from_coords, to_coords)
        return straight_distance * 1.3
    
    # ==================== MAP GENERATION ====================
    
    def create_folium_map(self, center_coords, zoom_start=13):
        """Create Folium map"""
        if not center_coords:
            center_coords = (20.5937, 78.9629)  # India center
        
        map = folium.Map(location=center_coords, zoom_start=zoom_start)
        
        return map
    
    def add_marker(self, map, coords, tooltip=None, color='blue'):
        """Add marker to map"""
        if not coords:
            return map
        
        folium.Marker(
            location=coords,
            tooltip=tooltip,
            popup=tooltip,
            icon=folium.Icon(color=color, icon='info-sign')
        ).add_to(map)
        
        return map
    
    def add_route_to_map(self, map, route, color='red'):
        """Add route line to map"""
        if not route:
            return map
        
        folium.PolyLine(
            locations=route,
            color=color,
            weight=3,
            opacity=0.8
        ).add_to(map)
        
        return map
    
    def create_heatmap(self, map, coords_list, weight=1):
        """Create heat map on map"""
        if not coords_list:
            return map
        
        HeatMap(
            input_data=coords_list,
            weight=weight,
            radius=10
        ).add_to(map)
        
        return map
    
    def create_marker_cluster(self, map, coords_list, tooltips=None):
        """Create marker cluster on map"""
        if not coords_list:
            return map
        
        cluster = MarkerCluster()
        
        for i, coords in enumerate(coords_list):
            tooltip = tooltips[i] if tooltips else None
            folium.Marker(
                location=coords,
                tooltip=tooltip,
                popup=tooltip
            ).add_to(cluster)
        
        cluster.add_to(map)
        
        return map
    
    # ==================== GEOJSON ====================
    
    def to_geojson(self, coords, name='Location'):
        """Convert coordinates to GeoJSON"""
        if not coords:
            return None
        
        return {
            'type': 'Feature',
            'geometry': {
                'type': 'Point',
                'coordinates': [coords[1], coords[0]]
            },
            'properties': {
                'name': name
            }
        }
    
    # ==================== POLYGON ====================
    
    def create_polygon(self, coords_list):
        """Create polygon from coordinates"""
        if not coords_list or len(coords_list) < 3:
            return None
        
        return {
            'type': 'Polygon',
            'coordinates': [[coords_list[1], coords_list[0]] for coords_list in coords_list]
        }