#!/usr/bin/env python3
"""
utils.py - Utility Module
Data management, report generation, and helper functions
"""

import pandas as pd
import numpy as np
import json
import os
from datetime import datetime
import reportlab
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

class DataManager:
    """Data management utility"""
    
    def __init__(self):
        """Initialize data manager"""
        self.dataset = None
        self.dataset_name = None
        self.total_trips = 0
        self.total_revenue = 0
        self.total_records = 0
    
    def load_dataset(self, dataset_path):
        """Load dataset"""
        if not os.path.exists(dataset_path):
            return False
        
        self.dataset = pd.read_csv(dataset_path)
        self.dataset_name = dataset_path
        self.total_records = len(self.dataset)
        self.total_trips = len(self.dataset)
        
        if 'fare' in self.dataset.columns:
            self.total_revenue = self.dataset['fare'].sum()
        
        return True
    
    def get_dataset_info(self):
        """Get dataset information"""
        if not self.dataset:
            return None
        
        return {
            'name': self.dataset_name,
            'total_records': self.total_records,
            'columns': self.dataset.columns.tolist(),
            'total_trips': self.total_trips,
            'total_revenue': self.total_revenue
        }

class ReportGenerator:
    """Report generation utility"""
    
    def __init__(self):
        """Initialize report generator"""
        self.output_dir = 'output'
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate_report(self, report_type, report_data):
        """Generate report in specified format"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if report_type == 'pdf':
            return self.generate_pdf_report(timestamp, report_data)
        elif report_type == 'html':
            return self.generate_html_report(timestamp, report_data)
        elif report_type == 'json':
            return self.generate_json_report(timestamp, report_data)
        elif report_type == 'csv':
            return self.generate_csv_report(timestamp, report_data)
        else:
            return self.generate_pdf_report(timestamp, report_data)
    
    def generate_pdf_report(self, timestamp, report_data):
        """Generate PDF report"""
        filename = f'{timestamp}_report.pdf'
        path = os.path.join(self.output_dir, filename)
        
        # Create PDF
        c = canvas.Canvas(path, pagesize=letter)
        c.setFont('Helvetica-Bold', 16)
        c.drawString(50, 750, 'Transportation Intelligence Platform Report')
        c.setFont('Helvetica', 12)
        c.drawString(50, 720, f'Generated: {datetime.now()}')
        
        # Add KPI data
        if 'kpi' in report_data:
            kpi = report_data['kpi']
            c.setFont('Helvetica-Bold', 14)
            c.drawString(50, 680, 'Key Performance Indicators')
            c.setFont('Helvetica', 11)
            c.drawString(50, 660, f'Total Trips: {kpi.get("total_trips", 0)}')
            c.drawString(50, 645, f'Total Revenue: {kpi.get("total_revenue", 0)}')
            c.drawString(50, 630, f'Average Fare: {kpi.get("average_fare", 0)}')
        
        c.save()
        
        return {'url': f'/output/{filename}', 'format': 'pdf'}
    
    def generate_html_report(self, timestamp, report_data):
        """Generate HTML report"""
        filename = f'{timestamp}_report.html'
        path = os.path.join(self.output_dir, filename)
        
        html_content = f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Transportation Intelligence Report</title>
            <style>
                body { font-family: Arial; padding: 20px; }
                h1 { color: #333; }
                .kpi { background: #f0f0f0; padding: 10px; margin: 10px 0; }
            </style>
        </head>
        <body>
            <h1>Transportation Intelligence Platform Report</h1>
            <p>Generated: {datetime.now()}</p>
            
            <div class="kpi">
                <h2>Key Performance Indicators</h2>
                {self._format_kpi_html(report_data.get('kpi', {}))}
            </div>
        </body>
        </html>
        '''
        
        with open(path, 'w') as f:
            f.write(html_content)
        
        return {'url': f'/output/{filename}', 'format': 'html'}
    
    def _format_kpi_html(self, kpi):
        """Format KPI as HTML"""
        html = ''
        for key, value in kpi.items():
            html += f'<p>{key}: {value}</p>'
        return html
    
    def generate_json_report(self, timestamp, report_data):
        """Generate JSON report"""
        filename = f'{timestamp}_report.json'
        path = os.path.join(self.output_dir, filename)
        
        with open(path, 'w') as f:
            json.dump(report_data, f, indent=2)
        
        return {'url': f'/output/{filename}', 'format': 'json'}
    
    def generate_csv_report(self, timestamp, report_data):
        """Generate CSV report"""
        filename = f'{timestamp}_report.csv'
        path = os.path.join(self.output_dir, filename)
        
        # Convert KPI to CSV
        if 'kpi' in report_data:
            df = pd.DataFrame([report_data['kpi']])
            df.to_csv(path, index=False)
        
        return {'url': f'/output/{filename}', 'format': 'csv'}