"""BUSINESS AGENT SERVICE v3.0.0

Autonomous agent that aggregates company data, computes KPIs,
generates insights, alerts, recommendations and executive briefings.
"""
from database.db import db
from database.models.company import Company
from database.models.financial import FinancialRecord
from database.models.inventory import Inventory
from database.models.project import Project
from database.models.customer import Customer
from database.models.notification import Notification
from database.models.activity_log import ActivityLog
from sqlalchemy import func
from datetime import datetime, timedelta


def _pct_change(current, previous):
    if not previous:
        return 0.0
    return round((current - previous) / abs(previous) * 100, 1)


class BusinessAgent:
    """Autonomous Business Agent."""

    # ─────────────────────────── STATUS ───────────────────────────

    @staticmethod
    def get_agent_status(cid):
        co = Company.query.get(cid)
        if not co:
            return None
        now = datetime.utcnow()
        lf = FinancialRecord.query.filter_by(company_id=cid).order_by(
            FinancialRecord.created_at.desc()).first()
        la = ActivityLog.query.filter_by(company_id=cid).order_by(
            ActivityLog.created_at.desc()).first()
        return {
            "agent_name": f"{co.company_name} Business Agent",
            "status": "active", "version": "3.0.0", "uptime": "99.9%",
            "last_scan": now.isoformat(),
            "data_freshness": {
                "financial_data": lf.created_at.isoformat() if lf else None,
                "last_activity": la.created_at.isoformat() if la else None},
            "active_alerts": Notification.query.filter_by(
                company_id=cid, is_read=False).count()}

    # ──────────────────────── COMMAND CENTER ──────────────────────

    @staticmethod
    def get_command_center(cid):
        """Aggregate everything the command center dashboard needs."""
        from services.analytics_service import AnalyticsService
        summary = AnalyticsService.get_executive_summary(cid)
        now = datetime.utcnow()

        # Revenue growth: current 30d vs previous 30d
        thirty = now - timedelta(days=30)
        sixty = now - timedelta(days=60)
        revenue_30d = summary.get('revenue_30d', 0)
        prev_30d = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == cid,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= sixty.date(),
            FinancialRecord.transaction_date < thirty.date()
        ).scalar() or 0
        revenue_growth = _pct_change(revenue_30d, float(prev_30d))

        active_projects = Project.query.filter(
            Project.company_id == cid,
            Project.status.in_(['active', 'in_progress', 'planning'])
        ).count()

        inventory_value = db.session.query(
            func.coalesce(func.sum(Inventory.quantity_on_hand * Inventory.unit_cost), 0)
        ).filter(Inventory.company_id == cid, Inventory.is_active == True).scalar()

        clv = db.session.query(func.avg(Customer.lifetime_value)).filter(
            Customer.company_id == cid).scalar() or 0

        kpis = {
            'revenue_30d': round(revenue_30d, 2),
            'revenue_growth': revenue_growth,
            'profit_30d': summary.get('profit_30d', 0),
            'margin': summary.get('margin', 0),
            'total_employees': summary.get('total_employees', 0),
            'active_projects': active_projects,
            'total_customers': summary.get('total_customers', 0),
            'churn_rate': summary.get('churn_rate', 0),
            'inventory_value': round(float(inventory_value), 2),
            'low_stock_items': summary.get('low_stock', 0),
            'revenue_per_employee': round(
                revenue_30d / max(summary.get('total_employees', 1), 1), 2),
            'customer_lifetime_value': round(float(clv), 2),
        }

        insights = BusinessAgent._generate_insights(kpis)
        alerts = BusinessAgent._generate_alerts(kpis)
        health = BusinessAgent._health_breakdown(cid, kpis)

        return {
            'generated_at': now.isoformat(),
            'kpis': kpis,
            'insights': insights,
            'alerts': alerts,
            'health': health,
        }

    # ──────────────────────── INNER LOGIC ─────────────────────────

    @staticmethod
    def _generate_insights(k):
        insights = []
        if k['margin'] >= 20:
            insights.append({
                'type': 'success', 'category': 'Profitability',
                'confidence': 92,
                'title': f"Healthy {k['margin']}% margin",
                'description': 'Margins are above the 20% benchmark. Consider reinvesting surplus into growth.',
                'action': 'Explore expansion simulations'})
        elif k['margin'] < 10:
            insights.append({
                'type': 'warning', 'category': 'Profitability',
                'confidence': 88,
                'title': f"Thin {k['margin']}% margin",
                'description': 'Expenses are consuming most revenue. Review top expense categories for cuts.',
                'action': 'Run expense analytics'})
        if k['revenue_growth'] > 5:
            insights.append({
                'type': 'success', 'category': 'Growth',
                'confidence': 85,
                'title': f"Revenue up {k['revenue_growth']}% month-over-month",
                'description': 'Momentum is positive. Scale marketing while acquisition costs remain efficient.',
                'action': 'Open marketing simulator'})
        elif k['revenue_growth'] < -5:
            insights.append({
                'type': 'warning', 'category': 'Growth',
                'confidence': 87,
                'title': f"Revenue down {abs(k['revenue_growth'])}% month-over-month",
                'description': 'Declining sales trend detected. Investigate demand and competitor activity.',
                'action': 'Check market intelligence'})
        if k['churn_rate'] > 10:
            insights.append({
                'type': 'warning', 'category': 'Customers',
                'confidence': 90,
                'title': f"Churn at {k['churn_rate']}%",
                'description': 'Customer retention is below target. Launch a retention campaign.',
                'action': 'Open customer simulator'})
        if 0 < k['revenue_per_employee'] < 5000:
            insights.append({
                'type': 'info', 'category': 'Operations',
                'confidence': 80,
                'title': 'Revenue per employee is low',
                'description': 'Productivity may be improvable via automation or better allocation.',
                'action': 'Review employee analytics'})
        if not insights:
            insights.append({
                'type': 'success', 'category': 'Overall',
                'confidence': 90,
                'title': 'All key metrics within healthy ranges',
                'description': 'No anomalies detected across revenue, margins, churn or operations.',
                'action': 'Continue monitoring'})
        return insights

    @staticmethod
    def _generate_alerts(k):
        alerts = []
        if k['low_stock_items'] > 0:
            alerts.append({
                'severity': 'warning' if k['low_stock_items'] < 5 else 'critical',
                'title': f"{k['low_stock_items']} item(s) below reorder point",
                'message': 'Inventory replenishment needed to avoid stockouts.',
                'action': 'Review inventory'})
        if k['churn_rate'] > 10:
            alerts.append({
                'severity': 'critical' if k['churn_rate'] > 20 else 'warning',
                'title': f"High churn rate: {k['churn_rate']}%",
                'message': 'Customer losses are accelerating beyond safe thresholds.',
                'action': 'Launch retention plan'})
        if k['margin'] < 10:
            alerts.append({
                'severity': 'warning',
                'title': f"Margin compressed to {k['margin']}%",
                'message': 'Cost structure needs review to protect profitability.',
                'action': 'Analyze expenses'})
        if k['active_projects'] == 0:
            alerts.append({
                'severity': 'info',
                'title': 'No active projects',
                'message': 'No strategic initiatives are currently in flight.',
                'action': 'Create a project'})
        return alerts

    @staticmethod
    def _health_breakdown(cid, k):
        profitability = min(30, max(0, round(k['margin'] / 25 * 30)))
        customers = min(25, max(0, round((100 - min(k['churn_rate'], 100)) / 100 * 25)))
        total_skus = Inventory.query.filter_by(company_id=cid, is_active=True).count()
        if total_skus:
            ops = min(25, max(0, round(25 - (k['low_stock_items'] / total_skus * 25))))
        else:
            ops = 20
        stability = 20
        try:
            from services.risk_service import RiskService
            risk = RiskService.get_risk_summary(cid)
            stability = min(20, max(0, round((100 - risk.get('overall_score', 50)) / 100 * 20)))
        except Exception:
            pass
        total = profitability + customers + ops + stability
        rating = ('Excellent' if total >= 80 else
                  'Good' if total >= 60 else
                  'Fair' if total >= 40 else 'At Risk')
        return {
            'total': total,
            'rating': rating,
            'components': {
                'profitability': {'label': 'Profitability', 'score': profitability, 'max': 30},
                'customers': {'label': 'Customers', 'score': customers, 'max': 25},
                'operations': {'label': 'Operations', 'score': ops, 'max': 25},
                'stability': {'label': 'Stability', 'score': stability, 'max': 20},
            },
        }

    # ─────────────────────── RECOMMENDATIONS ──────────────────────

    @staticmethod
    def get_recommendations(cid):
        cc = BusinessAgent.get_command_center(cid)
        k = cc['kpis']
        recs = []

        if k['churn_rate'] > 10:
            recs.append({
                'category': 'Customer Success',
                'expected_impact': f"-{round(k['churn_rate'] / 2, 1)}% churn",
                'title': 'Launch a customer retention program',
                'description': f"Churn is {k['churn_rate']}%. Targeted outreach and loyalty incentives can recover at-risk accounts.",
                'action': 'Open customer simulator'})
        if k['margin'] < 15:
            recs.append({
                'category': 'Finance',
                'expected_impact': f"+{round(20 - k['margin'], 1)} pts margin",
                'title': 'Optimize expense structure',
                'description': f"Margin is {k['margin']}%. Renegotiate supplier terms and trim non-critical spend.",
                'action': 'Run expense analytics'})
        if k['low_stock_items'] > 0:
            recs.append({
                'category': 'Supply Chain', 'expected_impact': 'Avoided stockouts',
                'title': f"Restock {k['low_stock_items']} low-stock item(s)",
                'description': 'Several SKUs are below reorder point and risk losing sales.',
                'action': 'Open supply chain simulator'})
        if k['revenue_growth'] < 0:
            recs.append({
                'category': 'Marketing',
                'expected_impact': f"+{abs(k['revenue_growth'])}% revenue",
                'title': 'Boost demand generation',
                'description': 'Revenue is declining. A targeted campaign can reverse the trend.',
                'action': 'Open marketing simulator'})
        if 0 < k['revenue_per_employee'] < 8000:
            recs.append({
                'category': 'Operations', 'expected_impact': '+10% productivity',
                'title': 'Improve workforce productivity',
                'description': f"Revenue per employee is {k['revenue_per_employee']}. Automation and training could lift output.",
                'action': 'Open employee simulator'})
        if not recs:
            recs.append({
                'category': 'Growth', 'expected_impact': '+15% revenue',
                'title': 'Invest surplus into expansion',
                'description': 'Metrics are healthy. Consider new markets, products or capacity investment.',
                'action': 'Open expansion simulation'})
        return recs

    # ──────────────────── EXECUTIVE BRIEFING ──────────────────────

    @staticmethod
    def generate_executive_briefing(cid, period='daily'):
        cc = BusinessAgent.get_command_center(cid)
        k = cc['kpis']
        days = {'daily': 1, 'weekly': 7, 'monthly': 30}.get(period, 1)
        since = datetime.utcnow() - timedelta(days=days)
        activities = ActivityLog.query.filter(
            ActivityLog.company_id == cid,
            ActivityLog.created_at >= since
        ).order_by(ActivityLog.created_at.desc()).limit(8).all()

        headline = (f"Business is {'growing' if k['revenue_growth'] >= 0 else 'contracting'} "
                    f"— health {cc['health']['total']}/100 ({cc['health']['rating']})")
        return {
            'period': period,
            'generated_at': datetime.utcnow().isoformat(),
            'headline': headline,
            'summary': (
                f"Revenue {k['revenue_30d']:,.0f} ({k['revenue_growth']:+}%), "
                f"margin {k['margin']}%, churn {k['churn_rate']}%. "
                f"{len(cc['alerts'])} active alert(s), "
                f"{k['active_projects']} active project(s)."),
            'highlights': [i['title'] for i in cc['insights'][:4]],
            'alerts': cc['alerts'],
            'health': cc['health'],
            'kpis': k,
            'recent_activity': [a.description for a in activities],
        }

    # ─────────────────────── HEALTH CHECK ─────────────────────────

    @staticmethod
    def run_health_check(cid, user_id):
        """Run a comprehensive check and create notifications for findings."""
        cc = BusinessAgent.get_command_center(cid)
        k = cc['kpis']
        created = []

        findings = []
        if k['low_stock_items'] > 0:
            findings.append((
                'Low stock warning',
                f"{k['low_stock_items']} item(s) below reorder point.",
                'warning', 'inventory'))
        if k['churn_rate'] > 10:
            findings.append((
                'High customer churn',
                f"Churn rate is {k['churn_rate']}%, above the 10% threshold.",
                'critical', 'customer'))
        if k['margin'] < 10:
            findings.append((
                'Margin pressure',
                f"Profit margin is {k['margin']}%, below the 10% threshold.",
                'warning', 'financial'))
        if k['revenue_growth'] < -5:
            findings.append((
                'Revenue decline',
                f"Revenue changed {k['revenue_growth']}% vs previous period.",
                'critical', 'analytics'))
        if not findings:
            findings.append((
                'Health check passed',
                f"All systems normal — health score {cc['health']['total']}/100.",
                'success', 'system'))

        for title, message, ntype, module in findings:
            n = Notification(
                company_id=cid, user_id=user_id, title=title, message=message,
                notification_type=ntype, module=module, is_read=False)
            db.session.add(n)
            created.append(n)

        # Persist health score on the company
        company = Company.query.get(cid)
        if company:
            company.health_score = cc['health']['total']
        db.session.commit()
        return created





