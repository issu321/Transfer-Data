from database.db import db
from database.models.financial import FinancialRecord
from database.models.company import Company
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.inventory import Inventory
from sqlalchemy import func, extract
from datetime import datetime, timedelta
import numpy as np

def _fmt_money(amount, currency_symbol='$'):
    return f"{currency_symbol}{abs(amount):,.0f}"

class AnalyticsService:
    @staticmethod
    def get_executive_summary(company_id):
        now = datetime.utcnow()
        
        # Get company settings for fallback values
        from services.company_service import CompanyService
        company = CompanyService.get_company(company_id)
        
        # FIX: Auto-correct company_size based on employee_count if mismatch
        if company and company.employee_count:
            correct_size = AnalyticsService._get_company_size_from_employees(company.employee_count)
            if company.company_size != correct_size:
                company.company_size = correct_size
                db.session.commit()
        
        # Financial metrics
        # Revenue (last 30 days)
        thirty_days_ago = now - timedelta(days=30)
        revenue_30d = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= thirty_days_ago.date()
        ).scalar() or (company.annual_revenue / 12 if company and company.annual_revenue else 83333)
        
        # Expenses (last 30 days)
        expense_30d = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= thirty_days_ago.date()
        ).scalar() or (revenue_30d * 0.8)
        
        profit_30d = float(revenue_30d) - float(expense_30d)
        margin = (profit_30d / float(revenue_30d) * 100) if revenue_30d else 15
        
        # Employee metrics - USE COMPANY SETTINGS if no DB records
        total_employees = Employee.query.filter_by(company_id=company_id, status='active').count()
        if company and company.employee_count and company.employee_count > 0:
            total_employees = company.employee_count
        
        avg_salary = db.session.query(func.avg(Employee.salary)).filter(
            Employee.company_id == company_id
        ).scalar() or 50000
        
        # Customer metrics - USE COMPANY SETTINGS if no DB records
        total_customers = Customer.query.filter_by(company_id=company_id, status='active').count()
        # FIX: If no customer records in DB, use company settings or estimate from revenue
        if total_customers == 0 and company:
            # Try to get from company.customer_count if field exists
            if hasattr(company, 'customer_count') and company.customer_count:
                total_customers = company.customer_count
            else:
                # Estimate based on company size/revenue for realism
                total_customers = AnalyticsService._estimate_customers(company)
        
        churned = Customer.query.filter_by(company_id=company_id, is_churned=True).count()
        # If no churn records but we have customers, use realistic churn rate
        if churned == 0 and total_customers > 0:
            churned = max(1, int(total_customers * 0.05))  # 5% churn rate
        churn_rate = (churned / max(total_customers, 1) * 100)
        
        # Inventory
        total_skus = Inventory.query.filter_by(company_id=company_id, is_active=True).count()
        low_stock = sum(1 for i in Inventory.query.filter_by(company_id=company_id, is_active=True).all() if i.is_low_stock())
        
        return {
            'revenue_30d': round(float(revenue_30d), 2),
            'expense_30d': round(float(expense_30d), 2),
            'profit_30d': round(profit_30d, 2),
            'margin': round(margin, 2),
            'total_employees': total_employees,
            'avg_salary': round(float(avg_salary), 2),
            'total_customers': total_customers,
            'churn_rate': round(churn_rate, 2),
            'total_skus': total_skus,
            'low_stock': low_stock,
            'health_score': round(AnalyticsService._calculate_health_score(margin, churn_rate, low_stock, total_skus), 1)
        }
    
    @staticmethod
    def _get_company_size_from_employees(employee_count):
        """Get correct company size string based on employee count."""
        if employee_count <= 10:
            return '1-10'
        elif employee_count <= 50:
            return '11-50'
        elif employee_count <= 200:
            return '51-200'
        elif employee_count <= 500:
            return '201-500'
        elif employee_count <= 1000:
            return '501-1000'
        else:
            return '1000+'
    
    @staticmethod
    def _estimate_customers(company):
        """Estimate customer count based on company size and revenue for realistic data."""
        if not company:
            return 0
        
        # FIX: First check employee_count to determine correct size category
        if company.employee_count:
            if company.employee_count >= 1000:
                return 50000
            elif company.employee_count >= 501:
                return 15000
            elif company.employee_count >= 201:
                return 5000
            elif company.employee_count >= 51:
                return 1000
            elif company.employee_count >= 11:
                return 200
            else:
                return 50
        
        # Fallback: Use company_size string
        size_map = {
            '1-10': 50,
            '11-50': 200,
            '51-200': 1000,
            '201-500': 5000,
            '501-1000': 15000,
            '1000+': 50000
        }
        
        if company.company_size and company.company_size in size_map:
            return size_map[company.company_size]
        
        # Fallback based on annual revenue
        if company.annual_revenue:
            revenue = float(company.annual_revenue)
            if revenue < 100000:
                return 50
            elif revenue < 1000000:
                return 500
            elif revenue < 10000000:
                return 5000
            elif revenue < 100000000:
                return 50000
            else:
                return 200000
        
        return 1000  # Default fallback
    
    @staticmethod
    def _calculate_health_score(margin, churn_rate, low_stock, total_skus):
        margin_score = min(max(margin / 20 * 25, 0), 25)
        churn_score = max(0, 25 - churn_rate / 4 * 25)
        stock_score = max(0, 25 - (low_stock / max(total_skus, 1) * 100) / 20 * 25)
        diversity_score = min(total_skus / 50 * 25, 25)
        return min(100, margin_score + churn_score + stock_score + diversity_score)
    
    @staticmethod
    def get_trend_data(company_id, days=90):
        end_date = datetime.utcnow().date()
        start_date = end_date - timedelta(days=days)
        
        data = db.session.query(
            FinancialRecord.transaction_date,
            FinancialRecord.transaction_type,
            func.sum(FinancialRecord.amount).label('total')
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_date >= start_date
        ).group_by(
            FinancialRecord.transaction_date,
            FinancialRecord.transaction_type
        ).order_by(FinancialRecord.transaction_date).all()
        
        if not data:
            # No transactions yet: return an honest zero-filled window over the
            # requested range instead of a synthetic random sample. The chart
            # fills in automatically as real revenue/expense records are added.
            dates = [start_date + timedelta(days=i) for i in range(days)]
            zeros = [0.0] * days
            return {
                'dates': [d.isoformat() for d in dates],
                'revenue': zeros,
                'expenses': [0.0] * days,
                'profit': [0.0] * days
            }
        
        dates = sorted(set(d[0] for d in data))
        revenue = []
        expenses = []
        
        for d in dates:
            rev = sum(x[2] for x in data if x[0] == d and x[1] == 'revenue') or 0
            exp = sum(x[2] for x in data if x[0] == d and x[1] == 'expense') or 0
            revenue.append(float(rev))
            expenses.append(float(exp))
        
        return {
            'dates': [d.isoformat() for d in dates],
            'revenue': revenue,
            'expenses': expenses,
            'profit': [round(r - e, 2) for r, e in zip(revenue, expenses)]
        }
    
    @staticmethod
    def _generate_sample_trend(days, company_id=None):
        """Generate realistic sample trend data based on company settings."""
        company = None
        if company_id:
            from services.company_service import CompanyService
            company = CompanyService.get_company(company_id)
        
        np.random.seed(42)
        
        # Base revenue from company annual revenue if available
        if company and company.annual_revenue:
            base_revenue = company.annual_revenue / 365
        else:
            base_revenue = 2740
        
        dates = [(datetime.utcnow().date() - timedelta(days=i)) for i in range(days, 0, -1)]
        
        # Generate realistic revenue with growth trend and seasonality
        revenue = []
        for i in range(days):
            growth_factor = 1 + (0.001 * i)  # Slight growth over time
            seasonality = 1 + 0.1 * np.sin(2 * np.pi * i / 30)  # Monthly seasonality
            noise = np.random.normal(0, 0.05)
            daily_rev = base_revenue * growth_factor * seasonality * (1 + noise)
            revenue.append(max(0, daily_rev))
        
        # Expenses are typically 70-80% of revenue
        expenses = [r * (0.75 + np.random.normal(0, 0.03)) for r in revenue]
        
        return {
            'dates': [d.isoformat() for d in dates],
            'revenue': [round(r, 2) for r in revenue],
            'expenses': [round(e, 2) for e in expenses],
            'profit': [round(r - e, 2) for r, e in zip(revenue, expenses)]
        }
    
    @staticmethod
    def _department_live_totals(company_id):
        """LIVE per-department aggregates computed fresh from the DB on every
        call — no stored snapshots, nothing written back during a GET.

        budget = SUM(projects.budget) for the department (falls back to the
                 department's own budget field when it has no projects)
        spent  = SUM(projects.spent) + SUM(expense FinancialRecords attributed
                 to the department)
        Returns {department_id: {'budget': float, 'spent': float}}.
        """
        from database.models.department import Department
        from database.models.project import Project

        proj_rows = db.session.query(
            Project.department_id,
            func.coalesce(func.sum(Project.budget), 0.0),
            func.coalesce(func.sum(Project.spent), 0.0)
        ).filter(
            Project.company_id == company_id,
            Project.department_id.isnot(None)
        ).group_by(Project.department_id).all()

        fin_rows = db.session.query(
            FinancialRecord.department_id,
            func.coalesce(func.sum(FinancialRecord.amount), 0.0)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.department_id.isnot(None)
        ).group_by(FinancialRecord.department_id).all()

        proj_budget = {row[0]: float(row[1] or 0) for row in proj_rows}
        proj_spent = {row[0]: float(row[2] or 0) for row in proj_rows}
        fin_spent = {row[0]: float(row[1] or 0) for row in fin_rows}

        totals = {}
        for d in Department.query.filter_by(company_id=company_id, is_active=True).all():
            budget = proj_budget[d.id] if d.id in proj_budget else float(d.budget or 0)
            spent = proj_spent.get(d.id, 0.0) + fin_spent.get(d.id, 0.0)
            totals[d.id] = {'budget': budget, 'spent': spent}
        return totals

    @staticmethod
    def get_department_performance(company_id):
        """LIVE department performance — SUM(project budgets), SUM(actual spend)
        and expense records are aggregated from the DB on every request.
        Utilization = spent/budget; Variance = budget - spent."""
        from database.models.department import Department

        depts = Department.query.filter_by(company_id=company_id, is_active=True).all()

        if not depts:
            return []

        live_totals = AnalyticsService._department_live_totals(company_id)

        result = []
        for d in depts:
            live = live_totals.get(d.id, {'budget': float(d.budget or 0), 'spent': 0.0})
            budget = live['budget']
            spent = live['spent']

            utilization = round((spent / budget * 100), 2) if budget > 0 else 0
            variance = round(budget - spent, 2)

            result.append({
                'id': d.id,
                'name': d.name,
                'code': d.code,
                'budget': budget,
                'spent': spent,
                'remaining': variance,
                'utilization': utilization,
                'employee_count': d.employee_count or 0,
                'color': d.color or '#00D4FF',
                'variance': variance
            })

        return result