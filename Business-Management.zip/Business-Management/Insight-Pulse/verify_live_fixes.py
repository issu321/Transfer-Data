"""End-to-end verification: Bug 1 (edit twin) + Bug 2 (live analytics).

Uses a THROWAWAY sqlite DB so real instance data is never touched.
Run:  python verify_live_fixes.py
"""
import os, re, sys, tempfile

os.environ['DATABASE_URL'] = f'sqlite:///{tempfile.mkdtemp()}/verify_live.db'

from app import create_app

app = create_app()

FAILURES = []


def check(label, cond, extra=''):
    status = 'PASS' if cond else 'FAIL'
    print(f"[{status}] {label} {extra}")
    if not cond:
        FAILURES.append(label)


with app.app_context():
    from database.db import db
    from database.models.user import User
    from database.models.company import Company
    from database.models.department import Department
    from database.models.project import Project
    from database.models.custom_twin import CustomTwin, CustomTwinRecord, TwinLink, TwinAuditLog
    from database.models.supplier import Supplier
    from database.models.inventory import Inventory

    company = Company(company_name='Verify Corp', business_name='Verify Corp',
                      owner_name='T', ceo_name='T', industry='Tech', is_active=True)
    db.session.add(company)
    db.session.flush()
    user = User(username='verifier', email='v@v.com', role='Admin', is_admin=True, is_active=True)
    user.set_password('x')
    db.session.add(user)
    db.session.commit()
    COMPANY_ID, USER_ID = company.id, user.id

client = app.test_client()
with client.session_transaction() as s:
    s['_user_id'] = str(USER_ID)
    s['company_id'] = COMPANY_ID

# Keep ONE app context open for the whole run so model queries work outside requests
_ctx = app.app_context()
_ctx.push()

# ------------------------------------------------------------------
# TEST A: twins page renders + every getElementById target exists
# ------------------------------------------------------------------
r = client.get('/business-twin/custom-twins')
check('GET /business-twin/custom-twins is 200', r.status_code == 200, f'(got {r.status_code})')
html = r.get_data(as_text=True)

id_refs = set(re.findall(r"getElementById\('([^']+)'\)", html))
id_defs = set(re.findall(r'id="([^"]+)"', html))
missing = sorted(i for i in id_refs if i not in id_defs)
check('All getElementById targets exist in rendered HTML', not missing, f'missing={missing}')

r2 = client.get('/analytics/')
check('GET /analytics/ is 200', r2.status_code == 200, f'(got {r2.status_code})')
r3 = client.get('/business-twin/departments')
check('GET /business-twin/departments is 200', r3.status_code == 200, f'(got {r3.status_code})')

# ------------------------------------------------------------------
# TEST B: create twin -> appears immediately; edit twin -> persists
# ------------------------------------------------------------------
r = client.post('/business-twin/custom-twins/create', data={
    'name': 'Fleet Assets', 'icon': 'fa-car', 'color': '#8B5CF6',
    'description': "Company vehicles", 'field_count': '0', 'stat_count': '0',
})
check('POST create twin success', (r.get_json(silent=True) or {}).get('success') is True, r.get_data(as_text=True)[:200])

twin = CustomTwin.query.filter_by(company_id=COMPANY_ID, slug='fleet-assets').first()
check('Twin row committed in DB', twin is not None)

r = client.get('/business-twin/custom-twins')
check('New twin visible on twins page immediately', 'Fleet Assets' in r.get_data(as_text=True))

r = client.post(f'/business-twin/custom-twins/{twin.id}/edit', data={
    'name': 'Fleet Vehicles', 'icon': 'fa-truck', 'color': '#10B981',
    'description': 'Updated description', 'field_count': '0', 'stat_count': '0',
})
j = r.get_json(silent=True) or {}
check('POST edit twin returns success', r.status_code == 200 and j.get('success') is True, r.get_data(as_text=True)[:200])
db.session.expire_all()
twin = db.session.get(CustomTwin, twin.id)
check('Edit persisted to DB (name/icon/color/desc)',
      twin.name == 'Fleet Vehicles' and twin.icon == 'fa-truck'
      and twin.color == '#10B981' and twin.description == 'Updated description',
      f"got name={twin.name!r} icon={twin.icon!r} color={twin.color!r}")
r = client.get('/business-twin/custom-twins')
check('Edited twin card shows updated name', 'Fleet Vehicles' in r.get_data(as_text=True))

# ------------------------------------------------------------------
# TEST C: department create -> immediately in twins page AND analytics
# ------------------------------------------------------------------
r = client.post('/business-twin/departments/add', data={
    'name': 'Research Lab', 'code': 'LAB', 'budget': '500000', 'color': '#F59E0B',
})
j = r.get_json(silent=True) or {}
check('POST departments/add success', r.status_code == 200 and j.get('success') is True, r.get_data(as_text=True)[:200])

dept = Department.query.filter_by(company_id=COMPANY_ID, name='Research Lab').first()
check('Department committed in DB', dept is not None)
r = client.get('/business-twin/custom-twins')
check('Auto-created dept twin visible on twins page', 'Research Lab Department' in r.get_data(as_text=True))
r = client.get('/analytics/')
check('New department visible in Analytics Department Performance', 'Research Lab' in r.get_data(as_text=True))

# ------------------------------------------------------------------
# TEST D: analytics numbers are LIVE aggregates from projects
# ------------------------------------------------------------------
p1 = Project(company_id=COMPANY_ID, name='Lab Buildout', department_id=dept.id,
             budget=250000, spent=100000, status='active')
p2 = Project(company_id=COMPANY_ID, name='Lab Tooling', department_id=dept.id,
             budget=150000, spent=50000, status='active')
db.session.add_all([p1, p2])
db.session.commit()

r = client.get('/analytics/')
check('200 with projects', r.status_code == 200)
page = r.get_data(as_text=True)
check('Analytics budget shows live SUM(project budgets) = 400,000', '400,000' in page)
check('Analytics spent shows live spend = 150,000', '150,000' in page)
check('Analytics variance = 250,000 (budget - spent)', '250,000' in page)

# Change a project -> analytics changes on next load (no re-import)
p1.budget = 400000
p1.spent = 300000
db.session.commit()
r = client.get('/analytics/')
page = r.get_data(as_text=True)
check('After project edit: budget = 550,000', '550,000' in page)
check('After project edit: spent = 350,000', '350,000' in page)
check('After project edit: variance = 200,000', '200,000' in page)

# Departments page reflects live spend too
r = client.get('/business-twin/departments')
page = r.get_data(as_text=True)
check('Departments page shows live spent 350,000', '350,000' in page)

# ------------------------------------------------------------------
# TEST E: trend data is real (zero-filled window, not synthetic sample)
# ------------------------------------------------------------------
from services.analytics_service import AnalyticsService
trend = AnalyticsService.get_trend_data(COMPANY_ID, 90)
check('Trend with no transactions: zero-filled real window (not random sample)',
      all(v == 0 for v in trend['revenue']), f"dates={len(trend['dates'])}")

# ------------------------------------------------------------------
# TEST F: delete twin cleans up orphans
# ------------------------------------------------------------------
other = CustomTwin(company_id=COMPANY_ID, name='Child Twin', slug='child-twin',
                   parent_twin_id=twin.id)
db.session.add(other)
db.session.flush()
rec = CustomTwinRecord(twin_id=twin.id, company_id=COMPANY_ID)
rec.set_data({'amount': 10})
db.session.add(rec)
db.session.flush()
link = TwinLink(company_id=COMPANY_ID, source_twin_id=twin.id, source_record_id=rec.id,
                target_twin_id=other.id, target_record_id=rec.id)
db.session.add(link)
audit = TwinAuditLog(company_id=COMPANY_ID, twin_id=twin.id, action='create', description='x')
db.session.add(audit)
db.session.commit()

r = client.delete(f'/business-twin/custom-twins/{twin.id}/delete')
j = r.get_json(silent=True) or {}
check('DELETE twin success', r.status_code == 200 and j.get('success') is True, r.get_data(as_text=True)[:200])
check('Twin row gone', db.session.get(CustomTwin, twin.id) is None)
check('No orphan twin records', CustomTwinRecord.query.filter_by(twin_id=twin.id).count() == 0)
check('No orphan twin links', TwinLink.query.filter(
    (TwinLink.source_twin_id == twin.id) | (TwinLink.target_twin_id == twin.id)).count() == 0)
check('No orphan audit logs', TwinAuditLog.query.filter_by(twin_id=twin.id).count() == 0)
db.session.expire_all()
child = CustomTwin.query.filter_by(slug='child-twin').first()
check('Child twin parent reference cleared (no dangling FK)', child.parent_twin_id is None,
      f'parent_twin_id={child.parent_twin_id}')

# ------------------------------------------------------------------
# TEST G: JSON prefill endpoints (used by all edit buttons now)
# ------------------------------------------------------------------
sup = Supplier(company_id=COMPANY_ID, name="O'Brien Parts & Sons", category='General')
item = Inventory(company_id=COMPANY_ID, name='Widget "Pro" <Deluxe>', sku='WDG-1')
db.session.add_all([sup, item])
db.session.flush()
rec2 = CustomTwinRecord(twin_id=other.id, company_id=COMPANY_ID)
rec2.set_data({'employee_name': "O'Brien & Co", 'salary': 123})
db.session.add(rec2)
db.session.commit()

r = client.get(f'/business-twin/custom-twins/{other.id}/json')
j = r.get_json(silent=True) or {}
check('Twin JSON endpoint works', r.status_code == 200 and j.get('twin', {}).get('id') == other.id)

r = client.get(f'/business-twin/custom-twins/records/{rec2.id}/json')
j = r.get_json(silent=True) or {}
check('Record JSON endpoint works (apostrophe data intact)',
      r.status_code == 200 and j.get('record', {}).get('data', {}).get('employee_name') == "O'Brien & Co")

r = client.get(f'/business-twin/suppliers/{sup.id}/json')
j = r.get_json(silent=True) or {}
check('Supplier JSON endpoint works (ampersand/apostrophe name intact)',
      r.status_code == 200 and j.get('supplier', {}).get('name') == "O'Brien Parts & Sons")

r = client.get(f'/business-twin/inventory/{item.id}/json')
j = r.get_json(silent=True) or {}
check('Inventory JSON endpoint works (quotes/angle brackets intact)',
      r.status_code == 200 and j.get('item', {}).get('name') == 'Widget "Pro" <Deluxe>')

# ------------------------------------------------------------------
# TEST H: no fragile JSON-in-onclick attributes left on twin pages
# ------------------------------------------------------------------
import re as _re
for page_url in ['/business-twin/', '/business-twin/custom-twins', '/business-twin/custom-twins/network',
                 '/business-twin/suppliers', '/business-twin/inventory', '/business-twin/employees',
                 '/business-twin/customers']:
    rp = client.get(page_url)
    hp = rp.get_data(as_text=True)
    bad = [m for m in _re.findall(r'onclick="[^"]*tojson[^"]*"', hp)]
    check(f'No JSON-in-onclick on {page_url}', not bad, str(bad[:1]))

# Overview page pencil uses the safe ID-based handler
r = client.get('/business-twin/')
hp = r.get_data(as_text=True)
check('Overview pencil uses openEditTwinFromOverview(id)', 'openEditTwinFromOverview(' in hp and 'editTwinFromOverview({{' not in hp)
check('Twins page pencil uses openEditTwin(id)', 'openEditTwin(' in client.get('/business-twin/custom-twins').get_data(as_text=True))

# ------------------------------------------------------------------
# TEST I: full edit round-trip on a twin whose name has an apostrophe
# ------------------------------------------------------------------
r = client.post('/business-twin/custom-twins/create', data={
    "name": "Sam's R&D Assets", 'icon': 'fa-car', 'color': '#8B5CF6',
    'description': 'Sam\'s "special" assets', 'field_count': '0', 'stat_count': '0',
})
j = r.get_json(silent=True) or {}
check('Create twin with apostrophe name succeeds', j.get('success') is True, r.get_data(as_text=True)[:150])
twin3 = CustomTwin.query.filter_by(company_id=COMPANY_ID, slug='sams-rd-assets').first()
r = client.get('/business-twin/custom-twins')
page = r.get_data(as_text=True)
check('Apostrophe twin renders without breaking the page markup', 'Sam&#39;s R&amp;D Assets' in page or "Sam's R&D Assets" in page)
r = client.post(f'/business-twin/custom-twins/{twin3.id}/edit', data={
    "name": "Sam's Research Assets", 'icon': 'fa-flask', 'color': '#F59E0B',
    'description': 'Updated', 'field_count': '0', 'stat_count': '0',
})
j = r.get_json(silent=True) or {}
check('Edit twin with apostrophe name succeeds', r.status_code == 200 and j.get('success') is True, r.get_data(as_text=True)[:150])
db.session.expire_all()
twin3 = db.session.get(CustomTwin, twin3.id)
check('Apostrophe twin edit persisted', twin3.name == "Sam's Research Assets" and twin3.icon == 'fa-flask')

# ------------------------------------------------------------------
# TEST J: page sweep — every main page renders without 500 errors
# ------------------------------------------------------------------
sweep = ['/', '/dashboard', '/business-twin/', '/business-twin/departments', '/business-twin/revenue',
         '/business-twin/expenses', '/business-twin/customers', '/business-twin/employees',
         '/business-twin/suppliers', '/business-twin/inventory', '/business-twin/custom-twins',
         '/business-twin/custom-twins/network', '/analytics/', '/analytics/revenue', '/analytics/expenses',
         '/analytics/profit', '/analytics/growth', '/analytics/departments', '/analytics/customers',
         '/analytics/employees']
five_hundreds = []
for u in sweep:
    try:
        rs = client.get(u)
        if rs.status_code >= 500:
            five_hundreds.append((u, rs.status_code))
    except Exception as e:
        five_hundreds.append((u, f'EXC: {type(e).__name__}: {str(e)[:80]}'))
check('No 500 errors on main pages', not five_hundreds, str(five_hundreds))

# ------------------------------------------------------------------
print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILURE(S): {FAILURES}")
    sys.exit(1)
print("RESULT: ALL CHECKS PASSED")



