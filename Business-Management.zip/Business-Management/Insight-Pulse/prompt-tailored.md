# PROMPT — Fix & Complete "Insight Pulse" Digital Business Twin (Flask + SQLAlchemy)

You are a senior full-stack engineer working on **Insight Pulse**, an enterprise business-management dashboard (Flask + SQLAlchemy + SQLite) where one dashboard manages multiple companies, and each company has "twins" — departments (e.g. "Project-Management") and custom twins (e.g. "Projects").

## PROJECT CONTEXT (verified against the actual workspace)

- Project root: `C:\Users\USSUROYAL\Documents\Programming\Python\Miniprj\Miniprj\Insight-Pulse`
- App entry: `app.py` / `run.py` (Flask dev server, `python run.py`)
- Local interpreter: Python 3.12.13 (`python --version` to confirm before running anything)
- Database: SQLite at `instance/business_simulator.db` (confirmed present)
- UI: dark "Enterprise Twin" theme — keep it intact. Templates are Jinja2; frontend JS must stay vanilla.

> ⚠️ **There is a nested stale copy of the app at `New-Releases/`.** Do NOT read it for diagnosis and do NOT edit anything inside it. All work happens in the project root only.

### Verified relevant files (all confirmed to exist)

Backend:
- `routes/business_twin.py` — twin overview/departments pages
- `routes/custom_twin.py` — custom twins CRUD + detail
- `routes/analytics.py` — analytics overview / Department Performance
- `routes/uploads.py` — Excel import
- `services/twin_service.py` — twin business logic
- `services/analytics_service.py` — analytics computation

Models (`database/models/`):
- `custom_twin.py`, `department.py`, `employee.py`, `project.py`, `financial.py` (also `company.py`, `analytics.py` if referenced)

Templates:
- `templates/business_twin/custom_twins.html` — twin cards (View + pencil edit button + "Create New Twin" card)
- `templates/business_twin/custom_twin_detail.html`
- `templates/business_twin/twin_overview.html`
- `templates/business_twin/twin_departments.html`
- `templates/business_twin/custom_twins_data.html`
- `templates/analytics/analytics_overview.html` — Department Performance table + charts

Debug helpers that already exist (use them, don't reinvent):
- `check_db.py` — inspect DB contents
- `smoke_test_fixes.py` — smoke test script
- `migrate_twin_interconnection.py`, `test_twin_interconnection.py` — twin-link feature tests
- `init_db.py`, `create_demo_company.py` — seed data

## BUG 1 — Edit button dead on Custom Twins page

**Symptom:** `Business Twin → Custom Twins` renders one card per twin with a "View" button and a pencil (edit) icon, plus a "Create New Twin" card. Clicking the pencil does nothing — modal never opens, or opens and fails, or the request hits a missing/500-ing route.

**Task:** Diagnose whether the break is frontend (no JS handler, broken/duplicated modal markup) or backend (missing route, wrong HTTP method, 500 on PUT/PATCH). Confirm with the actual code before claiming a cause. Then fix end-to-end:

1. Edit modal opens from every twin card, prefilled with name, icon/color, description.
2. Save issues a PUT/PATCH to a real endpoint in `routes/custom_twin.py` that loads the twin, updates fields, commits, and returns success/JSON or redirects with flash.
3. Card shows updated values after save — no manual refresh of stale data, no 500s.

## BUG 2 — New twins/departments never take effect ("stuffed"/static data)

**Symptom:** The twins list and `Analytics → Department Performance` only update when records are added/edited or an Excel import runs — but per the report, creating a new twin or department shows no change. Root cause to verify and eliminate: pages and analytics reading **materialized/cached snapshots** computed at import time instead of **live database queries**.

**Task:** Confirm by reading `services/twin_service.py`, `services/analytics_service.py`, `routes/analytics.py`, and the templates. Then refactor everything to compute from the DB on each request.

## MAKE IT REAL — REQUIREMENTS

1. **LIVE DATA EVERYWHERE.** No cached snapshots. Twins list, departments, and analytics query the DB fresh on every page load. Create/update/delete of any twin, department, employee, or project — and Excel import — must all be visible immediately on refresh, with no re-import step.
2. **REAL ANALYTICS.** The Department Performance table (Department, Budget, Spent, Utilization %, Variance) must be **live SQL aggregates**: `SUM(project budgets)` and `SUM(actual spend)` grouped per department — never stored constants. `Utilization = spent / budget`, `Variance = budget − spent`. Charts (Revenue / Expenses / Profit over time) derive from financial transactions, recomputed per request.
3. **END-TO-END FLOW WORKS:** create company → create twin/department → add or import employees & projects → analytics update instantly → edit twin works → delete cleans up with confirmation and leaves no orphan rows.
4. **EXCEL IMPORT** writes to the same DB tables as manual entry and flows through the same live queries. No separate snapshot-regeneration step.

## WORKING RULES

1. **Read before you write.** Read every file listed above plus the DB models/schema *before* writing code. State the confirmed root cause of each bug first (with file:line evidence), then patch.
2. **Verify against reality.** Use `grep`/reads to confirm route existence and template element IDs before claiming something is broken or fixed. If you run the app, use `python run.py` and the confirmed Python 3.12 interpreter.
3. **Minimal diffs, in-place edits**, match existing code style, keep the dark "Enterprise Twin" UI intact. No rewrites of unrelated code.
4. **No schema changes** unless absolutely unavoidable — prefer pure logic fixes.
5. **Error handling + feedback** on all CRUD: flash/toast messages, graceful failure (no raw 500s to the user).
6. **Vanilla JS only** for any new template JS — no new frameworks, consistent with the existing codebase.
7. **Never touch `New-Releases/`** or any file outside the project root.

## DELIVERABLES

1. Root-cause diagnosis for each bug (2–4 lines each, with file:line evidence).
2. Full updated contents of every edited file (or a clear diff summary + the exact edits made).
3. Exact manual test steps proving:
   - Edit saves and the card updates.
   - A new twin/department appears immediately on the twins page AND in Analytics.
   - Changing a project's budget/spent updates Utilization/Variance on next page load.
   - Excel import is reflected instantly.
   - No 500 errors anywhere in the flow.

## ACCEPTANCE CRITERIA (all must pass)

- Pencil edit on every twin card → modal opens → saves → card updates, no errors.
- New twin/department appears immediately on the twins page and in Analytics.
- Analytics numbers are live aggregates that change when underlying data changes.
- All CRUD gives user feedback; nothing requires a re-import to refresh.
