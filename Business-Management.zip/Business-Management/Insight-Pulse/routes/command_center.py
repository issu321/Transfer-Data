"""
COMMAND CENTER ROUTE - Executive Business Agent Dashboard

This route provides the main command center interface for the
automated business agent, giving executives a single pane of glass
to monitor and control their entire business.
"""

from flask import Blueprint, render_template, jsonify, session, request, redirect
from flask_login import login_required, current_user
from services.business_agent import BusinessAgent
from services.analytics_service import AnalyticsService
from services.risk_service import RiskService
from services.enterprise_service import EnterpriseService
from database.models.company import Company
from database.models.notification import Notification
from config.constants import CURRENCY_SYMBOLS

command_center_bp = Blueprint('command_center', __name__)


def _get_currency_symbol():
    """Get currency symbol from session or database."""
    currency_code = session.get('company_currency')
    if not currency_code:
        company = Company.query.get(session.get('company_id'))
        currency_code = getattr(company, 'currency', None) if company else None
        if not currency_code:
            currency_code = 'USD'
    return CURRENCY_SYMBOLS.get(currency_code, '$')


@command_center_bp.route('/')
@login_required
def index():
    """Main command center dashboard."""
    company_id = session.get('company_id')
    if not company_id:
        return redirect('/logout')
    
    currency_symbol = _get_currency_symbol()
    company = Company.query.get(company_id)
    
    # Get command center data from business agent
    command_data = BusinessAgent.get_command_center(company_id)
    
    # Get agent status
    agent_status = BusinessAgent.get_agent_status(company_id)
    
    # Get recommendations
    recommendations = BusinessAgent.get_recommendations(company_id)
    
    return render_template('command_center/command_center.html',
                         company=company,
                         command_data=command_data,
                         agent_status=agent_status,
                         recommendations=recommendations,
                         currency_symbol=currency_symbol)


@command_center_bp.route('/api/command-center')
@login_required
def api_command_center():
    """API endpoint for live command center data."""
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    command_data = BusinessAgent.get_command_center(company_id)
    return jsonify(command_data)


@command_center_bp.route('/api/agent-status')
@login_required
def api_agent_status():
    """API endpoint for agent status."""
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    status = BusinessAgent.get_agent_status(company_id)
    return jsonify(status)


@command_center_bp.route('/api/briefing/<period>')
@login_required
def api_briefing(period):
    """Generate executive briefing."""
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    if period not in ['daily', 'weekly', 'monthly']:
        period = 'daily'
    
    briefing = BusinessAgent.generate_executive_briefing(company_id, period)
    return jsonify(briefing)


@command_center_bp.route('/api/recommendations')
@login_required
def api_recommendations():
    """Get AI-powered business recommendations."""
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    recommendations = BusinessAgent.get_recommendations(company_id)
    return jsonify({'recommendations': recommendations})


@command_center_bp.route('/api/health-check', methods=['POST'])
@login_required
def api_health_check():
    """Run a comprehensive health check."""
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    notifications = BusinessAgent.run_health_check(company_id, current_user.id)
    return jsonify({
        'success': True,
        'notifications_created': len(notifications),
        'health_score': Company.query.get(company_id).health_score if Company.query.get(company_id) else 0
    })


@command_center_bp.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def api_mark_notifications_read():
    """Mark notifications as read."""
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    Notification.query.filter_by(
        company_id=company_id,
        user_id=current_user.id,
        is_read=False
    ).update({'is_read': True})
    from database.db import db
    db.session.commit()
    
    return jsonify({'success': True})


@command_center_bp.route('/api/notifications')
@login_required
def api_notifications():
    """Get recent notifications."""
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    notifications = Notification.query.filter_by(
        company_id=company_id,
        user_id=current_user.id
    ).order_by(Notification.created_at.desc()).limit(20).all()
    
    return jsonify({
        'notifications': [n.to_dict() for n in notifications],
        'unread_count': Notification.query.filter_by(
            company_id=company_id, user_id=current_user.id, is_read=False
        ).count()
    })