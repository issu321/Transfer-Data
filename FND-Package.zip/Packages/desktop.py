"""
Desktop window launcher using pywebview.
"""
import time


def launch_desktop_window(port=5000):
    """Launch native desktop window using pywebview."""
    try:
        import webview

        # Wait for server to start
        time.sleep(1.5)

        window = webview.create_window(
            'NeuroGuard FND - Fake News Detection',
            f'http://127.0.0.1:{port}/',
            width=1400,
            height=900,
            resizable=True,
            fullscreen=False,
            text_select=True,
            confirm_close=True
        )

        webview.start(debug=False)
    except ImportError:
        print("⚠️  pywebview not installed. Opening in browser instead.")
        import webbrowser
        webbrowser.open(f'http://127.0.0.1:{port}/')
        print(f"🌐 Open http://127.0.0.1:{port}/ in your browser")
        # Keep the main thread alive
        while True:
            time.sleep(1)
