"""
CLI entry point for the fakenews command.
"""
import sys
import threading

from fakenews_ussu321.app import create_app, run_flask_server
from fakenews_ussu321.desktop import launch_desktop_window


def main():
    """Main entry point for the fakenews CLI command."""
    app = create_app()
    port = 5000

    if '--server-only' in sys.argv:
        print("🌐 Starting in WEB SERVER mode...")
        print(f"   → http://127.0.0.1:{port}/")
        app.run(debug=True, host='0.0.0.0', port=port)
    else:
        print("🖥️  Starting NeuroGuard FND Desktop App...")
        print("   Developer: Mohammed Usman")
        print("   GitHub: issu321")
        print("   Model: Enhanced Ensemble NLP")
        print()

        server_thread = threading.Thread(
            target=run_flask_server,
            args=(app, port),
            daemon=True
        )
        server_thread.start()
        launch_desktop_window(port)


if __name__ == '__main__':
    main()
