"""
NeuroGuard FND - Fake News Detection Desktop Application
Package: fakenews_ussu321
"""

__version__ = "2.0.0"
__author__ = "Mohammed Usman"
__email__ = "jaafreeusman@gmail.com"
__github__ = "issu321"
__description__ = "NeuroGuard FND - Fake News Detection Desktop App"

from .app import create_app, run_flask_server
from .desktop import launch_desktop_window

__all__ = [
    "create_app",
    "run_flask_server",
    "launch_desktop_window",
]
