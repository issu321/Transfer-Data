"""
Entry point for: python -m fakenews_ussu321
"""
from fakenews_ussu321.cli import main

if __name__ == '__main__':
    main()
