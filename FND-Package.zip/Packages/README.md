# NeuroGuard FND — Fake News Detection

**PyPI Package:** `fakenews-ussu321`  
**Python Package:** `fakenews_ussu321`  
**Version:** 2.0.0  
**Developer:** Mohammed Usman  
**GitHub:** [@issu321](https://github.com/issu321)  
**Website:** [issu321.github.io](https://issu321.github.io/Large-Scale-Company-Management-Dashboard/)

---

## Overview

NeuroGuard FND is a professional desktop application for detecting fake news using an **Enhanced Ensemble NLP** model. It combines TF-IDF vectorization, statistical feature engineering, sentiment analysis, and machine learning to classify news articles as **Real** or **Fake** with confidence scores and explainable AI insights.

---

## Features

- **Single Article Analysis** — Paste any news article and get instant real/fake classification with confidence score
- **Batch Processing** — Upload CSV or Excel files to analyze multiple articles at once
- **Explainable AI** — Get detailed explanations of why an article was flagged (sensationalist language, emotional tone, capitalization, etc.)
- **Sentiment Analysis** — Real-time polarity and subjectivity scoring via TextBlob
- **User Authentication** — Secure registration and login with Flask-Login
- **Desktop App** — Native desktop window powered by pywebview (no browser needed)
- **Web Server Mode** — Optional `--server-only` flag for browser-based deployment
- **Model Statistics API** — Compare ensemble model performance metrics

---

## Installation

```bash
pip install fakenews-ussu321
```

---

## Usage

### Desktop Mode (Default)

```bash
fakenews
```

Or:

```bash
python -m fakenews_ussu321
```

Launches a native desktop window at `http://127.0.0.1:5000/`.

### Web Server Mode

```bash
fakenews --server-only
```

Or:

```bash
python -m fakenews_ussu321 --server-only
```

Runs the Flask development server accessible from any browser.

---

## Package Structure

```
fakenews_ussu321/
├── __init__.py          # Package metadata
├── __main__.py          # python -m entry point
├── cli.py               # CLI entry point (fakenews command)
├── desktop.py           # pywebview desktop launcher
├── app.py               # Flask application factory
├── config.py            # Configuration settings
├── models/
│   ├── __init__.py      # SQLAlchemy & LoginManager init
│   ├── predictor.py     # FakeNewsPredictor (ensemble NLP model)
│   └── user.py          # User database model
├── routes/
│   ├── __init__.py      # Blueprint registration
│   ├── main.py          # Public pages (index, about, contact, features)
│   ├── auth.py          # Authentication (login, register, logout)
│   └── dashboard.py     # Prediction API & dashboard routes
├── templates/           # Jinja2 HTML templates
├── static/              # CSS, JS, images
├── Datasets/            # Sample datasets
├── instance/            # SQLite database storage
└── *.pkl                # Trained ML models
```

---

## Dependencies

| Package | Version |
|---------|---------|
| Flask | >=2.3.0 |
| Flask-SQLAlchemy | >=3.0.0 |
| Flask-Login | >=0.6.0 |
| Werkzeug | >=2.3.0 |
| pandas | >=2.0.0 |
| numpy | >=1.24.0 |
| scikit-learn | >=1.3.0 |
| joblib | >=1.3.0 |
| textblob | >=0.17 |
| openpyxl | >=3.1.0 |
| pywebview | >=4.4.0 |

---

## Model Architecture

The **Enhanced Ensemble NLP** model extracts the following features:

1. **TF-IDF Vectorization** — Term frequency-inverse document frequency
2. **Statistical Features** (6 features):
   - Capitalization ratio
   - Exclamation mark count
   - Question mark count
   - Word count
   - Average word length
   - Sensationalist word count
3. **Sentiment Features** (2 features):
   - Polarity (via TextBlob)
   - Subjectivity (via TextBlob)

All features are combined into a sparse matrix and fed into an ensemble classifier.

---

## API Endpoints

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/` | GET | No | Landing page |
| `/features` | GET | No | Features page |
| `/about` | GET | No | About page |
| `/contact` | GET | No | Contact page |
| `/auth/register` | GET/POST | No | User registration |
| `/auth/login` | GET/POST | No | User login |
| `/auth/logout` | GET | Yes | User logout |
| `/auth/api/check-username/<username>` | GET | No | Username availability |
| `/dashboard/` | GET | Yes | Main dashboard |
| `/dashboard/api/predict` | POST | Yes | Single article prediction |
| `/dashboard/api/predict-batch` | POST | Yes | Batch file prediction |
| `/dashboard/api/stats` | GET | Yes | Model performance stats |
| `/api/model-stats` | GET | No | Best model statistics |

---

## Developer

**Mohammed Usman**
- Email: jaafreeusman@gmail.com
- Phone: 8884294749
- GitHub: [issu321](https://github.com/issu321)
- Website: [issu321.github.io](https://issu321.github.io/Large-Scale-Company-Management-Dashboard/)

---

## License

MIT License

---

## Related Packages

- [algo-ussu321](https://pypi.org/project/algo-ussu321/) — Algorithm Visualizer
- [programmingvisualizer-ussu321](https://pypi.org/project/programmingvisualizer-ussu321/) — Programming Visualizer
- [aidataviz-ussu321](https://pypi.org/project/aidataviz-ussu321/) — AI Data Visualization
- [business-ussu321](https://pypi.org/project/business-ussu321/) — Business Simulator
