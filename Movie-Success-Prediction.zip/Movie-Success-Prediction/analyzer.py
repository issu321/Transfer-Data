"""
Movie Data Analysis and EDA Engine
Handles exploratory data analysis, insights generation, and analytics
"""
import json
import numpy as np
import pandas as pd
from collections import Counter
from utils import get_season, format_currency, format_percentage

class MovieAnalyzer:
    def __init__(self, df=None):
        self.df = df
        self.analysis_results = {}
        self.insights = {}

    def load_data(self, df):
        self.df = df.copy()
        self.analysis_results = {}
        self.insights = {}

    def get_overview(self):
        """Generate dataset overview statistics"""
        if self.df is None or self.df.empty:
            return {}

        overview = {
            'total_movies': len(self.df),
            'total_columns': len(self.df.columns),
            'column_names': list(self.df.columns),
            'memory_usage': f"{self.df.memory_usage(deep=True).sum() / 1024**2:.2f} MB",
            'numeric_columns': list(self.df.select_dtypes(include=[np.number]).columns),
            'categorical_columns': list(self.df.select_dtypes(include=['object', 'category']).columns),
            'date_columns': list(self.df.select_dtypes(include=['datetime64']).columns)
        }

        # Detect movie-specific columns
        col_info = {}
        for col in self.df.columns:
            col_lower = col.lower().replace(' ', '_')
            if 'budget' in col_lower:
                col_info['budget_column'] = col
                overview['budget_stats'] = {
                    'mean': format_currency(self.df[col].mean()),
                    'median': format_currency(self.df[col].median()),
                    'min': format_currency(self.df[col].min()),
                    'max': format_currency(self.df[col].max())
                }
            elif 'revenue' in col_lower and 'budget' not in col_lower:
                col_info['revenue_column'] = col
                overview['revenue_stats'] = {
                    'mean': format_currency(self.df[col].mean()),
                    'median': format_currency(self.df[col].median()),
                    'min': format_currency(self.df[col].min()),
                    'max': format_currency(self.df[col].max())
                }
            elif 'genre' in col_lower:
                col_info['genre_column'] = col
                top_genres = self.df[col].value_counts().head(10).to_dict()
                overview['top_genres'] = {str(k): int(v) for k, v in top_genres.items()}
            elif 'rating' in col_lower or 'vote_average' in col_lower:
                col_info['rating_column'] = col
                overview['rating_stats'] = {
                    'mean': round(self.df[col].mean(), 2),
                    'median': round(self.df[col].median(), 2),
                    'min': round(self.df[col].min(), 2),
                    'max': round(self.df[col].max(), 2)
                }
            elif 'runtime' in col_lower or 'duration' in col_lower:
                col_info['runtime_column'] = col
                overview['runtime_stats'] = {
                    'mean': round(self.df[col].mean(), 1),
                    'median': round(self.df[col].median(), 1),
                    'min': round(self.df[col].min(), 1),
                    'max': round(self.df[col].max(), 1)
                }

        overview['detected_columns'] = col_info
        return overview

    def get_missing_analysis(self):
        """Analyze missing values in dataset"""
        if self.df is None:
            return {}

        missing = self.df.isnull().sum()
        missing_pct = (missing / len(self.df) * 100).round(2)

        missing_analysis = {
            'total_missing': int(missing.sum()),
            'columns_with_missing': int((missing > 0).sum()),
            'missing_by_column': {}
        }

        for col in self.df.columns:
            if missing[col] > 0:
                missing_analysis['missing_by_column'][col] = {
                    'count': int(missing[col]),
                    'percentage': float(missing_pct[col])
                }

        return missing_analysis

    def get_correlation_analysis(self):
        """Generate correlation analysis for numeric columns"""
        if self.df is None:
            return {}

        numeric_df = self.df.select_dtypes(include=[np.number])
        if numeric_df.empty or len(numeric_df.columns) < 2:
            return {'error': 'Not enough numeric columns for correlation'}

        corr_matrix = numeric_df.corr().round(3)

        # Find strongest correlations
        corr_pairs = []
        for i in range(len(corr_matrix.columns)):
            for j in range(i+1, len(corr_matrix.columns)):
                col1 = corr_matrix.columns[i]
                col2 = corr_matrix.columns[j]
                val = corr_matrix.iloc[i, j]
                if not np.isnan(val):
                    corr_pairs.append({
                        'column1': col1,
                        'column2': col2,
                        'correlation': float(val),
                        'strength': 'Strong' if abs(val) > 0.7 else 'Moderate' if abs(val) > 0.4 else 'Weak'
                    })

        corr_pairs.sort(key=lambda x: abs(x['correlation']), reverse=True)

        return {
            'correlation_matrix': corr_matrix.to_dict(),
            'top_correlations': corr_pairs[:15],
            'total_pairs': len(corr_pairs)
        }

    def get_genre_analysis(self):
        """Analyze genre performance and trends"""
        if self.df is None:
            return {}

        # Find genre column
        genre_col = None
        for col in self.df.columns:
            if 'genre' in col.lower():
                genre_col = col
                break

        if genre_col is None:
            return {'error': 'No genre column found'}

        genre_data = self.df[genre_col].astype(str)

        # Handle multiple genres per movie
        all_genres = []
        for genres in genre_data:
            if pd.isna(genres):
                continue
            for g in str(genres).split(','):
                all_genres.append(g.strip())

        genre_counts = Counter(all_genres)
        top_genres = dict(genre_counts.most_common(15))

        # Genre performance if revenue/rating available
        genre_performance = {}
        revenue_col = None
        rating_col = None

        for col in self.df.columns:
            if 'revenue' in col.lower() and 'budget' not in col.lower():
                revenue_col = col
            elif ('rating' in col.lower() or 'vote_average' in col.lower()) and 'count' not in col.lower():
                rating_col = col

        if revenue_col or rating_col:
            for genre in list(top_genres.keys())[:10]:
                mask = genre_data.str.contains(genre, na=False)
                perf = {'count': int(mask.sum())}

                if revenue_col:
                    perf['avg_revenue'] = format_currency(self.df.loc[mask, revenue_col].mean())
                if rating_col:
                    perf['avg_rating'] = round(self.df.loc[mask, rating_col].mean(), 2)

                genre_performance[genre] = perf

        return {
            'top_genres': top_genres,
            'genre_performance': genre_performance,
            'total_unique_genres': len(genre_counts)
        }

    def get_budget_analysis(self):
        """Analyze budget vs revenue and ROI"""
        if self.df is None:
            return {}

        budget_col = None
        revenue_col = None

        for col in self.df.columns:
            if 'budget' in col.lower():
                budget_col = col
            elif 'revenue' in col.lower() and 'budget' not in col.lower():
                revenue_col = col

        if not budget_col:
            return {'error': 'No budget column found'}

        budget = pd.to_numeric(self.df[budget_col], errors='coerce')

        analysis = {
            'budget_ranges': {
                'low': int((budget < 1e7).sum()),
                'medium': int(((budget >= 1e7) & (budget < 5e7)).sum()),
                'high': int(((budget >= 5e7) & (budget < 1e8)).sum()),
                'blockbuster': int((budget >= 1e8).sum())
            },
            'budget_stats': {
                'mean': format_currency(budget.mean()),
                'median': format_currency(budget.median()),
                'std': format_currency(budget.std())
            }
        }

        if revenue_col:
            revenue = pd.to_numeric(self.df[revenue_col], errors='coerce')
            roi = ((revenue - budget) / budget * 100).replace([np.inf, -np.inf], np.nan)

            analysis['roi_stats'] = {
                'mean': round(roi.mean(), 1),
                'median': round(roi.median(), 1),
                'profitable_movies': int((roi > 0).sum()),
                'loss_making_movies': int((roi < 0).sum())
            }

            # Budget vs Revenue correlation
            valid_mask = budget.notna() & revenue.notna()
            if valid_mask.sum() > 10:
                corr = budget[valid_mask].corr(revenue[valid_mask])
                analysis['budget_revenue_correlation'] = round(float(corr), 3)

        return analysis

    def get_seasonal_analysis(self):
        """Analyze seasonal release patterns"""
        if self.df is None:
            return {}

        # Find date column
        date_col = None
        for col in self.df.columns:
            if 'release' in col.lower() and 'date' in col.lower():
                date_col = col
                break

        if date_col is None:
            # Try month column
            for col in self.df.columns:
                if col.lower() == 'month':
                    date_col = col
                    break

        if date_col is None:
            return {'error': 'No release date column found'}

        if date_col.lower() == 'month':
            months = pd.to_numeric(self.df[date_col], errors='coerce').dropna().astype(int)
        else:
            dates = pd.to_datetime(self.df[date_col], errors='coerce')
            months = dates.dt.month.dropna().astype(int)

        if months.empty:
            return {'error': 'Could not parse dates'}

        month_counts = months.value_counts().sort_index().to_dict()
        seasons = months.apply(get_season)
        season_counts = seasons.value_counts().to_dict()

        # Revenue by season if available
        revenue_by_season = {}
        revenue_col = None
        for col in self.df.columns:
            if 'revenue' in col.lower() and 'budget' not in col.lower():
                revenue_col = col
                break

        if revenue_col and date_col.lower() != 'month':
            dates = pd.to_datetime(self.df[date_col], errors='coerce')
            seasons_full = dates.apply(get_season)
            revenue = pd.to_numeric(self.df[revenue_col], errors='coerce')

            for season in ['Spring', 'Summer', 'Fall', 'Winter']:
                mask = seasons_full == season
                if mask.sum() > 0:
                    revenue_by_season[season] = format_currency(revenue[mask].mean())

        return {
            'monthly_distribution': {int(k): int(v) for k, v in month_counts.items()},
            'seasonal_distribution': {str(k): int(v) for k, v in season_counts.items()},
            'revenue_by_season': revenue_by_season,
            'peak_month': int(months.value_counts().idxmax()),
            'peak_season': str(seasons.value_counts().idxmax())
        }

    def get_distribution_analysis(self):
        """Analyze distributions of key metrics"""
        if self.df is None:
            return {}

        distributions = {}

        for col in self.df.select_dtypes(include=[np.number]).columns:
            data = self.df[col].dropna()
            if len(data) > 0:
                distributions[col] = {
                    'mean': round(float(data.mean()), 3),
                    'median': round(float(data.median()), 3),
                    'std': round(float(data.std()), 3),
                    'min': round(float(data.min()), 3),
                    'max': round(float(data.max()), 3),
                    'q1': round(float(data.quantile(0.25)), 3),
                    'q3': round(float(data.quantile(0.75)), 3),
                    'skewness': round(float(data.skew()), 3)
                }

        return distributions

    def generate_insights(self):
        """Generate AI-like insights from the data"""
        if self.df is None:
            return {}

        insights = {
            'success_drivers': [],
            'failure_drivers': [],
            'revenue_influencers': [],
            'genre_trends': [],
            'seasonal_trends': [],
            'audience_preferences': [],
            'recommendations': []
        }

        overview = self.get_overview()
        corr = self.get_correlation_analysis()
        genre = self.get_genre_analysis()
        budget = self.get_budget_analysis()
        seasonal = self.get_seasonal_analysis()

        # Success drivers from correlation
        if 'top_correlations' in corr:
            for pair in corr['top_correlations'][:5]:
                if abs(pair['correlation']) > 0.3:
                    insights['success_drivers'].append(
                        f"{pair['column1']} and {pair['column2']} show {pair['strength'].lower()} correlation ({pair['correlation']:.2f})"
                    )

        # Genre insights
        if 'genre_performance' in genre:
            best_genre = max(genre['genre_performance'].items(), key=lambda x: x[1].get('avg_revenue', 0) if isinstance(x[1], dict) else 0, default=(None, {}))
            if best_genre[0]:
                insights['genre_trends'].append(
                    f"{best_genre[0]} shows the highest average revenue performance"
                )

        if 'top_genres' in genre:
            most_common = max(genre['top_genres'].items(), key=lambda x: x[1], default=(None, 0))
            if most_common[0]:
                insights['genre_trends'].append(
                    f"{most_common[0]} is the most common genre with {most_common[1]} movies"
                )

        # Budget insights
        if 'roi_stats' in budget:
            profitable = budget['roi_stats']['profitable_movies']
            total = sum(budget['budget_ranges'].values()) if 'budget_ranges' in budget else 0
            if total > 0:
                pct = profitable / total * 100
                insights['revenue_influencers'].append(
                    f"{pct:.1f}% of movies are profitable, indicating budget efficiency is critical"
                )

        if 'budget_revenue_correlation' in budget:
            corr_val = budget['budget_revenue_correlation']
            insights['revenue_influencers'].append(
                f"Budget and revenue correlation is {corr_val:.2f} - {'strong' if abs(corr_val) > 0.5 else 'moderate'} predictor of success"
            )

        # Seasonal insights
        if 'peak_season' in seasonal:
            insights['seasonal_trends'].append(
                f"{seasonal['peak_season']} is the peak release season"
            )

        if 'revenue_by_season' in seasonal and seasonal['revenue_by_season']:
            best_season = max(seasonal['revenue_by_season'].items(), key=lambda x: float(x[1].replace('$', '').replace('M', '').replace('K', '').replace('B', '')), default=(None, 0))
            if best_season[0]:
                insights['seasonal_trends'].append(
                    f"{best_season[0]} releases generate the highest average revenue"
                )

        # Recommendations
        insights['recommendations'].append("Focus on high-budget productions in peak seasons for maximum revenue potential")
        insights['recommendations'].append("Genre diversification can reduce risk and capture different audience segments")
        insights['recommendations'].append("Monitor cast and director popularity scores as key success indicators")

        if 'rating_stats' in overview:
            avg_rating = overview['rating_stats']['mean']
            insights['audience_preferences'].append(
                f"Average audience rating is {avg_rating} - {'above average' if avg_rating > 6 else 'below average'} reception"
            )

        self.insights = insights
        return insights

    def get_feature_importance_data(self, predictor_instance):
        """Get feature importance from trained model"""
        if predictor_instance and predictor_instance.is_trained:
            return predictor_instance.get_feature_importance()
        return {}

    def get_all_analytics(self):
        """Generate complete analytics package"""
        return {
            'overview': self.get_overview(),
            'missing_analysis': self.get_missing_analysis(),
            'correlation_analysis': self.get_correlation_analysis(),
            'genre_analysis': self.get_genre_analysis(),
            'budget_analysis': self.get_budget_analysis(),
            'seasonal_analysis': self.get_seasonal_analysis(),
            'distribution_analysis': self.get_distribution_analysis(),
            'insights': self.generate_insights()
        }

# Global analyzer instance
analyzer = MovieAnalyzer()
