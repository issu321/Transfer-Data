// ============================================
// Movie Success Prediction - Interactive JS
// Maximum Visibility & High Contrast Theme
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    initNavigation();
    initAnimations();
    initForms();
    initCharts();
    initUploadZone();
    initPredictionForm();
    initSearch();
});

// Theme Management - ROBUST VERSION
function initTheme() {
    const themeToggles = document.querySelectorAll('#theme-toggle');

    themeToggles.forEach(toggle => {
        toggle.addEventListener('click', async function() {
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);

            // Update server preference if logged in
            try {
                await fetch('/api/settings/theme', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({theme: newTheme})
                });
            } catch(e) {}
        });
    });

    // Load saved theme
    const savedTheme = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
}

// Navigation - Always visible
function initNavigation() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;

    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        if (currentScroll > 50) {
            navbar.style.boxShadow = '0 4px 20px rgba(0,0,0,0.3)';
        } else {
            navbar.style.boxShadow = 'none';
        }
    });

    // Mobile menu toggle
    const mobileToggle = document.getElementById('mobile-menu-toggle');
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function() {
            document.querySelector('.nav-links').classList.toggle('active');
        });
    }
}

// Animations - Fade in elements
function initAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    document.querySelectorAll('.glass-card, .feature-card, .movie-card, .actor-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(el);
    });
}

// Form Handling
function initForms() {
    // Auto-dismiss alerts
    document.querySelectorAll('.alert').forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 6000);
    });
}

// Chart.js Initialization
function initCharts() {
    if (typeof Chart === 'undefined') return;

    Chart.defaults.color = '#94a3b8';
    Chart.defaults.borderColor = 'rgba(148, 163, 184, 0.2)';
    Chart.defaults.font.family = "'Segoe UI', system-ui, sans-serif";
    Chart.defaults.font.weight = '600';
}

// Upload Zone
function initUploadZone() {
    const uploadZone = document.getElementById('upload-zone');
    if (!uploadZone) return;

    const fileInput = document.getElementById('file-input');
    const uploadStatus = document.getElementById('upload-status');
    const uploadProgress = document.getElementById('upload-progress');

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        uploadZone.addEventListener(eventName, () => uploadZone.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadZone.addEventListener(eventName, () => uploadZone.classList.remove('dragover'), false);
    });

    uploadZone.addEventListener('drop', handleDrop, false);
    uploadZone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFiles);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        handleFiles({target: {files: files}});
    }

    function handleFiles(e) {
        const files = e.target.files;
        if (!files.length) return;

        Array.from(files).forEach(file => {
            if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
                showAlert('Only CSV files are allowed', 'error');
                return;
            }
            uploadFile(file);
        });
    }

    function uploadFile(file) {
        const formData = new FormData();
        formData.append('file', file);

        uploadStatus.textContent = `Uploading ${file.name}...`;
        uploadStatus.style.color = 'var(--accent-primary)';
        uploadProgress.style.width = '30%';

        fetch('/api/upload', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            uploadProgress.style.width = '100%';
            if (data.success) {
                uploadStatus.textContent = `✅ ${data.message}`;
                uploadStatus.style.color = 'var(--accent-success)';
                showAlert(data.message, 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                uploadStatus.textContent = `❌ ${data.message}`;
                uploadStatus.style.color = 'var(--accent-danger)';
                showAlert(data.message, 'error');
            }
        })
        .catch(err => {
            uploadStatus.textContent = '❌ Upload failed';
            uploadStatus.style.color = 'var(--accent-danger)';
            showAlert('Upload failed: ' + err.message, 'error');
        });
    }
}

// Prediction Form
function initPredictionForm() {
    const form = document.getElementById('prediction-form');
    if (!form) return;

    form.addEventListener('submit', async function(e) {
        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<span class="spinner" style="width:20px;height:20px;border-width:2px;display:inline-block;margin-right:8px;"></span> Analyzing...';
        submitBtn.disabled = true;

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        // Convert numeric fields
        ['budget', 'runtime', 'cast_popularity', 'director_popularity', 'vote_count', 'popularity_score', 'release_month'].forEach(field => {
            if (data[field]) data[field] = parseFloat(data[field]);
        });

        try {
            const response = await fetch('/api/predict', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (result.success) {
                displayPredictionResult(result.result);
            } else {
                showAlert(result.message, 'error');
            }
        } catch (err) {
            showAlert('Prediction failed: ' + err.message, 'error');
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    });
}

function displayPredictionResult(result) {
    const container = document.getElementById('prediction-result');
    if (!container) return;

    const isSuccess = result.success;
    const probability = (result.success_probability * 100).toFixed(1);
    const confidence = (result.confidence * 100).toFixed(1);

    container.className = `prediction-result ${isSuccess ? 'prediction-success' : 'prediction-failure'}`;
    container.innerHTML = `
        <div style="margin-bottom: 1.5rem;">
            <div style="font-size: 4rem; margin-bottom: 1rem;">${isSuccess ? '🎉' : '⚠️'}</div>
            <h2 style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--text-primary);">${isSuccess ? 'Predicted Success!' : 'Predicted Risk'}</h2>
            <p style="color: var(--text-secondary); font-size: 1.1rem; font-weight: 600;">Model: ${result.model_used} | Confidence: ${confidence}%</p>
        </div>

        <div class="grid-3" style="margin: 2rem 0;">
            <div class="glass-card" style="padding: 1.5rem;">
                <div style="font-size: 0.875rem; color: var(--text-secondary); margin-bottom: 0.5rem; font-weight: 700;">Success Probability</div>
                <div style="font-size: 2.5rem; font-weight: 800; color: ${isSuccess ? 'var(--accent-success)' : 'var(--accent-danger)'};">${probability}%</div>
                <div class="progress-bar" style="margin-top: 0.75rem;">
                    <div class="progress-fill" style="width: ${probability}%; background: ${isSuccess ? 'var(--accent-success)' : 'var(--accent-danger)'};"></div>
                </div>
            </div>

            <div class="glass-card" style="padding: 1.5rem;">
                <div style="font-size: 0.875rem; color: var(--text-secondary); margin-bottom: 0.5rem; font-weight: 700;">Est. Revenue</div>
                <div style="font-size: 1.75rem; font-weight: 700; color: var(--text-primary);">${result.revenue_estimate.estimated_revenue}</div>
                <div style="font-size: 0.875rem; color: var(--text-secondary); margin-top: 0.25rem; font-weight: 600;">Range: ${result.revenue_estimate.revenue_range_low} - ${result.revenue_estimate.revenue_range_high}</div>
            </div>

            <div class="glass-card" style="padding: 1.5rem;">
                <div style="font-size: 0.875rem; color: var(--text-secondary); margin-bottom: 0.5rem; font-weight: 700;">Est. Rating</div>
                <div style="font-size: 2.5rem; font-weight: 700; color: var(--text-primary);">${result.rating_estimate.estimated_rating}</div>
                <div style="font-size: 0.875rem; color: var(--text-secondary); margin-top: 0.25rem; font-weight: 600;">Range: ${result.rating_estimate.rating_range_low} - ${result.rating_estimate.rating_range_high}</div>
            </div>
        </div>

        <div class="grid-2" style="text-align: left; margin-top: 1.5rem;">
            <div class="glass-card" style="padding: 1.5rem;">
                <h3 style="margin-bottom: 1rem; color: var(--accent-success); font-weight: 700;">✅ Success Factors</h3>
                ${result.success_factors.length ? result.success_factors.map(f => `<div style="padding: 0.5rem 0; border-bottom: 2px solid var(--border-glass); font-weight: 600; color: var(--text-primary);">${f}</div>`).join('') : '<div style="color: var(--text-secondary); font-weight: 600;">No specific success factors identified</div>'}
            </div>

            <div class="glass-card" style="padding: 1.5rem;">
                <h3 style="margin-bottom: 1rem; color: var(--accent-danger); font-weight: 700;">⚠️ Risk Factors</h3>
                ${result.failure_risks.length ? result.failure_risks.map(f => `<div style="padding: 0.5rem 0; border-bottom: 2px solid var(--border-glass); font-weight: 600; color: var(--text-primary);">${f}</div>`).join('') : '<div style="color: var(--text-secondary); font-weight: 600;">No significant risks identified</div>'}
            </div>
        </div>

        <div class="glass-card" style="padding: 1.5rem; margin-top: 1.5rem; text-align: left;">
            <h3 style="margin-bottom: 1rem; color: var(--text-primary); font-weight: 700;">📊 Feature Importance</h3>
            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                ${Object.entries(result.feature_importance || {}).slice(0, 8).map(([feature, importance]) => `
                    <div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                            <span style="font-size: 0.875rem; font-weight: 600; color: var(--text-primary);">${feature.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                            <span style="font-weight: 700; color: var(--accent-primary);">${importance}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${importance}%"></div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    container.scrollIntoView({behavior: 'smooth', block: 'nearest'});
}

// Search
function initSearch() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;

    let debounceTimer;
    searchInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => performSearch(this.value), 300);
    });
}

async function performSearch(query) {
    if (!query || query.length < 2) {
        document.getElementById('search-results').innerHTML = '';
        return;
    }

    try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const data = await response.json();

        if (data.success) {
            displaySearchResults(data.results);
        }
    } catch (e) {}
}

function displaySearchResults(results) {
    const container = document.getElementById('search-results');
    if (!container) return;

    let html = '';

    if (results.datasets.length) {
        html += '<div class="search-category"><h4>Datasets</h4>' + 
                results.datasets.map(d => `<div class="search-item">📁 ${d}</div>`).join('') + '</div>';
    }
    if (results.reports.length) {
        html += '<div class="search-category"><h4>Reports</h4>' + 
                results.reports.map(r => `<div class="search-item">📄 ${r.name}</div>`).join('') + '</div>';
    }
    if (results.history.length) {
        html += '<div class="search-category"><h4>History</h4>' + 
                results.history.map(h => `<div class="search-item">🕐 ${h.details}</div>`).join('') + '</div>';
    }

    container.innerHTML = html || '<div class="search-empty">No results found</div>';
}

// Alert Helper - HIGH VISIBILITY
function showAlert(message, type = 'info') {
    const container = document.getElementById('alert-container') || document.body;
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.innerHTML = `
        <span style="font-size: 1.25rem;">${type === 'success' ? '✅' : type === 'error' ? '❌' : type === 'warning' ? '⚠️' : 'ℹ️'}</span>
        <span>${message}</span>
    `;
    alert.style.position = 'fixed';
    alert.style.top = '90px';
    alert.style.right = '20px';
    alert.style.zIndex = '9999';
    alert.style.maxWidth = '400px';
    alert.style.fontWeight = '700';
    container.appendChild(alert);

    setTimeout(() => {
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
    }, 5000);
}

// Analytics Charts Loader
async function loadAnalytics() {
    const container = document.getElementById('analytics-container');
    if (!container) return;

    container.innerHTML = '<div style="text-align:center;padding:3rem;"><div class="spinner"></div><p style="margin-top:1rem;color:var(--text-secondary);font-weight:600;">Loading analytics...</p></div>';

    try {
        const response = await fetch('/api/analytics');
        const data = await response.json();

        if (data.success) {
            renderAnalytics(data.analytics);
        } else {
            container.innerHTML = `<div class="alert alert-error">${data.message}</div>`;
        }
    } catch (err) {
        container.innerHTML = `<div class="alert alert-error">Failed to load analytics</div>`;
    }
}

function renderAnalytics(analytics) {
    const container = document.getElementById('analytics-container');
    if (!container) return;

    const overview = analytics.overview || {};
    const insights = analytics.insights || {};

    container.innerHTML = `
        <div class="grid-4" style="margin-bottom: 2rem;">
            <div class="glass-card stat-card">
                <div class="stat-icon">🎬</div>
                <div class="stat-value">${overview.total_movies || 0}</div>
                <div class="stat-label">Total Movies</div>
            </div>
            <div class="glass-card stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-value">${overview.total_columns || 0}</div>
                <div class="stat-label">Columns</div>
            </div>
            <div class="glass-card stat-card">
                <div class="stat-icon">💾</div>
                <div class="stat-value">${overview.memory_usage || '0 MB'}</div>
                <div class="stat-label">Memory Usage</div>
            </div>
            <div class="glass-card stat-card">
                <div class="stat-icon">🔍</div>
                <div class="stat-value">${Object.keys(overview.detected_columns || {}).length}</div>
                <div class="stat-label">Detected Features</div>
            </div>
        </div>

        <div class="grid-2">
            <div class="glass-card">
                <div class="card-header">
                    <div class="card-title">💡 AI Insights</div>
                </div>
                <div class="card-body">
                    ${Object.entries(insights).filter(([_, items]) => items.length).map(([category, items]) => `
                        <div style="margin-bottom: 1.5rem;">
                            <h4 style="margin-bottom: 0.75rem; color: var(--accent-primary); font-weight: 700;">${category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</h4>
                            ${items.map(item => `<div class="insight-item">${item}</div>`).join('')}
                        </div>
                    `).join('') || '<div style="color: var(--text-secondary); font-weight: 600;">No insights available</div>'}
                </div>
            </div>

            <div class="glass-card">
                <div class="card-header">
                    <div class="card-title">📈 Distribution Analysis</div>
                </div>
                <div class="card-body">
                    ${Object.entries(analytics.distribution_analysis || {}).slice(0, 6).map(([col, stats]) => `
                        <div style="margin-bottom: 1rem; padding: 0.75rem; background: var(--bg-secondary); border-radius: var(--radius-sm); border: 2px solid var(--border-glass);">
                            <div style="font-weight: 700; margin-bottom: 0.5rem; color: var(--text-primary);">${col}</div>
                            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; font-size: 0.8rem; color: var(--text-secondary); font-weight: 600;">
                                <div>Mean: ${stats.mean}</div>
                                <div>Median: ${stats.median}</div>
                                <div>Std: ${stats.std}</div>
                            </div>
                        </div>
                    `).join('') || '<div style="color: var(--text-secondary); font-weight: 600;">No distribution data available</div>'}
                </div>
            </div>
        </div>
    `;
}

// Model Comparison Loader
async function loadModelComparison() {
    const container = document.getElementById('model-comparison-container');
    if (!container) return;

    try {
        const response = await fetch('/api/models/compare');
        const data = await response.json();

        if (data.success) {
            renderModelComparison(data.comparison);
        }
    } catch (err) {
        container.innerHTML = '<div class="alert alert-error">Failed to load model comparison</div>';
    }
}

function renderModelComparison(comparison) {
    const container = document.getElementById('model-comparison-container');
    if (!container) return;

    const models = Object.entries(comparison).filter(([_, data]) => data.trained);
    if (!models.length) {
        container.innerHTML = '<div class="alert alert-warning">No models trained yet. Upload a dataset first.</div>';
        return;
    }

    const bestModel = models.reduce((best, [name, data]) => 
        data.f1_score > best[1].f1_score ? [name, data] : best, models[0]);

    container.innerHTML = `
        <div class="glass-card" style="overflow: hidden;">
            <div class="card-header">
                <div class="card-title">🤖 Model Comparison</div>
                <span class="badge badge-success">Best: ${bestModel[0]}</span>
            </div>
            <div style="overflow-x: auto;">
                <table class="model-comparison">
                    <thead>
                        <tr>
                            <th>Model</th>
                            <th>Accuracy</th>
                            <th>Precision</th>
                            <th>Recall</th>
                            <th>F1 Score</th>
                            <th>ROC-AUC</th>
                            <th>CV Accuracy</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${models.map(([name, data]) => `
                            <tr class="${name === bestModel[0] ? 'best-model' : ''}">
                                <td style="font-weight: 700;">${name} ${name === bestModel[0] ? '⭐' : ''}</td>
                                <td>${(data.accuracy * 100).toFixed(1)}%</td>
                                <td>${(data.precision * 100).toFixed(1)}%</td>
                                <td>${(data.recall * 100).toFixed(1)}%</td>
                                <td style="font-weight: 700; color: ${name === bestModel[0] ? 'var(--accent-success)' : 'inherit'};">${(data.f1_score * 100).toFixed(1)}%</td>
                                <td>${(data.roc_auc * 100).toFixed(1)}%</td>
                                <td>${(data.cv_accuracy * 100).toFixed(1)}%</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>

        <div class="grid-2" style="margin-top: 1.5rem;">
            <div class="glass-card">
                <div class="card-header"><div class="card-title">📊 Accuracy Comparison</div></div>
                <div class="card-body">
                    <canvas id="accuracy-chart" height="200"></canvas>
                </div>
            </div>
            <div class="glass-card">
                <div class="card-header"><div class="card-title">📊 F1 Score Comparison</div></div>
                <div class="card-body">
                    <canvas id="f1-chart" height="200"></canvas>
                </div>
            </div>
        </div>
    `;

    if (typeof Chart !== 'undefined') {
        setTimeout(() => {
            renderComparisonChart('accuracy-chart', models, 'accuracy', 'Accuracy');
            renderComparisonChart('f1-chart', models, 'f1_score', 'F1 Score');
        }, 100);
    }
}

function renderComparisonChart(canvasId, models, metric, label) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: models.map(([name]) => name),
            datasets: [{
                label: label,
                data: models.map(([_, data]) => (data[metric] * 100).toFixed(1)),
                backgroundColor: models.map(([name, _]) => 
                    name === models[0][0] ? 'rgba(34, 197, 94, 0.8)' : 'rgba(59, 130, 246, 0.7)'
                ),
                borderColor: models.map(([name, _]) => 
                    name === models[0][0] ? 'rgba(34, 197, 94, 1)' : 'rgba(59, 130, 246, 1)'
                ),
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: { callback: v => v + '%', color: '#94a3b8', font: { weight: '600' } },
                    grid: { color: 'rgba(148, 163, 184, 0.15)' }
                },
                x: {
                    ticks: { color: '#94a3b8', font: { weight: '600' } },
                    grid: { display: false }
                }
            }
        }
    });
}

// Report Generation
async function generateReport(type) {
    const btn = document.getElementById(`generate-${type}-btn`);
    if (!btn) return;

    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="spinner" style="width:16px;height:16px;border-width:2px;display:inline-block;margin-right:8px;"></span> Generating...';
    btn.disabled = true;

    try {
        const response = await fetch('/api/reports/generate', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                type: type,
                name: `Movie_Analytics_Report_${new Date().toISOString().slice(0, 10)}`
            })
        });

        const data = await response.json();

        if (data.success) {
            showAlert(`${type.toUpperCase()} report generated successfully!`, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(data.message, 'error');
        }
    } catch (err) {
        showAlert('Report generation failed', 'error');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

// Export for global access
window.loadAnalytics = loadAnalytics;
window.loadModelComparison = loadModelComparison;
window.generateReport = generateReport;
window.showAlert = showAlert;
