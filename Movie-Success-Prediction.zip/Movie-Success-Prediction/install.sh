#!/usr/bin/env bash
# Movie Success Prediction - Linux Installer
# GitHub: https://github.com/issu321
# Repository: https://github.com/issu321/Analysis-of-Algorithms

set -e

echo "🎬 Movie Success Prediction - Installation Script"
echo "=================================================="

# Check Python version
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1,2)
REQUIRED_VERSION="3.11"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo "⚠️  Python 3.11+ is required. Found: $PYTHON_VERSION"
    exit 1
fi

echo "✅ Python version check passed: $PYTHON_VERSION"

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv venv

# Activate venv and install dependencies
echo "📥 Installing dependencies..."
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt

# Initialize data directories
echo "📁 Initializing data directories..."
mkdir -p data uploads reports models templates static/css static/js static/assets

# Initialize JSON files if they don't exist
if [ ! -f "data/users.json" ]; then
    echo '{"users": [], "next_id": 1}' > data/users.json
fi
if [ ! -f "data/history.json" ]; then
    echo '{"history": [], "next_id": 1}' > data/history.json
fi
if [ ! -f "data/reports.json" ]; then
    echo '{"reports": [], "next_id": 1}' > data/reports.json
fi
if [ ! -f "data/settings.json" ]; then
    echo '{"settings": {"theme": "dark", "default_model": "auto", "max_upload_size": 50, "session_timeout": 3600}}' > data/settings.json
fi

echo "✅ Installation complete!"
echo ""
echo "🚀 To start the application:"
echo "   ./venv/bin/python app.py"
echo ""
echo "🌐 The application will be available at: http://localhost:5000"
echo ""
