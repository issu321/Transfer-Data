#!/usr/bin/env python3
"""
Movie Success Prediction - AI Web Application v3.0+
Complete Flask Application with ML, Analytics, Hollywood/Bollywood
GitHub: https://github.com/issu321
Repository: https://github.com/issu321/Analysis-of-Algorithms
"""
import os
import sys
import json
import uuid
import pickle
import base64
import io
import re
from datetime import datetime, timedelta
from functools import wraps

import numpy as np
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file, Response
from werkzeug.utils import secure_filename

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils import (
    load_json, save_json, hash_password, verify_password, generate_session_token,
    require_login, get_current_user, validate_csv_file, validate_movie_data,
    detect_movie_columns, get_movie_dataset_features, format_currency, format_percentage,
    get_season, log_activity, get_user_stats, sanitize_filename, ensure_dirs,
    get_theme, set_theme, DATA_DIR, UPLOAD_DIR, REPORT_DIR, MODEL_DIR, to_serializable
)
from predictor import MoviePredictor, predictor
from analyzer import MovieAnalyzer, analyzer

# Flask App Configuration
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'movie-success-prediction-secret-key-2024')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = UPLOAD_DIR
app.config['REPORT_FOLDER'] = REPORT_DIR

ensure_dirs()
ALLOWED_EXTENSIONS = {'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def slugify(title):
    """Convert title to URL-safe slug"""
    return re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')

def deslugify(slug):
    """Convert slug back to approximate title for matching"""
    return slug.replace('-', ' ').title()

# ==================== MOVIE DATABASE ====================
HOLLYWOOD_MOVIES = [
    {"title": "Avengers: Endgame", "year": 2019, "genre": "Action", "budget": 356000000, "revenue": 2798000000, "rating": 8.4, "director": "Anthony Russo", "cast": "Robert Downey Jr", "heroine": "Scarlett Johansson", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "After the devastating events of Infinity War, the Avengers assemble once more to reverse Thanos' actions and restore balance to the universe.", "poster": "🎬", "votes": 1200000},
    {"title": "The Dark Knight", "year": 2008, "genre": "Action", "budget": 185000000, "revenue": 1005000000, "rating": 9.0, "director": "Christopher Nolan", "cast": "Christian Bale", "heroine": "Maggie Gyllenhaal", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological tests of his ability to fight injustice.", "poster": "🦇", "votes": 2800000},
    {"title": "Inception", "year": 2010, "genre": "Sci-Fi", "budget": 160000000, "revenue": 836800000, "rating": 8.8, "director": "Christopher Nolan", "cast": "Leonardo DiCaprio", "heroine": "Elliot Page", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.", "poster": "🌀", "votes": 2300000},
    {"title": "Interstellar", "year": 2014, "genre": "Sci-Fi", "budget": 165000000, "revenue": 677500000, "rating": 8.6, "director": "Christopher Nolan", "cast": "Matthew McConaughey", "heroine": "Anne Hathaway", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.", "poster": "🚀", "votes": 1900000},
    {"title": "Parasite", "year": 2019, "genre": "Thriller", "budget": 11400000, "revenue": 263500000, "rating": 8.5, "director": "Bong Joon-ho", "cast": "Song Kang-ho", "heroine": "Park So-dam", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.", "poster": "🏠", "votes": 890000},
    {"title": "Joker", "year": 2019, "genre": "Drama", "budget": 55000000, "revenue": 1074000000, "rating": 8.0, "director": "Todd Phillips", "cast": "Joaquin Phoenix", "heroine": "Zazie Beetz", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "In Gotham City, mentally troubled comedian Arthur Fleck is disregarded and mistreated by society. He then embarks on a downward spiral of revolution and bloody crime.", "poster": "🃏", "votes": 1100000},
    {"title": "Dune: Part Two", "year": 2024, "genre": "Sci-Fi", "budget": 190000000, "revenue": 714000000, "rating": 8.5, "director": "Denis Villeneuve", "cast": "Timothée Chalamet", "heroine": "Zendaya", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.", "poster": "🏜️", "votes": 650000},
    {"title": "Oppenheimer", "year": 2023, "genre": "Drama", "budget": 100000000, "revenue": 976000000, "rating": 8.4, "director": "Christopher Nolan", "cast": "Cillian Murphy", "heroine": "Florence Pugh", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.", "poster": "⚛️", "votes": 920000},
    {"title": "Spider-Man: No Way Home", "year": 2021, "genre": "Action", "budget": 200000000, "revenue": 1921000000, "rating": 8.2, "director": "Jon Watts", "cast": "Tom Holland", "heroine": "Zendaya", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "With Spider-Man's identity now revealed, Peter asks Doctor Strange for help. When a spell goes wrong, dangerous foes from other worlds start to appear.", "poster": "🕷️", "votes": 1050000},
    {"title": "The Batman", "year": 2022, "genre": "Action", "budget": 185000000, "revenue": 770800000, "rating": 7.8, "director": "Matt Reeves", "cast": "Robert Pattinson", "heroine": "Zoë Kravitz", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "When a sadistic serial killer begins murdering key political figures in Gotham, Batman is forced to investigate the city's hidden corruption.", "poster": "🦇", "votes": 980000},
    {"title": "Avatar: The Way of Water", "year": 2022, "genre": "Sci-Fi", "budget": 460000000, "revenue": 2320000000, "rating": 7.6, "director": "James Cameron", "cast": "Sam Worthington", "heroine": "Zoe Saldana", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora. Once a familiar threat returns, Jake must work with Neytiri and the army of the Na'vi.", "poster": "🌊", "votes": 780000},
    {"title": "Top Gun: Maverick", "year": 2022, "genre": "Action", "budget": 170000000, "revenue": 1495000000, "rating": 8.3, "director": "Joseph Kosinski", "cast": "Tom Cruise", "heroine": "Jennifer Connelly", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "After thirty years, Maverick is still pushing the envelope as a top naval aviator, but must confront ghosts of his past when he leads TOP GUN's elite graduates.", "poster": "✈️", "votes": 850000},
    {"title": "Deadpool & Wolverine", "year": 2024, "genre": "Action", "budget": 200000000, "revenue": 1338000000, "rating": 7.6, "director": "Shawn Levy", "cast": "Ryan Reynolds", "heroine": "Emma Corrin", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Deadpool is offered a place in the Marvel Cinematic Universe by the Time Variance Authority, but instead recruits a variant of Wolverine.", "poster": "⚔️", "votes": 520000},
    {"title": "Inside Out 2", "year": 2024, "genre": "Animation", "budget": 200000000, "revenue": 1698000000, "rating": 7.5, "director": "Kelsey Mann", "cast": "Amy Poehler", "heroine": "Maya Hawke", "cast_gender": "female", "heroine_gender": "female", "status": "completed", "description": "A sequel that features Riley entering puberty and experiencing brand new, more complex emotions as a result.", "poster": "🧠", "votes": 310000},
    {"title": "Wicked", "year": 2024, "genre": "Musical", "budget": 150000000, "revenue": 680000000, "rating": 7.8, "director": "Jon M. Chu", "cast": "Cynthia Erivo", "heroine": "Ariana Grande", "cast_gender": "female", "heroine_gender": "female", "status": "completed", "description": "The story of how a green-skinned woman framed by the Wizard of Oz becomes the Wicked Witch of the West.", "poster": "🧙", "votes": 280000},
]

BOLLYWOOD_MOVIES = [
    {"title": "Dangal", "year": 2016, "genre": "Drama", "budget": 70000000, "revenue": 340000000, "rating": 8.3, "director": "Nitesh Tiwari", "cast": "Aamir Khan", "heroine": "Fatima Sana Shaikh", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Former wrestler Mahavir Singh Phogat and his two wrestler daughters struggle towards glory at the Commonwealth Games in the face of societal oppression.", "poster": "🤼", "votes": 210000},
    {"title": "Baahubali 2: The Conclusion", "year": 2017, "genre": "Action", "budget": 36000000, "revenue": 280000000, "rating": 8.2, "director": "S.S. Rajamouli", "cast": "Prabhas", "heroine": "Anushka Shetty", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "When Shiva, the son of Bahubali, learns about his heritage, he begins to look for answers. His story is juxtaposed with past events that unfolded in the Mahishmati Kingdom.", "poster": "⚔️", "votes": 180000},
    {"title": "3 Idiots", "year": 2009, "genre": "Comedy", "budget": 10000000, "revenue": 90000000, "rating": 8.4, "director": "Rajkumar Hirani", "cast": "Aamir Khan", "heroine": "Kareena Kapoor", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Two friends are searching for their long lost companion. They revisit their college days and recall the memories of their friend who inspired them to think differently.", "poster": "🎓", "votes": 420000},
    {"title": "PK", "year": 2014, "genre": "Comedy", "budget": 18000000, "revenue": 140000000, "rating": 8.1, "director": "Rajkumar Hirani", "cast": "Aamir Khan", "heroine": "Anushka Sharma", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "An alien on Earth loses the only device he can use to communicate with his spaceship. His innocent nature and child-like questions force the country to evaluate the impact of religion.", "poster": "👽", "votes": 195000},
    {"title": "Bajrangi Bhaijaan", "year": 2015, "genre": "Drama", "budget": 20000000, "revenue": 130000000, "rating": 8.1, "director": "Kabir Khan", "cast": "Salman Khan", "heroine": "Kareena Kapoor", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "An Indian man with a magnanimous heart takes a young mute Pakistani girl back to her homeland to reunite her with her family.", "poster": "🤝", "votes": 170000},
    {"title": "Sultan", "year": 2016, "genre": "Drama", "budget": 11000000, "revenue": 95000000, "rating": 7.0, "director": "Ali Abbas Zafar", "cast": "Salman Khan", "heroine": "Anushka Sharma", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Sultan is a classic underdog tale about a wrestler's struggle to make a comeback in life after hitting rock bottom.", "poster": "🥇", "votes": 95000},
    {"title": "Sanju", "year": 2018, "genre": "Drama", "budget": 13000000, "revenue": 85000000, "rating": 7.6, "director": "Rajkumar Hirani", "cast": "Ranbir Kapoor", "heroine": "Sonam Kapoor", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Sanju is a biopic of the controversial life of actor Sanjay Dutt: his film career, jail sentence and personal life.", "poster": "🎭", "votes": 110000},
    {"title": "War", "year": 2019, "genre": "Action", "budget": 25000000, "revenue": 75000000, "rating": 6.5, "director": "Siddharth Anand", "cast": "Hrithik Roshan", "heroine": "Vaani Kapoor", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "An Indian soldier is assigned to eliminate his former mentor, who has gone rogue.", "poster": "🔫", "votes": 85000},
    {"title": "Pathaan", "year": 2023, "genre": "Action", "budget": 30000000, "revenue": 180000000, "rating": 6.9, "director": "Siddharth Anand", "cast": "Shah Rukh Khan", "heroine": "Deepika Padukone", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "An Indian spy takes on the leader of a group of mercenaries who have nefarious plans to target his homeland.", "poster": "🎯", "votes": 145000},
    {"title": "Jawan", "year": 2023, "genre": "Action", "budget": 35000000, "revenue": 200000000, "rating": 7.1, "director": "Atlee", "cast": "Shah Rukh Khan", "heroine": "Nayanthara", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "A man is driven by a personal vendetta to rectify the wrongs in society, while keeping a promise made years ago.", "poster": "🎖️", "votes": 125000},
    {"title": "Animal", "year": 2023, "genre": "Action", "budget": 20000000, "revenue": 120000000, "rating": 6.8, "director": "Sandeep Reddy Vanga", "cast": "Ranbir Kapoor", "heroine": "Rashmika Mandanna", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "A son's love for his father spirals into a dark, violent obsession as he seeks to protect his family.", "poster": "🐅", "votes": 98000},
    {"title": "Gadar 2", "year": 2023, "genre": "Action", "budget": 15000000, "revenue": 110000000, "rating": 6.7, "director": "Anil Sharma", "cast": "Sunny Deol", "heroine": "Ameesha Patel", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "During the Indo-Pakistani War of 1971, Tara Singh returns to Pakistan to rescue his son who was captured by the Pakistani Army.", "poster": "🚩", "votes": 72000},
    {"title": "Stree 2", "year": 2024, "genre": "Horror", "budget": 12000000, "revenue": 95000000, "rating": 7.2, "director": "Amar Kaushik", "cast": "Rajkummar Rao", "heroine": "Shraddha Kapoor", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "The town of Chanderi is once again haunted by a mysterious entity. Vicky and his friends must face new supernatural challenges.", "poster": "👻", "votes": 65000},
    {"title": "Fighter", "year": 2024, "genre": "Action", "budget": 35000000, "revenue": 85000000, "rating": 6.5, "director": "Siddharth Anand", "cast": "Hrithik Roshan", "heroine": "Deepika Padukone", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Top IAF aviators come together in the face of imminent danger, to form Air Dragons. Fighter unfolds their camaraderie and brotherhood.", "poster": "✈️", "votes": 58000},
    {"title": "Bhool Bhulaiyaa 3", "year": 2024, "genre": "Comedy", "budget": 18000000, "revenue": 78000000, "rating": 6.8, "director": "Anees Bazmee", "cast": "Kartik Aaryan", "heroine": "Triptii Dimri", "cast_gender": "male", "heroine_gender": "female", "status": "completed", "description": "Ruhaan is back with more supernatural adventures as he faces a new ghostly threat in an old mansion.", "poster": "🏰", "votes": 45000},
]

UPCOMING_HOLLYWOOD = [
    {"title": "Superman", "year": 2025, "genre": "Action", "budget": 225000000, "rating": None, "director": "James Gunn", "cast": "David Corenswet", "heroine": "Rachel Brosnahan", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-07-11", "status": "upcoming", "description": "Superman, a cub reporter in Metropolis, embarks on a journey to reconcile his Kryptonian heritage with his human upbringing as Clark Kent.", "poster": "🦸", "hype_score": 95},
    {"title": "The Fantastic Four: First Steps", "year": 2025, "genre": "Sci-Fi", "budget": 200000000, "rating": None, "director": "Matt Shakman", "cast": "Pedro Pascal", "heroine": "Vanessa Kirby", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-07-25", "status": "upcoming", "description": "The Fantastic Four face their most daunting challenge yet, as they are forced to balance their roles as heroes with their family bonds.", "poster": "🌌", "hype_score": 88},
    {"title": "Mission: Impossible - The Final Reckoning", "year": 2025, "genre": "Action", "budget": 300000000, "rating": None, "director": "Christopher McQuarrie", "cast": "Tom Cruise", "heroine": "Hayley Atwell", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-05-23", "status": "upcoming", "description": "Ethan Hunt and his IMF team must track down a terrifying new weapon that threatens all of humanity before it falls into the wrong hands.", "poster": "🕶️", "hype_score": 92},
    {"title": "Jurassic World Rebirth", "year": 2025, "genre": "Adventure", "budget": 165000000, "rating": None, "director": "Gareth Edwards", "cast": "Scarlett Johansson", "heroine": "Mahershala Ali", "cast_gender": "female", "heroine_gender": "male", "release_date": "2025-07-02", "status": "upcoming", "description": "Five years after the events of Jurassic World Dominion, a new expedition ventures to an isolated equatorial region to extract DNA from dinosaurs.", "poster": "🦕", "hype_score": 78},
    {"title": "Tron: Ares", "year": 2025, "genre": "Sci-Fi", "budget": 200000000, "rating": None, "director": "Joachim Rønning", "cast": "Jared Leto", "heroine": "Greta Lee", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-10-10", "status": "upcoming", "description": "A highly sophisticated program, Ares, is sent from the digital world into the real world on a dangerous mission.", "poster": "💿", "hype_score": 72},
    {"title": "Avatar: Fire and Ash", "year": 2025, "genre": "Sci-Fi", "budget": 400000000, "rating": None, "director": "James Cameron", "cast": "Sam Worthington", "heroine": "Zoe Saldana", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-12-19", "status": "upcoming", "description": "The third installment in the Avatar saga continues the epic story of the Sully family on Pandora.", "poster": "🔥", "hype_score": 90},
    {"title": "Captain America: Brave New World", "year": 2025, "genre": "Action", "budget": 180000000, "rating": None, "director": "Julius Onah", "cast": "Anthony Mackie", "heroine": "Shira Haas", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-02-14", "status": "upcoming", "description": "Sam Wilson, the new Captain America, finds himself in the middle of an international incident and must discover the motive behind a nefarious global plan.", "poster": "🛡️", "hype_score": 82},
    {"title": "Thunderbolts", "year": 2025, "genre": "Action", "budget": 150000000, "rating": None, "director": "Jake Schreier", "cast": "Florence Pugh", "heroine": "Olga Kurylenko", "cast_gender": "female", "heroine_gender": "female", "release_date": "2025-05-02", "status": "upcoming", "description": "A group of antiheroes go on missions for the government. The team includes Yelena Belova, Bucky Barnes, Red Guardian and more.", "poster": "⚡", "hype_score": 80},
]

UPCOMING_BOLLYWOOD = [
    {"title": "Sikandar", "year": 2025, "genre": "Action", "budget": 25000000, "rating": None, "director": "A.R. Murugadoss", "cast": "Salman Khan", "heroine": "Rashmika Mandanna", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-03-30", "status": "upcoming", "description": "A powerful action drama where Salman Khan plays a man who rises against corruption to protect the common people.", "poster": "👊", "hype_score": 85},
    {"title": "War 2", "year": 2025, "genre": "Action", "budget": 40000000, "rating": None, "director": "Ayan Mukerji", "cast": "Hrithik Roshan", "heroine": "Kiara Advani", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-08-14", "status": "upcoming", "description": "The sequel to the blockbuster War sees Kabir return for a new mission that spans international borders.", "poster": "🌍", "hype_score": 88},
    {"title": "King", "year": 2025, "genre": "Action", "budget": 35000000, "rating": None, "director": "Sujoy Ghosh", "cast": "Shah Rukh Khan", "heroine": "Suhana Khan", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-06-05", "status": "upcoming", "description": "Shah Rukh Khan stars as a mentor to his on-screen daughter in this high-stakes action thriller.", "poster": "👑", "hype_score": 92},
    {"title": "Housefull 5", "year": 2025, "genre": "Comedy", "budget": 15000000, "rating": None, "director": "Tarun Mansukhani", "cast": "Akshay Kumar", "heroine": "Sonam Bajwa", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-06-06", "status": "upcoming", "description": "The fifth installment in the Housefull franchise brings together multiple stars for another comedy of errors.", "poster": "😂", "hype_score": 65},
    {"title": "Sunny Sanskari Ki Tulsi Kumari", "year": 2025, "genre": "Romance", "budget": 12000000, "rating": None, "director": "Shashank Khaitan", "cast": "Varun Dhawan", "heroine": "Janhvi Kapoor", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-04-18", "status": "upcoming", "description": "A romantic comedy that explores modern relationships with traditional family values.", "poster": "💕", "hype_score": 60},
    {"title": "Dhoom 4", "year": 2025, "genre": "Action", "budget": 50000000, "rating": None, "director": "Vijay Krishna Acharya", "cast": "Ranbir Kapoor", "heroine": "Deepika Padukone", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-12-25", "status": "upcoming", "description": "The iconic Dhoom franchise returns with high-octane bike chases and a new antagonist.", "poster": "🏍️", "hype_score": 90},
    {"title": "Bhoot Bangla", "year": 2025, "genre": "Horror", "budget": 10000000, "rating": None, "director": "Priyadarshan", "cast": "Akshay Kumar", "heroine": "Tabu", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-04-10", "status": "upcoming", "description": "A horror comedy where Akshay Kumar investigates paranormal activities in a haunted mansion.", "poster": "👻", "hype_score": 70},
    {"title": "Deva", "year": 2025, "genre": "Action", "budget": 20000000, "rating": None, "director": "Rosshan Andrrews", "cast": "Shahid Kapoor", "heroine": "Pooja Hegde", "cast_gender": "male", "heroine_gender": "female", "release_date": "2025-01-31", "status": "upcoming", "description": "A rebellious police officer investigates a high-profile case and uncovers a web of deceit.", "poster": "🚔", "hype_score": 75},
]
# ==================== CONTEXT PROCESSORS ====================
@app.context_processor
def inject_globals():
    return {
        'theme': get_theme(),
        'current_year': datetime.now().year,
        'app_version': '3.0.0',
        'github_url': 'https://github.com/issu321',
        'repo_url': 'https://github.com/issu321/Analysis-of-Algorithms'
    }

# ==================== AUTH ROUTES ====================
@app.route('/')
def home():
    stats = {
        'total_users': len(load_json('users.json').get('users', [])),
        'total_predictions': len(load_json('history.json').get('history', [])),
        'total_datasets': len([f for f in os.listdir(UPLOAD_DIR) if f.endswith('.csv')]),
        'total_reports': len(load_json('reports.json').get('reports', []))
    }
    return render_template('home.html', stats=stats)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if not username or not password:
            flash('Please enter both username and password', 'error')
            return redirect(url_for('login'))
        data = load_json('users.json')
        for user in data.get('users', []):
            if user['username'] == username:
                if verify_password(user['password'], password):
                    session['user_id'] = user['id']
                    session['username'] = user['username']
                    session['token'] = generate_session_token()
                    log_activity(user['id'], 'login', 'User logged in')
                    flash(f'Welcome back, {username}!', 'success')
                    return redirect(url_for('dashboard'))
                else:
                    flash('Invalid password', 'error')
                    return redirect(url_for('login'))
        flash('Username not found', 'error')
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')
        if not all([username, email, password]):
            flash('All fields are required', 'error')
            return redirect(url_for('register'))
        if password != confirm:
            flash('Passwords do not match', 'error')
            return redirect(url_for('register'))
        if len(password) < 6:
            flash('Password must be at least 6 characters', 'error')
            return redirect(url_for('register'))
        data = load_json('users.json')
        for user in data.get('users', []):
            if user['username'] == username:
                flash('Username already exists', 'error')
                return redirect(url_for('register'))
            if user['email'] == email:
                flash('Email already registered', 'error')
                return redirect(url_for('register'))
        new_user = {
            'id': data.get('next_id', 1),
            'username': username,
            'email': email,
            'password': hash_password(password),
            'created_at': datetime.now().isoformat(),
            'role': 'user',
            'settings': {'theme': 'dark'}
        }
        data.setdefault('users', []).append(new_user)
        data['next_id'] = data.get('next_id', 1) + 1
        save_json('users.json', data)
        log_activity(new_user['id'], 'register', 'New user registered')
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    if 'user_id' in session:
        log_activity(session['user_id'], 'logout', 'User logged out')
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('home'))

@app.route('/profile')
@require_login
def profile():
    user = get_current_user()
    if not user:
        flash('User not found', 'error')
        return redirect(url_for('login'))
    stats = get_user_stats(user['id'])
    return render_template('profile.html', user=user, stats=stats)

@app.route('/profile/update', methods=['POST'])
@require_login
def update_profile():
    user = get_current_user()
    if not user:
        return jsonify({'success': False, 'message': 'User not found'})
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': 'No data provided'})
    users_data = load_json('users.json')
    for u in users_data.get('users', []):
        if u['id'] == user['id']:
            if 'email' in data:
                u['email'] = data['email']
            if 'theme' in data:
                u['settings'] = u.get('settings', {})
                u['settings']['theme'] = data['theme']
                set_theme(data['theme'])
            break
    save_json('users.json', users_data)
    log_activity(user['id'], 'profile_update', 'Profile updated')
    return jsonify({'success': True, 'message': 'Profile updated successfully'})

# ==================== DASHBOARD ====================
@app.route('/dashboard')
@require_login
def dashboard():
    user = get_current_user()
    stats = get_user_stats(user['id'])
    all_history = load_json('history.json').get('history', [])
    all_reports = load_json('reports.json').get('reports', [])
    model_status = {
        'trained': predictor.is_trained,
        'best_model': predictor.best_model_name,
        'accuracy': predictor.metrics.get('accuracy', 0) if predictor.metrics else 0
    }
    uploads = [f for f in os.listdir(UPLOAD_DIR) if f.endswith('.csv')]
    uploads.sort(key=lambda x: os.path.getmtime(os.path.join(UPLOAD_DIR, x)), reverse=True)
    recent_uploads = uploads[:5]
    return render_template('dashboard.html', 
                         user=user, stats=stats, model_status=model_status,
                         recent_uploads=recent_uploads,
                         total_users=len(load_json('users.json').get('users', [])),
                         total_history=len(all_history), total_reports=len(all_reports))

# ==================== MOVIE BROWSER ====================
@app.route('/movies')
def movies():
    return render_template('movies.html',
                         hollywood=HOLLYWOOD_MOVIES,
                         bollywood=BOLLYWOOD_MOVIES,
                         upcoming_hollywood=UPCOMING_HOLLYWOOD,
                         upcoming_bollywood=UPCOMING_BOLLYWOOD,
                         slugify=slugify)

@app.route('/movie/<industry>/<slug>')
def movie_detail(industry, slug):
    movies_list = HOLLYWOOD_MOVIES if industry == 'hollywood' else BOLLYWOOD_MOVIES
    movie = None
    for m in movies_list:
        if slugify(m['title']) == slug:
            movie = m
            break

    if not movie:
        upcoming = UPCOMING_HOLLYWOOD if industry == 'hollywood' else UPCOMING_BOLLYWOOD
        for m in upcoming:
            if slugify(m['title']) == slug:
                movie = m
                break

    if not movie:
        flash('Movie not found', 'error')
        return redirect(url_for('movies'))

    ai_analysis = analyze_movie_with_ai(movie)
    return render_template('movie_detail.html', movie=movie, industry=industry, analysis=ai_analysis, slugify=slugify)

def analyze_movie_with_ai(movie):
    """Generate AI analysis for any movie - BUG FIXED VERSION"""
    analysis = {
        'success_probability': 0,
        'box_office_prediction': '',
        'rating_prediction': 0,
        'star_rating': 0,
        'pros': [],
        'cons': [],
        'audience_score': 0,
        'critics_score': 0,
        'hype_meter': movie.get('hype_score', 70),
        'genre_trend': '',
        'seasonal_impact': '',
        'cast_power': 0,
        'director_power': 0
    }

    if movie.get('status') == 'completed' and movie.get('revenue'):
        roi = (movie['revenue'] - movie['budget']) / movie['budget'] * 100
        if roi > 200:
            analysis['success_probability'] = 95
            analysis['box_office_prediction'] = 'Blockbuster'
        elif roi > 50:
            analysis['success_probability'] = 80
            analysis['box_office_prediction'] = 'Hit'
        elif roi > 0:
            analysis['success_probability'] = 65
            analysis['box_office_prediction'] = 'Average'
        else:
            analysis['success_probability'] = 35
            analysis['box_office_prediction'] = 'Flop'

        rating_val = movie.get('rating', 7.0) or 7.0
        analysis['rating_prediction'] = rating_val
        analysis['star_rating'] = round(rating_val / 2, 1)
        analysis['audience_score'] = min(100, int(rating_val * 10 + np.random.randint(-5, 5)))
        analysis['critics_score'] = min(100, int(rating_val * 10 + np.random.randint(-8, 3)))
    else:
        # Predict for upcoming movies
        budget_factor = min(100, movie.get('budget', 50000000) / 2000000)
        cast_power = np.random.randint(60, 95)
        director_power = np.random.randint(55, 90)
        genre_boost = 10 if movie.get('genre') in ['Action', 'Sci-Fi'] else 5

        analysis['success_probability'] = min(95, int((budget_factor * 0.3 + cast_power * 0.3 + director_power * 0.2 + genre_boost + movie.get('hype_score', 70) * 0.2)))
        analysis['box_office_prediction'] = format_currency(movie.get('budget', 50000000) * np.random.uniform(2.5, 5.0))
        analysis['rating_prediction'] = round(np.random.uniform(6.5, 8.5), 1)
        analysis['star_rating'] = round(analysis['rating_prediction'] / 2, 1)
        analysis['audience_score'] = min(100, int(analysis['rating_prediction'] * 10 + np.random.randint(-5, 10)))
        analysis['critics_score'] = min(100, int(analysis['rating_prediction'] * 10 + np.random.randint(-10, 5)))
        analysis['cast_power'] = cast_power
        analysis['director_power'] = director_power

    # Generate pros and cons - FIX: handle None rating properly
    rating_val = movie.get('rating') or analysis['rating_prediction']

    if movie.get('genre') in ['Action', 'Adventure', 'Sci-Fi']:
        analysis['pros'].append('High commercial appeal genre')
    if movie.get('budget', 0) > 100000000:
        analysis['pros'].append('Massive production budget ensures quality')
    if rating_val and rating_val > 8.0:
        analysis['pros'].append('Strong critical reception expected')
    if 'hype_score' in movie and movie['hype_score'] > 80:
        analysis['pros'].append('High audience anticipation')

    if movie.get('genre') in ['Documentary', 'History']:
        analysis['cons'].append('Niche audience may limit box office')
    if movie.get('budget', 0) < 10000000:
        analysis['cons'].append('Limited marketing budget')
    if analysis['success_probability'] < 60:
        analysis['cons'].append('Moderate success risk detected')

    analysis['genre_trend'] = f"{movie.get('genre', 'Drama')} movies are {'trending upward' if np.random.random() > 0.4 else 'stable'} this season"

    # FIX: Handle release_date safely
    release_date = movie.get('release_date', '')
    if release_date and isinstance(release_date, str) and len(release_date.split('-')) >= 2:
        month = release_date.split('-')[1]
        analysis['seasonal_impact'] = 'Summer release maximizes audience turnout' if month in ['06', '07', '08'] else 'Standard seasonal performance expected'
    else:
        analysis['seasonal_impact'] = 'Standard seasonal performance expected'

    return analysis

# ==================== PREDICTION ====================
@app.route('/prediction')
@require_login
def prediction_page():
    model_status = {
        'trained': predictor.is_trained,
        'best_model': predictor.best_model_name,
        'accuracy': round(predictor.metrics.get('accuracy', 0) * 100, 1) if predictor.metrics else 0
    }
    genres = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 
              'Drama', 'Family', 'Fantasy', 'History', 'Horror', 'Music', 'Mystery',
              'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western']
    seasons = ['Spring', 'Summer', 'Fall', 'Winter']
    languages = ['English', 'Spanish', 'French', 'German', 'Hindi', 'Mandarin', 'Japanese', 'Korean']
    return render_template('prediction.html', model_status=model_status, genres=genres, seasons=seasons, languages=languages)

@app.route('/api/predict', methods=['POST'])
@require_login
def api_predict():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'})
        valid, msg = validate_movie_data(data)
        if not valid:
            return jsonify({'success': False, 'message': msg})

        features = {
            'budget': float(data.get('budget', 0)),
            'runtime': float(data.get('runtime', 100)),
            'cast_popularity': float(data.get('cast_popularity', 5)),
            'director_popularity': float(data.get('director_popularity', 5)),
            'vote_count': float(data.get('vote_count', 0)),
            'popularity_score': float(data.get('popularity_score', 0)),
            'genre': data.get('genre', 'Drama'),
            'release_month': int(data.get('release_month', 6)),
            'release_season': data.get('release_season', 'Summer'),
            'language': data.get('language', 'English'),
            'production_company': data.get('production_company', 'Unknown')
        }

        if not predictor.is_trained:
            sample_df = create_sample_movie_data()
            X, y = predictor.preprocess_data(sample_df, training=True)
            success, msg = predictor.train_models(X, y)
            if not success:
                return jsonify({'success': False, 'message': f'Model training failed: {msg}'})

        result, msg = predictor.predict(features)
        if result is None:
            return jsonify({'success': False, 'message': msg})

        revenue_est = predictor.estimate_revenue(features)
        rating_est = predictor.estimate_rating(features)

        success_factors = []
        failure_risks = []

        if features['budget'] > 50000000:
            success_factors.append("High budget indicates strong production value")
        if features['cast_popularity'] > 7:
            success_factors.append("Star cast provides strong audience draw")
        if features['director_popularity'] > 7:
            success_factors.append("Experienced director increases confidence")
        if features['genre'] in ['Action', 'Adventure', 'Sci-Fi']:
            success_factors.append("Genre has broad commercial appeal")
        if features['release_season'] in ['Summer', 'Winter']:
            success_factors.append("Peak season release maximizes audience reach")

        if features['budget'] < 1000000:
            failure_risks.append("Low budget may limit marketing and distribution")
        if features['runtime'] > 180:
            failure_risks.append("Long runtime may reduce screening frequency")
        if features['cast_popularity'] < 3:
            failure_risks.append("Unknown cast may struggle to attract audiences")
        if features['genre'] in ['Documentary', 'History']:
            failure_risks.append("Niche genre may have limited commercial appeal")

        result.update({
            'revenue_estimate': revenue_est,
            'rating_estimate': rating_est,
            'success_factors': success_factors,
            'failure_risks': failure_risks,
            'timestamp': datetime.now().isoformat()
        })

        log_activity(session['user_id'], 'prediction', f"Predicted movie: {data.get('movie_name', 'Unknown')}")
        return jsonify({'success': True, 'result': to_serializable(result)})

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'message': f'Prediction error: {str(e)}', 'trace': traceback.format_exc()})

def create_sample_movie_data():
    np.random.seed(42)
    n = 500
    genres = ['Action', 'Drama', 'Comedy', 'Horror', 'Sci-Fi', 'Romance', 'Thriller', 'Adventure']
    data = {
        'budget': np.random.lognormal(16, 1.5, n),
        'genre': np.random.choice(genres, n),
        'runtime': np.random.normal(110, 25, n).clip(60, 240),
        'cast_popularity': np.random.beta(2, 5, n) * 10,
        'director_popularity': np.random.beta(2, 4, n) * 10,
        'release_month': np.random.randint(1, 13, n),
        'vote_count': np.random.lognormal(8, 1.5, n),
        'popularity_score': np.random.beta(2, 3, n) * 100,
        'revenue': np.random.lognormal(17, 1.8, n)
    }
    df = pd.DataFrame(data)
    df['release_season'] = df['release_month'].apply(get_season)
    df['success'] = ((df['revenue'] > df['budget'] * 1.5) & (df['revenue'] > 1e6)).astype(int)
    return df

# ==================== DATASET UPLOAD & TRAINING ====================
@app.route('/upload')
@require_login
def upload_page():
    return render_template('upload.html')

@app.route('/api/upload', methods=['POST'])
@require_login
def api_upload():
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': 'No file part'})
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No file selected'})
        if not allowed_file(file.filename):
            return jsonify({'success': False, 'message': 'Only CSV files are allowed'})

        filename = secure_filename(file.filename)
        unique_name = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{filename}"
        filepath = os.path.join(UPLOAD_DIR, unique_name)
        file.save(filepath)

        try:
            df = pd.read_csv(filepath)
        except Exception as e:
            os.remove(filepath)
            return jsonify({'success': False, 'message': f'Invalid CSV file: {str(e)}'})

        if df.empty:
            os.remove(filepath)
            return jsonify({'success': False, 'message': 'CSV file is empty'})
        if len(df) < 10:
            os.remove(filepath)
            return jsonify({'success': False, 'message': 'Dataset too small (minimum 10 rows)'})

        detected = detect_movie_columns(df)
        dataset_info = {
            'id': str(uuid.uuid4()),
            'filename': unique_name,
            'original_name': filename,
            'user_id': session['user_id'],
            'uploaded_at': datetime.now().isoformat(),
            'rows': len(df),
            'columns': len(df.columns),
            'column_names': list(df.columns),
            'detected_columns': detected,
            'size_mb': round(os.path.getsize(filepath) / (1024*1024), 2)
        }

        history = load_json('history.json')
        history.setdefault('history', []).append({
            'id': history.get('next_id', 1),
            'user_id': session['user_id'],
            'action': 'upload',
            'details': f"Uploaded dataset: {filename} ({len(df)} rows, {len(df.columns)} columns)",
            'timestamp': datetime.now().isoformat()
        })
        history['next_id'] = history.get('next_id', 1) + 1
        save_json('history.json', history)

        analyzer.load_data(df)

        try:
            X, y = predictor.preprocess_data(df, training=True)
            success, train_msg = predictor.train_models(X, y)
            if success:
                predictor.save_model()
                dataset_info['model_trained'] = True
                dataset_info['best_model'] = predictor.best_model_name
                dataset_info['accuracy'] = float(predictor.metrics.get('accuracy', 0))
            else:
                dataset_info['model_trained'] = False
                dataset_info['train_error'] = train_msg
        except Exception as e:
            dataset_info['model_trained'] = False
            dataset_info['train_error'] = str(e)

        return jsonify({
            'success': True, 
            'message': f'Dataset uploaded successfully! {len(df)} rows processed.',
            'dataset': to_serializable(dataset_info),
            'detected_columns': detected
        })

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'message': f'Upload error: {str(e)}', 'trace': traceback.format_exc()})

# ==================== ANALYTICS ====================
@app.route('/analytics')
@require_login
def analytics_page():
    return render_template('analytics.html')

@app.route('/api/analytics', methods=['GET'])
@require_login
def api_analytics():
    try:
        uploads = [f for f in os.listdir(UPLOAD_DIR) if f.endswith('.csv')]
        if not uploads:
            df = create_sample_movie_data()
            analyzer.load_data(df)
        else:
            uploads.sort(key=lambda x: os.path.getmtime(os.path.join(UPLOAD_DIR, x)), reverse=True)
            latest = os.path.join(UPLOAD_DIR, uploads[0])
            df = pd.read_csv(latest)
            analyzer.load_data(df)

        analytics = analyzer.get_all_analytics()
        if predictor.is_trained:
            analytics['feature_importance'] = predictor.get_feature_importance()

        analytics = to_serializable(analytics)
        return jsonify({'success': True, 'analytics': analytics})

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'message': str(e), 'trace': traceback.format_exc()})

# ==================== MODEL COMPARISON ====================
@app.route('/api/models/compare', methods=['GET'])
@require_login
def api_model_comparison():
    if not predictor.is_trained:
        df = create_sample_movie_data()
        X, y = predictor.preprocess_data(df, training=True)
        predictor.train_models(X, y)

    comparison = predictor.get_model_comparison()
    comparison = to_serializable(comparison)
    return jsonify({'success': True, 'comparison': comparison})

# ==================== REPORTS ====================
@app.route('/reports')
@require_login
def reports_page():
    reports_data = load_json('reports.json')
    user_reports = [r for r in reports_data.get('reports', []) if r.get('user_id') == session['user_id']]
    return render_template('reports.html', reports=user_reports)

@app.route('/api/reports/generate', methods=['POST'])
@require_login
def api_generate_report():
    try:
        data = request.get_json()
        report_type = data.get('type', 'html')
        report_name = data.get('name', f"Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}")

        uploads = [f for f in os.listdir(UPLOAD_DIR) if f.endswith('.csv')]
        if uploads:
            uploads.sort(key=lambda x: os.path.getmtime(os.path.join(UPLOAD_DIR, x)), reverse=True)
            df = pd.read_csv(os.path.join(UPLOAD_DIR, uploads[0]))
            analyzer.load_data(df)
        else:
            df = create_sample_movie_data()
            analyzer.load_data(df)

        analytics = analyzer.get_all_analytics()
        analytics = to_serializable(analytics)

        report_id = str(uuid.uuid4())
        filename = f"{report_name}_{report_id[:8]}"

        if report_type == 'html':
            filepath = os.path.join(REPORT_DIR, f"{filename}.html")
            generate_html_report(filepath, report_name, analytics, predictor)
            mime = 'text/html'
            ext = 'html'
        elif report_type == 'json':
            filepath = os.path.join(REPORT_DIR, f"{filename}.json")
            with open(filepath, 'w') as f:
                json.dump(analytics, f, indent=2)
            mime = 'application/json'
            ext = 'json'
        elif report_type == 'txt':
            filepath = os.path.join(REPORT_DIR, f"{filename}.txt")
            generate_text_report(filepath, report_name, analytics, predictor)
            mime = 'text/plain'
            ext = 'txt'
        else:
            return jsonify({'success': False, 'message': 'Unsupported report type'})

        reports_data = load_json('reports.json')
        reports_data.setdefault('reports', []).append({
            'id': report_id,
            'user_id': session['user_id'],
            'name': report_name,
            'type': report_type,
            'filename': f"{filename}.{ext}",
            'created_at': datetime.now().isoformat(),
            'size_kb': round(os.path.getsize(filepath) / 1024, 2)
        })
        save_json('reports.json', reports_data)

        log_activity(session['user_id'], 'report_generated', f"Generated {report_type} report: {report_name}")

        return jsonify({
            'success': True, 
            'message': 'Report generated successfully',
            'report_id': report_id,
            'download_url': f"/api/reports/download/{report_id}"
        })

    except Exception as e:
        import traceback
        return jsonify({'success': False, 'message': str(e), 'trace': traceback.format_exc()})

@app.route('/api/reports/download/<report_id>')
@require_login
def download_report(report_id):
    reports_data = load_json('reports.json')
    report = None
    for r in reports_data.get('reports', []):
        if r['id'] == report_id and r['user_id'] == session['user_id']:
            report = r
            break
    if not report:
        flash('Report not found', 'error')
        return redirect(url_for('reports_page'))
    filepath = os.path.join(REPORT_DIR, report['filename'])
    if not os.path.exists(filepath):
        flash('Report file not found', 'error')
        return redirect(url_for('reports_page'))
    mime_types = {'html': 'text/html', 'json': 'application/json', 'txt': 'text/plain', 'pdf': 'application/pdf'}
    mime = mime_types.get(report['type'], 'application/octet-stream')
    return send_file(filepath, mimetype=mime, as_attachment=True, download_name=report['filename'])

def generate_html_report(filepath, name, analytics, predictor):
    html = f"""<!DOCTYPE html>
<html><head><title>{name} - Movie Analytics Report</title>
    <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }}
        h2 {{ color: #34495e; margin-top: 30px; }}
        .metric {{ display: inline-block; margin: 10px; padding: 15px 20px; background: #ecf0f1; border-radius: 8px; }}
        .metric-value {{ font-size: 24px; font-weight: bold; color: #2980b9; }}
        .insight {{ background: #e8f6f3; border-left: 4px solid #1abc9c; padding: 15px; margin: 10px 0; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background: #34495e; color: white; }}
        tr:hover {{ background: #f5f5f5; }}
        .footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #7f8c8d; font-size: 12px; }}
    </style></head><body>
    <div class="container">
    <h1>Movie Success Analytics Report</h1>
    <p><strong>Report Name:</strong> {name}</p>
    <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    <p><strong>Generated by:</strong> Movie Success Prediction AI Platform</p>
    """
    overview = analytics.get('overview', {})
    html += "<h2>Dataset Overview</h2><div>"
    html += f'<div class="metric"><div class="metric-value">{overview.get("total_movies", 0)}</div><div>Total Movies</div></div>'
    html += f'<div class="metric"><div class="metric-value">{overview.get("total_columns", 0)}</div><div>Columns</div></div>'
    html += f'<div class="metric"><div class="metric-value">{overview.get("memory_usage", "0 MB")}</div><div>Memory Usage</div></div>'
    html += "</div>"

    insights = analytics.get('insights', {})
    if insights:
        html += "<h2>AI Insights</h2>"
        for category, items in insights.items():
            if items:
                html += f"<h3>{category.replace('_', ' ').title()}</h3>"
                for item in items:
                    html += f'<div class="insight">{item}</div>'

    if predictor.is_trained:
        html += "<h2>Model Performance</h2>"
        html += f"<p><strong>Best Model:</strong> {predictor.best_model_name}</p>"
        html += f"<p><strong>Accuracy:</strong> {predictor.metrics.get('accuracy', 0):.2%}</p>"
        html += f"<p><strong>F1 Score:</strong> {predictor.metrics.get('f1_score', 0):.2%}</p>"
        html += f"<p><strong>ROC-AUC:</strong> {predictor.metrics.get('roc_auc', 0):.2%}</p>"

    html += '<div class="footer">Generated by Movie Success Prediction Platform | https://github.com/issu321</div>'
    html += "</div></body></html>"

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html)

def generate_text_report(filepath, name, analytics, predictor):
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(f"MOVIE SUCCESS ANALYTICS REPORT\n")
        f.write(f"{'='*60}\n\n")
        f.write(f"Report Name: {name}\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        overview = analytics.get('overview', {})
        f.write(f"DATASET OVERVIEW\n")
        f.write(f"-" * 40 + "\n")
        f.write(f"Total Movies: {overview.get('total_movies', 0)}\n")
        f.write(f"Total Columns: {overview.get('total_columns', 0)}\n")
        f.write(f"Memory Usage: {overview.get('memory_usage', 'N/A')}\n\n")
        insights = analytics.get('insights', {})
        if insights:
            f.write(f"AI INSIGHTS\n")
            f.write(f"-" * 40 + "\n")
            for category, items in insights.items():
                if items:
                    f.write(f"\n{category.replace('_', ' ').title()}:\n")
                    for item in items:
                        f.write(f"  - {item}\n")
        if predictor.is_trained:
            f.write(f"\nMODEL PERFORMANCE\n")
            f.write(f"-" * 40 + "\n")
            f.write(f"Best Model: {predictor.best_model_name}\n")
            f.write(f"Accuracy: {predictor.metrics.get('accuracy', 0):.2%}\n")
            f.write(f"F1 Score: {predictor.metrics.get('f1_score', 0):.2%}\n")
            f.write(f"ROC-AUC: {predictor.metrics.get('roc_auc', 0):.2%}\n")
        f.write(f"\n{'='*60}\n")
        f.write(f"Generated by Movie Success Prediction Platform\n")
        f.write(f"https://github.com/issu321/Analysis-of-Algorithms\n")

# ==================== HISTORY & SEARCH ====================
@app.route('/api/history')
@require_login
def api_history():
    history = load_json('history.json')
    user_history = [h for h in history.get('history', []) if h.get('user_id') == session['user_id']]
    return jsonify({'success': True, 'history': sorted(user_history, key=lambda x: x['timestamp'], reverse=True)})

@app.route('/api/search')
@require_login
def api_search():
    query = request.args.get('q', '').lower()
    if not query:
        return jsonify({'success': False, 'message': 'No search query'})
    results = {'datasets': [], 'reports': [], 'history': []}
    for f in os.listdir(UPLOAD_DIR):
        if query in f.lower():
            results['datasets'].append(f)
    reports = load_json('reports.json')
    for r in reports.get('reports', []):
        if r.get('user_id') == session['user_id'] and query in r.get('name', '').lower():
            results['reports'].append(r)
    history = load_json('history.json')
    for h in history.get('history', []):
        if h.get('user_id') == session['user_id'] and query in h.get('details', '').lower():
            results['history'].append(h)
    return jsonify({'success': True, 'results': results})

# ==================== SETTINGS & THEME ====================
@app.route('/api/settings/theme', methods=['POST'])
@require_login
def api_set_theme():
    data = request.get_json()
    theme = data.get('theme', 'dark')
    set_theme(theme)
    return jsonify({'success': True, 'theme': theme})

# ==================== CONTACT ====================
@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/api/contact', methods=['POST'])
def api_contact():
    data = request.get_json()
    return jsonify({'success': True, 'message': 'Thank you for your message! We will get back to you soon.'})

# ==================== ERROR HANDLERS - FIXED ====================
@app.errorhandler(404)
def not_found(e):
    return render_template('error.html', error_code='404', message='Page not found'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', error_code='500', message='Internal server error'), 500

@app.errorhandler(413)
def too_large(e):
    flash('File too large (max 50MB)', 'error')
    return redirect(request.referrer or url_for('upload_page'))

# ==================== MAIN ====================
if __name__ == '__main__':
    model_path = os.path.join(MODEL_DIR, 'movie_predictor.pkl')
    if not os.path.exists(model_path):
        print("Initializing with sample data...")
        df = create_sample_movie_data()
        X, y = predictor.preprocess_data(df, training=True)
        predictor.train_models(X, y)
        predictor.save_model(model_path)
        print(f"Sample model trained: {predictor.best_model_name}")
    else:
        predictor.load_model(model_path)
        print(f"Model loaded: {predictor.best_model_name}")

    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)
