"""
Movie Success Prediction Engine
Handles ML model training, comparison, and prediction
"""
import os
import json
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import warnings
warnings.filterwarnings('ignore')

# Optional advanced models
try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

try:
    import lightgbm as lgb
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

try:
    import catboost as cb
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False

from utils import MODEL_DIR, get_season, format_currency, log_activity

class MoviePredictor:
    def __init__(self):
        self.models = {}
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_names = []
        self.target_col = None
        self.is_trained = False
        self.best_model_name = None
        self.metrics = {}
        self.model_scores = {}

    def preprocess_data(self, df, target_col=None, training=True):
        """Complete preprocessing pipeline for movie data"""
        df_processed = df.copy()

        # Detect common movie columns
        col_mapping = {}
        for col in df.columns:
            col_lower = col.lower().replace(' ', '_')
            if 'budget' in col_lower:
                col_mapping['budget'] = col
            elif 'revenue' in col_lower and 'budget' not in col_lower:
                col_mapping['revenue'] = col
            elif 'genre' in col_lower:
                col_mapping['genre'] = col
            elif 'runtime' in col_lower or 'duration' in col_lower or 'length' in col_lower:
                col_mapping['runtime'] = col
            elif 'rating' in col_lower and 'vote' not in col_lower:
                col_mapping['rating'] = col
            elif 'vote' in col_lower and 'count' in col_lower:
                col_mapping['vote_count'] = col
            elif 'vote' in col_lower and 'average' in col_lower:
                col_mapping['vote_average'] = col
            elif 'popularity' in col_lower:
                col_mapping['popularity'] = col
            elif 'title' in col_lower or 'name' in col_lower:
                col_mapping['title'] = col
            elif 'director' in col_lower:
                col_mapping['director'] = col
            elif 'cast' in col_lower or 'actor' in col_lower:
                col_mapping['cast'] = col
            elif 'release' in col_lower and 'date' in col_lower:
                col_mapping['release_date'] = col
            elif 'year' in col_lower and 'release' not in col_lower:
                col_mapping['year'] = col
            elif 'month' in col_lower:
                col_mapping['month'] = col
            elif 'production' in col_lower or 'company' in col_lower:
                col_mapping['production_company'] = col
            elif 'language' in col_lower or 'lang' in col_lower:
                col_mapping['language'] = col

        # Feature engineering
        features = pd.DataFrame(index=df_processed.index)

        # Budget (numeric)
        if 'budget' in col_mapping:
            features['budget'] = pd.to_numeric(df_processed[col_mapping['budget']], errors='coerce')
            features['budget'] = features['budget'].fillna(features['budget'].median())
            features['budget_log'] = np.log1p(features['budget'])
        else:
            features['budget'] = 0
            features['budget_log'] = 0

        # Runtime (numeric)
        if 'runtime' in col_mapping:
            features['runtime'] = pd.to_numeric(df_processed[col_mapping['runtime']], errors='coerce')
            features['runtime'] = features['runtime'].fillna(features['runtime'].median())
        else:
            features['runtime'] = 100  # default

        # Genre (categorical)
        if 'genre' in col_mapping:
            genre_col = df_processed[col_mapping['genre']].astype(str)
            # Handle multiple genres
            features['genre_main'] = genre_col.apply(lambda x: x.split(',')[0].strip() if ',' in str(x) else str(x).strip())
            # One-hot encode top genres
            top_genres = features['genre_main'].value_counts().head(10).index.tolist()
            for genre in top_genres:
                features[f'genre_{genre}'] = (features['genre_main'] == genre).astype(int)
            features['genre_other'] = (~features['genre_main'].isin(top_genres)).astype(int)

        # Release date features
        if 'release_date' in col_mapping:
            df_processed['parsed_date'] = pd.to_datetime(df_processed[col_mapping['release_date']], errors='coerce')
            features['release_month'] = df_processed['parsed_date'].dt.month.fillna(6)
            features['release_year'] = df_processed['parsed_date'].dt.year.fillna(2020)
            features['release_season'] = features['release_month'].apply(get_season)
        elif 'month' in col_mapping:
            features['release_month'] = pd.to_numeric(df_processed[col_mapping['month']], errors='coerce').fillna(6)
            features['release_season'] = features['release_month'].apply(get_season)
        elif 'year' in col_mapping:
            features['release_year'] = pd.to_numeric(df_processed[col_mapping['year']], errors='coerce').fillna(2020)
        else:
            features['release_month'] = 6
            features['release_season'] = 'Summer'

        # Vote count and popularity
        if 'vote_count' in col_mapping:
            features['vote_count'] = pd.to_numeric(df_processed[col_mapping['vote_count']], errors='coerce').fillna(0)
            features['vote_count_log'] = np.log1p(features['vote_count'])
        else:
            features['vote_count'] = 0
            features['vote_count_log'] = 0

        if 'popularity' in col_mapping:
            features['popularity_score'] = pd.to_numeric(df_processed[col_mapping['popularity']], errors='coerce').fillna(0)
        else:
            features['popularity_score'] = 0

        # Cast/Director popularity (if available)
        if 'cast' in col_mapping:
            features['cast_popularity'] = pd.to_numeric(df_processed[col_mapping['cast']], errors='coerce').fillna(5)
        else:
            features['cast_popularity'] = 5

        if 'director' in col_mapping:
            features['director_popularity'] = pd.to_numeric(df_processed[col_mapping['director']], errors='coerce').fillna(5)
        else:
            features['director_popularity'] = 5

        # Production company
        if 'production_company' in col_mapping:
            prod_col = df_processed[col_mapping['production_company']].astype(str)
            top_prods = prod_col.value_counts().head(10).index.tolist()
            for prod in top_prods:
                features[f'prod_{prod[:20]}'] = (prod_col == prod).astype(int)

        # Language
        if 'language' in col_mapping:
            lang_col = df_processed[col_mapping['language']].astype(str)
            features['language_en'] = (lang_col.str.lower() == 'en').astype(int)
        else:
            features['language_en'] = 1

        # Season encoding
        if 'release_season' in features.columns:
            season_dummies = pd.get_dummies(features['release_season'], prefix='season')
            features = pd.concat([features, season_dummies], axis=1)
            features = features.drop('release_season', axis=1)

        # Drop non-numeric columns for modeling
        features = features.select_dtypes(include=[np.number])

        # Handle target variable
        y = None
        if target_col and target_col in df_processed.columns:
            self.target_col = target_col
            y = df_processed[target_col].copy()
            # Convert to binary success/failure if not already
            if y.dtype == 'object':
                # Try to interpret as success/failure
                y = y.str.lower().map({'success': 1, 'failure': 0, 'hit': 1, 'flop': 0, 'yes': 1, 'no': 0}).fillna(0)
            else:
                # For revenue or rating, threshold at median
                if 'revenue' in target_col.lower() or 'rating' in target_col.lower() or 'vote' in target_col.lower():
                    median_val = y.median()
                    y = (y > median_val).astype(int)
                else:
                    y = pd.to_numeric(y, errors='coerce').fillna(0)
        elif 'revenue' in col_mapping:
            # Auto-create target from revenue if available
            revenue = pd.to_numeric(df_processed[col_mapping['revenue']], errors='coerce')
            budget = features['budget'] if 'budget' in features.columns else pd.Series([1]*len(df_processed))
            y = ((revenue > budget * 1.5) & (revenue > 1e6)).astype(int).fillna(0)
        elif 'rating' in col_mapping or 'vote_average' in col_mapping:
            rating_key = 'rating' if 'rating' in col_mapping else 'vote_average'
            rating = pd.to_numeric(df_processed[col_mapping[rating_key]], errors='coerce')
            y = (rating > 6.5).astype(int).fillna(0)
        else:
            # Default: create synthetic target based on budget vs features
            if 'budget' in features.columns and features['budget'].max() > 0:
                y = (features['budget'] > features['budget'].median()).astype(int)
            else:
                y = pd.Series([0] * len(df_processed))

        # Fill any remaining NaN
        features = features.fillna(0)

        if training:
            self.feature_names = features.columns.tolist()
            self.scaler.fit(features)

        features_scaled = pd.DataFrame(
            self.scaler.transform(features),
            columns=features.columns,
            index=features.index
        )

        return features_scaled, y

    def train_models(self, X, y, test_size=0.2):
        """Train and compare multiple ML models"""
        if len(X) < 10:
            return False, "Dataset too small for training (minimum 10 samples)"

        # Ensure we have both classes
        if len(y.unique()) < 2:
            return False, "Dataset must contain both success and failure examples"

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )

        self.models = {}
        self.model_scores = {}

        # Define models
        model_definitions = {
            'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
            'Decision Tree': DecisionTreeClassifier(max_depth=10, random_state=42),
            'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=15, random_state=42, n_jobs=-1)
        }

        if XGBOOST_AVAILABLE:
            model_definitions['XGBoost'] = xgb.XGBClassifier(
                n_estimators=100, max_depth=6, learning_rate=0.1, 
                random_state=42, use_label_encoder=False, eval_metric='logloss'
            )

        if LIGHTGBM_AVAILABLE:
            model_definitions['LightGBM'] = lgb.LGBMClassifier(
                n_estimators=100, max_depth=6, random_state=42, verbose=-1
            )

        if CATBOOST_AVAILABLE:
            model_definitions['CatBoost'] = cb.CatBoostClassifier(
                iterations=100, depth=6, random_state=42, verbose=False
            )

        # Train and evaluate each model
        for name, model in model_definitions.items():
            try:
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                y_prob = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else y_pred.astype(float)

                acc = accuracy_score(y_test, y_pred)
                prec = precision_score(y_test, y_pred, zero_division=0)
                rec = recall_score(y_test, y_pred, zero_division=0)
                f1 = f1_score(y_test, y_pred, zero_division=0)
                roc = roc_auc_score(y_test, y_prob) if len(np.unique(y_test)) > 1 else 0.5

                # Cross-validation
                cv_scores = cross_val_score(model, X, y, cv=min(5, len(X)//2), scoring='accuracy')
                cv_mean = cv_scores.mean()

                self.models[name] = model
                self.model_scores[name] = {
                    'accuracy': float(acc),
                    'precision': float(prec),
                    'recall': float(rec),
                    'f1_score': float(f1),
                    'roc_auc': float(roc),
                    'cv_accuracy': float(cv_mean),
                    'trained': True
                }
            except Exception as e:
                self.model_scores[name] = {
                    'accuracy': 0, 'precision': 0, 'recall': 0, 
                    'f1_score': 0, 'roc_auc': 0, 'cv_accuracy': 0,
                    'trained': False, 'error': str(e)
                }

        # Select best model by F1 score
        trained_scores = {k: v for k, v in self.model_scores.items() if v.get('trained', False)}
        if trained_scores:
            self.best_model_name = max(trained_scores, key=lambda x: trained_scores[x]['f1_score'])
            self.metrics = trained_scores[self.best_model_name]
            self.is_trained = True

        return True, f"Trained {len(trained_scores)} models. Best: {self.best_model_name}"

    def predict(self, features_dict):
        """Predict movie success from feature dictionary"""
        if not self.is_trained or not self.best_model_name:
            return None, "Model not trained yet"

        # Create feature vector
        features = pd.DataFrame([features_dict])

        # Ensure all required columns exist
        for col in self.feature_names:
            if col not in features.columns:
                features[col] = 0

        features = features[self.feature_names].fillna(0)
        features_scaled = self.scaler.transform(features)

        model = self.models[self.best_model_name]
        prediction = model.predict(features_scaled)[0]

        if hasattr(model, 'predict_proba'):
            probability = model.predict_proba(features_scaled)[0]
            confidence = probability[prediction]
        else:
            confidence = 0.5

        # Feature importance for explanation
        importance = self.get_feature_importance()

        result = {
            'success': bool(prediction == 1),
            'success_probability': float(probability[1]) if hasattr(model, 'predict_proba') else float(prediction),
            'confidence': float(confidence),
            'predicted_class': 'Success' if prediction == 1 else 'Failure',
            'model_used': self.best_model_name,
            'feature_importance': importance,
            'risk_score': float(1 - confidence) if prediction == 1 else float(confidence)
        }

        return result, "Prediction successful"

    def get_feature_importance(self):
        """Get feature importance from best model"""
        if not self.is_trained or not self.best_model_name:
            return {}

        model = self.models[self.best_model_name]
        importance = {}

        if hasattr(model, 'feature_importances_'):
            importances = model.feature_importances_
        elif hasattr(model, 'coef_'):
            importances = np.abs(model.coef_[0])
        else:
            return {}

        for name, imp in zip(self.feature_names, importances):
            importance[name] = float(imp)

        # Normalize to percentages
        total = sum(importance.values())
        if total > 0:
            importance = {k: round(v/total*100, 2) for k, v in importance.items()}

        return dict(sorted(importance.items(), key=lambda x: x[1], reverse=True)[:10])

    def save_model(self, filepath=None):
        """Save trained model to disk"""
        if not self.is_trained:
            return False

        if filepath is None:
            filepath = os.path.join(MODEL_DIR, 'movie_predictor.pkl')

        model_data = {
            'models': self.models,
            'scaler': self.scaler,
            'feature_names': self.feature_names,
            'best_model_name': self.best_model_name,
            'metrics': self.metrics,
            'model_scores': self.model_scores,
            'is_trained': self.is_trained
        }

        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)

        return True

    def load_model(self, filepath=None):
        """Load trained model from disk"""
        if filepath is None:
            filepath = os.path.join(MODEL_DIR, 'movie_predictor.pkl')

        if not os.path.exists(filepath):
            return False

        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)

        self.models = model_data['models']
        self.scaler = model_data['scaler']
        self.feature_names = model_data['feature_names']
        self.best_model_name = model_data['best_model_name']
        self.metrics = model_data['metrics']
        self.model_scores = model_data['model_scores']
        self.is_trained = model_data['is_trained']

        return True

    def get_model_comparison(self):
        """Return comparison data for all trained models"""
        return self.model_scores

    def estimate_revenue(self, features_dict, dataset_stats=None):
        """Estimate revenue range based on features"""
        budget = features_dict.get('budget', 1000000)

        # Base multiplier based on features
        multiplier = 1.0

        if features_dict.get('genre') in ['Action', 'Adventure', 'Sci-Fi', 'Fantasy']:
            multiplier *= 1.4
        elif features_dict.get('genre') in ['Horror', 'Thriller']:
            multiplier *= 1.2
        elif features_dict.get('genre') in ['Drama', 'Romance']:
            multiplier *= 0.9

        if features_dict.get('cast_popularity', 5) > 7:
            multiplier *= 1.3
        if features_dict.get('director_popularity', 5) > 7:
            multiplier *= 1.2

        season = features_dict.get('release_season', 'Summer')
        if season in ['Summer', 'Winter']:
            multiplier *= 1.15

        if features_dict.get('vote_count', 0) > 1000:
            multiplier *= 1.1

        estimated = budget * multiplier
        low = estimated * 0.7
        high = estimated * 1.5

        return {
            'estimated_revenue': format_currency(estimated),
            'revenue_range_low': format_currency(low),
            'revenue_range_high': format_currency(high),
            'roi_percentage': round((multiplier - 1) * 100, 1)
        }

    def estimate_rating(self, features_dict):
        """Estimate rating range"""
        base_rating = 6.0

        if features_dict.get('genre') in ['Drama', 'Documentary']:
            base_rating += 0.5

        if features_dict.get('director_popularity', 5) > 8:
            base_rating += 0.4
        if features_dict.get('cast_popularity', 5) > 8:
            base_rating += 0.3

        if features_dict.get('runtime', 100) > 120:
            base_rating += 0.2

        budget = features_dict.get('budget', 1000000)
        if budget > 100000000:
            base_rating += 0.1

        low = max(1, base_rating - 1.5)
        high = min(10, base_rating + 1.0)

        return {
            'estimated_rating': round(base_rating, 1),
            'rating_range_low': round(low, 1),
            'rating_range_high': round(high, 1)
        }

# Global predictor instance
predictor = MoviePredictor()
