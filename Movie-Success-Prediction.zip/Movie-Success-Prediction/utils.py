"""
Utility Module for Movie Success Prediction
Handles JSON storage, authentication, validation, and security
"""
import json
import os
import hashlib
import secrets
import re
from datetime import datetime, timedelta
from functools import wraps
from flask import session, redirect, url_for, flash, request
import pandas as pd
import numpy as np

# Paths
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'uploads')
REPORT_DIR = os.path.join(os.path.dirname(__file__), 'reports')
MODEL_DIR = os.path.join(os.path.dirname(__file__), 'models')

def get_data_path(filename):
    return os.path.join(DATA_DIR, filename)

def load_json(filename):
    path = get_data_path(filename)
    if not os.path.exists(path):
        return {}
    with open(path, 'r') as f:
        return json.load(f)

def save_json(filename, data):
    path = get_data_path(filename)
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def hash_password(password):
    salt = secrets.token_hex(16)
    pwdhash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return salt + pwdhash.hex()

def verify_password(stored, provided):
    salt = stored[:32]
    pwdhash = hashlib.pbkdf2_hmac('sha256', provided.encode(), salt.encode(), 100000)
    return stored == salt + pwdhash.hex()

def generate_session_token():
    return secrets.token_urlsafe(32)

def require_login(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def get_current_user():
    if 'user_id' not in session:
        return None
    data = load_json('users.json')
    for user in data.get('users', []):
        if user['id'] == session['user_id']:
            return user
    return None

def validate_csv_file(file):
    if not file or file.filename == '':
        return False, "No file selected"
    if not file.filename.endswith('.csv'):
        return False, "Only CSV files are allowed"
    return True, "Valid file"

def validate_movie_data(data):
    required = ['budget', 'genre', 'runtime']
    missing = [f for f in required if f not in data or not data[f]]
    if missing:
        return False, f"Missing required fields: {', '.join(missing)}"
    return True, "Valid data"

def detect_movie_columns(df):
    movie_keywords = ['budget', 'revenue', 'genre', 'runtime', 'rating', 'vote', 'popularity', 
                      'title', 'name', 'director', 'cast', 'release', 'date', 'year', 'month']
    detected = {}
    for col in df.columns:
        col_lower = col.lower().replace(' ', '_')
        for keyword in movie_keywords:
            if keyword in col_lower:
                detected[keyword] = col
                break
    return detected

def get_movie_dataset_features():
    return [
        'budget', 'genre', 'runtime', 'cast_popularity', 'director_popularity',
        'production_company', 'release_month', 'release_season', 'language',
        'vote_count', 'popularity_score'
    ]

def format_currency(value):
    if value >= 1e9:
        return f"${value/1e9:.2f}B"
    elif value >= 1e6:
        return f"${value/1e6:.2f}M"
    elif value >= 1e3:
        return f"${value/1e3:.2f}K"
    return f"${value:.2f}"

def format_percentage(value):
    return f"{value*100:.1f}%"

def get_season(month):
    if month in [12, 1, 2]:
        return 'Winter'
    elif month in [3, 4, 5]:
        return 'Spring'
    elif month in [6, 7, 8]:
        return 'Summer'
    else:
        return 'Fall'

def log_activity(user_id, action, details=""):
    history = load_json('history.json')
    entry = {
        'id': history.get('next_id', 1),
        'user_id': user_id,
        'action': action,
        'details': details,
        'timestamp': datetime.now().isoformat()
    }
    history.setdefault('history', []).append(entry)
    history['next_id'] = history.get('next_id', 1) + 1
    save_json('history.json', history)

def get_user_stats(user_id):
    history = load_json('history.json')
    user_history = [h for h in history.get('history', []) if h['user_id'] == user_id]
    predictions = len([h for h in user_history if 'prediction' in h['action'].lower()])
    uploads = len([h for h in user_history if 'upload' in h['action'].lower()])
    reports = len([h for h in user_history if 'report' in h['action'].lower()])
    return {
        'total_predictions': predictions,
        'datasets_uploaded': uploads,
        'reports_generated': reports,
        'recent_activity': sorted(user_history, key=lambda x: x['timestamp'], reverse=True)[:10]
    }

def sanitize_filename(filename):
    return re.sub(r'[^a-zA-Z0-9_.-]', '_', filename)

def ensure_dirs():
    for d in [DATA_DIR, UPLOAD_DIR, REPORT_DIR, MODEL_DIR]:
        os.makedirs(d, exist_ok=True)

def get_theme():
    settings = load_json('settings.json')
    return settings.get('settings', {}).get('theme', 'dark')

def set_theme(theme):
    settings = load_json('settings.json')
    settings.setdefault('settings', {})['theme'] = theme
    save_json('settings.json', settings)


# JSON Serialization Helper - Add this to utils.py
def to_serializable(obj):
    """Convert numpy/pandas types to Python native types for JSON serialization"""
    import numpy as np
    import pandas as pd
    if isinstance(obj, (np.integer, np.int64, np.int32, np.int16, np.int8)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float64, np.float32, np.float16)):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {k: to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [to_serializable(i) for i in obj]
    elif isinstance(obj, tuple):
        return [to_serializable(i) for i in obj]
    return obj
