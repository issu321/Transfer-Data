# Movie Success Prediction Using Data Mining

A complete production-ready Flask AI web application for predicting movie success using advanced machine learning algorithms.

**GitHub:** https://github.com/issu321  
**Repository:** https://github.com/issu321/Analysis-of-Algorithms

---

## Features

- **AI Prediction Engine** - Train and compare Logistic Regression, Decision Tree, Random Forest, XGBoost, LightGBM, and CatBoost
- **Dataset Upload** - CSV upload with automatic column detection and validation
- **Advanced Analytics** - Comprehensive EDA with correlation analysis, distribution metrics, and genre insights
- **Interactive Visualizations** - Plotly and Chart.js powered charts
- **Report Generation** - Downloadable HTML, JSON, and TXT reports
- **User Management** - Secure registration, login, and profile management
- **Theme System** - Full light/dark mode support
- **Premium UI** - Glassmorphism, Claymorphism, and Frosted Glass design

---

## Technology Stack

- **Backend:** Python 3.11+, Flask
- **ML:** Scikit-learn, XGBoost, LightGBM, CatBoost
- **Data:** Pandas, NumPy
- **Visualization:** Plotly, Chart.js
- **Storage:** JSON files (no SQL required)

---

## Project Structure

```
Movie-Success-Prediction/
├── app.py              # Main Flask application
├── predictor.py        # ML prediction engine
├── analyzer.py         # Data analysis & EDA
├── utils.py            # Utilities & helpers
├── requirements.txt    # Python dependencies
├── Dockerfile          # Docker configuration
├── install.sh          # Linux installer
├── install.bat         # Windows installer
├── data/               # JSON storage
├── uploads/            # CSV uploads
├── reports/            # Generated reports
├── models/             # Trained ML models
├── templates/          # HTML templates
└── static/             # CSS, JS, assets
```

---

## Installation

### Linux (Kali Linux / Ubuntu)

```bash
chmod +x install.sh
./install.sh
./venv/bin/python app.py
```

### Windows 11

```cmd
install.bat
venv\Scripts\python.exe app.py
```

### Docker

```bash
docker build -t movie-predict .
docker run -p 5000:5000 movie-predict
```

---

## Usage

1. Register a new account or login
2. Upload a CSV dataset with movie data
3. Navigate to **Predict** to analyze upcoming movies
4. View **Analytics** for comprehensive EDA
5. Generate **Reports** for download

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `SECRET_KEY` | Flask secret key | `movie-success-prediction-secret-key-2024` |
| `PORT` | Server port | `5000` |
| `FLASK_DEBUG` | Debug mode | `False` |

---

## Supported CSV Columns

- `budget` - Production budget
- `revenue` - Box office revenue
- `genre` - Movie genre
- `runtime` - Duration in minutes
- `rating` / `vote_average` - Audience rating
- `vote_count` - Number of votes
- `popularity` - Popularity score
- `release_date` - Release date
- `cast` / `director` - Cast/director popularity
- `production_company` - Production house

---

## Deployment

- **Local:** `python app.py`
- **Docker:** `docker run -p 5000:5000 movie-predict`
- **Hugging Face Spaces:** Use provided Dockerfile
