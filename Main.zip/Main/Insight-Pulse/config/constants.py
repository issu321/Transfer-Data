# Industries
INDUSTRIES = [
    'Technology', 'Manufacturing', 'Retail', 'E-Commerce', 'Logistics',
    'Healthcare', 'Finance', 'Education', 'Consulting', 'Food & Beverage',
    'Real Estate', 'Energy', 'Agriculture', 'Other'
]

# Business Types
BUSINESS_TYPES = [
    'Sole Proprietorship', 'Partnership', 'LLC', 'Corporation', 
    'Non-Profit', 'Startup'
]

# Company Sizes
COMPANY_SIZES = ['1-10', '11-50', '51-200', '201-500', '501-1000', '1000+']

# Currencies
CURRENCIES = ['USD', 'EUR', 'GBP', 'INR', 'JPY', 'CNY', 'AUD', 'CAD', 'SGD', 'AED', 'Other']

# Currency Symbols — used globally across all templates
CURRENCY_SYMBOLS = {
    'USD': '$',
    'EUR': '€',
    'GBP': '£',
    'INR': '₹',
    'JPY': '¥',
    'CNY': '¥',
    'AUD': 'A$',
    'CAD': 'C$',
    'SGD': 'S$',
    'AED': 'د.إ',
    'Other': '$'
}

# Countries (abbreviated list - full list in form)
COUNTRIES = [
    'United States', 'United Kingdom', 'Canada', 'Australia', 'Germany',
    'France', 'India', 'China', 'Japan', 'Singapore', 'UAE', 'Brazil',
    'Mexico', 'South Korea', 'Italy', 'Spain', 'Netherlands', 'Sweden',
    'Switzerland', 'South Africa', 'Nigeria', 'Kenya', 'Egypt',
    'Saudi Arabia', 'Israel', 'Thailand', 'Malaysia', 'Indonesia',
    'Philippines', 'Vietnam', 'Pakistan', 'Bangladesh', 'Turkey',
    'Russia', 'Poland', 'Ukraine', 'Argentina', 'Chile', 'Colombia',
    'New Zealand', 'Ireland', 'Portugal', 'Greece', 'Czech Republic',
    'Romania', 'Hungary', 'Austria', 'Belgium', 'Denmark', 'Finland',
    'Norway', 'Iceland', 'Other'
]

# Timezones
TIMEZONES = [
    'UTC', 'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
    'America/Toronto', 'America/Vancouver', 'America/Mexico_City', 'America/Sao_Paulo',
    'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Europe/Madrid', 'Europe/Rome',
    'Europe/Amsterdam', 'Europe/Stockholm', 'Europe/Zurich', 'Europe/Moscow',
    'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Asia/Shanghai',
    'Asia/Hong_Kong', 'Asia/Seoul', 'Asia/Bangkok', 'Asia/Jakarta',
    'Australia/Sydney', 'Australia/Melbourne', 'Pacific/Auckland', 'Africa/Lagos',
    'Africa/Cairo', 'Africa/Johannesburg'
]

# Tax Types
TAX_TYPES = ['GST', 'VAT', 'Sales Tax', 'Income Tax', 'Corporate Tax', 'No Tax']

# ─── Country calling codes (ITU-T E.164) ───
# Used by the registration form to prefix mobile numbers so the generated
# wa.me / UPI links are internationally dialable.  No external API needed.
COUNTRY_CALLING_CODES = {
    'United States': '+1', 'Canada': '+1', 'United Kingdom': '+44',
    'Germany': '+49', 'France': '+33', 'Spain': '+34', 'Italy': '+39',
    'Netherlands': '+31', 'Belgium': '+32', 'Switzerland': '+41',
    'Austria': '+43', 'Sweden': '+46', 'Norway': '+47', 'Denmark': '+45',
    'Finland': '+358', 'Poland': '+48', 'Ireland': '+353', 'Portugal': '+351',
    'Greece': '+30', 'Czech Republic': '+420', 'Romania': '+40',
    'Hungary': '+36', 'Ukraine': '+380', 'Turkey': '+90', 'Russia': '+7',
    'India': '+91', 'China': '+86', 'Japan': '+81', 'South Korea': '+82',
    'Singapore': '+65', 'Malaysia': '+60', 'Thailand': '+66',
    'Vietnam': '+84', 'Indonesia': '+62', 'Philippines': '+63',
    'Pakistan': '+92', 'Bangladesh': '+880', 'Sri Lanka': '+94',
    'Australia': '+61', 'New Zealand': '+64', 'UAE': '+971',
    'Saudi Arabia': '+966', 'Israel': '+972', 'Egypt': '+20',
    'Nigeria': '+234', 'Kenya': '+254', 'South Africa': '+27',
    'Brazil': '+55', 'Mexico': '+52', 'Argentina': '+54', 'Chile': '+56',
    'Colombia': '+57', 'Peru': '+51',
}
# Countries that actually use UPI (so we only show the UPI field for them)
UPI_COUNTRIES = {'India'}

# User Roles
ROLES = ['Admin', 'Manager', 'Analyst', 'Viewer']

# Simulation Types
SIMULATION_TYPES = [
    'price_increase', 'price_reduction', 'new_branch', 'employee_hiring',
    'employee_layoff', 'inventory_expansion', 'product_launch', 'marketing_campaign',
    'loan_taking', 'investment_planning', 'international_expansion', 'warehouse_expansion',
    'supplier_change', 'tax_changes', 'currency_fluctuation', 'inflation_impact',
    'market_crash', 'competitor_entry', 'economic_recession', 'customer_growth',
    'demand_growth', 'supply_disruption'
]

SIMULATION_LABELS = {
    'price_increase': 'Price Increase',
    'price_reduction': 'Price Reduction',
    'new_branch': 'New Branch Opening',
    'employee_hiring': 'Employee Hiring',
    'employee_layoff': 'Employee Layoff',
    'inventory_expansion': 'Inventory Expansion',
    'product_launch': 'New Product Launch',
    'marketing_campaign': 'Marketing Campaign',
    'loan_taking': 'Loan Taking',
    'investment_planning': 'Investment Planning',
    'international_expansion': 'International Expansion',
    'warehouse_expansion': 'Warehouse Expansion',
    'supplier_change': 'Supplier Change',
    'tax_changes': 'Tax Changes',
    'currency_fluctuation': 'Currency Fluctuation',
    'inflation_impact': 'Inflation Impact',
    'market_crash': 'Market Crash',
    'competitor_entry': 'Competitor Entry',
    'economic_recession': 'Economic Recession',
    'customer_growth': 'Customer Growth',
    'demand_growth': 'Demand Growth',
    'supply_disruption': 'Supply Disruption'
}

# Risk Categories
RISK_CATEGORIES = [
    'financial', 'operational', 'market', 'supply_chain', 'inventory',
    'growth', 'competition', 'economic', 'cashflow'
]

RISK_LABELS = {
    'financial': 'Financial Risk',
    'operational': 'Operational Risk',
    'market': 'Market Risk',
    'supply_chain': 'Supply Chain Risk',
    'inventory': 'Inventory Risk',
    'growth': 'Growth Risk',
    'competition': 'Competition Risk',
    'economic': 'Economic Risk',
    'cashflow': 'Cash Flow Risk'
}

# Forecast Types
FORECAST_TYPES = [
    'revenue', 'profit', 'demand', 'customer', 'market',
    'cashflow', 'expense', 'expansion', 'risk', 'opportunity'
]

FORECAST_LABELS = {
    'revenue': 'Revenue Forecast',
    'profit': 'Profit Forecast',
    'demand': 'Demand Forecast',
    'customer': 'Customer Growth Forecast',
    'market': 'Market Growth Forecast',
    'cashflow': 'Cash Flow Forecast',
    'expense': 'Expense Forecast',
    'expansion': 'Expansion Forecast',
    'risk': 'Risk Forecast',
    'opportunity': 'Opportunity Forecast'
}

# Forecast Methods
FORECAST_METHODS = [
    'moving_average', 'exponential_smoothing', 'arima', 'prophet', 'linear_regression'
]

# Forecast Horizons (in days)
FORECAST_HORIZONS = [30, 90, 180, 365, 1095, 1825]

# Report Types
REPORT_TYPES = [
    'executive', 'board', 'investor', 'risk', 'growth',
    'forecast', 'financial', 'operational', 'department'
]

REPORT_LABELS = {
    'executive': 'Executive Report',
    'board': 'Board Report',
    'investor': 'Investor Report',
    'risk': 'Risk Report',
    'growth': 'Growth Report',
    'forecast': 'Forecast Report',
    'financial': 'Financial Report',
    'operational': 'Operational Report',
    'department': 'Department Report'
}

# Document Types
DOCUMENT_TYPES = ['pdf', 'csv', 'xlsx', 'xls', 'docx', 'txt', 'json', 'xml', 'png', 'jpg', 'jpeg', 'gif', 'zip']

# Department defaults
DEFAULT_DEPARTMENTS = ['Sales', 'Marketing', 'Operations', 'Finance', 'HR', 'IT']

# ─── Country, State and City data (real, no external API) ───
COUNTRY_DATA = {
    'United States': {
        'states': ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
                   'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho',
                   'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
                   'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
                   'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada',
                   'New Hampshire', 'New Jersey', 'New Mexico', 'New York',
                   'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon',
                   'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
                   'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington',
                   'West Virginia', 'Wisconsin', 'Wyoming'],
        'currency': 'USD', 'currency_symbol': '$', 'tax_type': 'Sales Tax', 'tax_rate': 8.0
    },
    'United Kingdom': {
        'states': ['England', 'Scotland', 'Wales', 'Northern Ireland', 'Greater London'],
        'currency': 'GBP', 'currency_symbol': '£', 'tax_type': 'VAT', 'tax_rate': 20.0
    },
    'Canada': {
        'states': ['Ontario', 'Quebec', 'British Columbia', 'Alberta', 'Manitoba',
                   'Saskatchewan', 'Nova Scotia', 'New Brunswick', 'Newfoundland and Labrador',
                   'Prince Edward Island', 'Newfoundland', 'Yukon', 'Northwest Territories',
                   'Nunavut'],
        'currency': 'CAD', 'currency_symbol': 'C$', 'tax_type': 'GST/HST', 'tax_rate': 5.0
    },
    'India': {
        'states': ['Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh',
                   'Chhattisgarh', 'Dadra and Nagar Haveli', 'Daman and Diu', 'Delhi',
                   'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
                   'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh',
                   'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland',
                   'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim',
                   'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand',
                   'West Bengal'],
        'currency': 'INR', 'currency_symbol': '₹', 'tax_type': 'GST', 'tax_rate': 18.0
    },
    'Australia': {
        'states': ['Australian Capital Territory', 'New South Wales', 'Northern Territory',
                   'Queensland', 'South Australia', 'Tasmania', 'Victoria', 'Western Australia'],
        'currency': 'AUD', 'currency_symbol': 'A$', 'tax_type': 'GST', 'tax_rate': 10.0
    },
    'Germany': {
        'states': ['Baden-Württemberg', 'Bayern', 'Berlin', 'Brandenburg', 'Bremen',
                   'Hamburg', 'Hesse', 'Mecklenburg-Vorpommern', 'Niedersachsen',
                   'Nordrhein-Westfalen', 'Rheinland-Pfalz', 'Saarland', 'Sachsen',
                   'Sachsen-Anhalt', 'Schleswig-Holstein', 'Thüringen'],
        'currency': 'EUR', 'currency_symbol': '€', 'tax_type': 'VAT', 'tax_rate': 19.0
    },
    'France': {
        'states': ['Auvergne-Rhône-Alpes', 'Bourgogne-Franche-Comté', 'Bretagne',
                   'Centre-Val de Loire', 'Corse', 'Grand Est', 'Hauts-de-France',
                   'Île-de-France', 'Normandie', 'Nouvelle-Aquitaine', 'Occitanie',
                   'Pays de la Loire', 'Provence-Alpes-Côte d\'Azur'],
        'currency': 'EUR', 'currency_symbol': '€', 'tax_type': 'VAT', 'tax_rate': 20.0
    },
    'China': {
        'states': ['Anhui', 'Fujian', 'Gansu', 'Guangdong', 'Guizhou', 'Hainan',
                   'Hebei', 'Heilongjiang', 'Henan', 'Hubei', 'Hunan', 'Jiangsu',
                   'Jiangxi', 'Jilin', 'Liaoning', 'Qinghai', 'Shaanxi', 'Shandong',
                   'Shanghai', 'Sichuan', 'Yunnan', 'Zhejiang', 'Taiwan', 'Hong Kong', 'Macao'],
        'currency': 'CNY', 'currency_symbol': '¥', 'tax_type': 'VAT', 'tax_rate': 13.0
    },
    'Japan': {
        'states': ['Hokkaido', 'Tohoku', 'Kanto', 'Chubu', 'Kinki', 'Chugoku', 'Shikoku',
                   'Kyushu', 'Okinawa'],
        'currency': 'JPY', 'currency_symbol': '¥', 'tax_type': 'Consumption Tax', 'tax_rate': 10.0
    },
    'Singapore': {
        'states': ['Central', 'North', 'Northeast', 'West'],
        'currency': 'SGD', 'currency_symbol': 'S$', 'tax_type': 'GST', 'tax_rate': 8.0
    },
    'UAE': {
        'states': ['Abu Dhabi', 'Dubai', 'Sharjah', 'Ajman', 'Fujairah',
                   'Ras Al Khaimah', 'Umm Al Quwain'],
        'currency': 'AED', 'currency_symbol': 'د.إ', 'tax_type': 'VAT', 'tax_rate': 5.0
    },
    'Brazil': {
        'states': ['Acre', 'Alagoas', 'Amapá', 'Amazonas', 'Bahia', 'Ceará',
                   'Distrito Federal', 'Espírito Santo', 'Goiás', 'Maranhão',
                   'Mato Grosso', 'Mato Grosso do Sul', 'Minas Gerais', 'Pará',
                   'Paraíba', 'Paraná', 'Pernambuco', 'Piauí', 'Rio de Janeiro',
                   'Rio Grande do Norte', 'Rio Grande do Sul', 'Rondônia', 'Roraima',
                   'Santa Catarina', 'São Paulo', 'Sergipe', 'Tocantins'],
        'currency': 'BRL', 'currency_symbol': 'R$', 'tax_type': 'ICMS/ISS', 'tax_rate': 17.0
    },
}

# ─── Industry-based department budget allocations ───
# Each industry maps departments to % of the annual revenue target.
INDUSTRY_BUDGET_ALLOCATIONS = {
    'Technology': {
        'allocations': {'R&D': 25, 'Engineering': 25, 'Sales': 20, 'Marketing': 15,
                        'Operations': 10, 'Finance': 5, 'HR': 5, 'IT': 5},
        'default_departments': ['Sales', 'Marketing', 'Engineering', 'R&D', 'Operations', 'Finance', 'HR', 'IT'],
    },
    'Manufacturing': {
        'allocations': {'Production': 35, 'Quality': 10, 'Sales': 20, 'Marketing': 10,
                        'Supply Chain': 15, 'Finance': 5, 'HR': 5},
        'default_departments': ['Production', 'Quality', 'Sales', 'Marketing', 'Supply Chain', 'Finance', 'HR'],
    },
    'Retail': {
        'allocations': {'Store Operations': 40, 'Inventory': 15, 'Sales': 20, 'Marketing': 10,
                        'Finance': 8, 'HR': 7},
        'default_departments': ['Store Operations', 'Inventory', 'Sales', 'Marketing', 'Finance', 'HR'],
    },
    'E-Commerce': {
        'allocations': {'Platform': 25, 'Marketing': 25, 'Sales': 15, 'Logistics': 20,
                        'Customer Support': 10, 'Finance': 5},
        'default_departments': ['Platform', 'Marketing', 'Sales', 'Logistics', 'Customer Support', 'Finance'],
    },
    'Healthcare': {
        'allocations': {'Clinical Operations': 50, 'R&D': 10, 'Sales': 15, 'Marketing': 5,
                        'Finance': 10, 'HR': 5, 'Administration': 5},
        'default_departments': ['Clinical Operations', 'R&D', 'Sales', 'Marketing', 'Finance', 'HR', 'Administration'],
    },
}

# ─── Security Questions
SECURITY_QUESTIONS = [
    "What was your childhood nickname?",
    "What is the name of your first pet?",
    "What was your first car?",
    "What elementary school did you attend?",
    "What is your mother's maiden name?",
    "What is your favorite movie?",
    "What city were you born in?",
    "What is your favorite book?"
]

# Pagination options
PAGINATION_OPTIONS = [10, 25, 50, 100]

# Health score thresholds
HEALTH_SCORE_THRESHOLDS = {
    'critical': 40,
    'warning': 70,
    'good': 90
}

# Score colors
SCORE_COLORS = {
    'critical': '#EF4444',
    'warning': '#F59E0B',
    'good': '#10B981',
    'excellent': '#059669'
}

# Country data (states/provinces, default currency/tax) is loaded from the
# country_data module so constants.py stays small and editable.
from config.country_data import COUNTRY_DATA  # noqa: E402,F401 — re-exported for convenience