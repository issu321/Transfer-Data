THEMES = {
    'aurora_enterprise': {
        'name': 'Executive Slate',
        'bg_primary': '#0A0E1C',
        'bg_secondary': '#111831',
        'accent_primary': '#C9A227',
        'accent_secondary': '#5B83B3',
        'accent_warning': '#DF5D5D',
        'accent_success': '#3FA664',
        'text_primary': '#F5F7FA',
        'text_secondary': '#AAB7C4',
        'card_bg': 'rgba(255,255,255,0.04)',
        'border': 'rgba(255,255,255,0.10)',
        'shadow': '0 12px 40px rgba(3,8,22,0.55)',
        'gradient': 'linear-gradient(135deg, #0A0E1C 0%, #111831 50%, #0D1428 100%)',
        'aurora': 'radial-gradient(ellipse at 22% 45%, rgba(201,162,39,0.05) 0%, transparent 55%), radial-gradient(ellipse at 78% 22%, rgba(91,131,179,0.06) 0%, transparent 55%)',
    },
    'midnight_gold': {
        'name': 'Midnight Gold',
        'bg_primary': '#0f0f0f',
        'bg_secondary': '#1a1a1a',
        'accent_primary': '#F59E0B',
        'accent_secondary': '#D97706',
        'accent_warning': '#EF4444',
        'accent_success': '#10B981',
        'text_primary': '#FFFFFF',
        'text_secondary': '#DADAE4',
        'card_bg': 'rgba(255,255,255,0.03)',
        'border': 'rgba(255,255,255,0.08)',
        'shadow': '0 8px 32px rgba(0,0,0,0.3)',
        'gradient': 'linear-gradient(135deg, #0f0f0f 0%, #1a1a1a 50%, #141414 100%)',
        'aurora': 'radial-gradient(ellipse at 20% 50%, rgba(245,158,11,0.08) 0%, transparent 50%), radial-gradient(ellipse at 80% 20%, rgba(217,119,6,0.06) 0%, transparent 50%)',
    },
    'arctic_frost': {
        'name': 'Arctic Frost',
        'bg_primary': '#0c4a6e',
        'bg_secondary': '#075985',
        'accent_primary': '#0EA5E9',
        'accent_secondary': '#38BDF8',
        'accent_warning': '#F472B6',
        'accent_success': '#10B981',
        'text_primary': '#FFFFFF',
        'text_secondary': '#BAE6FD',
        'card_bg': 'rgba(255,255,255,0.08)',
        'border': 'rgba(255,255,255,0.12)',
        'shadow': '0 8px 32px rgba(0,0,0,0.2)',
        'gradient': 'linear-gradient(135deg, #0c4a6e 0%, #075985 50%, #0369a1 100%)',
        'aurora': 'radial-gradient(ellipse at 30% 40%, rgba(14,165,233,0.12) 0%, transparent 50%), radial-gradient(ellipse at 70% 60%, rgba(56,189,248,0.08) 0%, transparent 50%)',
    },
    'neon_cyber': {
        'name': 'Neon Cyber',
        'bg_primary': '#050505',
        'bg_secondary': '#0a0a0a',
        'accent_primary': '#22C55E',
        'accent_secondary': '#EC4899',
        'accent_warning': '#FBBF24',
        'accent_success': '#22C55E',
        'text_primary': '#FFFFFF',
        'text_secondary': '#E0EAE0',
        'card_bg': 'rgba(34,197,94,0.03)',
        'border': 'rgba(34,197,94,0.12)',
        'shadow': '0 8px 32px rgba(34,197,94,0.1)',
        'gradient': 'linear-gradient(135deg, #050505 0%, #0a0a0a 50%, #0f0f0f 100%)',
        'aurora': 'radial-gradient(ellipse at 20% 50%, rgba(34,197,94,0.1) 0%, transparent 50%), radial-gradient(ellipse at 80% 20%, rgba(236,72,153,0.08) 0%, transparent 50%)',
    },
    'solar_flare': {
        'name': 'Solar Flare',
        'bg_primary': '#1c0f0a',
        'bg_secondary': '#2a1a12',
        'accent_primary': '#F97316',
        'accent_secondary': '#FB923C',
        'accent_warning': '#EF4444',
        'accent_success': '#10B981',
        'text_primary': '#FFFFFF',
        'text_secondary': '#FDBA74',
        'card_bg': 'rgba(255,255,255,0.03)',
        'border': 'rgba(255,255,255,0.08)',
        'shadow': '0 8px 32px rgba(0,0,0,0.3)',
        'gradient': 'linear-gradient(135deg, #1c0f0a 0%, #2a1a12 50%, #1f150f 100%)',
        'aurora': 'radial-gradient(ellipse at 30% 40%, rgba(249,115,22,0.1) 0%, transparent 50%), radial-gradient(ellipse at 70% 60%, rgba(251,146,60,0.06) 0%, transparent 50%)',
    },
    'obsidian_elite': {
        'name': 'Obsidian Elite',
        'bg_primary': '#000000',
        'bg_secondary': '#0a0a0a',
        'accent_primary': '#C0C0C0',
        'accent_secondary': '#A0A0A0',
        'accent_warning': '#EF4444',
        'accent_success': '#10B981',
        'text_primary': '#FFFFFF',
        'text_secondary': '#E2E2E2',
        'card_bg': 'rgba(192,192,192,0.03)',
        'border': 'rgba(192,192,192,0.1)',
        'shadow': '0 8px 32px rgba(0,0,0,0.5)',
        'gradient': 'linear-gradient(135deg, #000000 0%, #0a0a0a 50%, #050505 100%)',
        'aurora': 'radial-gradient(ellipse at 50% 50%, rgba(192,192,192,0.05) 0%, transparent 60%)',
    },
    'forest_zen': {
        'name': 'Forest Zen',
        'bg_primary': '#064e3b',
        'bg_secondary': '#065f46',
        'accent_primary': '#34D399',
        'accent_secondary': '#6EE7B7',
        'accent_warning': '#FBBF24',
        'accent_success': '#10B981',
        'text_primary': '#FFFFFF',
        'text_secondary': '#A7F3D0',
        'card_bg': 'rgba(255,255,255,0.04)',
        'border': 'rgba(255,255,255,0.08)',
        'shadow': '0 8px 32px rgba(0,0,0,0.3)',
        'gradient': 'linear-gradient(135deg, #064e3b 0%, #065f46 50%, #047857 100%)',
        'aurora': 'radial-gradient(ellipse at 25% 45%, rgba(52,211,153,0.1) 0%, transparent 50%), radial-gradient(ellipse at 75% 55%, rgba(110,231,183,0.06) 0%, transparent 50%)',
    },
    'cosmic_void': {
        'name': 'Cosmic Void',
        'bg_primary': '#030712',
        'bg_secondary': '#0a0f1e',
        'accent_primary': '#E2E8F0',
        'accent_secondary': '#8B5CF6',
        'accent_warning': '#F472B6',
        'accent_success': '#10B981',
        'text_primary': '#FFFFFF',
        'text_secondary': '#D8E1EE',
        'card_bg': 'rgba(255,255,255,0.02)',
        'border': 'rgba(255,255,255,0.06)',
        'shadow': '0 8px 32px rgba(0,0,0,0.4)',
        'gradient': 'linear-gradient(135deg, #030712 0%, #0a0f1e 50%, #080c18 100%)',
        'aurora': 'radial-gradient(ellipse at 20% 30%, rgba(226,232,240,0.06) 0%, transparent 50%), radial-gradient(ellipse at 80% 70%, rgba(139,92,246,0.08) 0%, transparent 50%)',
    }
}

def get_theme_css(theme_id):
    theme = THEMES.get(theme_id, THEMES['aurora_enterprise'])
    return f"""
:root {{
    --bg-primary: {theme['bg_primary']};
    --bg-secondary: {theme['bg_secondary']};
    --accent-primary: {theme['accent_primary']};
    --accent-secondary: {theme['accent_secondary']};
    --accent-warning: {theme['accent_warning']};
    --accent-success: {theme['accent_success']};
    --text-primary: {theme['text_primary']};
    --text-secondary: {theme['text_secondary']};
    --card-bg: {theme['card_bg']};
    --border-color: {theme['border']};
    --shadow: {theme['shadow']};
    --gradient: {theme['gradient']};
    --aurora: {theme['aurora']};
}}
"""