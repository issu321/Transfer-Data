from database.db import db
from database.models.financial import FinancialRecord
from database.models.company import Company
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.inventory import Inventory
from sqlalchemy import func, extract
from datetime import datetime, timedelta

def _fmt_money(amount, currency_symbol='$'):
    return f"{currency_symbol}{abs(amount):,.0f}"

class AnalyticsService:
    @staticmethod
    def get_executive_summary(company_id):
        now = datetime.utcnow()
        
        # Get company settings for fallback values
        from services.company_service import CompanyService
        company = CompanyService.get_company(company_id)
        
        # FIX: Auto-correct company_size based on employee_count if mismatch
        if company and company.employee_count:
            correct_size = AnalyticsService._get_company_size_from_employees(company.employee_count)
            if company.company_size != correct_size:
                company.company_size = correct_size
                db.session.commit()
        
        # ------------------------------------------------------------------
        # Financial metrics - OBSERVED ONLY. Every figure traces to real
        # FinancialRecord ledger rows. `companies.annual_revenue` is the FY
        # revenue TARGET entered at setup (the plan) - it is NEVER injected
        # into actuals; it is reported separately as target-vs-actual.
        # ------------------------------------------------------------------
        thirty_days_ago = now - timedelta(days=30)
        sixty_days_ago = now - timedelta(days=60)
        fy_start = datetime(now.year, 1, 1).date()

        def _sum(tx_type, since=None, until=None, fy=False):
            q = db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_type == tx_type)
            if fy:
                q = q.filter(FinancialRecord.transaction_date >= fy_start)
            else:
                if since is not None:
                    q = q.filter(FinancialRecord.transaction_date >= since.date())
                if until is not None:
                    q = q.filter(FinancialRecord.transaction_date < until.date())
            return float(q.scalar() or 0)

        def _count(tx_type, since):
            return db.session.query(FinancialRecord.id).filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_type == tx_type,
                FinancialRecord.transaction_date >= since.date()
            ).count()

        revenue_30d = _sum('revenue', since=thirty_days_ago)
        expense_30d = _sum('expense', since=thirty_days_ago)
        revenue_prev = _sum('revenue', since=sixty_days_ago, until=thirty_days_ago)
        expense_prev = _sum('expense', since=sixty_days_ago, until=thirty_days_ago)
        revenue_rows = _count('revenue', thirty_days_ago)
        expense_rows = _count('expense', thirty_days_ago)
        actual_revenue_ytd = _sum('revenue', fy=True)
        actual_expense_ytd = _sum('expense', fy=True)
        has_ledger_activity = (revenue_rows + expense_rows) > 0
        revenue_source = 'records' if revenue_rows > 0 else ('plan' if company and company.annual_revenue else 'no_data')

        profit_30d = (revenue_30d - expense_30d) if has_ledger_activity else 0.0
        margin = (profit_30d / revenue_30d * 100) if has_ledger_activity and revenue_30d else 0.0
        prev_profit = (revenue_prev - expense_prev) if (revenue_prev or expense_prev) else 0.0
        prev_margin = (prev_profit / revenue_prev * 100) if revenue_prev else 0.0

        # FY target (setup input) vs booked ledger (T12M-equivalent within year).
        annual_target = float(getattr(company, 'annual_revenue', 0) or 0)
        days_elapsed = max((now.date() - fy_start).days + 1, 1)
        expected_to_date = annual_target * days_elapsed / 365.0 if annual_target else 0.0
        revenue_attainment = (actual_revenue_ytd / annual_target * 100) if annual_target > 0 else 0.0
        revenue_pacing_gap = round(actual_revenue_ytd - expected_to_date, 2) if annual_target else 0.0

        # Employee metrics — real roster rows only; setup headcount shown as plan.
        roster_active = Employee.query.filter_by(company_id=company_id, status='active').count()
        roster_total = Employee.query.filter_by(company_id=company_id).count()
        plan_headcount = int(getattr(company, 'employee_count', 0) or 0)
        total_employees = roster_active if roster_active else 0
        employee_source = 'records' if roster_active else ('no_data')

        avg_salary = db.session.query(func.avg(Employee.salary)).filter(
            Employee.company_id == company_id,
            Employee.status == 'active'
        ).scalar() or 0
        total_payroll = db.session.query(func.coalesce(func.sum(Employee.salary), 0.0)).filter(
            Employee.company_id == company_id,
            Employee.status == 'active'
        ).scalar() or 0.0
        hiring_completion = round(roster_active / plan_headcount * 100, 1) if plan_headcount > 0 else 0.0

        # Customer metrics — real CRM rows only; setup estimate shown as plan.
        total_customers = Customer.query.filter_by(company_id=company_id, status='active').count()
        total_customer_rows = Customer.query.filter_by(company_id=company_id).count()
        plan_customers = int(getattr(company, 'customer_count', 0) or 0)
        customer_source = 'records' if total_customer_rows else 'no_data'
        churned = Customer.query.filter_by(company_id=company_id, is_churned=True).count()
        churn_base = total_customers + churned
        churn_rate = (churned / churn_base * 100) if churn_base else 0.0

        # Inventory
        total_skus = Inventory.query.filter_by(company_id=company_id, is_active=True).count()
        low_stock = sum(1 for i in Inventory.query.filter_by(company_id=company_id, is_active=True).all() if i.is_low_stock())

        setup_completion = AnalyticsService._setup_completion(company, roster_active, total_customer_rows, total_skus, has_ledger_activity)

        # ── Cash runway & burn multiple (honest, from real data only) ──
        # runway_months = cash balance / monthly burn. We use total_equity as the
        # best available cash proxy when the ledger has expenses booked this month.
        cash_balance = float(getattr(company, 'total_equity', 0) or 0)
        monthly_burn = expense_30d / 30.0 if expense_30d else 0.0
        runway_months = round(cash_balance / monthly_burn, 1) if monthly_burn > 0 and cash_balance > 0 else None
        # Burn multiple = net cash outflow per unit of net new value destroyed.
        # Only meaningful when there is real activity; None = "insufficient data".
        if has_ledger_activity and expense_30d > revenue_30d and revenue_30d > 0:
            burn_multiple = round(expense_30d / (revenue_30d), 2)
        elif has_ledger_activity and revenue_30d >= expense_30d:
            burn_multiple = 0.0
        else:
            burn_multiple = None

        return {
            'revenue_30d': round(float(revenue_30d), 2),
            'revenue_prev_30d': round(float(revenue_prev), 2),
            'expense_30d': round(float(expense_30d), 2),
            'expense_prev_30d': round(float(expense_prev), 2),
            'profit_30d': round(profit_30d, 2),
            'profit_prev_30d': round(prev_profit, 2),
            'margin': round(margin, 2),
            'margin_prev': round(prev_margin, 2),
            'total_employees': total_employees,
            'roster_total': roster_total,
            'plan_headcount': plan_headcount,
            'hiring_completion': hiring_completion,
            'avg_salary': round(float(avg_salary or 0), 2),
            'total_payroll': round(float(total_payroll or 0), 2),
            'total_customers': total_customers,
            'plan_customers': plan_customers,
            'churn_rate': round(churn_rate, 2),
            'churned_count': churned,
            'total_skus': total_skus,
            'low_stock': low_stock,
            'health_score': round(AnalyticsService._calculate_health_score(margin, churn_rate, low_stock, total_skus), 1),
            # Target-vs-Actual block: FY target (setup) vs booked ledger (YTD).
            # Templates must render annual_target ONLY as "Target" context —
            # never as observed revenue. Observed money is revenue_ytd/revenue_30d.
            'revenue_source': revenue_source,
            'financial_complete': bool(has_ledger_activity),
            'financial_status': 'observed' if has_ledger_activity else 'no_data',
            'revenue_target_label': 'FY Revenue Target' if annual_target else 'No target set',
            'annual_target': round(float(annual_target), 2),
            'revenue_ytd': round(actual_revenue_ytd, 2),
            'revenue_status': 'observed' if has_ledger_activity else 'no_data',
            'expense_ytd': round(actual_expense_ytd, 2),
            'expense_status': 'observed' if has_ledger_activity else 'no_data',
            'profit_ytd': round(actual_revenue_ytd - actual_expense_ytd, 2),
            'profit_status': 'observed' if has_ledger_activity else 'insufficient_data',
            'revenue_attainment': round(revenue_attainment, 1),
            'revenue_expected_to_date': round(expected_to_date, 2),
            'revenue_pacing_gap': revenue_pacing_gap,
            'has_activity': bool(has_ledger_activity),
            'setup_progress_pct': round(setup_completion, 1),
            'runway_months': runway_months,
            'burn_multiple': burn_multiple,
            'data_quality': {
                'financial': 'observed' if has_ledger_activity else 'no_data',
                'profitability': 'observed' if has_ledger_activity else 'insufficient_data',
                'customers': customer_source,
                'employees': employee_source,
                'inventory': 'records' if total_skus else 'no_data'
            }
        }

    @staticmethod
    def _setup_completion(company, roster_active, customer_rows, sku_count, has_ledger):
        steps = [
            bool(company),
            roster_active > 0,
            customer_rows > 0,
            sku_count > 0,
            bool(has_ledger),
        ]
        return sum(1 for x in steps if x) / len(steps) * 100

    @staticmethod
    def _get_company_size_from_employees(employee_count):
        """Get correct company size string based on employee count."""
        if employee_count <= 10:
            return '1-10'
        elif employee_count <= 50:
            return '11-50'
        elif employee_count <= 200:
            return '51-200'
        elif employee_count <= 500:
            return '201-500'
        elif employee_count <= 1000:
            return '501-1000'
        else:
            return '1000+'
    
    @staticmethod
    def _estimate_customers(company):
        """Estimate customer count based on company size and revenue for realistic data."""
        if not company:
            return 0
        
        # FIX: First check employee_count to determine correct size category
        if company.employee_count:
            if company.employee_count >= 1000:
                return 50000
            elif company.employee_count >= 501:
                return 15000
            elif company.employee_count >= 201:
                return 5000
            elif company.employee_count >= 51:
                return 1000
            elif company.employee_count >= 11:
                return 200
            else:
                return 50
        
        # Fallback: Use company_size string
        size_map = {
            '1-10': 50,
            '11-50': 200,
            '51-200': 1000,
            '201-500': 5000,
            '501-1000': 15000,
            '1000+': 50000
        }
        
        if company.company_size and company.company_size in size_map:
            return size_map[company.company_size]
        
        # Fallback based on annual revenue
        if company.annual_revenue:
            revenue = float(company.annual_revenue)
            if revenue < 100000:
                return 50
            elif revenue < 1000000:
                return 500
            elif revenue < 10000000:
                return 5000
            elif revenue < 100000000:
                return 50000
            else:
                return 200000
        
        return 1000  # Default fallback
    
    @staticmethod
    def _calculate_health_score(margin, churn_rate, low_stock, total_skus):
        margin_score = min(max(margin / 20 * 25, 0), 25)
        churn_score = max(0, 25 - churn_rate / 4 * 25)
        stock_score = max(0, 25 - (low_stock / max(total_skus, 1) * 100) / 20 * 25)
        diversity_score = min(total_skus / 50 * 25, 25)
        return min(100, margin_score + churn_score + stock_score + diversity_score)
    
    @staticmethod
    def get_trend_data(company_id, days=90):
        end_date = datetime.utcnow().date()
        start_date = end_date - timedelta(days=days)
        
        data = db.session.query(
            FinancialRecord.transaction_date,
            FinancialRecord.transaction_type,
            func.sum(FinancialRecord.amount).label('total')
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_date >= start_date
        ).group_by(
            FinancialRecord.transaction_date,
            FinancialRecord.transaction_type
        ).order_by(FinancialRecord.transaction_date).all()
        
        if not data:
            # No transactions yet: return an honest zero-filled window over the
            # requested range instead of a synthetic random sample. The chart
            # fills in automatically as real revenue/expense records are added.
            dates = [start_date + timedelta(days=i) for i in range(days + 1)]
            zeros = [0.0] * len(dates)
            return {
                'dates': [d.isoformat() for d in dates],
                'revenue': zeros,
                'expenses': [0.0] * days,
                'profit': [0.0] * days
            }
        
        daily = {}
        for transaction_date, transaction_type, total in data:
            daily.setdefault(transaction_date, {'revenue': 0.0, 'expense': 0.0})
            daily[transaction_date][transaction_type] = float(total or 0)

        # Return a contiguous date axis so charts and exports do not imply
        # missing dates were omitted or reorder the company's time series.
        dates = [start_date + timedelta(days=i) for i in range(days + 1)]
        revenue = [daily.get(d, {}).get('revenue', 0.0) for d in dates]
        expenses = [daily.get(d, {}).get('expense', 0.0) for d in dates]
        
        return {
            'dates': [d.isoformat() for d in dates],
            'revenue': revenue,
            'expenses': expenses,
            'profit': [round(r - e, 2) for r, e in zip(revenue, expenses)]
        }
    
    @staticmethod
    def _generate_sample_trend(days, company_id=None):
        """Generate realistic sample trend data based on company settings."""
        company = None
        if company_id:
            from services.company_service import CompanyService
            company = CompanyService.get_company(company_id)
        
        # Kept for backwards compatibility with older callers. It now returns
        # an explicit empty series instead of a fabricated business history.
        dates = [(datetime.utcnow().date() - timedelta(days=i)) for i in range(days, -1, -1)]
        return {'dates': [d.isoformat() for d in dates],
                'revenue': [0.0] * len(dates),
                'expenses': [0.0] * len(dates),
                'profit': [0.0] * len(dates)}
    
    @staticmethod
    def _department_live_totals(company_id):
        """LIVE per-department aggregates computed fresh from the DB on every
        call — no stored snapshots, nothing written back during a GET.

        budget = SUM(projects.budget) for the department (falls back to the
                 department's own budget field when it has no projects)
        spent  = SUM(projects.spent) + SUM(expense FinancialRecords attributed
                 to the department)
        Returns {department_id: {'budget': float, 'spent': float}}.
        """
        from database.models.department import Department
        from database.models.project import Project

        proj_rows = db.session.query(
            Project.department_id,
            func.coalesce(func.sum(Project.budget), 0.0),
            func.coalesce(func.sum(Project.spent), 0.0)
        ).filter(
            Project.company_id == company_id,
            Project.department_id.isnot(None)
        ).group_by(Project.department_id).all()

        fin_rows = db.session.query(
            FinancialRecord.department_id,
            func.coalesce(func.sum(FinancialRecord.amount), 0.0)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.department_id.isnot(None)
        ).group_by(FinancialRecord.department_id).all()

        proj_budget = {row[0]: float(row[1] or 0) for row in proj_rows}
        proj_spent = {row[0]: float(row[2] or 0) for row in proj_rows}
        fin_spent = {row[0]: float(row[1] or 0) for row in fin_rows}

        totals = {}
        for d in Department.query.filter_by(company_id=company_id, is_active=True).all():
            budget = proj_budget[d.id] if d.id in proj_budget else float(d.budget or 0)
            spent = proj_spent.get(d.id, 0.0) + fin_spent.get(d.id, 0.0)
            totals[d.id] = {'budget': budget, 'spent': spent}
        return totals

    @staticmethod
    def get_department_performance(company_id):
        """LIVE department performance — SUM(project budgets), SUM(actual spend)
        and expense records are aggregated from the DB on every request.
        Utilization = spent/budget; Variance = budget - spent."""
        from database.models.department import Department

        depts = Department.query.filter_by(company_id=company_id, is_active=True).all()

        if not depts:
            return []

        live_totals = AnalyticsService._department_live_totals(company_id)

        result = []
        for d in depts:
            live = live_totals.get(d.id, {'budget': float(d.budget or 0), 'spent': 0.0})
            budget = live['budget']
            spent = live['spent']

            utilization = round((spent / budget * 100), 2) if budget > 0 else 0
            variance = round(budget - spent, 2)

            result.append({
                'id': d.id,
                'name': d.name,
                'code': d.code,
                'budget': budget,
                'spent': spent,
                'remaining': variance,
                'utilization': utilization,
                'employee_count': d.employee_count or 0,
                'color': d.color or '#00D4FF',
                'variance': variance
            })

        return result