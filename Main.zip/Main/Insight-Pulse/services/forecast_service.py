from database.db import db
from database.models.forecast import Forecast, ForecastResult
from database.models.company import Company
from database.models.financial import FinancialRecord
from services.company_service import CompanyService
from database.db import db
from sqlalchemy import func
import numpy as np
from datetime import datetime, timedelta

def _fmt_money(amount, currency_symbol='$'):
    return f"{currency_symbol}{abs(amount):,.0f}"

class ForecastService:
    @staticmethod
    def generate_forecast(company_id, user_id, forecast_type, method, horizon_days, name, params=None, currency_symbol='$'):
        forecast = Forecast(
            company_id=company_id,
            user_id=user_id,
            name=name,
            forecast_type=forecast_type,
            method=method,
            horizon_days=horizon_days,
            status='running',
            parameters=str(params or {})
        )
        db.session.add(forecast)
        db.session.commit()
        
        try:
            baseline = ForecastService._get_baseline_data(company_id, forecast_type)
            dates, values = ForecastService._apply_method(baseline, method, horizon_days)
            
            for d, v, lb, ub in zip(dates, values['forecast'], values['lower'], values['upper']):
                result = ForecastResult(
                    forecast_id=forecast.id,
                    date=d,
                    value=v,
                    lower_bound=lb,
                    upper_bound=ub
                )
                db.session.add(result)
            
            forecast.accuracy_mae = values.get('mae')
            forecast.accuracy_rmse = values.get('rmse')
            forecast.accuracy_mape = values.get('mape')
            forecast.accuracy_r2 = values.get('r2')
            forecast.status = 'completed'
            forecast.summary = f"Forecast generated using {method} for {horizon_days} days. Expected value range: {_fmt_money(min(values['forecast']), currency_symbol)} - {_fmt_money(max(values['forecast']), currency_symbol)}"
            
        except Exception as e:
            forecast.status = 'failed'
            forecast.summary = str(e)
        
        db.session.commit()
        return forecast
    
    @staticmethod
    def _get_baseline_data(company_id, forecast_type):
        if forecast_type not in {'revenue', 'expense', 'profit'}:
            raise ValueError(
                f"No observed time series is available for '{forecast_type}'. "
                "Import or record historical data before forecasting."
            )

        rows = db.session.query(
            FinancialRecord.transaction_date,
            FinancialRecord.transaction_type,
            func.sum(FinancialRecord.amount)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type.in_(['revenue', 'expense'])
        ).group_by(
            FinancialRecord.transaction_date,
            FinancialRecord.transaction_type
        ).order_by(FinancialRecord.transaction_date).all()

        by_date = {}
        for date, transaction_type, amount in rows:
            by_date.setdefault(date, {'revenue': 0.0, 'expense': 0.0})
            by_date[date][transaction_type] = float(amount or 0)

        if len(by_date) < 14:
            raise ValueError(
                "At least 14 days of observed financial records are required "
                "to generate a reliable forecast."
            )

        return [
            (by_date[date]['revenue'] if forecast_type == 'revenue'
             else by_date[date]['expense'] if forecast_type == 'expense'
             else by_date[date]['revenue'] - by_date[date]['expense'])
            for date in sorted(by_date)
        ]
    
    @staticmethod
    def _apply_method(baseline, method, horizon_days):
        historical = np.array(baseline)
        n = len(historical)
        
        if method == 'moving_average':
            window = min(30, n // 2)
            last_avg = np.mean(historical[-window:])
            trend = np.mean(np.diff(historical[-window:])) if window > 1 else 0
            forecast_vals = [last_avg + trend * (i + 1) for i in range(horizon_days)]
            std_dev = np.std(historical[-window:]) * 1.5
            
        elif method == 'exponential_smoothing':
            alpha = 0.3
            smoothed = historical[0]
            for val in historical[1:]:
                smoothed = alpha * val + (1 - alpha) * smoothed
            trend = np.mean(np.diff(historical[-30:]))
            forecast_vals = [smoothed + trend * (i + 1) for i in range(horizon_days)]
            std_dev = np.std(historical) * 1.2
            
        elif method == 'linear_regression':
            x = np.arange(n)
            coeffs = np.polyfit(x, historical, 1)
            forecast_vals = [coeffs[0] * (n + i) + coeffs[1] for i in range(horizon_days)]
            residuals = historical - np.polyval(coeffs, x)
            std_dev = np.std(residuals) * 1.5
            
        else:
            trend = np.mean(np.diff(historical[-60:])) if len(historical) >= 60 else 0
            last_val = historical[-1]
            forecast_vals = [last_val + trend * (i + 1) for i in range(horizon_days)]
            std_dev = np.std(historical) * 1.3
        
        forecast_vals = [max(0, v) for v in forecast_vals]
        lower = [max(0, v - std_dev * (1 + i * 0.01)) for i, v in enumerate(forecast_vals)]
        upper = [v + std_dev * (1 + i * 0.01) for i, v in enumerate(forecast_vals)]
        
        start_date = datetime.now().date()
        dates = [start_date + timedelta(days=i) for i in range(horizon_days)]
        
        residuals = historical[-30:] - np.mean(historical[-30:])
        mae = np.mean(np.abs(residuals))
        rmse = np.sqrt(np.mean(residuals**2))
        mape = np.mean(np.abs(residuals / np.maximum(historical[-30:], 1))) * 100
        
        return dates, {
            'forecast': forecast_vals,
            'lower': lower,
            'upper': upper,
            'mae': round(mae, 2),
            'rmse': round(rmse, 2),
            'mape': round(mape, 2),
            'r2': round(1 - np.var(residuals) / np.var(historical[-30:]), 3) if np.var(historical[-30:]) > 0 else 0.85
        }
    
    @staticmethod
    def get_forecast_results(forecast_id):
        return ForecastResult.query.filter_by(forecast_id=forecast_id).order_by(ForecastResult.date).all()