import os
import csv
import io
import ast
from datetime import datetime, timedelta
from database.db import db
from database.models.report import Report
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, ListFlowable, ListItem
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from sqlalchemy import func

# ==================== OPTIONAL IMPORTS ====================
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    _OPENPYXL_AVAILABLE = True
except ImportError:
    _OPENPYXL_AVAILABLE = False

# ==================== UNICODE FONT REGISTRATION ====================
_PDF_FONT = 'Helvetica'
_PDF_FONT_BOLD = 'Helvetica-Bold'

def _register_unicode_fonts():
    global _PDF_FONT, _PDF_FONT_BOLD
    candidates = [
        ('DejaVuSans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
         'DejaVuSans-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
        ('LiberationSans', '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
         'LiberationSans-Bold', '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'),
        ('NotoSans', '/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf',
         'NotoSans-Bold', '/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf'),
        ('ArialUnicode', 'C:/Windows/Fonts/arial.ttf',
         'ArialUnicode-Bold', 'C:/Windows/Fonts/arialbd.ttf'),
        ('ArialUnicode', '/Library/Fonts/Arial.ttf',
         'ArialUnicode-Bold', '/Library/Fonts/Arial Bold.ttf'),
        ('ArialUnicode', '/System/Library/Fonts/Supplemental/Arial.ttf',
         'ArialUnicode-Bold', '/System/Library/Fonts/Supplemental/Arial Bold.ttf'),
    ]
    for reg_name, reg_path, bold_name, bold_path in candidates:
        try:
            pdfmetrics.registerFont(TTFont(reg_name, reg_path))
            pdfmetrics.registerFont(TTFont(bold_name, bold_path))
            _PDF_FONT = reg_name
            _PDF_FONT_BOLD = bold_name
            return
        except Exception:
            continue

_register_unicode_fonts()

def _pdf_currency_symbol(data):
    """Return PDF-safe currency symbol. Falls back to ISO code if no Unicode font."""
    cs = data.get('currency_symbol', '$')
    if _PDF_FONT == 'Helvetica':
        iso_map = {
            '$': 'USD', '€': 'EUR', '£': 'GBP', '₹': 'INR', '¥': 'JPY',
            '₩': 'KRW', 'A$': 'AUD', 'C$': 'CAD', 'S$': 'SGD', 'د.إ': 'AED',
            'Other': ''
        }
        return iso_map.get(cs, cs)
    return cs

# Absolute base directories for generated files
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
REPORTS_DIR = os.path.join(BASE_DIR, 'documents', 'reports')
EXPORTS_DIR = os.path.join(BASE_DIR, 'exports')

def _fmt_money(amount, currency_symbol='$'):
    return f"{currency_symbol}{abs(amount):,.0f}"

class ReportService:
    REPORT_TYPE_CONFIG = {
        'executive': {
            'title': 'Executive Summary Report',
            'description': 'High-level strategic overview for C-suite leadership.',
            'sections': ['summary', 'financials', 'health', 'recommendations']
        },
        'board': {
            'title': 'Board of Directors Report',
            'description': 'Governance, compliance, and fiduciary oversight metrics.',
            'sections': ['governance', 'financial_highlights', 'risk_oversight', 'strategic_initiatives']
        },
        'investor': {
            'title': 'Investor Relations Report',
            'description': 'ROI, growth trajectory, valuation indicators, and market position.',
            'sections': ['performance', 'growth_metrics', 'valuation', 'market_position']
        },
        'risk': {
            'title': 'Enterprise Risk Report',
            'description': 'Risk register, heat map data, mitigation status, and compliance.',
            'sections': ['risk_overview', 'risk_register', 'mitigation', 'compliance']
        },
        'growth': {
            'title': 'Growth & Expansion Report',
            'description': 'Customer acquisition, market share, and scaling opportunities.',
            'sections': ['growth_kpis', 'customer_analytics', 'expansion_opps', 'investment_needs']
        },
        'forecast': {
            'title': 'Predictive Forecast Report',
            'description': 'Trend analysis, scenario planning, and confidence intervals.',
            'sections': ['forecast_summary', 'trends', 'scenarios', 'confidence_analysis']
        },
        'financial': {
            'title': 'Detailed Financial Report',
            'description': 'P&L, balance sheet indicators, cash flow, and financial ratios.',
            'sections': ['income_statement', 'cash_flow', 'balance_sheet', 'ratios']
        },
        'operational': {
            'title': 'Operational Efficiency Report',
            'description': 'Throughput, quality scores, supply chain, and process metrics.',
            'sections': ['efficiency', 'supply_chain', 'quality', 'capacity']
        },
        'department': {
            'title': 'Departmental Performance Report',
            'description': 'Headcount, budget vs. actual, and team performance by department.',
            'sections': ['headcount', 'budget_analysis', 'performance', 'salary_breakdown']
        }
    }

    @staticmethod
    def generate_report(company_id, user_id, report_type, name, format_type='pdf', parameters=None, currency_symbol='$'):
        report = Report(
            company_id=company_id,
            user_id=user_id,
            name=name,
            report_type=report_type,
            format=format_type,
            parameters=str(parameters or {})
        )
        db.session.add(report)
        db.session.commit()
        
        try:
            filepath = ReportService.generate_file_for_report(report, company_id, report_type, format_type, parameters, currency_symbol=currency_symbol)
            report.file_path = filepath
            report.last_generated = datetime.utcnow()
            report.summary = f"{ReportService.REPORT_TYPE_CONFIG.get(report_type, {}).get('title', 'Report')} generated successfully on {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}"
            if os.path.exists(filepath):
                report.file_size = os.path.getsize(filepath)
        except Exception as e:
            report.file_path = None
            report.summary = f"Error: {str(e)}"
        
        db.session.commit()
        return report
    
    @staticmethod
    def generate_file_for_report(report, company_id, report_type, format_type=None, parameters=None, currency_symbol='$'):
        """Generate the actual file for an existing report record. Returns absolute file path."""
        if format_type is None:
            format_type = report.format
        if parameters is None:
            parameters = ast.literal_eval(report.parameters) if report.parameters else {}
            
        os.makedirs(REPORTS_DIR, exist_ok=True)
        os.makedirs(EXPORTS_DIR, exist_ok=True)
        
        data = ReportService._get_report_data(company_id, report_type, currency_symbol)
        
        if format_type == 'pdf':
            filepath = ReportService._generate_pdf(report, company_id, report_type, data)
        elif format_type in ('excel', 'xlsx'):
            filepath = ReportService._generate_excel(report, company_id, report_type, data)
        elif format_type == 'csv':
            filepath = ReportService._generate_csv(report, company_id, report_type, data)
        else:
            filepath = ReportService._generate_pdf(report, company_id, report_type, data)
        
        return filepath

    # ==================== DATA COLLECTION ====================
    
    @staticmethod
    def _get_report_data(company_id, report_type, currency_symbol='$'):
        """Fetch all relevant data for a specific report type."""
        from database.models.company import Company
        from database.models.financial import FinancialRecord
        from database.models.employee import Employee
        from database.models.customer import Customer
        from database.models.inventory import Inventory
        from database.models.risk import Risk
        from database.models.forecast import Forecast, ForecastResult
        from database.models.simulation import Simulation
        from database.models.department import Department
        from database.models.project import Project
        from database.models.financial import FinancialAccount
        
        company = Company.query.get(company_id)
        now = datetime.utcnow()
        start_30 = (now - timedelta(days=30)).date()
        start_90 = (now - timedelta(days=90)).date()
        start_365 = (now - timedelta(days=365)).date()
        
        # Base financials
        rev_30 = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= start_30
        ).scalar() or 0
        
        exp_30 = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= start_30
        ).scalar() or 0
        
        rev_90 = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= start_90
        ).scalar() or 0
        
        exp_90 = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= start_90
        ).scalar() or 0
        
        rev_365 = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= start_365
        ).scalar() or 0
        
        exp_365 = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= start_365
        ).scalar() or 0
        ledger_days = db.session.query(func.count(func.distinct(FinancialRecord.transaction_date))).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_date >= start_365
        ).scalar() or 0
        
        annual_revenue_source = 'company_profile' if company and company.annual_revenue else 'observed_ledger'
        annual_revenue = (company.annual_revenue if company and company.annual_revenue else rev_365) or 0
        observed_revenue_365 = float(rev_365)
        profile_annual_revenue = float(company.annual_revenue or 0) if company else 0
        annual_cost = exp_365
        profit_30 = rev_30 - exp_30
        profit_365 = rev_365 - exp_365
        margin = (profit_365 / observed_revenue_365 * 100) if observed_revenue_365 else 0
        
        # Employees
        total_employees = db.session.query(func.count(Employee.id)).filter(
            Employee.company_id == company_id, Employee.status == 'active'
        ).scalar() or 0
        
        avg_salary = db.session.query(func.avg(Employee.salary)).filter(
            Employee.company_id == company_id, Employee.status == 'active', Employee.salary.isnot(None)
        ).scalar() or 0
        
        departments = db.session.query(Department).filter(Department.company_id == company_id).all()
        dept_data = []
        for d in departments:
            count = db.session.query(func.count(Employee.id)).filter(
                Employee.department_id == d.id, Employee.status == 'active'
            ).scalar() or 0
            dept_salary = db.session.query(func.sum(Employee.salary)).filter(
                Employee.department_id == d.id, Employee.status == 'active'
            ).scalar() or 0
            dept_revenue = db.session.query(func.sum(FinancialRecord.amount)).filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.department_id == d.id,
                FinancialRecord.transaction_type == 'revenue'
            ).scalar() or 0
            dept_expenses = db.session.query(func.sum(FinancialRecord.amount)).filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.department_id == d.id,
                FinancialRecord.transaction_type == 'expense'
            ).scalar() or 0
            project_budget = db.session.query(func.sum(Project.budget)).filter(
                Project.company_id == company_id, Project.department_id == d.id
            ).scalar() or 0
            project_spent = db.session.query(func.sum(Project.spent)).filter(
                Project.company_id == company_id, Project.department_id == d.id
            ).scalar() or 0
            budget = float(d.budget or 0)
            company_revenue = float(company.annual_revenue or 0)
            budget_is_outlier = budget > 0 and company_revenue > 0 and budget > company_revenue
            dept_data.append({
                'id': d.id,
                'code': d.code or '',
                'name': d.name,
                'headcount': count,
                'payroll': float(dept_salary),
                'budget': budget,
                'recorded_expenses': float(dept_expenses),
                'recorded_revenue': float(dept_revenue),
                'project_budget': float(project_budget),
                'project_spent': float(project_spent),
                'total_recorded_cost': float(dept_salary) + float(dept_expenses),
                'budget_source': 'recorded_department_budget' if budget > 0 else 'not_recorded',
                'budget_status': 'outlier_vs_company_revenue' if budget_is_outlier else ('recorded' if budget > 0 else 'not_recorded'),
                'variance': None if budget_is_outlier else (budget - (float(dept_salary) + float(dept_expenses)) if budget > 0 else None)
            })
        
        # Customers
        total_customers = db.session.query(func.count(Customer.id)).filter(
            Customer.company_id == company_id, Customer.status == 'active'
        ).scalar() or 0
        
        churned = db.session.query(func.count(Customer.id)).filter(
            Customer.company_id == company_id, Customer.is_churned == True
        ).scalar() or 0
        
        profile_customer_count = int(getattr(company, 'customer_count', 0) or 0) if company else 0
        customer_count_source = 'records'
        if total_customers == 0 and profile_customer_count:
            total_customers = profile_customer_count
            customer_count_source = 'company_profile'
        elif total_customers == 0:
            customer_count_source = 'no_data'

        churn_rate = (churned / max(total_customers + churned, 1) * 100) if churned or total_customers else 0
        new_customers_30 = db.session.query(func.count(Customer.id)).filter(
            Customer.company_id == company_id,
            Customer.created_at >= (now - timedelta(days=30))
        ).scalar() or 0
        observed_cac = db.session.query(func.avg(Customer.acquisition_cost)).filter(
            Customer.company_id == company_id,
            Customer.acquisition_cost > 0
        ).scalar() or 0
        observed_ltv = db.session.query(func.avg(Customer.lifetime_value)).filter(
            Customer.company_id == company_id,
            Customer.lifetime_value > 0
        ).scalar() or 0
        
        # Inventory
        inventory_items = Inventory.query.filter_by(company_id=company_id, is_active=True).all()
        total_inventory_value = sum((i.quantity_on_hand or 0) * (i.unit_cost or 0) for i in inventory_items)
        low_stock_count = sum(1 for i in inventory_items if getattr(i, 'is_low_stock', lambda: False)())
        total_skus = len(inventory_items)
        
        # Risks
        risks = Risk.query.filter_by(company_id=company_id).all()
        risk_data = [{
            'id': r.id,
            'name': r.name,
            'category': r.category,
            'description': r.description or '',
            'probability': float(r.probability or 0),
            'impact': float(r.impact or 0),
            'risk_score': float(r.risk_score or 0),
            'risk_level': r.risk_level or '',
            'status': r.status or '',
            'mitigation_plan': r.mitigation_plan or '',
            'review_date': r.review_date.isoformat() if r.review_date else ''
        } for r in risks] if risks else []
        avg_risk_score = sum(r.risk_score for r in risks) / len(risks) if risks else 0
        critical_risks = len([r for r in risks if r.risk_level == 'critical'])
        high_risks = len([r for r in risks if r.risk_level == 'high'])
        
        # Forecasts
        recent_forecasts = Forecast.query.filter_by(company_id=company_id).order_by(
            Forecast.created_at.desc()
        ).limit(5).all()
        forecast_data = []
        forecast_results = []
        for f in recent_forecasts:
            results = ForecastResult.query.filter_by(forecast_id=f.id).order_by(ForecastResult.date).all()
            if results:
                first = results[0].value
                last = results[-1].value
                forecast_data.append({
                    'name': f.name,
                    'type': f.forecast_type,
                    'method': f.method,
                    'horizon': f.horizon_days,
                    'trend': ((last - first) / max(abs(first), 1) * 100),
                    'final_value': last,
                    'status': f.status or '',
                    'schedule': f.schedule or '',
                    'accuracy_mae': f.accuracy_mae,
                    'accuracy_rmse': f.accuracy_rmse,
                    'accuracy_mape': f.accuracy_mape,
                    'accuracy_r2': f.accuracy_r2
                })
                forecast_results.extend([{
                    'forecast_id': f.id,
                    'forecast_name': f.name,
                    'date': result.date.isoformat() if result.date else '',
                    'value': result.value,
                    'lower_bound': result.lower_bound,
                    'upper_bound': result.upper_bound,
                    'actual': result.actual
                } for result in results])
        
        # Simulations
        recent_sims = Simulation.query.filter_by(company_id=company_id).order_by(
            Simulation.created_at.desc()
        ).limit(5).all()
        sim_data = [{
            'name': s.name,
            'type': s.sim_type,
            'revenue_before': s.revenue_before,
            'revenue_after': s.revenue_after,
            'profit_before': s.profit_before,
            'profit_after': s.profit_after,
            'risk_score': s.risk_score
        } for s in recent_sims]

        financial_transactions = FinancialRecord.query.filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_date >= start_365
        ).order_by(FinancialRecord.transaction_date, FinancialRecord.id).all()
        ledger_data = [{
            'date': r.transaction_date.isoformat() if r.transaction_date else '',
            'type': r.transaction_type,
            'category': r.category or '',
            'subcategory': r.subcategory or '',
            'amount': float(r.amount or 0),
            'description': r.description or '',
            'department_id': r.department_id,
            'project_id': r.project_id,
            'recurring': bool(r.is_recurring)
        } for r in financial_transactions]

        customer_data = [{
            'id': c.id,
            'name': c.full_name(),
            'segment': c.segment or '',
            'status': c.status or '',
            'lifetime_value': float(c.lifetime_value or 0),
            'acquisition_cost': float(c.acquisition_cost or 0),
            'total_orders': int(c.total_orders or 0),
            'total_spent': float(c.total_spent or 0),
            'churned': bool(c.is_churned)
        } for c in Customer.query.filter_by(company_id=company_id).order_by(Customer.id).all()]

        inventory_data = [{
            'id': i.id,
            'sku': getattr(i, 'sku', '') or '',
            'name': getattr(i, 'product_name', None) or getattr(i, 'name', '') or '',
            'quantity': float(i.quantity_on_hand or 0),
            'reorder_point': float(getattr(i, 'reorder_point', 0) or 0),
            'unit_cost': float(i.unit_cost or 0),
            'value': float((i.quantity_on_hand or 0) * (i.unit_cost or 0)),
            'low_stock': bool(getattr(i, 'is_low_stock', lambda: False)())
        } for i in inventory_items]

        account_data = [{
            'id': account.id,
            'name': account.account_name,
            'type': account.account_type,
            'category': account.account_category or '',
            'opening_balance': float(account.opening_balance or 0),
            'current_balance': float(account.current_balance or 0),
            'currency': account.currency or '',
            'active': bool(account.is_active)
        } for account in FinancialAccount.query.filter_by(company_id=company_id).order_by(FinancialAccount.id).all()]

        category_totals = {}
        for transaction in ledger_data:
            key = (transaction['type'], transaction['category'] or 'Uncategorized')
            category_totals[key] = category_totals.get(key, 0) + transaction['amount']
        financial_categories = [{
            'type': key[0],
            'category': key[1],
            'amount': amount
        } for key, amount in sorted(category_totals.items())]
        
        # Health score calculation
        health_score = 50
        if margin > 20: health_score += 15
        elif margin > 10: health_score += 5
        elif margin > 0: health_score -= 5
        else: health_score -= 20
        
        if churn_rate < 5: health_score += 15
        elif churn_rate < 10: health_score += 5
        elif churn_rate < 20: health_score -= 5
        else: health_score -= 15
        
        if critical_risks == 0: health_score += 10
        if high_risks == 0: health_score += 5
        if total_employees > 10: health_score += 5
        health_score = min(max(health_score, 0), 100)
        
        # Ratios
        current_ratio = getattr(company, 'current_ratio', 0) or 0
        roe = getattr(company, 'return_on_equity', 0) or 0
        burn_rate = exp_30
        # A runway requires a cash balance, which this schema does not store.
        # Do not present profitability as liquidity runway.
        runway_months = None
        
        return {
            'company': company,
            'company_name': company.company_name if company else 'Business',
            'industry': company.industry if company else 'General',
            'annual_revenue': float(annual_revenue),
            'observed_revenue_365': observed_revenue_365,
            'profile_annual_revenue': profile_annual_revenue,
            'annual_cost': float(annual_cost),
            'profit_30': float(profit_30),
            'profit_365': float(profit_365),
            'margin': float(margin),
            'rev_30': float(rev_30),
            'exp_30': float(exp_30),
            'rev_90': float(rev_90),
            'exp_90': float(exp_90),
            'rev_365': float(rev_365),
            'exp_365': float(exp_365),
            'ledger_days': int(ledger_days),
            'total_employees': total_employees,
            'avg_salary': float(avg_salary),
            'departments': dept_data,
            'total_customers': total_customers,
            'churned_customers': int(churned),
            'churn_rate': float(churn_rate),
            'new_customers_30': new_customers_30,
            'total_inventory_value': float(total_inventory_value),
            'low_stock_count': low_stock_count,
            'total_skus': total_skus,
            'risks': risk_data,
            'avg_risk_score': float(avg_risk_score),
            'critical_risks': critical_risks,
            'high_risks': high_risks,
            'forecasts': forecast_data,
            'forecast_results': forecast_results,
            'simulations': sim_data,
            'ledger': ledger_data,
            'financial_categories': financial_categories,
            'financial_accounts': account_data,
            'customers_detail': customer_data,
            'inventory_detail': inventory_data,
            'health_score': health_score,
            'current_ratio': current_ratio,
            'roe': float(roe),
            'burn_rate': float(burn_rate),
            'runway_months': runway_months,
            'market_cap': float(getattr(company, 'market_cap', 0) or 0) if company else 0,
            'enterprise_value': float(getattr(company, 'enterprise_value', 0) or 0) if company else 0,
            'observed_cac': float(observed_cac),
            'observed_ltv': float(observed_ltv),
            'generated_at': datetime.utcnow().strftime('%B %d, %Y at %H:%M UTC'),
            'currency_symbol': currency_symbol,
            'report_type': report_type,
            'data_quality': {
                'financial_ledger': 'observed' if rev_365 or exp_365 else 'no_data',
                'annual_revenue': annual_revenue_source if annual_revenue else 'no_data',
                'customers': customer_count_source,
                'employees': 'records' if total_employees else 'no_data',
                'salaries': 'records' if avg_salary else 'no_data',
                'departments': 'records' if departments else 'no_data',
                'inventory': 'records' if total_skus else 'no_data',
                'risks': 'records' if risks else 'no_data',
                'runway': 'unavailable_without_cash_balance'
            }
        }

    # ==================== PDF GENERATOR ====================
    
    @staticmethod
    def _generate_pdf(report, company_id, report_type, data):
        config = ReportService.REPORT_TYPE_CONFIG.get(report_type, ReportService.REPORT_TYPE_CONFIG['executive'])
        filename = os.path.join(REPORTS_DIR, f"{report_type}_{report.id}.pdf")
        
        doc = SimpleDocTemplate(filename, pagesize=A4,
                               rightMargin=54, leftMargin=54,
                               topMargin=54, bottomMargin=18)
        
        styles = getSampleStyleSheet()
        
        # Custom styles with Unicode-safe font
        title_style = ParagraphStyle(
            'CustomTitle', parent=styles['Heading1'],
            fontSize=22, textColor=colors.HexColor('#1e293b'),
            spaceAfter=6, alignment=TA_CENTER, fontName=_PDF_FONT_BOLD
        )
        subtitle_style = ParagraphStyle(
            'CustomSubtitle', parent=styles['Normal'],
            fontSize=11, textColor=colors.HexColor('#64748b'),
            alignment=TA_CENTER, spaceAfter=20, fontName=_PDF_FONT
        )
        heading2 = ParagraphStyle(
            'CustomH2', parent=styles['Heading2'],
            fontSize=14, textColor=colors.HexColor('#1e293b'),
            spaceAfter=10, spaceBefore=16, fontName=_PDF_FONT_BOLD,
            borderColor=colors.HexColor('#e2e8f0'), borderWidth=1, borderPadding=5,
            leftIndent=-5, backColor=colors.HexColor('#f8fafc')
        )
        normal = ParagraphStyle(
            'CustomNormal', parent=styles['Normal'],
            fontSize=10, textColor=colors.HexColor('#334155'), leading=14, fontName=_PDF_FONT
        )
        metric_style = ParagraphStyle(
            'Metric', parent=styles['Normal'],
            fontSize=11, textColor=colors.HexColor('#0f172a'), fontName=_PDF_FONT_BOLD
        )
        
        elements = []
        
        # HEADER
        elements.append(Paragraph(f"{data['company_name']}", title_style))
        elements.append(Paragraph(f"{config['title']}", subtitle_style))
        elements.append(Paragraph(f"Generated: {data['generated_at']} &nbsp;|&nbsp; Industry: {data['industry']}", subtitle_style))
        elements.append(Spacer(1, 0.2*inch))
        
        # TYPE-SPECIFIC CONTENT
        if report_type == 'executive':
            ReportService._pdf_executive(elements, data, heading2, normal, metric_style)
        elif report_type == 'board':
            ReportService._pdf_board(elements, data, heading2, normal, metric_style)
        elif report_type == 'investor':
            ReportService._pdf_investor(elements, data, heading2, normal, metric_style)
        elif report_type == 'risk':
            ReportService._pdf_risk(elements, data, heading2, normal, metric_style)
        elif report_type == 'growth':
            ReportService._pdf_growth(elements, data, heading2, normal, metric_style)
        elif report_type == 'forecast':
            ReportService._pdf_forecast(elements, data, heading2, normal, metric_style)
        elif report_type == 'financial':
            ReportService._pdf_financial(elements, data, heading2, normal, metric_style)
        elif report_type == 'operational':
            ReportService._pdf_operational(elements, data, heading2, normal, metric_style)
        elif report_type == 'department':
            ReportService._pdf_department(elements, data, heading2, normal, metric_style)
        else:
            ReportService._pdf_executive(elements, data, heading2, normal, metric_style)
        
        doc.build(elements)
        return filename

    @staticmethod
    def _pdf_table(elements, headers, rows, col_widths=None):
        """Helper to create a styled table."""
        table_data = [headers] + rows
        if not col_widths:
            col_widths = [3*inch] * len(headers)
            if len(headers) == 2:
                col_widths = [3.5*inch, 3.5*inch]
            elif len(headers) == 3:
                col_widths = [2.5*inch, 2.5*inch, 2.5*inch]
            elif len(headers) >= 4:
                total = 7 * inch
                col_widths = [total / len(headers)] * len(headers)
        
        t = Table(table_data, colWidths=col_widths, repeatRows=1)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e293b')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), _PDF_FONT_BOLD),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('TOPPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#ffffff')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
            ('FONTNAME', (0, 1), (-1, -1), _PDF_FONT),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('TEXTCOLOR', (0, 1), (-1, -1), colors.HexColor('#334155')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#ffffff'), colors.HexColor('#f8fafc')]),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ]))
        elements.append(t)
        elements.append(Spacer(1, 0.15*inch))

    @staticmethod
    def _pdf_executive(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Executive Summary", h2))
        elements.append(Paragraph(
            f"This report provides a strategic overview of <b>{data['company_name']}</b>. "
            f"The organization operates in the <b>{data['industry']}</b> sector with an annual revenue run-rate of "
            f"<b>{cs}{data['annual_revenue']:,.0f}</b> and a net margin of <b>{data['margin']:.1f}%</b>. "
            f"Overall organizational health is rated <b>{data['health_score']:.0f}/100</b>.",
            normal
        ))
        elements.append(Spacer(1, 0.1*inch))
        
        ReportService._pdf_table(elements, 
            ['Metric', 'Value'],
            [
                ['Annual Revenue Run-Rate', f"{cs}{data['annual_revenue']:,.0f}"],
                ['Observed Expenses (365d)', f"{cs}{data['annual_cost']:,.0f}"],
                ['Net Profit (LTM)', f"{cs}{data['profit_365']:,.0f}"],
                ['Net Margin', f"{data['margin']:.1f}%"],
                ['Health Score', f"{data['health_score']:.0f}/100"],
                ['Active Employees', f"{data['total_employees']}"],
                ['Active Customers', f"{data['total_customers']}"],
                ['Customer Churn Rate', f"{data['churn_rate']:.1f}%"],
                ['Inventory SKUs', f"{data['total_skus']}"],
                ['Low Stock Alerts', f"{data['low_stock_count']}"],
            ]
        )
        
        elements.append(Paragraph("30-Day Financial Pulse", h2))
        elements.append(Paragraph(
            f"Recent trailing-30-day performance shows revenue of <b>{cs}{data['rev_30']:,.0f}</b> "
            f"against expenses of <b>{cs}{data['exp_30']:,.0f}</b>, yielding a short-term profit of "
            f"<b>{cs}{data['profit_30']:,.0f}</b>.",
            normal
        ))
        elements.append(Spacer(1, 0.1*inch))
        
        ReportService._pdf_table(elements,
            ['Period', 'Revenue', 'Expenses', 'Profit'],
            [
                ['Last 30 Days', f"{cs}{data['rev_30']:,.0f}", f"{cs}{data['exp_30']:,.0f}", f"{cs}{data['profit_30']:,.0f}"],
                ['Last 90 Days', f"{cs}{data['rev_90']:,.0f}", f"{cs}{data['exp_90']:,.0f}", f"{cs}{data['rev_90'] - data['exp_90']:,.0f}"],
                ['Last 12 Months', f"{cs}{data['rev_365']:,.0f}", f"{cs}{data['exp_365']:,.0f}", f"{cs}{data['profit_365']:,.0f}"],
            ],
            [1.8*inch, 1.8*inch, 1.8*inch, 1.8*inch]
        )
        
        elements.append(Paragraph("Strategic Recommendations", h2))
        recs = ReportService._get_recommendations(data, 'executive')
        for rec in recs:
            elements.append(Paragraph(f"• {rec}", normal))
            elements.append(Spacer(1, 0.05*inch))

    @staticmethod
    def _pdf_board(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Governance & Fiduciary Overview", h2))
        elements.append(Paragraph(
            f"Presented to the Board of Directors for <b>{data['company_name']}</b>. "
            f"This document covers financial stewardship, risk oversight, and strategic alignment.",
            normal
        ))
        
        elements.append(Paragraph("Financial Highlights", h2))
        ReportService._pdf_table(elements,
            ['Metric', 'Value', 'Board Note'],
            [
                ['Annual Revenue', f"{cs}{data['annual_revenue']:,.0f}", 'Verify against audited statements'],
                ['Observed Expenses (365d)', f"{cs}{data['annual_cost']:,.0f}", 'Review cost containment policies'],
                ['Net Margin', f"{data['margin']:.1f}%", 'Benchmark vs. industry peers'],
                ['Cash Outflow (30d)', f"{cs}{data['burn_rate']:,.0f}", 'Observed expense ledger'],
                ['Cash Runway', 'Not available', 'Cash balance is not recorded'],
            ],
            [2*inch, 2*inch, 3*inch]
        )
        
        elements.append(Paragraph("Risk Oversight", h2))
        elements.append(Paragraph(
            f"The enterprise currently tracks <b>{len(data['risks'])}</b> active risks with an average score of "
            f"<b>{data['avg_risk_score']:.1f}</b>. Critical risks: <b>{data['critical_risks']}</b>. "
            f"High risks: <b>{data['high_risks']}</b>.",
            normal
        ))
        if data['risks']:
            risk_rows = []
            for r in data['risks'][:8]:
                risk_rows.append([
                    r.get('name', 'Unknown'),
                    r.get('category', 'N/A').replace('_', ' ').title(),
                    f"{r.get('risk_score', 0):.0f}",
                    r.get('risk_level', 'N/A').title()
                ])
            ReportService._pdf_table(elements,
                ['Risk Name', 'Category', 'Score', 'Level'],
                risk_rows,
                [2.5*inch, 2*inch, 1.5*inch, 1.5*inch]
            )
        
        elements.append(Paragraph("Strategic Initiatives", h2))
        sims = data.get('simulations', [])
        if sims:
            for s in sims[:3]:
                rev_impact = (s['revenue_after'] or 0) - (s['revenue_before'] or 0)
                elements.append(Paragraph(
                    f"• <b>{s['name']}</b> ({s['type']}): Revenue impact {rev_impact:+,.0f}, "
                    f"Risk score {s['risk_score']:.0f}",
                    normal
                ))
        else:
            elements.append(Paragraph("• No recent simulations on record. Recommend quarterly scenario planning.", normal))

    @staticmethod
    def _pdf_investor(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Investor Relations Summary", h2))
        elements.append(Paragraph(
            f"<b>{data['company_name']}</b> — Investment performance and growth trajectory for the current fiscal period.",
            normal
        ))
        
        elements.append(Paragraph("Performance Metrics", h2))
        ReportService._pdf_table(elements,
            ['KPI', 'Value', 'Investor Relevance'],
            [
                ['LTM Revenue', f"{cs}{data['rev_365']:,.0f}", 'Top-line growth indicator'],
                ['LTM Profit', f"{cs}{data['profit_365']:,.0f}", 'Bottom-line profitability'],
                ['Net Margin', f"{data['margin']:.1f}%", 'Unit economics efficiency'],
                ['Customer Base', f"{data['total_customers']}", 'Market penetration proxy'],
                ['Monthly Churn', f"{data['churn_rate']:.1f}%", 'Retention & LTV health'],
                ['New Customers (30d)', f"{data['new_customers_30']}", 'Growth velocity signal'],
                ['Return on Equity', f"{data['roe']:.1f}%" if data['roe'] else 'Not available', 'Recorded company metric'],
            ],
            [2*inch, 2*inch, 3*inch]
        )
        
        elements.append(Paragraph("Growth Trajectory", h2))
        if data['forecasts']:
            for f in data['forecasts'][:3]:
                direction = "upward" if f['trend'] > 0 else "downward"
                elements.append(Paragraph(
                    f"• <b>{f['name']}</b> ({f['type']}) projects a <b>{direction}</b> trend of "
                    f"<b>{abs(f['trend']):.1f}%</b> over {f['horizon']} days using {f['method']}.",
                    normal
                ))
        else:
            elements.append(Paragraph("• No active forecasts. Recommend initiating predictive modeling for investor guidance.", normal))
        
        elements.append(Paragraph("Valuation Indicators", h2))
        if data['market_cap'] or data['enterprise_value']:
            elements.append(Paragraph(
                f"Recorded valuation indicators: market capitalization <b>{cs}{data['market_cap']:,.0f}</b>; "
                f"enterprise value <b>{cs}{data['enterprise_value']:,.0f}</b>.",
                normal
            ))
        else:
            elements.append(Paragraph(
                "Valuation is not available because no market capitalization, enterprise value, "
                "or approved valuation model result is recorded.",
                normal
            ))
        
        elements.append(Paragraph("Investor Recommendations", h2))
        for rec in ReportService._get_recommendations(data, 'investor'):
            elements.append(Paragraph(f"• {rec}", normal))
            elements.append(Spacer(1, 0.05*inch))

    @staticmethod
    def _pdf_risk(elements, data, h2, normal, metric):
        elements.append(Paragraph("Enterprise Risk Assessment", h2))
        elements.append(Paragraph(
            f"Comprehensive risk register for <b>{data['company_name']}</b>. "
            f"Aggregate risk exposure: <b>{data['avg_risk_score']:.1f}/100</b>.",
            normal
        ))
        
        elements.append(Paragraph("Risk Distribution", h2))
        ReportService._pdf_table(elements,
            ['Severity', 'Count', 'Threshold', 'Action Required'],
            [
                ['Critical', str(data['critical_risks']), 'Score ≥ 70', 'Immediate board escalation'],
                ['High', str(data['high_risks']), 'Score 40-69', 'Executive mitigation within 30 days'],
                ['Medium', str(len([r for r in data['risks'] if r.get('risk_level') == 'medium'])), 'Score 20-39', 'Manager monitoring quarterly'],
                ['Low', str(len([r for r in data['risks'] if r.get('risk_level') == 'low'])), 'Score < 20', 'Standard controls'],
            ],
            [1.8*inch, 1.2*inch, 1.8*inch, 2.7*inch]
        )
        
        elements.append(Paragraph("Detailed Risk Register", h2))
        if data['risks']:
            risk_rows = []
            for r in data['risks'][:12]:
                risk_rows.append([
                    r.get('name', 'Unknown')[:30],
                    r.get('category', 'N/A').replace('_', ' ').title()[:15],
                    f"{r.get('probability', 0)*100:.0f}%",
                    f"{r.get('impact', 0)*100:.0f}%",
                    f"{r.get('risk_score', 0):.0f}",
                    r.get('risk_level', 'N/A').title()
                ])
            ReportService._pdf_table(elements,
                ['Risk', 'Category', 'Probability', 'Impact', 'Score', 'Level'],
                risk_rows,
                [1.8*inch, 1.3*inch, 1.1*inch, 1*inch, 0.9*inch, 1*inch]
            )
        else:
            elements.append(Paragraph("No risks registered. Recommend immediate risk assessment.", normal))
        
        elements.append(Paragraph("Mitigation Recommendations", h2))
        for rec in ReportService._get_recommendations(data, 'risk'):
            elements.append(Paragraph(f"• {rec}", normal))
            elements.append(Spacer(1, 0.05*inch))

    @staticmethod
    def _pdf_growth(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Growth & Expansion Analysis", h2))
        elements.append(Paragraph(
            f"Growth performance and scaling readiness for <b>{data['company_name']}</b>.",
            normal
        ))
        
        elements.append(Paragraph("Growth KPIs", h2))
        cac = data['observed_cac']
        ltv = data['observed_ltv']
        ReportService._pdf_table(elements,
            ['Growth Metric', 'Value', 'Benchmark'],
            [
                ['New Customers (30d)', str(data['new_customers_30']), 'Target: >5% of base monthly'],
                ['Total Customer Base', str(data['total_customers']), 'Retention-focused growth'],
                ['Churn Rate', f"{data['churn_rate']:.1f}%", 'Best-in-class: <5% annually'],
                ['Observed CAC', f"{cs}{cac:,.0f}" if cac else "Not available", 'Customer acquisition records'],
                ['Observed LTV', f"{cs}{ltv:,.0f}" if ltv else "Not available", 'Customer lifetime value records'],
                ['LTV/CAC Ratio', f"{ltv/cac:.1f}x" if cac and ltv else "Not available", 'Requires both observed metrics'],
                ['Revenue/Employee', f"{cs}{data['annual_revenue']/max(data['total_employees'],1):,.0f}", 'Efficiency indicator'],
            ],
            [2.2*inch, 2.2*inch, 2.8*inch]
        )
        
        elements.append(Paragraph("Expansion Opportunities", h2))
        elements.append(Paragraph(
            f"With <b>{data['total_employees']}</b> employees and <b>{data['total_customers']}</b> customers, "
            f"the organization has a revenue-per-employee ratio of <b>{cs}{data['annual_revenue']/max(data['total_employees'],1):,.0f}</b>. "
            f"Inventory coverage stands at <b>{data['total_skus']}</b> SKUs with "
            f"<b>{data['low_stock_count']}</b> low-stock alerts.",
            normal
        ))
        
        elements.append(Paragraph("Investment Requirements", h2))
        if data['runway_months'] is None:
            elements.append(Paragraph(
                "• <b>Liquidity planning:</b> Cash runway cannot be calculated until a current cash balance is recorded.",
                normal
            ))
        if data['low_stock_count'] > 0:
            elements.append(Paragraph(
                f"• <b>Inventory Investment:</b> {data['low_stock_count']} items require replenishment "
                f"to avoid revenue leakage.", normal
            ))
        if data['churn_rate'] > 10:
            elements.append(Paragraph(
                f"• <b>Retention Investment:</b> Churn rate of {data['churn_rate']:.1f}% suggests "
                f"customer success program funding is needed.", normal
            ))
        if data['runway_months'] is not None and data['runway_months'] >= 6 and data['low_stock_count'] == 0 and data['churn_rate'] <= 10:
            elements.append(Paragraph("• Growth profile is stable. Consider market expansion or product line extension.", normal))

    @staticmethod
    def _pdf_forecast(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Predictive Forecast & Scenario Analysis", h2))
        elements.append(Paragraph(
            f"Forward-looking analysis for <b>{data['company_name']}</b> based on recent trends and model projections.",
            normal
        ))
        
        elements.append(Paragraph("Active Forecasts", h2))
        if data['forecasts']:
            forecast_rows = []
            for f in data['forecasts']:
                direction = "↑ Growth" if f['trend'] > 5 else "↓ Decline" if f['trend'] < -5 else "→ Stable"
                forecast_rows.append([
                    f['name'], f['method'], f"{f['horizon']} days", direction,
                    f"{f['trend']:+.1f}%", f"{cs}{f['final_value']:,.0f}",
                    f"{f['accuracy_mape']:.2f}" if f['accuracy_mape'] is not None else 'Not available'
                ])
            ReportService._pdf_table(
                elements,
                ['Forecast', 'Method', 'Horizon', 'Direction', 'Trend', 'Final Value', 'MAPE'],
                forecast_rows,
                [1.25*inch, .9*inch, .8*inch, .8*inch, .7*inch, 1.1*inch, .8*inch]
            )
        else:
            elements.append(Paragraph("No forecasts available. Generate forecasts in the Forecasting Lab to populate this section.", normal))
        
        elements.append(Paragraph("Scenario Planning", h2))
        sims = data.get('simulations', [])
        if sims:
            for s in sims[:4]:
                rev_impact = (s['revenue_after'] or 0) - (s['revenue_before'] or 0)
                profit_impact = (s['profit_after'] or 0) - (s['profit_before'] or 0)
                elements.append(Paragraph(
                    f"• <b>{s['name']}</b> ({s['type']})<br/>"
                    f"&nbsp;&nbsp;Revenue impact: {rev_impact:+,.0f} | Profit impact: {profit_impact:+,.0f} | Risk: {s['risk_score']:.0f}",
                    normal
                ))
                elements.append(Spacer(1, 0.05*inch))
        else:
            elements.append(Paragraph("No simulation scenarios run. Use the Simulation Center to model 'what-if' situations.", normal))
        
        elements.append(Paragraph("Confidence & Methodology Notes", h2))
        elements.append(Paragraph(
            "Forecasts are generated using statistical models (Prophet, ARIMA, Moving Average) and should be "
            "interpreted with appropriate confidence intervals. Always validate model assumptions against "
            "qualitative market intelligence before making capital allocation decisions.",
            normal
        ))

    @staticmethod
    def _pdf_financial(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Detailed Financial Statement", h2))
        elements.append(Paragraph(
            f"Comprehensive financial analysis for <b>{data['company_name']}</b>. "
            f"All figures in company currency unless otherwise noted.",
            normal
        ))
        
        elements.append(Paragraph("Income Statement (Observed Ledger)", h2))
        ReportService._pdf_table(elements,
            ['Line Item', 'Amount', '% of Revenue'],
            [
                ['Revenue', f"{cs}{data['rev_365']:,.0f}", '100.0%'],
                ['Operating Expenses', f"{cs}{data['exp_365']:,.0f}", f"{(data['exp_365']/max(data['rev_365'],1)*100):.1f}%"],
                ['Net Profit / (Loss)', f"{cs}{data['profit_365']:,.0f}", f"{(data['profit_365']/max(data['rev_365'],1)*100):.1f}%"],
            ],
            [2.5*inch, 2*inch, 2.5*inch]
        )
        
        elements.append(Paragraph("Cash Flow Indicators", h2))
        ReportService._pdf_table(elements,
            ['Indicator', 'Value', 'Assessment'],
            [
                ['Monthly Burn Rate', f"{cs}{data['burn_rate']:,.0f}", 'High' if data['burn_rate'] > data['rev_30'] else 'Moderate' if data['burn_rate'] > data['rev_30']*0.5 else 'Low'],
                ['Cash Runway', 'Not available', 'Cash balance is not recorded'],
                ['Revenue (30d)', f"{cs}{data['rev_30']:,.0f}", 'Current liquidity inflow'],
                ['Expenses (30d)', f"{cs}{data['exp_30']:,.0f}", 'Current liquidity outflow'],
            ],
            [2.2*inch, 2.2*inch, 2.8*inch]
        )
        
        elements.append(Paragraph("Financial Ratios", h2))
        ReportService._pdf_table(elements,
            ['Ratio', 'Value', 'Interpretation'],
            [
                ['Net Margin', f"{data['margin']:.1f}%", 'Strong' if data['margin'] > 20 else 'Average' if data['margin'] > 10 else 'Weak'],
                ['Return on Equity', f"{data['roe']:.1f}%" if data['roe'] else 'Not available', 'Recorded company metric'],
                ['Revenue per Employee', f"{cs}{data['annual_revenue']/max(data['total_employees'],1):,.0f}", 'Efficiency benchmark'],
                ['Cost Ratio', f"{(data['annual_cost']/max(data['annual_revenue'],1)*100):.1f}%", 'Lower is better'],
            ],
            [2.2*inch, 2.2*inch, 2.8*inch]
        )

        if data.get('financial_accounts'):
            elements.append(Paragraph("Recorded Account Balances", h2))
            ReportService._pdf_table(
                elements,
                ['Account', 'Type', 'Opening', 'Current', 'Currency'],
                [[
                    account['name'], account['type'],
                    f"{cs}{account['opening_balance']:,.0f}",
                    f"{cs}{account['current_balance']:,.0f}",
                    account['currency']
                ] for account in data['financial_accounts']],
                [1.8*inch, 1.2*inch, 1.4*inch, 1.4*inch, 1*inch]
            )
        
        elements.append(Paragraph("Financial Recommendations", h2))
        for rec in ReportService._get_recommendations(data, 'financial'):
            elements.append(Paragraph(f"• {rec}", normal))
            elements.append(Spacer(1, 0.05*inch))

    @staticmethod
    def _pdf_operational(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Operational Efficiency Report", h2))
        elements.append(Paragraph(
            f"Process, supply chain, and capacity metrics for <b>{data['company_name']}</b>.",
            normal
        ))
        
        elements.append(Paragraph("Workforce & Capacity", h2))
        ReportService._pdf_table(elements,
            ['Metric', 'Value', 'Status'],
            [
                ['Total Employees', str(data['total_employees']), 'Active headcount'],
                ['Average Salary', f"{cs}{data['avg_salary']:,.0f}" if data['avg_salary'] else 'Not available', 'Observed employee salary records'],
                ['Annual Payroll', f"{cs}{data['avg_salary'] * data['total_employees']:,.0f}" if data['avg_salary'] else 'Not available', 'Observed salaries only'],
                ['Revenue per Employee', f"{cs}{data['annual_revenue']/max(data['total_employees'],1):,.0f}" if data['total_employees'] else 'Not available', 'Productivity indicator'],
            ],
            [2.2*inch, 2.2*inch, 2.8*inch]
        )
        
        elements.append(Paragraph("Inventory & Supply Chain", h2))
        stock_health = "Healthy" if data['low_stock_count'] == 0 else "Attention Needed" if data['low_stock_count'] < 5 else "Critical"
        ReportService._pdf_table(elements,
            ['Metric', 'Value', 'Status'],
            [
                ['Total SKUs', str(data['total_skus']), 'Product breadth'],
                ['Inventory Value', f"{cs}{data['total_inventory_value']:,.0f}", 'Working capital tied'],
                ['Low Stock Items', str(data['low_stock_count']), stock_health],
                ['Inventory/Revenue Ratio', f"{(data['total_inventory_value']/max(data['annual_revenue'],1)*100):.1f}%", 'Capital efficiency'],
            ],
            [2.2*inch, 2.2*inch, 2.8*inch]
        )
        
        elements.append(Paragraph("Operational Recommendations", h2))
        for rec in ReportService._get_recommendations(data, 'operational'):
            elements.append(Paragraph(f"• {rec}", normal))
            elements.append(Spacer(1, 0.05*inch))

    @staticmethod
    def _pdf_department(elements, data, h2, normal, metric):
        cs = _pdf_currency_symbol(data)
        elements.append(Paragraph("Departmental Performance Report", h2))
        elements.append(Paragraph(
            f"Team-level breakdown for <b>{data['company_name']}</b> across all active departments.",
            normal
        ))
        
        elements.append(Paragraph("Department Summary", h2))
        if data['departments']:
            dept_rows = []
            for d in data['departments']:
                variance = d['variance']
                variance_pct = (
                    variance / d['budget'] * 100
                    if variance is not None and d['budget'] else None
                )
                dept_rows.append([
                    d['name'],
                    str(d['headcount']),
                    f"{cs}{d['payroll']:,.0f}",
                    f"{cs}{d['recorded_revenue']:,.0f}",
                    f"{cs}{d['recorded_expenses']:,.0f}",
                    f"{cs}{d['budget']:,.0f}" if d['budget'] else 'Not recorded',
                    f"{cs}{variance:,.0f}" if variance is not None else 'Validate source',
                    f"{variance_pct:+.1f}%" if variance_pct is not None else 'Not available'
                ])
            ReportService._pdf_table(elements,
                ['Department', 'Headcount', 'Payroll', f'Revenue ({cs})', f'Expenses ({cs})', f'Budget ({cs})', f'Variance ({cs})', 'Variance (%)'],
                dept_rows,
                [1.25*inch, .7*inch, 1*inch, 1*inch, 1*inch, 1*inch, 1*inch, .9*inch]
            )
        else:
            elements.append(Paragraph("No department data available. Configure departments in Settings.", normal))
        
        elements.append(Paragraph("Salary Distribution", h2))
        elements.append(Paragraph(
            f"Company-wide average salary is "
            f"<b>{cs}{data['avg_salary']:,.0f}</b> based on observed salary records."
            if data['avg_salary'] else
            "Salary and payroll analysis is unavailable because no employee salary records are recorded.",
            normal
        ))
        
        elements.append(Paragraph("Department Recommendations", h2))
        for rec in ReportService._get_recommendations(data, 'department'):
            elements.append(Paragraph(f"• {rec}", normal))
            elements.append(Spacer(1, 0.05*inch))

    @staticmethod
    def _get_recommendations(data, report_type):
        """Generate contextual recommendations based on report type and data."""
        cs = _pdf_currency_symbol(data)
        recs = []
        
        if report_type in ('executive', 'financial'):
            if data['margin'] < 10:
                recs.append("URGENT: Net margin is below 10%. Immediate cost review and pricing optimization required.")
            elif data['margin'] < 20:
                recs.append("Net margin is moderate. Explore vendor renegotiation and automation to improve.")
            else:
                recs.append("Strong margin profile. Consider reinvesting in R&D or market expansion.")
            
            if data['runway_months'] is None:
                recs.append("Liquidity runway is not assessed because the current cash balance is not recorded.")
            if data['churn_rate'] > 10:
                recs.append(f"Customer churn at {data['churn_rate']:.1f}% is eroding growth. Launch retention program.")
            if data['low_stock_count'] > 3:
                recs.append(f"{data['low_stock_count']} inventory items are low. Adjust reorder points to prevent lost sales.")
        
        if report_type in ('executive', 'operational'):
            if data['total_employees'] < 10:
                recs.append("Team size is lean. Document key processes to reduce single-point-of-failure risk.")
            if data['annual_revenue'] / max(data['total_employees'], 1) < 100000:
                recs.append(f"Revenue per employee is below {cs}100K. Evaluate automation or sales training investments.")
        
        if report_type == 'investor':
            if data['churn_rate'] > 5:
                recs.append("Investor Note: Churn above 5% may compress LTV/CAC multiples. Prioritize retention.")
            if data['margin'] > 25:
                recs.append("Investor Positive: Strong margins support premium valuation multiples.")
            if data['new_customers_30'] < data['total_customers'] * 0.02:
                recs.append("Investor Concern: Customer acquisition velocity is low. Review go-to-market spend.")
        
        if report_type == 'risk':
            if data['critical_risks'] > 0:
                recs.append(f"CRITICAL: {data['critical_risks']} risks require immediate mitigation. Assign owners and deadlines.")
            if data['high_risks'] > 3:
                recs.append(f"High risk volume ({data['high_risks']}) suggests systemic exposure. Conduct enterprise risk audit.")
            if not data['risks']:
                recs.append("No risks registered. This is a blind spot. Complete full risk register immediately.")
        
        if report_type == 'growth':
            if data['new_customers_30'] == 0:
                recs.append("No new customers in 30 days. Activate acquisition channels or review sales funnel.")
            if data['churn_rate'] > data['new_customers_30'] / max(data['total_customers'], 1) * 100:
                recs.append("Churn is outpacing acquisition. Net customer base is contracting. Reverse immediately.")
            if data['total_skus'] < 5 and data['annual_revenue'] > 500000:
                recs.append("Revenue concentration risk: Low SKU count with high revenue. Diversify product line.")
        
        if report_type == 'department':
            for d in data['departments']:
                if d['budget_status'] == 'outlier_vs_company_revenue':
                    recs.append(
                        f"{d['name']}: recorded budget exceeds company profile revenue; "
                        "validate the budget source before using variance for planning."
                    )
                elif d['budget'] > 0:
                    variance = (d['total_recorded_cost'] - d['budget']) / d['budget'] * 100
                    if variance > 10:
                        recs.append(f"{d['name']}: Over budget by {variance:.1f}%. Freeze non-essential hiring.")
                    elif variance < -15:
                        recs.append(f"{d['name']}: Recorded cost is {abs(variance):.1f}% below budget. Verify the budget and expense coverage.")
            if not data['departments']:
                recs.append("Department structure not defined. Configure departments and budgets for accurate tracking.")
        
        if not recs:
            recs.append("Maintain current trajectory. Schedule next review in 30 days.")
        
        return recs

    # ==================== EXCEL GENERATOR ====================
    
    @staticmethod
    def _generate_excel(report, company_id, report_type, data):
        if not _OPENPYXL_AVAILABLE:
            return ReportService._generate_csv(report, company_id, report_type, data)
        
        config = ReportService.REPORT_TYPE_CONFIG.get(report_type, ReportService.REPORT_TYPE_CONFIG['executive'])
        filename = os.path.join(REPORTS_DIR, f"{report_type}_{report.id}.xlsx")
        
        wb = Workbook()
        
        # Remove default sheet and create type-specific sheets
        wb.remove(wb.active)
        
        # Sheet 1: Overview
        ws = wb.create_sheet("Overview")
        ReportService._excel_overview(ws, data, config)
        
        # Sheet 2: Type-specific data
        if report_type == 'executive':
            ws2 = wb.create_sheet("Financials")
            ReportService._excel_financials(ws2, data)
            ws3 = wb.create_sheet("Health Metrics")
            ReportService._excel_health(ws3, data)
        elif report_type == 'board':
            ws2 = wb.create_sheet("Governance")
            ReportService._excel_governance(ws2, data)
            ws3 = wb.create_sheet("Risk Oversight")
            ReportService._excel_risk_oversight(ws3, data)
        elif report_type == 'investor':
            ws2 = wb.create_sheet("Performance")
            ReportService._excel_investor_performance(ws2, data)
            ws3 = wb.create_sheet("Forecasts")
            ReportService._excel_forecasts(ws3, data)
        elif report_type == 'risk':
            ws2 = wb.create_sheet("Risk Register")
            ReportService._excel_risk_register(ws2, data)
            ws3 = wb.create_sheet("Mitigation")
            ReportService._excel_mitigation(ws3, data)
        elif report_type == 'growth':
            ws2 = wb.create_sheet("Growth KPIs")
            ReportService._excel_growth_kpis(ws2, data)
            ws3 = wb.create_sheet("Customer Analytics")
            ReportService._excel_customers(ws3, data)
        elif report_type == 'forecast':
            ws2 = wb.create_sheet("Forecasts")
            ReportService._excel_forecasts(ws2, data)
            ws3 = wb.create_sheet("Scenarios")
            ReportService._excel_scenarios(ws3, data)
        elif report_type == 'financial':
            ws2 = wb.create_sheet("Income Statement")
            ReportService._excel_income_statement(ws2, data)
            ws3 = wb.create_sheet("Ratios")
            ReportService._excel_ratios(ws3, data)
        elif report_type == 'operational':
            ws2 = wb.create_sheet("Operations")
            ReportService._excel_operations(ws2, data)
            ws3 = wb.create_sheet("Inventory")
            ReportService._excel_inventory(ws3, data)
        elif report_type == 'department':
            ws2 = wb.create_sheet("Department Performance")
            ReportService._excel_departments(ws2, data)
            ws3 = wb.create_sheet("Department Financials")
            ReportService._excel_department_financials(ws3, data)
            ws4 = wb.create_sheet("Department Employees")
            ReportService._excel_department_employees(ws4, data)
            ws5 = wb.create_sheet("Department Projects")
            ReportService._excel_department_projects(ws5, data)
        else:
            ws2 = wb.create_sheet("Details")
            ReportService._excel_financials(ws2, data)
            ws3 = wb.create_sheet("Health")
            ReportService._excel_health(ws3, data)

        ws_detail = wb.create_sheet("Detailed Analysis")
        ReportService._excel_type_detail(ws_detail, data, report_type)
        
        # Sheet 4: Recommendations (all types)
        ws4 = wb.create_sheet("Recommendations")
        ReportService._excel_recommendations(ws4, data, report_type)
        ws5 = wb.create_sheet("Data Quality")
        ReportService._excel_data_quality(ws5, data)
        ws6 = wb.create_sheet("Source Ledger")
        ReportService._excel_ledger(ws6, data)
        ws7 = wb.create_sheet("Entity Detail")
        ReportService._excel_entity_detail(ws7, data)
        
        wb.save(filename)
        return filename

    @staticmethod
    def _excel_style_header(cell):
        cell.font = Font(bold=True, color='FFFFFF', size=11)
        cell.fill = PatternFill(start_color='1e293b', end_color='1e293b', fill_type='solid')
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = Border(
            bottom=Side(style='thin', color='334155')
        )

    @staticmethod
    def _excel_style_data(cell, is_currency=False, is_percent=False, currency_symbol='$'):
        cell.font = Font(size=10, color='334155')
        cell.alignment = Alignment(horizontal='center' if not is_currency else 'right', vertical='center')
        if is_currency:
            cell.number_format = f'{currency_symbol}#,##0'
        elif is_percent:
            cell.number_format = '0.0%'

    @staticmethod
    def _excel_overview(ws, data, config):
        cs = data.get('currency_symbol', '$')
        ws.append([config['title']])
        ws.append([f"Report Type: {data['report_type']}"])
        ws.append([f"Company: {data['company_name']}"])
        ws.append([f"Industry: {data['industry']}"])
        ws.append([f"Generated: {data['generated_at']}"])
        ws.append([])
        ws.append(['Metric', 'Value'])
        ws.append(['Annual Revenue', data['annual_revenue']])
        ws.append(['Observed Expenses (365d)', data['annual_cost']])
        ws.append(['Net Profit (LTM)', data['profit_365']])
        ws.append(['Net Margin', data['margin'] / 100])
        ws.append(['Health Score', data['health_score']])
        ws.append(['Employees', data['total_employees']])
        ws.append(['Customers', data['total_customers']])
        ws.append(['Churn Rate', data['churn_rate'] / 100])
        ws.append(['Inventory Value', data['total_inventory_value']])
        
        # Style
        for cell in ws[1]:
            cell.font = Font(bold=True, size=16, color='1e293b')
        for cell in ws[7]:
            ReportService._excel_style_header(cell)
        for row in ws.iter_rows(min_row=8, max_row=ws.max_row):
            ReportService._excel_style_data(row[0])
            if row[1].value and isinstance(row[1].value, (int, float)):
                if 'Margin' in str(row[0].value) or 'Rate' in str(row[0].value):
                    row[1].number_format = '0.0%'
                    row[1].value = row[1].value / 100 if row[1].value > 1 else row[1].value
                else:
                    row[1].number_format = f'{cs}#,##0'
        
        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 20

    @staticmethod
    def _excel_financials(ws, data):
        cs = data.get('currency_symbol', '$')
        ws.append(['Period', 'Revenue', 'Expenses', 'Profit'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Last 30 Days', data['rev_30'], data['exp_30'], data['profit_30']])
        ws.append(['Last 90 Days', data['rev_90'], data['exp_90'], data['rev_90'] - data['exp_90']])
        ws.append(['Last 12 Months', data['rev_365'], data['exp_365'], data['profit_365']])
        for row in ws.iter_rows(min_row=2):
            for cell in row[1:]:
                cell.number_format = f'{cs}#,##0'
        ws.column_dimensions['A'].width = 20
        for col in ['B', 'C', 'D']:
            ws.column_dimensions[col].width = 18

    @staticmethod
    def _excel_health(ws, data):
        ws.append(['Health Indicator', 'Score', 'Status'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        score = data['health_score']
        status = 'Excellent' if score >= 80 else 'Good' if score >= 60 else 'Fair' if score >= 40 else 'Poor'
        ws.append(['Overall Health', score, status])
        ws.append(['Margin Health', data['margin'] / 100, 'Strong' if data['margin'] > 20 else 'Moderate' if data['margin'] > 10 else 'Weak'])
        ws.append(['Liquidity Health', data['runway_months'], 'Not available without cash balance'])
        ws.append(['Retention Health', 100 - data['churn_rate'], 'Strong' if data['churn_rate'] < 5 else 'Moderate' if data['churn_rate'] < 15 else 'Weak'])

    @staticmethod
    def _excel_governance(ws, data):
        ws.append(['Governance Item', 'Value', 'Board Action'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Annual Revenue', data['annual_revenue'], 'Verify against audit'])
        ws.append(['Observed Expenses (365d)', data['annual_cost'], 'Review cost policies'])
        ws.append(['Net Margin', data['margin'] / 100, 'Benchmark vs peers'])
        ws.append(['Cash Burn', data['burn_rate'], 'Assess runway'])
        ws.append(['Runway (months)', data['runway_months'], 'Not available without cash balance'])

    @staticmethod
    def _excel_risk_oversight(ws, data):
        ws.append(['Risk Level', 'Count', 'Action Required'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Critical', data['critical_risks'], 'Immediate escalation'])
        ws.append(['High', data['high_risks'], 'Mitigate within 30 days'])
        medium = len([r for r in data['risks'] if r.get('risk_level') == 'medium'])
        low = len([r for r in data['risks'] if r.get('risk_level') == 'low'])
        ws.append(['Medium', medium, 'Quarterly review'])
        ws.append(['Low', low, 'Standard controls'])

    @staticmethod
    def _excel_investor_performance(ws, data):
        ws.append(['KPI', 'Value', 'Benchmark'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['LTM Revenue', data['rev_365'], 'YoY growth target'])
        ws.append(['LTM Profit', data['profit_365'], 'Bottom-line target'])
        ws.append(['Net Margin', data['margin'] / 100, 'Industry avg 15-20%'])
        ws.append(['Customer Base', data['total_customers'], 'Retention focus'])
        ws.append(['Churn Rate', data['churn_rate'] / 100, 'Target <5%'])
        ws.append(['New Customers (30d)', data['new_customers_30'], 'Growth velocity'])

    @staticmethod
    def _excel_forecasts(ws, data):
        ws.append(['Forecast Name', 'Type', 'Method', 'Horizon', 'Trend %', 'Final Value'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        for f in data['forecasts']:
            ws.append([f['name'], f['type'], f['method'], f['horizon'], f['trend'] / 100, f['final_value']])

    @staticmethod
    def _excel_scenarios(ws, data):
        ws.append(['Scenario Name', 'Type', 'Revenue Before', 'Revenue After', 'Revenue Impact', 'Profit Before', 'Profit After', 'Profit Impact', 'Risk Score'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        for scenario in data['simulations']:
            revenue_before = float(scenario['revenue_before'] or 0)
            revenue_after = float(scenario['revenue_after'] or 0)
            profit_before = float(scenario['profit_before'] or 0)
            profit_after = float(scenario['profit_after'] or 0)
            ws.append([
                scenario['name'], scenario['type'], revenue_before, revenue_after,
                revenue_after - revenue_before, profit_before, profit_after,
                profit_after - profit_before, scenario['risk_score']
            ])

    @staticmethod
    def _excel_risk_register(ws, data):
        ws.append(['Risk Name', 'Category', 'Probability', 'Impact', 'Score', 'Level'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        for r in data['risks'][:20]:
            ws.append([
                r.get('name', 'Unknown'),
                r.get('category', 'N/A').replace('_', ' ').title(),
                r.get('probability', 0),
                r.get('impact', 0),
                r.get('risk_score', 0),
                r.get('risk_level', 'N/A').title()
            ])

    @staticmethod
    def _excel_mitigation(ws, data):
        ws.append(['Priority', 'Risk Count', 'Recommended Action'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Critical', data['critical_risks'], 'Board-level intervention required'])
        ws.append(['High', data['high_risks'], 'Executive ownership within 30 days'])
        ws.append(['Process', 'All', 'Implement quarterly risk review cycle'])

    @staticmethod
    def _excel_growth_kpis(ws, data):
        cac = data['observed_cac']
        ltv = data['observed_ltv']
        ws.append(['Growth Metric', 'Value', 'Target'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['New Customers (30d)', data['new_customers_30'], '>5% of base monthly'])
        ws.append(['Total Customers', data['total_customers'], 'Retention-focused'])
        ws.append(['Churn Rate', data['churn_rate'] / 100, '<5% annually'])
        ws.append(['Observed CAC', cac or None, 'Requires acquisition cost records'])
        ws.append(['Observed LTV', ltv or None, 'Requires lifetime value records'])
        ws.append(['LTV/CAC', ltv / cac if cac and ltv else None, 'Requires both observed metrics'])
        ws.append(['Revenue/Employee', data['annual_revenue'] / max(data['total_employees'], 1), '>100K'])

    @staticmethod
    def _excel_customers(ws, data):
        ws.append(['Customer Metric', 'Value'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Total Active', data['total_customers']])
        ws.append(['Churned', data['churned_customers']])
        ws.append(['New (30d)', data['new_customers_30']])
        ws.append(['Revenue per Customer', data['annual_revenue'] / max(data['total_customers'], 1)])

    @staticmethod
    def _excel_income_statement(ws, data):
        ws.append(['Line Item', 'Amount', '% of Revenue'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Revenue', data['rev_365'], 1.0])
        ws.append(['Operating Expenses', data['exp_365'], data['exp_365'] / max(data['rev_365'], 1)])
        ws.append(['Net Profit / (Loss)', data['profit_365'], data['profit_365'] / max(data['rev_365'], 1)])

    @staticmethod
    def _excel_ratios(ws, data):
        ws.append(['Ratio', 'Value', 'Assessment'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Net Margin', data['margin'] / 100, 'Strong' if data['margin'] > 20 else 'Average' if data['margin'] > 10 else 'Weak'])
        ws.append(['Return on Equity', data['roe'] / 100 if data['roe'] else None, 'Recorded company metric' if data['roe'] else 'Not available'])
        ws.append(['Revenue per Employee', data['annual_revenue'] / max(data['total_employees'], 1), 'Efficiency'])
        ws.append(['Cost Ratio', data['annual_cost'] / max(data['annual_revenue'], 1), 'Lower is better'])

    @staticmethod
    def _excel_operations(ws, data):
        ws.append(['Operational Metric', 'Value', 'Note'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Total Employees', data['total_employees'], 'Active headcount'])
        ws.append(['Avg Salary', data['avg_salary'], 'Compensation benchmark'])
        ws.append(['Annual Payroll', data['avg_salary'] * data['total_employees'] if data['avg_salary'] else None, 'Observed salaries only'])
        ws.append(['Revenue per Employee', data['annual_revenue'] / max(data['total_employees'], 1), 'Productivity'])

    @staticmethod
    def _excel_inventory(ws, data):
        ws.append(['Inventory Metric', 'Value', 'Status'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        status = 'Healthy' if data['low_stock_count'] == 0 else 'Attention' if data['low_stock_count'] < 5 else 'Critical'
        ws.append(['Total SKUs', data['total_skus'], 'Product breadth'])
        ws.append(['Inventory Value', data['total_inventory_value'], 'Working capital'])
        ws.append(['Low Stock Items', data['low_stock_count'], status])
        ws.append(['Inventory/Revenue', data['total_inventory_value'] / max(data['annual_revenue'], 1), 'Capital efficiency'])

    @staticmethod
    def _excel_departments(ws, data):
        ws.append([
            'Department ID', 'Code', 'Department', 'Headcount', 'Payroll',
            'Recorded Revenue', 'Recorded Expenses', 'Recorded Cost',
            'Department Budget', 'Budget Source', 'Budget Status', 'Variance', 'Utilization %',
            'Project Budget', 'Project Spent'
        ])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        for d in data['departments']:
            utilization = (
                d['total_recorded_cost'] / d['budget']
                if d['budget'] > 0 and d['budget_status'] != 'outlier_vs_company_revenue'
                else None
            )
            ws.append([
                d['id'], d['code'], d['name'], d['headcount'], d['payroll'],
                d['recorded_revenue'], d['recorded_expenses'], d['total_recorded_cost'],
                d['budget'], d['budget_source'], d['budget_status'], d['variance'], utilization,
                d['project_budget'], d['project_spent']
            ])
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        for column in ws.columns:
            letter = column[0].column_letter
            ws.column_dimensions[letter].width = min(max(max(len(str(cell.value or '')) for cell in column) + 2, 12), 28)

    @staticmethod
    def _excel_department_financials(ws, data):
        ws.append(['Department', 'Recorded Revenue', 'Recorded Expenses', 'Payroll', 'Recorded Cost', 'Net Contribution', 'Revenue/Cost'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        for d in data['departments']:
            cost = d['total_recorded_cost']
            ws.append([
                d['name'], d['recorded_revenue'], d['recorded_expenses'], d['payroll'],
                cost, d['recorded_revenue'] - cost if d['recorded_revenue'] else None,
                d['recorded_revenue'] / cost if cost else None
            ])
        ws.freeze_panes = 'A2'

    @staticmethod
    def _excel_department_employees(ws, data):
        from database.models.employee import Employee
        ws.append(['Employee ID', 'Name', 'Department', 'Role', 'Status', 'Salary', 'Hire Date'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        employees = Employee.query.filter_by(company_id=data['company'].id).order_by(Employee.department_id, Employee.id).all()
        for employee in employees:
            department = employee.department.name if employee.department else ''
            ws.append([
                employee.id,
                employee.full_name() if hasattr(employee, 'full_name') else f"{employee.first_name or ''} {employee.last_name or ''}".strip(),
                department,
                getattr(employee, 'position', '') or getattr(employee, 'job_title', '') or '',
                employee.status or '',
                employee.salary,
                employee.hire_date.isoformat() if getattr(employee, 'hire_date', None) else ''
            ])
        ws.freeze_panes = 'A2'

    @staticmethod
    def _excel_department_projects(ws, data):
        from database.models.project import Project
        department_names = {d['id']: d['name'] for d in data['departments']}
        ws.append(['Project ID', 'Project', 'Department', 'Status', 'Priority', 'Budget', 'Spent', 'Variance', 'Progress %'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        projects = Project.query.filter_by(company_id=data['company'].id).order_by(Project.department_id, Project.id).all()
        for project in projects:
            budget = float(project.budget or 0)
            spent = float(project.spent or 0)
            ws.append([
                project.id, project.name, department_names.get(project.department_id, ''),
                project.status or '', project.priority or '', budget, spent, budget - spent,
                project.progress
            ])
        ws.freeze_panes = 'A2'

    @staticmethod
    def _excel_type_detail(ws, data, report_type):
        """Write the complete report-specific evidence set used by every export."""
        cs = data.get('currency_symbol', '$')

        def section(title, headers, rows):
            ws.append([title])
            ws.append(headers)
            for cell in ws[ws.max_row]:
                ReportService._excel_style_header(cell)
            for row in rows:
                ws.append(row)
            ws.append([])

        if report_type in ('executive', 'board'):
            section('Executive Financial Evidence',
                    ['Period', 'Revenue', 'Expenses', 'Profit', 'Margin'],
                    [
                        ['30 days', data['rev_30'], data['exp_30'], data['profit_30'],
                         data['profit_30'] / data['rev_30'] if data['rev_30'] else None],
                        ['90 days', data['rev_90'], data['exp_90'], data['rev_90'] - data['exp_90'],
                         (data['rev_90'] - data['exp_90']) / data['rev_90'] if data['rev_90'] else None],
                        ['365 days', data['rev_365'], data['exp_365'], data['profit_365'],
                         data['profit_365'] / data['rev_365'] if data['rev_365'] else None],
                    ])
            section('Risk Oversight Evidence',
                    ['Risk', 'Category', 'Probability', 'Impact', 'Score', 'Level', 'Status', 'Mitigation'],
                    [[r['name'], r['category'], r['probability'], r['impact'], r['risk_score'],
                      r['risk_level'], r['status'], r['mitigation_plan']] for r in data['risks']])
        elif report_type == 'investor':
            section('Investor Unit Economics',
                    ['Metric', 'Value', 'Source'],
                    [
                        ['Observed CAC', data['observed_cac'] or None, 'Customer acquisition_cost records'],
                        ['Observed LTV', data['observed_ltv'] or None, 'Customer lifetime_value records'],
                        ['LTV/CAC', data['observed_ltv'] / data['observed_cac']
                         if data['observed_ltv'] and data['observed_cac'] else None, 'Observed values only'],
                        ['Market Capitalization', data['market_cap'] or None, 'Company profile'],
                        ['Enterprise Value', data['enterprise_value'] or None, 'Company profile'],
                        ['Return on Equity', data['roe'] or None, 'Company profile'],
                    ])
            section('Investor Forecast Evidence',
                    ['Forecast', 'Method', 'Horizon', 'Trend %', 'Final Value', 'MAPE', 'R2'],
                    [[f['name'], f['method'], f['horizon'], f['trend'] / 100, f['final_value'],
                      f['accuracy_mape'], f['accuracy_r2']] for f in data['forecasts']])
        elif report_type == 'risk':
            section('Complete Risk Register',
                    ['ID', 'Risk', 'Category', 'Description', 'Probability', 'Impact', 'Score', 'Level', 'Status', 'Review Date', 'Mitigation'],
                    [[r['id'], r['name'], r['category'], r['description'], r['probability'], r['impact'],
                      r['risk_score'], r['risk_level'], r['status'], r['review_date'], r['mitigation_plan']]
                     for r in data['risks']])
        elif report_type == 'growth':
            section('Growth Cohort Evidence',
                    ['Customer ID', 'Customer', 'Segment', 'Status', 'Created/Observed', 'LTV', 'CAC', 'Orders', 'Total Spent', 'Churned'],
                    [[c['id'], c['name'], c['segment'], c['status'], '', c['lifetime_value'],
                      c['acquisition_cost'], c['total_orders'], c['total_spent'], c['churned']]
                     for c in data['customers_detail']])
        elif report_type == 'forecast':
            section('Forecast Model Evidence',
                    ['Forecast', 'Date', 'Forecast Value', 'Lower Bound', 'Upper Bound', 'Actual'],
                    [[r['forecast_name'], r['date'], r['value'], r['lower_bound'], r['upper_bound'], r['actual']]
                     for r in data['forecast_results']])
            section('Scenario Evidence',
                    ['Scenario', 'Type', 'Revenue Before', 'Revenue After', 'Profit Before', 'Profit After', 'Risk Score'],
                    [[s['name'], s['type'], s['revenue_before'], s['revenue_after'],
                      s['profit_before'], s['profit_after'], s['risk_score']] for s in data['simulations']])
        elif report_type == 'financial':
            section('Income Statement Evidence',
                    ['Line Item', 'Amount', '% of Revenue', 'Source'],
                    [
                        ['Revenue', data['rev_365'], 1 if data['rev_365'] else None, 'FinancialRecord revenue'],
                        ['Expenses', data['exp_365'], data['exp_365'] / data['rev_365'] if data['rev_365'] else None, 'FinancialRecord expense'],
                        ['Net Profit/(Loss)', data['profit_365'], data['profit_365'] / data['rev_365'] if data['rev_365'] else None, 'Calculated from ledger'],
                    ])
            section('Account Balances',
                    ['Account ID', 'Account', 'Type', 'Category', 'Opening Balance', 'Current Balance', 'Currency', 'Active'],
                    [[a['id'], a['name'], a['type'], a['category'], a['opening_balance'], a['current_balance'],
                      a['currency'], a['active']] for a in data['financial_accounts']])
            section('Ledger Category Totals',
                    ['Transaction Type', 'Category', 'Amount'],
                    [[c['type'], c['category'], c['amount']] for c in data['financial_categories']])
        elif report_type == 'operational':
            section('Operational Workforce',
                    ['Department', 'Headcount', 'Payroll', 'Recorded Revenue', 'Recorded Expenses', 'Recorded Cost'],
                    [[d['name'], d['headcount'], d['payroll'], d['recorded_revenue'],
                      d['recorded_expenses'], d['total_recorded_cost']] for d in data['departments']])
            section('Inventory Evidence',
                    ['ID', 'SKU', 'Item', 'Quantity', 'Reorder Point', 'Unit Cost', 'Value', 'Low Stock'],
                    [[i['id'], i['sku'], i['name'], i['quantity'], i['reorder_point'],
                      i['unit_cost'], i['value'], i['low_stock']] for i in data['inventory_detail']])
        elif report_type == 'department':
            section('Department Evidence',
                    ['ID', 'Code', 'Department', 'Headcount', 'Payroll', 'Revenue', 'Expenses', 'Recorded Cost',
                     'Budget', 'Budget Source', 'Budget Status', 'Variance', 'Project Budget', 'Project Spent'],
                    [[d['id'], d['code'], d['name'], d['headcount'], d['payroll'], d['recorded_revenue'],
                      d['recorded_expenses'], d['total_recorded_cost'], d['budget'], d['budget_source'],
                      d['budget_status'], d['variance'], d['project_budget'], d['project_spent']]
                     for d in data['departments']])

        section('Report Provenance',
                ['Domain', 'Status', 'Detail'],
                [[domain, status, data['data_quality'].get(domain, '')]
                 for domain, status in data['data_quality'].items()])
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        for column in ws.columns:
            letter = column[0].column_letter
            ws.column_dimensions[letter].width = min(
                max(max(len(str(cell.value or '')) for cell in column) + 2, 12), 32
            )

    @staticmethod
    def _excel_payroll(ws, data):
        ws.append(['Payroll Metric', 'Value'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        ws.append(['Total Employees', data['total_employees']])
        ws.append(['Average Salary', data['avg_salary']])
        ws.append(['Total Payroll', data['avg_salary'] * data['total_employees']])
        ws.append(['Payroll/Revenue %', (data['avg_salary'] * data['total_employees']) / max(data['annual_revenue'], 1)])

    @staticmethod
    def _excel_recommendations(ws, data, report_type):
        ws.append(['Priority', 'Recommendation'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        recs = ReportService._get_recommendations(data, report_type)
        for i, rec in enumerate(recs, 1):
            ws.append([f"{i}", rec])

    @staticmethod
    def _excel_data_quality(ws, data):
        ws.append(['Data Domain', 'Status', 'Detail'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        details = {
            'financial_ledger': f"{data['ledger_days']} observed transaction dates",
            'annual_revenue': 'Company profile value' if data['data_quality']['annual_revenue'] == 'company_profile' else 'Observed ledger total',
            'customers': f"{len(data['customers_detail'])} customer records",
            'employees': f"{data['total_employees']} active employee records",
            'salaries': 'Observed salary values' if data['avg_salary'] else 'No salary values recorded',
            'departments': f"{len(data['departments'])} department records",
            'inventory': f"{len(data['inventory_detail'])} active inventory records",
            'risks': f"{len(data['risks'])} risk records",
            'runway': 'Unavailable without a recorded cash balance'
        }
        for domain, status in data['data_quality'].items():
            ws.append([domain, status, details.get(domain, '')])

    @staticmethod
    def _excel_ledger(ws, data):
        ws.append(['Date', 'Type', 'Category', 'Subcategory', 'Amount', 'Description', 'Department ID', 'Project ID', 'Recurring'])
        for cell in ws[1]:
            ReportService._excel_style_header(cell)
        for row in data['ledger']:
            ws.append([
                row['date'], row['type'], row['category'], row['subcategory'],
                row['amount'], row['description'], row['department_id'],
                row['project_id'], row['recurring']
            ])
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        for col, width in {'A': 14, 'B': 12, 'C': 18, 'D': 18, 'E': 16, 'F': 42, 'G': 14, 'H': 12, 'I': 12}.items():
            ws.column_dimensions[col].width = width

    @staticmethod
    def _excel_entity_detail(ws, data):
        ws.append(['CUSTOMERS'])
        ws.append(['ID', 'Name', 'Segment', 'Status', 'Lifetime Value', 'Acquisition Cost', 'Orders', 'Total Spent', 'Churned'])
        for cell in ws[2]:
            ReportService._excel_style_header(cell)
        for customer in data['customers_detail']:
            ws.append([
                customer['id'], customer['name'], customer['segment'], customer['status'],
                customer['lifetime_value'], customer['acquisition_cost'],
                customer['total_orders'], customer['total_spent'], customer['churned']
            ])
        ws.append([])
        ws.append(['INVENTORY'])
        ws.append(['ID', 'SKU', 'Name', 'Quantity', 'Reorder Point', 'Unit Cost', 'Value', 'Low Stock'])
        for cell in ws[ws.max_row]:
            ReportService._excel_style_header(cell)
        for item in data['inventory_detail']:
            ws.append([
                item['id'], item['sku'], item['name'], item['quantity'],
                item['reorder_point'], item['unit_cost'], item['value'], item['low_stock']
            ])
        ws.freeze_panes = 'A3'
        for col, width in {'A': 12, 'B': 18, 'C': 28, 'D': 14, 'E': 16, 'F': 16, 'G': 16, 'H': 12, 'I': 12}.items():
            ws.column_dimensions[col].width = width

    # ==================== CSV GENERATOR ====================
    
    @staticmethod
    def _generate_csv(report, company_id, report_type, data):
        config = ReportService.REPORT_TYPE_CONFIG.get(report_type, ReportService.REPORT_TYPE_CONFIG['executive'])
        filename = os.path.join(EXPORTS_DIR, f"{report_type}_{report.id}.csv")
        
        rows = []
        rows.append(['REPORT_TYPE', config['title']])
        rows.append(['REPORT_KEY', report_type])
        rows.append(['REPORT_SCOPE', ', '.join(config.get('sections', []))])
        rows.append(['COMPANY', data['company_name']])
        rows.append(['INDUSTRY', data['industry']])
        rows.append(['GENERATED', data['generated_at']])
        rows.append([])
        
        if report_type == 'executive':
            rows.append(['SECTION', 'Executive Summary'])
            rows.append(['METRIC', 'VALUE'])
            rows.append(['Annual Revenue', data['annual_revenue']])
            rows.append(['Observed Expenses (365d)', data['annual_cost']])
            rows.append(['Net Profit (LTM)', data['profit_365']])
            rows.append(['Net Margin %', data['margin']])
            rows.append(['Health Score', data['health_score']])
            rows.append(['Employees', data['total_employees']])
            rows.append(['Customers', data['total_customers']])
            rows.append(['Churned Customers', data['churned_customers']])
            rows.append(['Churn Rate %', data['churn_rate']])
            rows.append([])
            rows.append(['SECTION', '30-Day Financial Pulse'])
            rows.append(['PERIOD', 'REVENUE', 'EXPENSES', 'PROFIT'])
            rows.append(['Last 30 Days', data['rev_30'], data['exp_30'], data['profit_30']])
            rows.append(['Last 90 Days', data['rev_90'], data['exp_90'], data['rev_90'] - data['exp_90']])
            rows.append(['Last 12 Months', data['rev_365'], data['exp_365'], data['profit_365']])
            rows.append([])
            rows.append(['SECTION', 'Recommendations'])
            for rec in ReportService._get_recommendations(data, 'executive'):
                rows.append(['RECOMMENDATION', rec])
        
        elif report_type == 'board':
            rows.append(['SECTION', 'Governance & Financial Highlights'])
            rows.append(['METRIC', 'VALUE', 'BOARD_NOTE'])
            rows.append(['Annual Revenue', data['annual_revenue'], 'Verify against audit'])
            rows.append(['Observed Expenses (365d)', data['annual_cost'], 'Review cost policies'])
            rows.append(['Net Margin %', data['margin'], 'Benchmark vs peers'])
            rows.append(['Cash Burn (30d)', data['burn_rate'], 'Assess runway'])
            rows.append(['Runway (months)', data['runway_months'], 'Not available without cash balance'])
            rows.append([])
            rows.append(['SECTION', 'Risk Oversight'])
            rows.append(['SEVERITY', 'COUNT'])
            rows.append(['Critical', data['critical_risks']])
            rows.append(['High', data['high_risks']])
            rows.append(['Medium', len([r for r in data['risks'] if r.get('risk_level') == 'medium'])])
            rows.append(['Low', len([r for r in data['risks'] if r.get('risk_level') == 'low'])])
        
        elif report_type == 'investor':
            rows.append(['SECTION', 'Investor Performance Metrics'])
            rows.append(['KPI', 'VALUE', 'RELEVANCE'])
            rows.append(['LTM Revenue', data['rev_365'], 'Top-line growth'])
            rows.append(['LTM Profit', data['profit_365'], 'Bottom-line'])
            rows.append(['Net Margin %', data['margin'], 'Unit economics'])
            rows.append(['Customer Base', data['total_customers'], 'Market penetration'])
            rows.append(['Churned Customers', data['churned_customers'], 'Retention health'])
            rows.append(['Churn Rate %', data['churn_rate'], 'Retention health'])
            rows.append(['New Customers (30d)', data['new_customers_30'], 'Growth velocity'])
            rows.append(['Return on Equity %', data['roe'], 'Capital efficiency'])
            rows.append([])
            rows.append(['SECTION', 'Forecasts'])
            rows.append(['NAME', 'TYPE', 'METHOD', 'HORIZON', 'TREND_%', 'FINAL_VALUE'])
            for f in data['forecasts']:
                rows.append([f['name'], f['type'], f['method'], f['horizon'], f['trend'], f['final_value']])
        
        elif report_type == 'risk':
            rows.append(['SECTION', 'Enterprise Risk Register'])
            rows.append(['RISK_NAME', 'CATEGORY', 'PROBABILITY', 'IMPACT', 'SCORE', 'LEVEL'])
            for r in data['risks'][:50]:
                rows.append([
                    r.get('name', 'Unknown'),
                    r.get('category', 'N/A'),
                    r.get('probability', 0),
                    r.get('impact', 0),
                    r.get('risk_score', 0),
                    r.get('risk_level', 'N/A')
                ])
            rows.append([])
            rows.append(['SECTION', 'Risk Distribution'])
            rows.append(['LEVEL', 'COUNT'])
            rows.append(['Critical', data['critical_risks']])
            rows.append(['High', data['high_risks']])
            rows.append(['Medium', len([r for r in data['risks'] if r.get('risk_level') == 'medium'])])
            rows.append(['Low', len([r for r in data['risks'] if r.get('risk_level') == 'low'])])
        
        elif report_type == 'growth':
            cac = data['observed_cac']
            ltv = data['observed_ltv']
            rows.append(['SECTION', 'Growth KPIs'])
            rows.append(['METRIC', 'VALUE', 'BENCHMARK'])
            rows.append(['New Customers (30d)', data['new_customers_30'], '>5% of base monthly'])
            rows.append(['Total Customers', data['total_customers'], 'Retention focus'])
            rows.append(['Churned Customers', data['churned_customers'], 'Observed churn records'])
            rows.append(['Churn Rate %', data['churn_rate'], '<5% annually'])
            rows.append(['Observed CAC', cac or None, 'Requires acquisition cost records'])
            rows.append(['Observed LTV', ltv or None, 'Requires lifetime value records'])
            rows.append(['LTV/CAC Ratio', ltv / cac if cac and ltv else None, 'Requires both observed metrics'])
            rows.append(['Revenue per Employee', data['annual_revenue'] / max(data['total_employees'], 1), '>100K'])
        
        elif report_type == 'forecast':
            rows.append(['SECTION', 'Active Forecasts'])
            rows.append(['NAME', 'TYPE', 'METHOD', 'HORIZON', 'TREND_%', 'FINAL_VALUE'])
            for f in data['forecasts']:
                rows.append([f['name'], f['type'], f['method'], f['horizon'], f['trend'], f['final_value']])
            rows.append([])
            rows.append(['SECTION', 'Recent Simulations'])
            rows.append(['NAME', 'TYPE', 'REV_IMPACT', 'PROFIT_IMPACT', 'RISK_SCORE'])
            for s in data['simulations'][:10]:
                rev_impact = (s['revenue_after'] or 0) - (s['revenue_before'] or 0)
                profit_impact = (s['profit_after'] or 0) - (s['profit_before'] or 0)
                rows.append([s['name'], s['type'], rev_impact, profit_impact, s['risk_score']])
        
        elif report_type == 'financial':
            rows.append(['SECTION', 'Income Statement (Trailing 12 Months)'])
            rows.append(['LINE_ITEM', 'AMOUNT', 'PCT_OF_REVENUE'])
            rows.append(['Revenue', data['rev_365'], 1.0])
            rows.append(['Operating Expenses', data['exp_365'], data['exp_365'] / max(data['rev_365'], 1)])
            rows.append(['Net Profit / (Loss)', data['profit_365'], data['profit_365'] / max(data['rev_365'], 1)])
            rows.append([])
            rows.append(['SECTION', 'Financial Ratios'])
            rows.append(['RATIO', 'VALUE', 'ASSESSMENT'])
            rows.append(['Net Margin %', data['margin'], 'Strong' if data['margin'] > 20 else 'Average' if data['margin'] > 10 else 'Weak'])
            rows.append(['Return on Equity %', data['roe'], 'Strong' if data['roe'] > 25 else 'Average' if data['roe'] > 10 else 'Weak'])
            rows.append(['Revenue per Employee', data['annual_revenue'] / max(data['total_employees'], 1), 'Efficiency'])
            rows.append(['Cost Ratio %', (data['annual_cost'] / max(data['annual_revenue'], 1)) * 100, 'Lower is better'])
        
        elif report_type == 'operational':
            rows.append(['SECTION', 'Operational Metrics'])
            rows.append(['METRIC', 'VALUE', 'NOTE'])
            rows.append(['Total Employees', data['total_employees'], 'Active headcount'])
            rows.append(['Average Salary', data['avg_salary'] or None, 'Observed employee salary records'])
            rows.append(['Annual Payroll', data['avg_salary'] * data['total_employees'] if data['avg_salary'] else None, 'Observed salaries only'])
            rows.append(['Revenue per Employee', data['annual_revenue'] / max(data['total_employees'], 1), 'Productivity'])
            rows.append([])
            rows.append(['SECTION', 'Inventory'])
            rows.append(['METRIC', 'VALUE', 'STATUS'])
            status = 'Healthy' if data['low_stock_count'] == 0 else 'Attention' if data['low_stock_count'] < 5 else 'Critical'
            rows.append(['Total SKUs', data['total_skus'], 'Product breadth'])
            rows.append(['Inventory Value', data['total_inventory_value'], 'Working capital'])
            rows.append(['Low Stock Items', data['low_stock_count'], status])
            rows.append(['Inventory/Revenue %', (data['total_inventory_value'] / max(data['annual_revenue'], 1)) * 100, 'Capital efficiency'])
        
        elif report_type == 'department':
            rows.append(['SECTION', 'Departmental Breakdown'])
            rows.append([
                'DEPARTMENT_ID', 'CODE', 'DEPARTMENT', 'HEADCOUNT', 'PAYROLL',
                'RECORDED_REVENUE', 'RECORDED_EXPENSES', 'RECORDED_COST',
                'DEPARTMENT_BUDGET', 'BUDGET_SOURCE', 'BUDGET_STATUS', 'VARIANCE', 'UTILIZATION_%',
                'PROJECT_BUDGET', 'PROJECT_SPENT'
            ])
            for d in data['departments']:
                utilization = (
                    d['total_recorded_cost'] / d['budget'] * 100
                    if d['budget'] > 0 and d['budget_status'] != 'outlier_vs_company_revenue'
                    else None
                )
                rows.append([
                    d['id'], d['code'], d['name'], d['headcount'], d['payroll'],
                    d['recorded_revenue'], d['recorded_expenses'], d['total_recorded_cost'],
                    d['budget'], d['budget_source'], d['budget_status'], d['variance'], utilization,
                    d['project_budget'], d['project_spent']
                ])
            rows.append([])
            rows.append(['SECTION', 'Department Financial Contribution'])
            rows.append(['DEPARTMENT', 'RECORDED_REVENUE', 'RECORDED_EXPENSES', 'PAYROLL', 'RECORDED_COST', 'NET_CONTRIBUTION', 'REVENUE_COST_RATIO'])
            for d in data['departments']:
                cost = d['total_recorded_cost']
                rows.append([
                    d['name'], d['recorded_revenue'], d['recorded_expenses'], d['payroll'],
                    cost, d['recorded_revenue'] - cost if d['recorded_revenue'] else None,
                    d['recorded_revenue'] / cost if cost else None
                ])
            rows.append([])
            rows.append(['SECTION', 'Company Payroll Summary'])
            rows.append(['METRIC', 'VALUE'])
            rows.append(['Total Employees', data['total_employees']])
            rows.append(['Average Salary', data['avg_salary']])
            rows.append(['Total Payroll', data['avg_salary'] * data['total_employees']])
            rows.append(['Payroll/Revenue %', (data['avg_salary'] * data['total_employees']) / max(data['annual_revenue'], 1) * 100])
        
        else:
            rows.append(['SECTION', 'General Report'])
            rows.append(['METRIC', 'VALUE'])
            rows.append(['Revenue', data['annual_revenue']])
            rows.append(['Observed Expenses (365d)', data['annual_cost']])
            rows.append(['Profit', data['profit_365']])
            rows.append(['Margin %', data['margin']])

        rows.extend(ReportService._csv_type_detail_rows(data, report_type))
        rows.append([])
        rows.append(['SECTION', 'Data Quality & Provenance'])
        rows.append(['DOMAIN', 'STATUS', 'DETAIL'])
        quality_details = {
            'financial_ledger': f"{data['ledger_days']} observed transaction dates",
            'annual_revenue': 'Company profile value' if data['data_quality']['annual_revenue'] == 'company_profile' else 'Observed ledger total',
            'customers': f"{len(data['customers_detail'])} customer records",
            'employees': f"{data['total_employees']} active employee records",
            'salaries': 'Observed salary values' if data['avg_salary'] else 'No salary values recorded',
            'departments': f"{len(data['departments'])} department records",
            'inventory': f"{len(data['inventory_detail'])} active inventory records",
            'risks': f"{len(data['risks'])} risk records",
            'runway': 'Unavailable without a recorded cash balance'
        }
        for domain, status in data['data_quality'].items():
            rows.append([domain, status, quality_details.get(domain, '')])

        rows.append([])
        rows.append(['SECTION', 'Observed Financial Transactions (Trailing 365 Days)'])
        rows.append(['DATE', 'TYPE', 'CATEGORY', 'SUBCATEGORY', 'AMOUNT', 'DESCRIPTION', 'DEPARTMENT_ID', 'PROJECT_ID', 'RECURRING'])
        for transaction in data['ledger']:
            rows.append([
                transaction['date'], transaction['type'], transaction['category'],
                transaction['subcategory'], transaction['amount'], transaction['description'],
                transaction['department_id'], transaction['project_id'], transaction['recurring']
            ])

        rows.append([])
        rows.append(['SECTION', 'Customer Detail'])
        rows.append(['ID', 'NAME', 'SEGMENT', 'STATUS', 'LIFETIME_VALUE', 'ACQUISITION_COST', 'ORDERS', 'TOTAL_SPENT', 'CHURNED'])
        for customer in data['customers_detail']:
            rows.append([
                customer['id'], customer['name'], customer['segment'], customer['status'],
                customer['lifetime_value'], customer['acquisition_cost'], customer['total_orders'],
                customer['total_spent'], customer['churned']
            ])

        rows.append([])
        rows.append(['SECTION', 'Inventory Detail'])
        rows.append(['ID', 'SKU', 'NAME', 'QUANTITY', 'REORDER_POINT', 'UNIT_COST', 'VALUE', 'LOW_STOCK'])
        for item in data['inventory_detail']:
            rows.append([
                item['id'], item['sku'], item['name'], item['quantity'],
                item['reorder_point'], item['unit_cost'], item['value'], item['low_stock']
            ])

        rows.append([])
        rows.append(['SECTION', 'Recommendations'])
        rows.append(['PRIORITY', 'RECOMMENDATION'])
        for priority, recommendation in enumerate(ReportService._get_recommendations(data, report_type), 1):
            rows.append([priority, recommendation])
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            for row in rows:
                writer.writerow(row)
        
        return filename

    @staticmethod
    def _csv_type_detail_rows(data, report_type):
        """Return report-specific evidence rows shared by CSV consumers."""
        rows = [[], ['SECTION', f"{report_type.title()} Detailed Evidence"]]

        if report_type in ('executive', 'board'):
            rows += [
                ['PERIOD', 'REVENUE', 'EXPENSES', 'PROFIT', 'MARGIN_%'],
                ['30 days', data['rev_30'], data['exp_30'], data['profit_30'],
                 data['profit_30'] / data['rev_30'] * 100 if data['rev_30'] else None],
                ['90 days', data['rev_90'], data['exp_90'], data['rev_90'] - data['exp_90'],
                 (data['rev_90'] - data['exp_90']) / data['rev_90'] * 100 if data['rev_90'] else None],
                ['365 days', data['rev_365'], data['exp_365'], data['profit_365'],
                 data['profit_365'] / data['rev_365'] * 100 if data['rev_365'] else None],
                [],
                ['RISK', 'CATEGORY', 'PROBABILITY', 'IMPACT', 'SCORE', 'LEVEL', 'STATUS', 'MITIGATION']
            ]
            rows.extend([
                [r['name'], r['category'], r['probability'], r['impact'], r['risk_score'],
                 r['risk_level'], r['status'], r['mitigation_plan']]
                for r in data['risks']
            ])
        elif report_type == 'investor':
            rows += [
                ['METRIC', 'VALUE', 'SOURCE'],
                ['Observed CAC', data['observed_cac'] or None, 'Customer acquisition_cost records'],
                ['Observed LTV', data['observed_ltv'] or None, 'Customer lifetime_value records'],
                ['LTV/CAC', data['observed_ltv'] / data['observed_cac']
                 if data['observed_ltv'] and data['observed_cac'] else None, 'Observed values only'],
                ['Market Capitalization', data['market_cap'] or None, 'Company profile'],
                ['Enterprise Value', data['enterprise_value'] or None, 'Company profile'],
                ['Return on Equity', data['roe'] or None, 'Company profile'],
                [],
                ['FORECAST', 'METHOD', 'HORIZON', 'TREND_%', 'FINAL_VALUE', 'MAPE', 'R2']
            ]
            rows.extend([[f['name'], f['method'], f['horizon'], f['trend'], f['final_value'],
                          f['accuracy_mape'], f['accuracy_r2']] for f in data['forecasts']])
        elif report_type == 'risk':
            rows.append(['ID', 'RISK', 'CATEGORY', 'DESCRIPTION', 'PROBABILITY', 'IMPACT',
                         'SCORE', 'LEVEL', 'STATUS', 'REVIEW_DATE', 'MITIGATION'])
            rows.extend([
                [r['id'], r['name'], r['category'], r['description'], r['probability'], r['impact'],
                 r['risk_score'], r['risk_level'], r['status'], r['review_date'], r['mitigation_plan']]
                for r in data['risks']
            ])
        elif report_type == 'growth':
            rows.append(['CUSTOMER_ID', 'CUSTOMER', 'SEGMENT', 'STATUS', 'LTV', 'CAC',
                         'ORDERS', 'TOTAL_SPENT', 'CHURNED'])
            rows.extend([
                [c['id'], c['name'], c['segment'], c['status'], c['lifetime_value'],
                 c['acquisition_cost'], c['total_orders'], c['total_spent'], c['churned']]
                for c in data['customers_detail']
            ])
        elif report_type == 'forecast':
            rows.append(['FORECAST', 'DATE', 'VALUE', 'LOWER_BOUND', 'UPPER_BOUND', 'ACTUAL'])
            rows.extend([
                [r['forecast_name'], r['date'], r['value'], r['lower_bound'], r['upper_bound'], r['actual']]
                for r in data['forecast_results']
            ])
            rows.append([])
            rows.append(['SCENARIO', 'TYPE', 'REVENUE_BEFORE', 'REVENUE_AFTER',
                         'PROFIT_BEFORE', 'PROFIT_AFTER', 'RISK_SCORE'])
            rows.extend([
                [s['name'], s['type'], s['revenue_before'], s['revenue_after'],
                 s['profit_before'], s['profit_after'], s['risk_score']]
                for s in data['simulations']
            ])
        elif report_type == 'financial':
            rows += [
                ['LINE_ITEM', 'AMOUNT', 'PCT_OF_REVENUE', 'SOURCE'],
                ['Revenue', data['rev_365'], 100 if data['rev_365'] else None, 'FinancialRecord revenue'],
                ['Expenses', data['exp_365'], data['exp_365'] / data['rev_365'] * 100 if data['rev_365'] else None, 'FinancialRecord expense'],
                ['Net Profit/(Loss)', data['profit_365'], data['profit_365'] / data['rev_365'] * 100 if data['rev_365'] else None, 'Calculated from ledger'],
                [],
                ['ACCOUNT_ID', 'ACCOUNT', 'TYPE', 'CATEGORY', 'OPENING_BALANCE', 'CURRENT_BALANCE', 'CURRENCY', 'ACTIVE']
            ]
            rows.extend([
                [a['id'], a['name'], a['type'], a['category'], a['opening_balance'],
                 a['current_balance'], a['currency'], a['active']]
                for a in data['financial_accounts']
            ])
            rows.append([])
            rows.append(['TRANSACTION_TYPE', 'CATEGORY', 'AMOUNT'])
            rows.extend([[c['type'], c['category'], c['amount']] for c in data['financial_categories']])
        elif report_type == 'operational':
            rows += [
                ['DEPARTMENT', 'HEADCOUNT', 'PAYROLL', 'REVENUE', 'EXPENSES', 'RECORDED_COST'],
                *[[d['name'], d['headcount'], d['payroll'], d['recorded_revenue'],
                   d['recorded_expenses'], d['total_recorded_cost']] for d in data['departments']],
                [],
                ['ID', 'SKU', 'ITEM', 'QUANTITY', 'REORDER_POINT', 'UNIT_COST', 'VALUE', 'LOW_STOCK']
            ]
            rows.extend([
                [i['id'], i['sku'], i['name'], i['quantity'], i['reorder_point'],
                 i['unit_cost'], i['value'], i['low_stock']]
                for i in data['inventory_detail']
            ])
        elif report_type == 'department':
            rows += [
                ['ID', 'CODE', 'DEPARTMENT', 'HEADCOUNT', 'PAYROLL', 'REVENUE', 'EXPENSES',
                 'RECORDED_COST', 'BUDGET', 'BUDGET_SOURCE', 'BUDGET_STATUS', 'VARIANCE',
                 'PROJECT_BUDGET', 'PROJECT_SPENT'],
                *[[d['id'], d['code'], d['name'], d['headcount'], d['payroll'], d['recorded_revenue'],
                   d['recorded_expenses'], d['total_recorded_cost'], d['budget'], d['budget_source'],
                   d['budget_status'], d['variance'], d['project_budget'], d['project_spent']]
                  for d in data['departments']]
            ]

        return rows