from database.db import db
from datetime import datetime
import json


class CoreTwinExtraRecord(db.Model):
    """Shadow storage for per-record custom field values on CORE twins.

    Core twins (revenue, customers, employees, ...) map to real, fixed database
    tables. To let companies add their own custom fields to these twins without
    migrating those tables, we store the extra field values keyed by
    (company_id, twin_key, record_id). One row per core record, with the
    custom values in ``data`` as a JSON object of ``{field_name: value}``.
    """
    __tablename__ = 'core_twin_extra_records'

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    twin_key = db.Column(db.String(50), nullable=False)   # 'revenue', 'customers', ...
    record_id = db.Column(db.Integer, nullable=False)     # id inside the twin's real table
    data = db.Column(db.Text, default='{}')

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('company_id', 'twin_key', 'record_id',
                            name='uq_core_twin_extra_record'),
    )

    def get_data(self):
        try:
            return json.loads(self.data) if self.data else {}
        except Exception:
            return {}

    def set_data(self, data):
        self.data = json.dumps(data or {})

    def to_dict(self):
        return {
            'company_id': self.company_id,
            'twin_key': self.twin_key,
            'record_id': self.record_id,
            'data': self.get_data(),
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }