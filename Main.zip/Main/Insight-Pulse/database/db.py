from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text
from datetime import datetime
import os

db = SQLAlchemy()


def _sqlalchemy_type_to_sqlite(col):
    """Map a SQLAlchemy column type to a SQLite column type string."""
    t = col.type
    name = type(t).__name__.upper()
    if 'VARCHAR' in name:
        if hasattr(t, 'length') and t.length:
            return f'VARCHAR({t.length})'
        return 'VARCHAR'
    if 'TEXT' in name:
        return 'TEXT'
    if 'INTEGER' in name or 'BIGINT' in name:
        return 'INTEGER'
    if 'FLOAT' in name or 'NUMERIC' in name or 'DECIMAL' in name:
        return 'FLOAT'
    if 'REAL' in name or 'DOUBLE' in name:
        return 'REAL'
    if 'BOOLEAN' in name or 'BOOL' in name:
        return 'INTEGER'
    if 'DATETIME' in name or 'TIMESTAMP' in name:
        return 'TIMESTAMP'
    if 'DATE' in name:
        return 'DATE'
    if 'BLOB' in name or 'BINARY' in name:
        return 'BLOB'
    if 'JSON' in name:
        return 'TEXT'
    return 'TEXT'


def _default_sql(col_obj, col_type):
    """Build a SQLite DEFAULT clause from a SQLAlchemy column's default."""
    if col_obj.default is not None:
        try:
            d = col_obj.default.arg
            if callable(d):
                d = d(None)
            if isinstance(d, str):
                return f" DEFAULT '{d}'"
            if isinstance(d, (int, float)):
                return f" DEFAULT {d}"
            if d is None:
                return ''
        except Exception:
            return ''
    if col_obj.nullable:
        return ''
    if col_type == 'INTEGER':
        return ' DEFAULT 0'
    if col_type in ('FLOAT', 'REAL'):
        return ' DEFAULT 0.0'
    if col_type in ('VARCHAR', 'TEXT'):
        return " DEFAULT ''"
    if col_type == 'BOOLEAN':
        return ' DEFAULT 0'
    return ''


def _heal_schema():
    """Add missing columns to existing SQLite tables so the schema always
    matches the SQLAlchemy models. Safe to run on every startup: it skips
    columns that already exist. Uses the SQLAlchemy 2.0 connection API
    (``engine.connect()`` + ``text()``) — no legacy bare-string
    ``engine.execute()`` calls."""
    engine = db.engine
    if engine.url.get_backend_name() != 'sqlite':
        return None

    with engine.connect() as conn:
        existing = {r[0] for r in conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table'")).fetchall()}
        if not existing:
            return {}

    mapped = []
    try:
        for mapper in db.Model.registry.mappers:
            cls = mapper.class_
            tn = getattr(cls, '__tablename__', None)
            if tn and tn in existing:
                mapped.append((tn, cls))
    except Exception:
        return {}

    added = {}
    with engine.connect() as conn:
        for tname, mcls in mapped:
            try:
                pragma = conn.execute(
                    text(f'PRAGMA table_info("{tname}")')).fetchall()
                have = {r[1] for r in pragma}
            except Exception:
                continue
            for col in mcls.__table__.columns:
                if col.name in have:
                    continue
                ct = _sqlalchemy_type_to_sqlite(col)
                dv = _default_sql(col, ct)
                null = '' if col.nullable else ' NOT NULL'
                try:
                    conn.execute(text(
                        f'ALTER TABLE "{tname}" ADD COLUMN '
                        f'"{col.name}" {ct}{dv}{null}'))
                    conn.commit()
                    added.setdefault(tname, []).append(col.name)
                except Exception as e:
                    print(f"[HEAL] {tname}.{col.name}: {e}")

    if added:
        total = sum(len(v) for v in added.values())
        print(f"[HEAL] +{total} columns across {len(added)} tables: "
              + ', '.join(f'{t}({len(c)})' for t, c in added.items()))
    else:
        print("[HEAL] Schema up to date.")
    return added


def init_db(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()
        _heal_schema()
        try:
            seed_initial_data()
        except Exception as e:
            print(f"Seed warning: {e}")


def seed_initial_data():
    """Create a recovery admin only when a company exists but no user can
    log into it (e.g. after a DB file loses its users table). A fresh
    install keeps the normal /setup wizard flow."""
    from database.models.user import User
    from database.models.company import Company
    if Company.query.first() is None:
        return
    if User.query.first() is None:
        recovery = User(
            username='admin',
            email='admin@businessimulator.com',
            first_name='System',
            last_name='Administrator',
            role='Admin',
            is_admin=True,
            is_active=True,
        )
        recovery.set_password('Admin@123')
        db.session.add(recovery)
        db.session.commit()
        print("[SEED] No users found for existing company — created recovery "
              "admin (username: admin / password: Admin@123 — change it!)")
