#!/usr/bin/env python3
"""End-to-end verification for the twin table enhancements.

Runs against a SCRATCH database (DATABASE_URL env override) - never touches
instance/business_simulator.db. Verifies:
  1. Company Flow is fully removed (no routes, no references)
  2. Every twin records page renders with the table toolkit (search/sort/select/bulk)
  3. Bulk delete works for core twins AND custom twins (via their real handlers,
     so interconnection hooks still run)
  4. Department delete detaches employees/financials
  5. Validation & error paths
"""
import os
import sys
import json
import shutil
import tempfile
from datetime import date

PROJ = os.path.dirname(os.path.abspath(__file__))
os.chdir(PROJ)

# Scratch DB BEFORE importing the app
_tmp = tempfile.mkdtemp(prefix='twin_tables_check_')
os.environ['DATABASE_URL'] = f'sqlite:///{_tmp}/scratch.db'

from app import create_app
from database.db import db
from database.models.user import User
from database.models.company import Company
from database.models.department import Department
from database.models.customer import Customer
from database.models.employee import Employee
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.financial import FinancialRecord
from database.models.custom_twin import CustomTwin, CustomTwinRecord

PASS, FAIL = [], []


def check(name, cond, detail=''):
    (PASS if cond else FAIL).append(name)
    print(f"  {'PASS' if cond else 'FAIL'}  {name}" + (f"  [{detail}]" if detail and not cond else ''))


app = create_app()
app.config['TESTING'] = True
app.config['WTF_CSRF_ENABLED'] = False

with app.app_context():
    db.create_all()
    comp = Company(company_name='Acme Corp', business_name='Acme Corp',
                   owner_name='Test Owner', ceo_name='Test CEO',
                   industry='Technology', currency='USD')
    db.session.add(comp)
    db.session.flush()

    user = User(username='tester', email='tester@acme.io', role='Admin', is_admin=True)
    from security.password_hash import hash_password
    user.password_hash = hash_password('test1234')
    db.session.add(user)

    d1 = Department(company_id=comp.id, name='Sales', code='SLS', budget=50000, spent=300)
    d2 = Department(company_id=comp.id, name='Engineering', code='ENG', budget=80000, spent=0)
    db.session.add_all([d1, d2])
    db.session.flush()

    c1 = Customer(company_id=comp.id, company_name='Beta LLC', email='b@x.io')
    c2 = Customer(company_id=comp.id, company_name='Alpha Inc', email='a@x.io')
    c3 = Customer(company_id=comp.id, company_name='Gamma Co', email='g@x.io')
    db.session.add_all([c1, c2, c3])

    e1 = Employee(company_id=comp.id, first_name='John', last_name='Doe', department_id=d1.id)
    e2 = Employee(company_id=comp.id, first_name='Jane', last_name='Roe', department_id=d2.id)
    db.session.add_all([e1, e2])
    db.session.add_all([
        Supplier(company_id=comp.id, name='SteelWorks'),
        Supplier(company_id=comp.id, name='PlumbCo'),
        Inventory(company_id=comp.id, sku='SKU-1', name='Widget'),
        Inventory(company_id=comp.id, sku='SKU-2', name='Gear'),
    ])
    db.session.add_all([
        FinancialRecord(company_id=comp.id, transaction_date=date(2026, 1, 5),
                        transaction_type='expense', amount=100, category='Office',
                        description='Chairs', department_id=d1.id),
        FinancialRecord(company_id=comp.id, transaction_date=date(2026, 1, 6),
                        transaction_type='expense', amount=200, category='Software',
                        description='Licenses', department_id=d1.id),
        FinancialRecord(company_id=comp.id, transaction_date=date(2026, 1, 7),
                        transaction_type='revenue', amount=900, category='Sales',
                        description='Deal A'),
        FinancialRecord(company_id=comp.id, transaction_date=date(2026, 1, 8),
                        transaction_type='revenue', amount=1200, category='Sales',
                        description='Deal B'),
    ])

    twin = CustomTwin(company_id=comp.id, name='Leads', slug='leads', created_by=user.id)
    db.session.add(twin)
    db.session.flush()
    r1 = CustomTwinRecord(twin_id=twin.id, company_id=comp.id, data=json.dumps({'name': 'L1'}))
    r2 = CustomTwinRecord(twin_id=twin.id, company_id=comp.id, data=json.dumps({'name': 'L2'}))
    r3 = CustomTwinRecord(twin_id=twin.id, company_id=comp.id, data=json.dumps({'name': 'L3'}))
    db.session.add_all([r1, r2, r3])
    db.session.commit()

    ids = {'company': comp.id, 'dept1': d1.id, 'dept2': d2.id,
           'cust': [c1.id, c2.id, c3.id], 'twin': twin.id,
           'recs': [r1.id, r2.id, r3.id]}

# ---- STAGE 1: Company Flow removal ----
print('\n[1] COMPANY FLOW REMOVAL')
with app.app_context():
    endpoints = set(app.view_functions.keys())
    check('org_flow route removed', 'custom_twin.org_flow' not in endpoints)
    check('onboarding routes removed', 'custom_twin.twin_onboarding' not in endpoints
          and 'custom_twin.provision_company_flow' not in endpoints)
    check('repair route removed', 'custom_twin.repair_twins' not in endpoints)
    check('provisioner module deleted', not os.path.exists(os.path.join(PROJ, 'services', 'twin_provisioner.py')))
    leftovers = []
    for root, dirs, files in os.walk(os.path.join(PROJ, 'templates')):
        dirs[:] = [d for d in dirs if d != '__pycache__']
        for f in files:
            if f.endswith(('.html', '.py')):
                p = os.path.join(root, f)
                if 'org_flow' in open(p, encoding='utf-8', errors='ignore').read():
                    leftovers.append(p)
    check('no org_flow references in templates', not leftovers, ', '.join(leftovers))


# ---- STAGE 2: pages render with the toolkit ----
print('\n[2] TWIN PAGES RENDER + TOOLKIT PRESENT')
client = app.test_client()
rv = client.post('/login', data={'username': 'tester', 'password': 'test1234'}, follow_redirects=True)
check('login works', b'dashboard' in rv.data.lower() or rv.status_code == 200)

PAGES = {
    '/business-twin/revenue': 'revenue',
    '/business-twin/expenses': 'expenses',
    '/business-twin/customers': 'customers',
    '/business-twin/employees': 'employees',
    '/business-twin/suppliers': 'suppliers',
    '/business-twin/inventory': 'inventory',
    '/business-twin/departments': 'departments',
}
for url, key in PAGES.items():
    rv = client.get(url)
    ok = rv.status_code == 200 and f'data-twin-table="{key}"'.encode() in rv.data \
        and b'twDeleteOne' in rv.data and b'tw-toolbar' in rv.data
    check(f'{url} renders with toolkit', ok, f'status={rv.status_code}')

with app.app_context():
    t = CustomTwin.query.get(ids['twin'])
    rv = client.get(f'/business-twin/custom-twins/{t.slug}')
    ok = rv.status_code == 200 and b'data-twin-table="custom-records"' in rv.data \
        and b'bulk-delete' in rv.data
    check('custom twin detail renders with toolkit', ok, f'status={rv.status_code}')

# ---- STAGE 3: bulk deletes via real handlers ----
print('\n[3] BULK DELETE (core twins reuse interconnection handlers)')
with app.app_context():
    alive = Customer.query.filter_by(company_id=ids['company']).count()
    check('pre-count customers', alive == 3, str(alive))

rv = client.post('/business-twin/bulk-delete',
                 data=json.dumps({'twin': 'customers', 'ids': ids['cust'][1:]}),
                 content_type='application/json')
d = rv.get_json()
check('bulk delete customers accepted', rv.status_code == 200 and d.get('success'), str(d))
with app.app_context():
    names = sorted(c.company_name for c in Customer.query.filter_by(company_id=ids['company']).all())
    check('customers bulk-deleted (only Beta LLC left)', names == ['Beta LLC'], str(names))

# expenses bulk: verify dept.spent reversal hook ran (dept1.spent was 300)
with app.app_context():
    expense_ids = [r.id for r in db.session.query(FinancialRecord.id)
                   .filter_by(transaction_type='expense').all()]
rv = client.post('/business-twin/bulk-delete',
                 data=json.dumps({'twin': 'expenses', 'ids': expense_ids}),
                 content_type='application/json')
d = rv.get_json()
check('bulk delete expenses accepted', rv.status_code == 200 and d.get('success'), str(d))
with app.app_context():
    spent = Department.query.get(ids['dept1']).spent
    check('department spent reversed by delete hooks', spent == 0, f'spent={spent}')
    check('expense rows gone', FinancialRecord.query.filter_by(transaction_type='expense').count() == 0)

# custom twin records bulk
rv = client.post('/business-twin/custom-twins/records/bulk-delete',
                 data=json.dumps({'ids': ids['recs'][:2]}),
                 content_type='application/json')
d = rv.get_json()
check('bulk delete custom records accepted', rv.status_code == 200 and d.get('success'), str(d))
with app.app_context():
    left = CustomTwinRecord.query.filter_by(twin_id=ids['twin']).count()
    check('custom records bulk-deleted (1 left)', left == 1, str(left))

# ---- STAGE 4: department delete detaches children ----
print('\n[4] DEPARTMENT DELETE DETACHES CHILDREN')
rv = client.delete(f'/business-twin/departments/delete/{ids["dept1"]}')
d = rv.get_json()
check('department delete accepted', rv.status_code == 200 and d.get('success'), str(d))
with app.app_context():
    check('department gone', Department.query.get(ids['dept1']) is None)
    emp = Employee.query.filter_by(first_name='John').first()
    check('employee detached (department_id=None)', emp is not None and emp.department_id is None)

# ---- STAGE 5: validation & errors ----
print('\n[5] VALIDATION & ERROR PATHS')
rv = client.post('/business-twin/bulk-delete',
                 data=json.dumps({'twin': 'doesnotexist', 'ids': [1]}),
                 content_type='application/json')
check('unknown twin rejected', rv.status_code == 400)
rv = client.post('/business-twin/bulk-delete',
                 data=json.dumps({'twin': 'customers', 'ids': []}),
                 content_type='application/json')
check('empty ids rejected', rv.status_code == 400)
rv = client.post('/business-twin/custom-twins/records/bulk-delete',
                 data=json.dumps({'ids': []}),
                 content_type='application/json')
check('custom empty ids rejected', rv.status_code == 400)


# ---- STAGE 6: cleanup + summary ----
print('\n[6] CLEANUP & SUMMARY')
shutil.rmtree(_tmp, ignore_errors=True)
check('scratch db cleaned', not os.path.exists(os.environ['DATABASE_URL'].replace('sqlite:///', '')))

print('\n' + '=' * 60)
print(f'RESULT: {len(PASS)} passed, {len(FAIL)} failed')
if FAIL:
    print('FAILED CHECKS:')
    for f in FAIL:
        print(f'  - {f}')
    sys.exit(1)
print('ALL CHECKS PASSED - twin tables verified end to end')
