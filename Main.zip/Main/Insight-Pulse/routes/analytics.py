from flask import Blueprint, render_template, jsonify, session, request
from flask_login import login_required
from services.analytics_service import AnalyticsService
from database.models.analytics import Analytics
from config.constants import CURRENCY_SYMBOLS

analytics_bp = Blueprint('analytics', __name__)

def _get_currency_symbol():
    """Get currency symbol from session or fallback to CURRENCY_SYMBOLS."""
    if 'currency_symbol' in session:
        return session['currency_symbol']
    currency = session.get('company_currency', 'USD')
    return CURRENCY_SYMBOLS.get(currency, '$')


def _series_sum(series, start, end):
    """Sum a numeric series slice, ignoring falsy/None entries."""
    total = 0.0
    for x in series[max(start, 0):max(end, 0)]:
        try:
            total += float(x) or 0.0
        except (TypeError, ValueError):
            pass
    return total


def _series_delta(series, days=30):
    """% change of the most recent `days` vs the `days` before them."""
    s = series or []
    if len(s) < days * 2:
        return None
    now = _series_sum(s, len(s) - days, len(s))
    prev = _series_sum(s, len(s) - days * 2, len(s) - days)
    if prev == 0:
        return 100.0 if now > 0 else None
    return round((now - prev) / prev * 100, 1)


@analytics_bp.route('/')
@login_required
def overview():
    company_id = session.get('company_id')
    summary = AnalyticsService.get_executive_summary(company_id)
    trend = AnalyticsService.get_trend_data(company_id, 90)
    dept_perf = AnalyticsService.get_department_performance(company_id)
    currency_symbol = _get_currency_symbol()

    # Meaningful "vs previous period" deltas + sparklines for the KPI grid.
    rev = trend.get('revenue', []) or []
    exp = trend.get('expenses', []) or []
    prof = trend.get('profit', []) or []
    spark = lambda s: list(s[-30:]) if len(s) >= 30 else list(s)

    # A rough data-quality score (0-100) derived from the summary's data_quality map.
    def _dq_score(state):
        if not state:
            return 0.0
        if state in ('observed', 'records', 'company_profile', 'company_profile_estimate'):
            return 1.0
        if state == 'partial':
            return 0.5
        return 0.0

    dq = summary.get('data_quality', {})
    dq_states = [dq.get(k) for k in ('financial', 'profitability', 'customers', 'employees', 'inventory')]
    quality_score = 0
    if dq_states:
        quality_score = int(round(sum(_dq_score(s) for s in dq_states) / len(dq_states) * 100))

    # ── Operating pulse: honest per-day rates from the last-30-day window ──
    rev30 = _series_sum(rev, len(rev) - 30, len(rev))
    exp30 = _series_sum(exp, len(exp) - 30, len(exp))
    prev_rev30 = _series_sum(rev, len(rev) - 60, len(rev) - 30)
    prev_exp30 = _series_sum(exp, len(exp) - 60, len(exp) - 30)
    avg_daily_rev = round(rev30 / 30, 2) if rev else 0.0
    avg_daily_exp = round(exp30 / 30, 2) if exp else 0.0
    daily_net = round(avg_daily_rev - avg_daily_exp, 2)
    breakeven = (avg_daily_rev / avg_daily_exp) if avg_daily_exp else None
    # Operating margin = net / revenue for the window; prev-window for the delta.
    margin_now = (rev30 - exp30) / rev30 * 100 if rev30 else 0.0
    margin_prev = (prev_rev30 - prev_exp30) / prev_rev30 * 100 if prev_rev30 else None
    margin_delta = round(margin_now - margin_prev, 1) if margin_prev is not None else None

    # ── Department roll-up: totals + watch list, straight from live rows ──
    dept_budget = round(sum((d.get('budget') or 0) for d in dept_perf), 2)
    dept_spent = round(sum((d.get('spent') or 0) for d in dept_perf), 2)
    dept_util = round(dept_spent / dept_budget * 100, 1) if dept_budget else 0.0
    over_budget = [d for d in dept_perf if (d.get('budget') or 0) > 0 and (d.get('spent') or 0) > (d.get('budget') or 0)]
    top_spender = max(dept_perf, key=lambda d: d.get('spent') or 0, default=None)

    kpis = {
        'revenue': {'label': 'Revenue', 'icon': 'fa-coins',
                    'value': summary.get('revenue_30d', 0), 'delta': _series_delta(rev),
                    'spark': spark(rev), 'fmt': 'money', 'unit': currency_symbol,
                    'sub': 'Total income · last 30 days'},
        'profit': {'label': 'Net Profit', 'icon': 'fa-chart-line',
                   'value': summary.get('profit_30d', 0), 'delta': _series_delta(prof),
                   'spark': spark(prof), 'fmt': 'money', 'unit': currency_symbol,
                   'sub': 'Revenue minus expenses'},
        'expenses': {'label': 'Expenses', 'icon': 'fa-receipt',
                     'value': summary.get('expense_30d', 0), 'delta': _series_delta(exp),
                     'spark': spark(exp), 'fmt': 'money', 'unit': currency_symbol,
                     'sub': 'Total spend · last 30 days'},
        'margin': {'label': 'Margin', 'icon': 'fa-percentage',
                   'value': summary.get('margin', 0), 'delta': margin_delta,
                   'delta_suffix': 'pts', 'spark': None, 'fmt': 'percent', 'unit': '',
                   'sub': 'Profitability as % of revenue'},
        'employees': {'label': 'Employees', 'icon': 'fa-user-tie',
                      'value': summary.get('total_employees', 0), 'delta': None,
                      'spark': None, 'fmt': 'int', 'unit': '',
                      'sub': "Avg salary {} {:,.0f}".format(currency_symbol, summary.get('avg_salary', 0))},
        'customers': {'label': 'Customers', 'icon': 'fa-users',
                      'value': summary.get('total_customers', 0), 'delta': None,
                      'spark': None, 'fmt': 'int', 'unit': '',
                      'sub': "Churn rate {}%".format(summary.get('churn_rate', 0))},
        'health': {'label': 'Health Score', 'icon': 'fa-heart-pulse',
                   'value': summary.get('health_score', 0), 'delta': None,
                   'spark': None, 'fmt': 'percent', 'unit': '',
                   'sub': 'Composite financial + operational health'},
        'quality': {'label': 'Data Quality', 'icon': 'fa-database',
                    'value': quality_score, 'delta': None,
                    'spark': None, 'fmt': 'percent', 'unit': '',
                    'sub': 'Share of live, verified company data'},
    }

    return render_template('analytics/analytics_overview.html',
                         summary=summary, trend=trend, dept_perf=dept_perf,
                         kpis=kpis, currency_symbol=currency_symbol,
                         pulse={'avg_daily_rev': avg_daily_rev,
                                'avg_daily_exp': avg_daily_exp,
                                'daily_net': daily_net, 'breakeven': breakeven,
                                'rev30': rev30, 'exp30': exp30},
                         dept_rollup={'budget': dept_budget, 'spent': dept_spent,
                                      'util': dept_util, 'over_budget': over_budget,
                                      'top_spender': top_spender})

@analytics_bp.route('/revenue')
@login_required
def revenue():
    company_id = session.get('company_id')
    trend = AnalyticsService.get_trend_data(company_id, 180)
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/revenue_analytics.html', trend=trend,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/expenses')
@login_required
def expenses():
    company_id = session.get('company_id')
    dept_perf = AnalyticsService.get_department_performance(company_id)
    summary = AnalyticsService.get_executive_summary(company_id)
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/expense_analytics.html', dept_perf=dept_perf, summary=summary,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/profit')
@login_required
def profit():
    company_id = session.get('company_id')
    trend = AnalyticsService.get_trend_data(company_id, 365)
    summary = AnalyticsService.get_executive_summary(company_id)
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/profit_analytics.html', trend=trend, summary=summary,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/growth')
@login_required
def growth():
    company_id = session.get('company_id')
    summary = AnalyticsService.get_executive_summary(company_id)
    trend = AnalyticsService.get_trend_data(company_id, 180)
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/growth_analytics.html', summary=summary, trend=trend,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/departments')
@login_required
def departments():
    company_id = session.get('company_id')
    dept_perf = AnalyticsService.get_department_performance(company_id)
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/department_analytics.html', dept_perf=dept_perf,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/customers')
@login_required
def customers():
    company_id = session.get('company_id')
    from database.models.customer import Customer
    customers = Customer.query.filter_by(company_id=company_id).all()
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/customer_analytics.html', customers=customers,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/employees')
@login_required
def employees():
    company_id = session.get('company_id')
    from database.models.employee import Employee
    employees = Employee.query.filter_by(company_id=company_id).all()
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/employee_analytics.html', employees=employees,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/supply-chain')
@login_required
def supply_chain():
    company_id = session.get('company_id')
    from database.models.supplier import Supplier
    suppliers = Supplier.query.filter_by(company_id=company_id).all()
    currency_symbol = _get_currency_symbol()
    return render_template('analytics/supply_chain_analytics.html', suppliers=suppliers,
                         currency_symbol=currency_symbol)

@analytics_bp.route('/api/trend')
@login_required
def api_trend():
    company_id = session.get('company_id')
    days = int(request.args.get('days', 90))
    currency_symbol = _get_currency_symbol()
    data = AnalyticsService.get_trend_data(company_id, days)
    data['currency_symbol'] = currency_symbol
    return jsonify(data)