# Video Studio - Flask Video Generator

A production-quality web application for creating synchronized MP4 videos from audio and images. Built with Flask, SQLAlchemy, FFmpeg, and modern CSS.

## Features

- **Secure User Authentication**: Register, login, and logout with bcrypt password hashing
- **Project Management**: Create, view, and delete video projects
- **Audio + Image Upload**: Support for MP3, WAV, AAC, OGG, FLAC, M4A, WMA audio and PNG, JPG, GIF, WEBP, BMP images
- **Automatic Video Generation**:
  - Calculates image display duration based on audio length
  - Smooth crossfade transitions between images
  - Center-crop resize to maintain aspect ratio (1280x720)
  - Merges original audio with generated video
- **Background Processing**: Non-blocking video generation with status polling
- **Responsive UI**: Clean, modern interface that works on desktop and mobile
- **File Management**: Automatic cleanup when deleting projects

## Prerequisites

**FFmpeg must be installed on your system.** This app uses FFmpeg directly (no MoviePy dependency).

### Windows
1. Download FFmpeg from https://ffmpeg.org/download.html (Windows builds by BtbN or gyan.dev)
2. Extract the zip
3. Add the `bin` folder to your system PATH
4. Open a new CMD/PowerShell and verify: `ffmpeg -version`

### macOS
```bash
brew install ffmpeg
```

### Linux
```bash
sudo apt update && sudo apt install ffmpeg
```

## Quick Start

1. **Install Python 3.8 or higher**

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**:
   ```bash
   python app.py
   ```

4. **Open your browser** and go to `http://localhost:5000`

## Project Structure

```
flask_video_app/
├── app.py              # Application entry point
├── config.py           # Configuration settings
├── extensions.py       # Flask extensions (DB, Login, Bcrypt, CSRF)
├── models.py           # Database models (User, VideoProject, ProjectImage)
├── routes.py           # All application routes
├── video_utils.py      # Video generation engine using FFmpeg subprocess
├── requirements.txt    # Python dependencies
├── static/
│   └── css/
│       └── style.css   # Modern responsive stylesheet
├── templates/          # Jinja2 HTML templates
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── new_project.html
│   ├── processing.html
│   └── result.html
└── uploads/            # File storage (auto-created)
    ├── audio/
    ├── images/
    └── output/
```

## How It Works

1. **Register/Login**: Create an account or sign in
2. **New Project**: Enter a title, upload one audio file, and select multiple images
3. **Processing**: The app calculates how long each image should display based on the audio duration, then generates a 1280x720 MP4 with smooth crossfade transitions in the background
4. **Download**: Preview the video in the browser and download the high-quality MP4 file

## Configuration

Edit `config.py` to customize:
- `VIDEO_RESOLUTION`: Output video dimensions (default: 1280x720)
- `VIDEO_FPS`: Frames per second (default: 24)
- `VIDEO_TRANSITION_SECONDS`: Crossfade duration between images (default: 0.5s)
- `MAX_CONTENT_LENGTH`: Maximum upload size (default: 100MB)

## Notes

- This app uses **FFmpeg directly via subprocess** — no MoviePy, no imageio, no pkg_resources issues.
- Video generation runs in a background thread so the UI remains responsive.
- The SQLite database (`app.db`) is created automatically on first run.
- All uploaded files are stored in the `uploads/` directory and cleaned up when projects are deleted.
