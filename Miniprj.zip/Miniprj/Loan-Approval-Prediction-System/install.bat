@echo off
REM ============================================================
REM Loan Approval Prediction System - Windows Installer
REM ============================================================

echo.
echo ============================================================
echo    LOAN APPROVAL PREDICTION SYSTEM - WINDOWS INSTALLER
echo ============================================================
echo.

REM Check for Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.11+ from https://python.org
    pause
    exit /b 1
)

echo [OK] Python detected.

REM Create virtual environment
if exist "venv" (
    echo [WARN] Virtual environment exists. Removing...
    rmdir /s /q "venv"
)

echo [INFO] Creating virtual environment...
python -m venv venv

echo [INFO] Activating virtual environment...
call venv\Scripts\activate.bat

echo [INFO] Upgrading pip...
python -m pip install --upgrade pip

echo [INFO] Installing dependencies...
pip install -r requirements.txt

echo.
echo [SUCCESS] Installation complete!
echo.
echo [INFO] Starting Streamlit application...
echo.

REM Launch using python -m to avoid PATH issues
python -m streamlit run app.py

pause
