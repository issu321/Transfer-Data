"""Verify the enterprise twin interconnection system."""
import sys
import os

def main():
    print("=" * 70)
    print("ENTERPRISE TWIN INTERCONNECTION VERIFICATION")
    print("=" * 70)
    
    try:
        from app import app
        print("[OK] App imports successfully")
    except Exception as e:
        print(f"[FAIL] App import failed: {e}")
        sys.exit(1)
    
    with app.app_context():
        from database.db import db
        from sqlalchemy import inspect
        
        # Check tables
        insp = inspect(db.engine)
        tables = insp.get_table_names()
        print(f"[INFO] Database has {len(tables)} tables")
        
        required_tables = [
            'custom_twins', 'custom_twin_records', 'twin_links', 'twin_audit_logs',
            'companies', 'departments', 'employees', 'customers', 'suppliers',
            'inventory', 'financial_records', 'branches', 'projects', 'users',
            'notifications', 'analytics', 'audit_logs', 'activity_logs'
        ]
        
        missing = [t for t in required_tables if t not in tables]
        if missing:
            print(f"[WARN] Missing tables: {missing}")
        else:
            print("[OK] All required tables exist")
        
        # Check custom twin model fields
        from database.models.custom_twin import CustomTwin, CustomTwinRecord, TwinLink, TwinAuditLog
        from database.models.department import Department
        from database.models.employee import Employee
        from database.models.company import Company
        
        # Test CustomTwin model
        twin_cols = [c.name for c in CustomTwin.__table__.columns]
        print(f"\n[INFO] CustomTwin columns: {len(twin_cols)}")
        enterprise_cols = ['linked_entity_type', 'linked_entity_id', 'parent_twin_id',
                          'cross_references', 'automation_rules', 'impact_config',
                          'auto_sync', 'sync_interval']
        for col in enterprise_cols:
            if col in twin_cols:
                print(f"  [OK] {col}")
            else:
                print(f"  [MISSING] {col}")
        
        # Check TwinService
        try:
            from services.twin_service import TwinService
            methods = [m for m in dir(TwinService) if not m.startswith('_')]
            print(f"\n[OK] TwinService loaded with {len(methods)} public methods")
            print(f"  Methods: {', '.join(methods[:10])}...")
        except Exception as e:
            print(f"[FAIL] TwinService import failed: {e}")
            sys.exit(1)
        
        # Test propagation
        print("\n[TEST] Testing TwinService.propagate_record...")
        try:
            result = TwinService.propagate_record(None, None, 'on_create', None)
            print(f"  [OK] propagate_record called (result: {result})")
        except Exception as e:
            print(f"  [OK] propagate_record raised expected error: {e}")
        
        # Check company data
        companies = Company.query.all()
        print(f"\n[INFO] Companies in database: {len(companies)}")
        for company in companies:
            print(f"  - {company.company_name} (ID: {company.id})")
            
            depts = Department.query.filter_by(company_id=company.id).all()
            emps = Employee.query.filter_by(company_id=company.id).count()
            twins = CustomTwin.query.filter_by(company_id=company.id).count()
            print(f"    Departments: {len(depts)}, Employees: {emps}, Twins: {twins}")
        
        print("\n" + "=" * 70)
        print("VERIFICATION COMPLETE")
        print("=" * 70)

if __name__ == '__main__':
    main()