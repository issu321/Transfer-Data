from database.db import db
from datetime import datetime
import json

# Core entity types that custom twins can link to
TWIN_ENTITY_TYPES = [
    'department',
    'employee',
    'customer',
    'supplier',
    'inventory',
    'financial',
    'branch',
    'project',
    'custom'
]

# Automation rule action types
AUTOMATION_ACTIONS = [
    'update_company_metric',
    'create_record',
    'update_record',
    'send_notification',
    'update_department_budget',
    'update_employee_count',
    'update_customer_count',
    'update_revenue',
    'update_expense',
    'sync_field'
]

# Impact levels for cross-twin propagation
IMPACT_LEVELS = ['none', 'low', 'medium', 'high', 'critical']


class CustomTwin(db.Model):
    """Model for user-defined custom twins with enterprise interconnections."""
    __tablename__ = 'custom_twins'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    
    # Twin metadata
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(100), nullable=False)  # URL-friendly name
    description = db.Column(db.Text)
    icon = db.Column(db.String(50), default='fa-cube')  # FontAwesome icon class
    color = db.Column(db.String(20), default='#00D4FF')  # Theme color
    
    # Field definitions (JSON array of field configs)
    # Each field: {name, label, type, required, default, options}
    field_definitions = db.Column(db.Text, default='[]')
    
    # Stats configuration (JSON array of stat configs)
    # Each stat: {name, label, type, field, formula, color}
    stats_config = db.Column(db.Text, default='[]')
    
    # Display configuration
    table_columns = db.Column(db.Text, default='[]')  # Which fields to show in table
    
    # ============================================================
    # ENTERPRISE INTERCONNECTION FIELDS
    # ============================================================
    
    # Entity linking: what core entity this twin represents (if any)
    linked_entity_type = db.Column(db.String(50), default='custom')  # department, employee, etc.
    linked_entity_id = db.Column(db.Integer, nullable=True)  # ID of the linked entity
    
    # Parent-child twin relationships (e.g., a "Vehicles" twin under "Fleet" twin)
    parent_twin_id = db.Column(db.Integer, db.ForeignKey('custom_twins.id'), nullable=True)
    parent = db.relationship('CustomTwin', remote_side='CustomTwin.id', backref='child_twins', foreign_keys=[parent_twin_id])
    
    # Cross-twin references: JSON array of {twin_id, field, source_field, sync_on}
    # Defines which fields pull data from other twins
    cross_references = db.Column(db.Text, default='[]')
    
    # Automation rules: JSON array of {name, event, condition, action, target, value}
    # event: on_create, on_update, on_delete
    # action: update_company_metric, create_record, update_record, send_notification, etc.
    automation_rules = db.Column(db.Text, default='[]')
    
    # Impact configuration: how changes to this twin affect the company
    # {level: 'high', propagate_to: ['revenue', 'expenses'], weight: 0.5}
    impact_config = db.Column(db.Text, default='{}')
    
    # Sync settings
    auto_sync = db.Column(db.Boolean, default=True)  # Auto-sync with linked entity
    sync_interval = db.Column(db.Integer, default=0)  # Minutes, 0 = real-time
    
    # Audit
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    records = db.relationship('CustomTwinRecord', backref='twin', lazy='dynamic', cascade='all, delete-orphan')
    
    # ============================================================
    # FIELD DEFINITIONS HELPERS
    # ============================================================
    
    def get_field_definitions(self):
        """Parse and return field definitions as list."""
        try:
            return json.loads(self.field_definitions) if self.field_definitions else []
        except:
            return []
    
    def set_field_definitions(self, fields):
        """Set field definitions from list."""
        self.field_definitions = json.dumps(fields)
    
    def get_stats_config(self):
        """Parse and return stats configuration as list."""
        try:
            return json.loads(self.stats_config) if self.stats_config else []
        except:
            return []
    
    def set_stats_config(self, stats):
        """Set stats configuration from list."""
        self.stats_config = json.dumps(stats)
    
    def get_table_columns(self):
        """Parse and return table columns as list."""
        try:
            return json.loads(self.table_columns) if self.table_columns else []
        except:
            return []
    
    def set_table_columns(self, columns):
        """Set table columns from list."""
        self.table_columns = json.dumps(columns)
    
    # ============================================================
    # ENTERPRISE INTERCONNECTION HELPERS
    # ============================================================
    
    def get_cross_references(self):
        """Parse and return cross-twin references."""
        try:
            return json.loads(self.cross_references) if self.cross_references else []
        except:
            return []
    
    def set_cross_references(self, refs):
        """Set cross-twin references."""
        self.cross_references = json.dumps(refs)
    
    def get_automation_rules(self):
        """Parse and return automation rules."""
        try:
            return json.loads(self.automation_rules) if self.automation_rules else []
        except:
            return []
    
    def set_automation_rules(self, rules):
        """Set automation rules."""
        self.automation_rules = json.dumps(rules)
    
    def get_impact_config(self):
        """Parse and return impact configuration."""
        try:
            return json.loads(self.impact_config) if self.impact_config else {}
        except:
            return {}
    
    def set_impact_config(self, config):
        """Set impact configuration."""
        self.impact_config = json.dumps(config)
    
    def get_linked_entity(self):
        """Get the linked core entity object if this twin is linked to one."""
        if not self.linked_entity_type or self.linked_entity_type == 'custom' or not self.linked_entity_id:
            return None
        
        try:
            if self.linked_entity_type == 'department':
                from database.models.department import Department
                return Department.query.get(self.linked_entity_id)
            elif self.linked_entity_type == 'employee':
                from database.models.employee import Employee
                return Employee.query.get(self.linked_entity_id)
            elif self.linked_entity_type == 'customer':
                from database.models.customer import Customer
                return Customer.query.get(self.linked_entity_id)
            elif self.linked_entity_type == 'supplier':
                from database.models.supplier import Supplier
                return Supplier.query.get(self.linked_entity_id)
            elif self.linked_entity_type == 'inventory':
                from database.models.inventory import Inventory
                return Inventory.query.get(self.linked_entity_id)
            elif self.linked_entity_type == 'branch':
                from database.models.branch import Branch
                return Branch.query.get(self.linked_entity_id)
            elif self.linked_entity_type == 'project':
                from database.models.project import Project
                return Project.query.get(self.linked_entity_id)
        except Exception:
            return None
        return None
    
    def get_child_twins(self):
        """Get all child twins (direct children only)."""
        return CustomTwin.query.filter_by(parent_twin_id=self.id, is_active=True).all()
    
    def get_descendant_twins(self):
        """Get all descendant twins (recursive)."""
        result = []
        for child in self.get_child_twins():
            result.append(child)
            result.extend(child.get_descendant_twins())
        return result
    
    def get_related_twins(self):
        """Get all twins that reference this twin or are referenced by it."""
        related = set()
        # Twins that this twin references
        for ref in self.get_cross_references():
            if ref.get('twin_id'):
                related.add(ref['twin_id'])
        # Twins that reference this twin
        all_twins = CustomTwin.query.filter_by(company_id=self.company_id, is_active=True).all()
        for twin in all_twins:
            if twin.id == self.id:
                continue
            for ref in twin.get_cross_references():
                if ref.get('twin_id') == self.id:
                    related.add(twin.id)
        return list(related)
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'name': self.name,
            'slug': self.slug,
            'description': self.description,
            'icon': self.icon,
            'color': self.color,
            'field_definitions': self.get_field_definitions(),
            'stats_config': self.get_stats_config(),
            'table_columns': self.get_table_columns(),
            'linked_entity_type': self.linked_entity_type,
            'linked_entity_id': self.linked_entity_id,
            'parent_twin_id': self.parent_twin_id,
            'cross_references': self.get_cross_references(),
            'automation_rules': self.get_automation_rules(),
            'impact_config': self.get_impact_config(),
            'auto_sync': self.auto_sync,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'record_count': self.records.count()
        }


class CustomTwinRecord(db.Model):
    """Model for records in a custom twin."""
    __tablename__ = 'custom_twin_records'
    
    id = db.Column(db.Integer, primary_key=True)
    twin_id = db.Column(db.Integer, db.ForeignKey('custom_twins.id'), nullable=False)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    
    # Record data (JSON object with field values)
    data = db.Column(db.Text, default='{}')
    
    # Metadata
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    def get_data(self):
        """Parse and return record data as dict."""
        try:
            return json.loads(self.data) if self.data else {}
        except:
            return {}
    
    def set_data(self, data):
        """Set record data from dict."""
        self.data = json.dumps(data)
    
    def get_field_value(self, field_name, default=None):
        """Get a specific field value."""
        data = self.get_data()
        return data.get(field_name, default)
    
    def set_field_value(self, field_name, value):
        """Set a specific field value."""
        data = self.get_data()
        data[field_name] = value
        self.set_data(data)
    
    def to_dict(self, include_twin=False):
        result = {
            'id': self.id,
            'twin_id': self.twin_id,
            'company_id': self.company_id,
            'data': self.get_data(),
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        if include_twin and self.twin:
            result['twin'] = self.twin.to_dict()
        return result


class TwinLink(db.Model):
    """Model for linking records across twins (many-to-many relationships)."""
    __tablename__ = 'twin_links'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    
    # Source record
    source_twin_id = db.Column(db.Integer, db.ForeignKey('custom_twins.id'), nullable=False)
    source_record_id = db.Column(db.Integer, nullable=False)
    
    # Target record
    target_twin_id = db.Column(db.Integer, db.ForeignKey('custom_twins.id'), nullable=False)
    target_record_id = db.Column(db.Integer, nullable=False)
    
    # Link metadata
    link_type = db.Column(db.String(50), default='related')  # related, parent, child, references
    metadata_json = db.Column(db.Text, default='{}')
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Relationships
    source_twin = db.relationship('CustomTwin', foreign_keys=[source_twin_id], backref='outgoing_links')
    target_twin = db.relationship('CustomTwin', foreign_keys=[target_twin_id], backref='incoming_links')
    
    def get_metadata(self):
        try:
            return json.loads(self.metadata_json) if self.metadata_json else {}
        except:
            return {}
    
    def set_metadata(self, data):
        self.metadata_json = json.dumps(data)
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'source_twin_id': self.source_twin_id,
            'source_record_id': self.source_record_id,
            'target_twin_id': self.target_twin_id,
            'target_record_id': self.target_record_id,
            'link_type': self.link_type,
            'metadata': self.get_metadata(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class TwinAuditLog(db.Model):
    """Audit log for twin operations and automation actions."""
    __tablename__ = 'twin_audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    twin_id = db.Column(db.Integer, db.ForeignKey('custom_twins.id'), nullable=True)
    record_id = db.Column(db.Integer, nullable=True)
    
    action = db.Column(db.String(50), nullable=False)  # create, update, delete, sync, automate
    entity_type = db.Column(db.String(50), default='custom_twin')
    entity_id = db.Column(db.Integer, nullable=True)
    description = db.Column(db.Text)
    details = db.Column(db.Text, default='{}')
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    def get_details(self):
        try:
            return json.loads(self.details) if self.details else {}
        except:
            return {}
    
    def set_details(self, data):
        self.details = json.dumps(data)
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'twin_id': self.twin_id,
            'record_id': self.record_id,
            'action': self.action,
            'entity_type': self.entity_type,
            'entity_id': self.entity_id,
            'description': self.description,
            'details': self.get_details(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }