from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

db = SQLAlchemy()

def init_db(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()
        try:
            seed_initial_data()
        except Exception as e:
            print(f"Seed warning: {e}")

def seed_initial_data():
    """Seed fallback data after schema creation.
    
    Only acts when the database is in a broken state: a company exists
    but no user can log into it (e.g. users table was lost to a corrupt
    DB file). A fresh install keeps the normal /setup wizard flow.
    """
    from database.models.user import User
    from database.models.company import Company

    if Company.query.first() is None:
        # Fresh install - the /setup wizard will create company + admin.
        return

    if User.query.first() is None:
        # Company exists but nobody can log in - create a recovery admin.
        recovery = User(
            username='admin',
            email='admin@businessimulator.com',
            first_name='System',
            last_name='Administrator',
            role='Admin',
            is_admin=True,
            is_active=True,
        )
        recovery.set_password('Admin@123')
        db.session.add(recovery)
        db.session.commit()
        print("[SEED] No users found for existing company - created recovery admin "
              "(username: admin / password: Admin@123 - change it after login!)")