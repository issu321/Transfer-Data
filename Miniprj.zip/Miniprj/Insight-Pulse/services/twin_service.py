"""
TWIN INTERCONNECTION SERVICE - Enterprise Twin Orchestration

This service handles the interconnection between custom twins and the core
business entities. It provides:
- Cross-twin data propagation
- Automation rule execution
- Company metric updates
- Entity linking sync
- Audit logging
- Impact propagation
"""

from database.db import db
from database.models.custom_twin import (
    CustomTwin, CustomTwinRecord, TwinLink, TwinAuditLog,
    TWIN_ENTITY_TYPES, AUTOMATION_ACTIONS, IMPACT_LEVELS
)
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.financial import FinancialRecord
from database.models.notification import Notification
from sqlalchemy import func
from datetime import datetime
import json
import logging

logger = logging.getLogger(__name__)


class TwinService:
    """Enterprise twin interconnection and automation service."""
    
    # ============================================================
    # AUDIT LOGGING
    # ============================================================
    
    @staticmethod
    def log_action(company_id, action, description, twin_id=None, record_id=None,
                   entity_type='custom_twin', entity_id=None, details=None, user_id=None):
        """Create an audit log entry for twin operations."""
        try:
            log = TwinAuditLog(
                company_id=company_id,
                twin_id=twin_id,
                record_id=record_id,
                action=action,
                entity_type=entity_type,
                entity_id=entity_id,
                description=description,
                created_by=user_id
            )
            if details:
                log.set_details(details)
            db.session.add(log)
        except Exception as e:
            logger.error(f"Failed to create audit log: {e}")
    
    # ============================================================
    # CROSS-TWIN DATA PROPAGATION
    # ============================================================
    
    @staticmethod
    def propagate_record(twin, record, event='on_create', user_id=None):
        """
        Propagate a record change to all related twins and linked entities.
        This is the core interconnection engine.
        """
        company_id = twin.company_id
        record_data = record.get_data()
        results = []
        
        # 1. Propagate to child twins (parent-child hierarchy)
        for child in twin.get_child_twins():
            try:
                result = TwinService._propagate_to_child(child, twin, record, event, user_id)
                if result:
                    results.append(result)
            except Exception as e:
                logger.error(f"Error propagating to child twin {child.id}: {e}")
        
        # 2. Propagate via cross-references
        for ref in twin.get_cross_references():
            try:
                result = TwinService._propagate_via_reference(twin, record, ref, event, user_id)
                if result:
                    results.append(result)
            except Exception as e:
                logger.error(f"Error propagating via reference: {e}")
        
        # 3. Execute automation rules
        for rule in twin.get_automation_rules():
            try:
                result = TwinService._execute_automation_rule(twin, record, rule, event, user_id)
                if result:
                    results.append(result)
            except Exception as e:
                logger.error(f"Error executing automation rule: {e}")
        
        # 4. Apply impact to company metrics
        try:
            impact = TwinService._apply_company_impact(twin, record, event, user_id)
            if impact:
                results.append(impact)
        except Exception as e:
            logger.error(f"Error applying company impact: {e}")
        
        # 5. Recompute authoritative company metrics from real source data
        #    (employees, customers, financial records, twin network) so the
        #    dashboard always reflects reality, not incremental deltas.
        try:
            summary = TwinService.recalculate_company_metrics(company_id)
            if summary:
                results.append({'type': 'company_metrics_recalculated', 'summary': summary})
        except Exception as e:
            logger.error(f"Error recalculating company metrics: {e}")
        
        # 6. Sync with linked entity if applicable
        if twin.linked_entity_type and twin.linked_entity_type != 'custom' and twin.auto_sync:
            try:
                result = TwinService._sync_linked_entity(twin, record, event, user_id)
                if result:
                    results.append(result)
            except Exception as e:
                logger.error(f"Error syncing linked entity: {e}")
        
        # Log the propagation
        TwinService.log_action(
            company_id=company_id,
            action='propagate',
            description=f"Propagated {event} for record {record.id} in twin '{twin.name}'",
            twin_id=twin.id,
            record_id=record.id,
            details={'results': results},
            user_id=user_id
        )
        
        return results
    
    @staticmethod
    def _propagate_to_child(child_twin, parent_twin, record, event, user_id):
        """Propagate data to a child twin."""
        # Check if child has a field that maps to parent's data
        child_fields = child_twin.get_field_definitions()
        parent_data = record.get_data()
        
        # Look for a field in child that references parent
        for field in child_fields:
            if field.get('type') == 'reference' or field.get('source') == 'parent':
                # Create a record in child twin if it doesn't exist
                field_name = field.get('name')
                parent_id_field = field.get('parent_id_field', 'parent_id')
                
                existing = CustomTwinRecord.query.filter_by(
                    twin_id=child_twin.id,
                    company_id=child_twin.company_id
                ).filter(
                    CustomTwinRecord.data.contains(json.dumps({parent_id_field: record.id}))
                ).first()
                
                if not existing:
                    new_record = CustomTwinRecord(
                        twin_id=child_twin.id,
                        company_id=child_twin.company_id,
                        created_by=user_id
                    )
                    new_data = {parent_id_field: record.id}
                    # Copy mapped fields
                    for child_field in child_fields:
                        if child_field.get('source_field') and child_field['source_field'] in parent_data:
                            new_data[child_field['name']] = parent_data[child_field['source_field']]
                    new_record.set_data(new_data)
                    db.session.add(new_record)
                    return {
                        'type': 'child_created',
                        'twin_id': child_twin.id,
                        'twin_name': child_twin.name,
                        'record_id': new_record.id
                    }
        return None
    
    @staticmethod
    def _propagate_via_reference(twin, record, ref, event, user_id):
        """Propagate data via a cross-twin reference."""
        target_twin_id = ref.get('twin_id')
        if not target_twin_id:
            return None
        
        target_twin = CustomTwin.query.get(target_twin_id)
        if not target_twin:
            return None
        
        # Get the field mapping
        source_field = ref.get('source_field')
        target_field = ref.get('field')
        sync_on = ref.get('sync_on', 'create')
        
        if event != sync_on and sync_on != 'all':
            return None
        
        record_data = record.get_data()
        if source_field and source_field in record_data:
            value = record_data[source_field]
            
            # Find or create the target record
            target_records = CustomTwinRecord.query.filter_by(
                twin_id=target_twin_id,
                company_id=twin.company_id
            ).all()
            
            # Try to match by the reference field
            for target_record in target_records:
                target_data = target_record.get_data()
                if target_data.get(target_field) == value:
                    # Update the target record
                    if ref.get('update_fields'):
                        for field_map in ref['update_fields']:
                            src = field_map.get('source')
                            dst = field_map.get('target')
                            if src in record_data:
                                target_data[dst] = record_data[src]
                        target_record.set_data(target_data)
                        return {
                            'type': 'reference_updated',
                            'twin_id': target_twin_id,
                            'twin_name': target_twin.name,
                            'record_id': target_record.id
                        }
            
            # Create new record in target twin
            new_record = CustomTwinRecord(
                twin_id=target_twin_id,
                company_id=twin.company_id,
                created_by=user_id
            )
            new_data = {target_field: value}
            if ref.get('update_fields'):
                for field_map in ref['update_fields']:
                    src = field_map.get('source')
                    dst = field_map.get('target')
                    if src in record_data:
                        new_data[dst] = record_data[src]
            new_record.set_data(new_data)
            db.session.add(new_record)
            return {
                'type': 'reference_created',
                'twin_id': target_twin_id,
                'twin_name': target_twin.name,
                'record_id': new_record.id
            }
        
        return None
    
    # ============================================================
    # AUTOMATION RULES
    # ============================================================
    
    @staticmethod
    def _execute_automation_rule(twin, record, rule, event, user_id):
        """Execute a single automation rule."""
        rule_event = rule.get('event', 'on_create')
        if rule_event != event and rule_event != 'all':
            return None
        
        # Check condition
        condition = rule.get('condition')
        if condition and not TwinService._evaluate_condition(record, condition):
            return None
        
        action = rule.get('action')
        target = rule.get('target')
        value = rule.get('value')
        
        result = None
        
        if action == 'update_company_metric':
            result = TwinService._action_update_company_metric(twin, record, target, value, user_id)
        elif action == 'create_record':
            result = TwinService._action_create_record(twin, record, target, value, user_id)
        elif action == 'update_record':
            result = TwinService._action_update_record(twin, record, target, value, user_id)
        elif action == 'send_notification':
            result = TwinService._action_send_notification(twin, record, target, value, user_id)
        elif action == 'update_department_budget':
            result = TwinService._action_update_department_budget(twin, record, target, value, user_id)
        elif action == 'update_employee_count':
            result = TwinService._action_update_employee_count(twin, record, target, value, user_id)
        elif action == 'update_customer_count':
            result = TwinService._action_update_customer_count(twin, record, target, value, user_id)
        elif action == 'update_revenue':
            result = TwinService._action_update_revenue(twin, record, target, value, user_id)
        elif action == 'update_expense':
            result = TwinService._action_update_expense(twin, record, target, value, user_id)
        elif action == 'sync_field':
            result = TwinService._action_sync_field(twin, record, target, value, user_id)
        
        if result:
            # Log the automation action
            TwinService.log_action(
                company_id=twin.company_id,
                action='automate',
                description=f"Automation rule '{rule.get('name', 'unnamed')}' executed: {action}",
                twin_id=twin.id,
                record_id=record.id,
                details={'rule': rule, 'result': result},
                user_id=user_id
            )
        
        return result
    
    @staticmethod
    def _evaluate_condition(record, condition):
        """Evaluate a condition against a record's data."""
        try:
            field = condition.get('field')
            operator = condition.get('operator', 'equals')
            value = condition.get('value')
            
            record_value = record.get_data().get(field)
            
            if operator == 'equals':
                return str(record_value) == str(value)
            elif operator == 'not_equals':
                return str(record_value) != str(value)
            elif operator == 'greater_than':
                return float(record_value or 0) > float(value)
            elif operator == 'less_than':
                return float(record_value or 0) < float(value)
            elif operator == 'contains':
                return str(value) in str(record_value or '')
            elif operator == 'not_contains':
                return str(value) not in str(record_value or '')
            elif operator == 'is_empty':
                return not record_value
            elif operator == 'is_not_empty':
                return bool(record_value)
            return True
        except:
            return True
    
    @staticmethod
    def _action_update_company_metric(twin, record, target, value, user_id):
        """Update a company metric based on record data."""
        company = Company.query.get(twin.company_id)
        if not company:
            return None
        
        metric = target or 'annual_revenue'
        amount = float(value or 0)
        
        # Try to get value from record if value is a field name
        if value and isinstance(value, str) and value in record.get_data():
            amount = float(record.get_data().get(value, 0) or 0)
        
        if hasattr(company, metric):
            current = getattr(company, metric) or 0
            setattr(company, metric, current + amount)
            return {
                'type': 'company_metric_updated',
                'metric': metric,
                'old_value': current,
                'new_value': current + amount
            }
        return None
    
    @staticmethod
    def _action_create_record(twin, record, target, value, user_id):
        """Create a record in another twin."""
        target_twin_id = target
        if not target_twin_id:
            return None
        
        target_twin = CustomTwin.query.get(int(target_twin_id))
        if not target_twin:
            return None
        
        new_record = CustomTwinRecord(
            twin_id=target_twin.id,
            company_id=twin.company_id,
            created_by=user_id
        )
        
        # Build data from value mapping
        data = {}
        if value and isinstance(value, dict):
            for field_name, source in value.items():
                if source in record.get_data():
                    data[field_name] = record.get_data()[source]
                else:
                    data[field_name] = source
        
        new_record.set_data(data)
        db.session.add(new_record)
        return {
            'type': 'record_created',
            'twin_id': target_twin.id,
            'twin_name': target_twin.name,
            'record_id': new_record.id
        }
    
    @staticmethod
    def _action_update_record(twin, record, target, value, user_id):
        """Update a record in another twin."""
        target_record_id = target
        if not target_record_id:
            return None
        
        target_record = CustomTwinRecord.query.get(int(target_record_id))
        if not target_record:
            return None
        
        data = target_record.get_data()
        if value and isinstance(value, dict):
            for field_name, source in value.items():
                if source in record.get_data():
                    data[field_name] = record.get_data()[source]
                else:
                    data[field_name] = source
        
        target_record.set_data(data)
        return {
            'type': 'record_updated',
            'record_id': target_record.id
        }
    
    @staticmethod
    def _action_send_notification(twin, record, target, value, user_id):
        """Send a notification."""
        try:
            notification = Notification(
                company_id=twin.company_id,
                title=value.get('title', f'{twin.name} Update') if isinstance(value, dict) else f'{twin.name} Update',
                message=value.get('message', f'New record added to {twin.name}') if isinstance(value, dict) else f'New record added to {twin.name}',
                notification_type='twin_automation',
                user_id=user_id
            )
            db.session.add(notification)
            return {
                'type': 'notification_sent',
                'title': notification.title
            }
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
            return None
    
    @staticmethod
    def _action_update_department_budget(twin, record, target, value, user_id):
        """Update a department's budget."""
        dept_id = target
        if not dept_id:
            return None
        
        dept = Department.query.get(int(dept_id))
        if not dept:
            return None
        
        amount = 0.0
        try:
            amount = float(value or 0)
        except (ValueError, TypeError):
            amount = 0.0
        if value and isinstance(value, str) and value in record.get_data():
            amount = float(record.get_data().get(value, 0) or 0)
        
        dept.budget = (dept.budget or 0) + amount
        return {
            'type': 'department_budget_updated',
            'department_id': dept.id,
            'new_budget': dept.budget
        }
    
    @staticmethod
    def _action_update_employee_count(twin, record, target, value, user_id):
        """Update company employee count."""
        company = Company.query.get(twin.company_id)
        if not company:
            return None
        
        delta = 0
        try:
            delta = int(value or 0)
        except (ValueError, TypeError):
            delta = 0
        if value and isinstance(value, str) and value in record.get_data():
            delta = int(record.get_data().get(value, 0) or 0)
        
        company.employee_count = (company.employee_count or 0) + delta
        return {
            'type': 'employee_count_updated',
            'new_count': company.employee_count
        }
    
    @staticmethod
    def _action_update_customer_count(twin, record, target, value, user_id):
        """Update company customer count."""
        company = Company.query.get(twin.company_id)
        if not company:
            return None
        
        delta = 0
        try:
            delta = int(value or 0)
        except (ValueError, TypeError):
            delta = 0
        if value and isinstance(value, str) and value in record.get_data():
            delta = int(record.get_data().get(value, 0) or 0)
        
        company.customer_count = (company.customer_count or 0) + delta
        return {
            'type': 'customer_count_updated',
            'new_count': company.customer_count
        }
    
    @staticmethod
    def _action_update_revenue(twin, record, target, value, user_id):
        """Create a revenue financial record."""
        company_id = twin.company_id
        amount = 0.0
        try:
            amount = float(value or 0)
        except (ValueError, TypeError):
            amount = 0.0
        if value and isinstance(value, str) and value in record.get_data():
            amount = float(record.get_data().get(value, 0) or 0)
        
        if amount <= 0:
            return None
        
        financial = FinancialRecord(
            company_id=company_id,
            transaction_date=datetime.utcnow().date(),
            transaction_type='revenue',
            category=target or 'Twin Automation',
            subcategory=twin.name,
            amount=amount,
            description=f'Automated revenue from {twin.name} twin',
            created_by=user_id
        )
        db.session.add(financial)
        return {
            'type': 'revenue_created',
            'amount': amount,
            'record_id': financial.id
        }
    
    @staticmethod
    def _action_update_expense(twin, record, target, value, user_id):
        """Create an expense financial record."""
        company_id = twin.company_id
        amount = 0.0
        try:
            amount = float(value or 0)
        except (ValueError, TypeError):
            amount = 0.0
        if value and isinstance(value, str) and value in record.get_data():
            amount = float(record.get_data().get(value, 0) or 0)
        
        if amount <= 0:
            return None
        
        financial = FinancialRecord(
            company_id=company_id,
            transaction_date=datetime.utcnow().date(),
            transaction_type='expense',
            category=target or 'Twin Automation',
            subcategory=twin.name,
            amount=amount,
            description=f'Automated expense from {twin.name} twin',
            created_by=user_id
        )
        db.session.add(financial)
        return {
            'type': 'expense_created',
            'amount': amount,
            'record_id': financial.id
        }
    
    @staticmethod
    def _action_sync_field(twin, record, target, value, user_id):
        """Sync a field value to a linked entity."""
        if not twin.linked_entity_type or twin.linked_entity_type == 'custom':
            return None
        
        entity = twin.get_linked_entity()
        if not entity:
            return None
        
        field_name = target
        source_field = value
        
        if field_name and source_field and source_field in record.get_data():
            setattr(entity, field_name, record.get_data()[source_field])
            return {
                'type': 'field_synced',
                'entity_type': twin.linked_entity_type,
                'entity_id': entity.id,
                'field': field_name
            }
        return None
    
    # ============================================================
    # COMPANY IMPACT
    # ============================================================
    
    @staticmethod
    def _apply_company_impact(twin, record, event, user_id):
        """Apply the twin's impact configuration to company metrics."""
        impact = twin.get_impact_config()
        if not impact or impact.get('level', 'none') == 'none':
            return None
        
        company = Company.query.get(twin.company_id)
        if not company:
            return None
        
        level = impact.get('level', 'low')
        weight = float(impact.get('weight', 0.5))
        propagate_to = impact.get('propagate_to', [])
        company_id = twin.company_id
        
        # Calculate impact factor based on level
        level_factors = {'low': 0.1, 'medium': 0.25, 'high': 0.5, 'critical': 1.0}
        factor = level_factors.get(level, 0.1) * weight
        
        results = []
        
        # Preferred amount field (configurable per twin), then auto-detect
        preferred_field = impact.get('field')
        amount_fields = ([preferred_field] if preferred_field else []) + ['amount', 'value', 'revenue', 'total']

        # Apply to revenue - create a real FinancialRecord so the impact is
        # traceable in the finance module AND survives the recalculation below
        # (which rebuilds annual_revenue from FinancialRecord rows; the old
        # direct attribute mutation was immediately clobbered by it).
        if 'revenue' in propagate_to:
            record_data = record.get_data()
            for field_name in amount_fields:
                if field_name in record_data:
                    try:
                        amount = float(record_data[field_name] or 0)
                        if event == 'on_create' and amount > 0:
                            financial = FinancialRecord(
                                company_id=company_id,
                                transaction_date=datetime.utcnow().date(),
                                transaction_type='revenue',
                                category='Twin Impact',
                                subcategory=twin.name,
                                amount=amount * factor,
                                description=f"Impact revenue from {twin.name} twin (record #{record.id})",
                                created_by=user_id
                            )
                            db.session.add(financial)
                        elif event == 'on_delete' and amount > 0:
                            # Reverse the impact revenue created on_create
                            TwinService._remove_impact_financial_record(
                                company_id, twin.name, amount * factor, 'revenue', record.id
                            )
                        results.append({
                            'type': 'revenue_impact',
                            'amount': amount * factor
                        })
                    except (ValueError, TypeError):
                        pass
                    break
        
        # Apply to expenses - create a real FinancialRecord so the impact
        # is traceable in the finance twin (Company has no total_expenses
        # column - writing that attribute was silently discarded before).
        if 'expenses' in propagate_to:
            record_data = record.get_data()
            for field_name in ([preferred_field] if preferred_field else []) + ['amount', 'value', 'expense', 'cost', 'total']:
                if field_name in record_data:
                    try:
                        amount = float(record_data[field_name] or 0)
                        if event == 'on_create' and amount > 0:
                            financial = FinancialRecord(
                                company_id=company_id,
                                transaction_date=datetime.utcnow().date(),
                                transaction_type='expense',
                                category='Twin Impact',
                                subcategory=twin.name,
                                amount=amount,
                                description=f"Impact expense from {twin.name} twin (record #{record.id})",
                                created_by=user_id
                            )
                            db.session.add(financial)
                        elif event == 'on_delete' and amount > 0:
                            # Reverse the impact expense created on_create
                            TwinService._remove_impact_financial_record(
                                company_id, twin.name, amount, 'expense', record.id
                            )
                        results.append({
                            'type': 'expense_impact',
                            'amount': amount
                        })
                    except (ValueError, TypeError):
                        pass
                    break
        
        # Apply to employee count
        if 'employees' in propagate_to:
            record_data = record.get_data()
            for field_name in ['employee_count', 'headcount', 'employees']:
                if field_name in record_data:
                    try:
                        count = int(record_data[field_name] or 0)
                        if event == 'on_create':
                            company.employee_count = (company.employee_count or 0) + count
                        elif event == 'on_delete':
                            company.employee_count = max(0, (company.employee_count or 0) - count)
                        results.append({
                            'type': 'employee_impact',
                            'count': count
                        })
                    except (ValueError, TypeError):
                        pass
                    break
        
        # Apply to customer count
        if 'customers' in propagate_to:
            record_data = record.get_data()
            for field_name in ['customer_count', 'customers']:
                if field_name in record_data:
                    try:
                        count = int(record_data[field_name] or 0)
                        if event == 'on_create':
                            company.customer_count = (company.customer_count or 0) + count
                        elif event == 'on_delete':
                            company.customer_count = max(0, (company.customer_count or 0) - count)
                        results.append({
                            'type': 'customer_impact',
                            'count': count
                        })
                    except (ValueError, TypeError):
                        pass
                    break
        
        return results if results else None
    
    @staticmethod
    def _remove_impact_financial_record(company_id, twin_name, amount, tx_type, record_id):
        """Remove the auto-created financial record that a twin impact created
        earlier (used to reverse on_create impacts when a record is deleted).
        Matches both impact-expense variants: category='Twin Impact' (from
        _apply_company_impact) and subcategory=twin_name (from automation
        rules like update_expense)."""
        try:
            base = FinancialRecord.query.filter_by(
                company_id=company_id,
                transaction_type=tx_type,
                amount=amount
            )
            # 1st choice: the record tagged with this twin + source record id
            candidate = base.filter(
                FinancialRecord.description.like(f"%record #{record_id}%")
            ).first()
            if not candidate:
                # 2nd: automation-rule record (subcategory = twin name)
                candidate = base.filter(
                    FinancialRecord.subcategory == twin_name
                ).order_by(FinancialRecord.created_at.desc()).first()
            if not candidate:
                # 3rd: generic impact record
                candidate = base.filter(
                    FinancialRecord.category == 'Twin Impact'
                ).order_by(FinancialRecord.created_at.desc()).first()
            if candidate:
                db.session.delete(candidate)
                return True
        except Exception as e:
            logger.error(f"Failed to remove impact financial record: {e}")
        return False
    
    # ============================================================
    # COMPANY METRICS RECALCULATION
    # ============================================================
    
    @staticmethod
    def recalculate_company_metrics(company_id):
        """Recompute authoritative company metrics from real source data.
        
        Called after every twin propagation so the company dashboard always
        mirrors reality: headcounts come from actual Employee/Customer rows,
        revenue/expenses from actual FinancialRecord rows, and the health
        score is a composite of financial + organizational + twin-network
        signals.
        """
        company = Company.query.get(company_id)
        if not company:
            return None
        
        # Headcounts from source-of-truth tables
        employees = Employee.query.filter_by(company_id=company_id, status='active').count()
        customers = Customer.query.filter_by(company_id=company_id, status='active').count()
        
        # Financial totals from real transactions
        total_revenue = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue'
        ).scalar() or 0
        total_expenses = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense'
        ).scalar() or 0
        
        # Department aggregate payroll (real employee salaries)
        dept_payroll = db.session.query(
            func.sum(Employee.salary + func.coalesce(Employee.benefits_cost, 0))
        ).filter(
            Employee.company_id == company_id,
            Employee.status == 'active'
        ).scalar() or 0
        
        # Twin network signals
        twin_count = CustomTwin.query.filter_by(company_id=company_id, is_active=True).count()
        record_count = db.session.query(func.count(CustomTwinRecord.id)).join(
            CustomTwin, CustomTwinRecord.twin_id == CustomTwin.id
        ).filter(
            CustomTwin.company_id == company_id,
            CustomTwinRecord.is_active.is_(True)
        ).scalar() or 0
        
        # Persist authoritative values (never regress a manual entry to zero)
        if employees:
            company.employee_count = employees
        if customers:
            company.customer_count = customers
        if total_revenue:
            company.annual_revenue = total_revenue
        
        # Composite health score (0-100)
        margin = ((total_revenue - total_expenses) / total_revenue * 100) if total_revenue > 0 else 0
        score = 50
        if margin > 20:
            score += 15
        elif margin > 10:
            score += 5
        elif margin < 0:
            score -= 10
        if employees >= 10:
            score += 10
        elif employees >= 1:
            score += 5
        if customers >= 10:
            score += 10
        elif customers >= 1:
            score += 5
        if twin_count:
            score += 5  # digital twin coverage adds operational visibility
        if record_count >= 10:
            score += 5
        company.health_score = min(100, max(0, score))
        
        return {
            'employee_count': company.employee_count,
            'customer_count': company.customer_count,
            'annual_revenue': company.annual_revenue,
            'total_revenue': total_revenue,
            'total_expenses': total_expenses,
            'department_payroll': dept_payroll,
            'margin_pct': round(margin, 2),
            'twin_count': twin_count,
            'twin_record_count': record_count,
            'health_score': company.health_score
        }
    
    # ============================================================
    # ENTITY LINKING SYNC
    # ============================================================
    
    @staticmethod
    def _sync_linked_entity(twin, record, event, user_id):
        """Sync record data to the linked core entity."""
        entity = twin.get_linked_entity()
        if not entity:
            return None
        
        record_data = record.get_data()
        field_definitions = twin.get_field_definitions()
        
        # Map twin fields to entity attributes
        synced_fields = []
        for field in field_definitions:
            field_name = field.get('name')
            entity_field = field.get('entity_field')
            
            if entity_field and field_name in record_data:
                try:
                    setattr(entity, entity_field, record_data[field_name])
                    synced_fields.append(entity_field)
                except Exception as e:
                    logger.error(f"Failed to sync field {entity_field}: {e}")
        
        if synced_fields:
            return {
                'type': 'entity_synced',
                'entity_type': twin.linked_entity_type,
                'entity_id': entity.id,
                'fields': synced_fields
            }
        return None
    
    # ============================================================
    # RECORD LINKING
    # ============================================================
    
    @staticmethod
    def link_records(company_id, source_twin_id, source_record_id,
                     target_twin_id, target_record_id, link_type='related',
                     metadata=None, user_id=None):
        """Create a link between two records in different twins."""
        # Check if link already exists
        existing = TwinLink.query.filter_by(
            company_id=company_id,
            source_twin_id=source_twin_id,
            source_record_id=source_record_id,
            target_twin_id=target_twin_id,
            target_record_id=target_record_id
        ).first()
        
        if existing:
            return existing
        
        link = TwinLink(
            company_id=company_id,
            source_twin_id=source_twin_id,
            source_record_id=source_record_id,
            target_twin_id=target_twin_id,
            target_record_id=target_record_id,
            link_type=link_type,
            created_by=user_id
        )
        if metadata:
            link.set_metadata(metadata)
        
        db.session.add(link)
        return link
    
    @staticmethod
    def get_record_links(company_id, twin_id, record_id):
        """Get all links for a specific record."""
        outgoing = TwinLink.query.filter_by(
            company_id=company_id,
            source_twin_id=twin_id,
            source_record_id=record_id
        ).all()
        
        incoming = TwinLink.query.filter_by(
            company_id=company_id,
            target_twin_id=twin_id,
            target_record_id=record_id
        ).all()
        
        return {
            'outgoing': [l.to_dict() for l in outgoing],
            'incoming': [l.to_dict() for l in incoming]
        }
    
    # ============================================================
    # TWIN HEALTH & SYNC STATUS
    # ============================================================
    
    @staticmethod
    def get_twin_health(twin):
        """Calculate the health and sync status of a twin."""
        company_id = twin.company_id
        
        # Count records
        record_count = CustomTwinRecord.query.filter_by(
            twin_id=twin.id, company_id=company_id, is_active=True
        ).count()
        
        # Count related twins
        related_count = len(twin.get_related_twins())
        
        # Count child twins
        child_count = len(twin.get_child_twins())
        
        # Check automation rules
        automation_count = len(twin.get_automation_rules())
        
        # Check cross references
        reference_count = len(twin.get_cross_references())
        
        # Calculate health score (0-100)
        health_score = 50  # Base score
        
        if record_count > 0:
            health_score += 10
        if related_count > 0:
            health_score += 10
        if child_count > 0:
            health_score += 10
        if automation_count > 0:
            health_score += 10
        if reference_count > 0:
            health_score += 10
        
        health_score = min(100, health_score)
        
        # Determine status
        if health_score >= 80:
            status = 'excellent'
        elif health_score >= 60:
            status = 'good'
        elif health_score >= 40:
            status = 'fair'
        else:
            status = 'poor'
        
        return {
            'twin_id': twin.id,
            'twin_name': twin.name,
            'record_count': record_count,
            'related_twins': related_count,
            'child_twins': child_count,
            'automation_rules': automation_count,
            'cross_references': reference_count,
            'health_score': health_score,
            'status': status,
            'linked_entity': twin.linked_entity_type if twin.linked_entity_type != 'custom' else None,
            'auto_sync': twin.auto_sync
        }
    
    @staticmethod
    def get_company_twin_network(company_id):
        """Get the full twin network for a company."""
        twins = CustomTwin.query.filter_by(company_id=company_id, is_active=True).all()
        
        network = {
            'twins': [],
            'connections': [],
            'total_twins': len(twins),
            'total_records': 0,
            'total_automations': 0
        }
        
        for twin in twins:
            twin_data = twin.to_dict()
            twin_data['health'] = TwinService.get_twin_health(twin)
            network['twins'].append(twin_data)
            network['total_records'] += twin_data['record_count']
            network['total_automations'] += len(twin.get_automation_rules())
            
            # Add parent-child connections
            if twin.parent_twin_id:
                network['connections'].append({
                    'source': twin.parent_twin_id,
                    'target': twin.id,
                    'type': 'parent_child'
                })
            
            # Add cross-reference connections
            for ref in twin.get_cross_references():
                if ref.get('twin_id'):
                    network['connections'].append({
                        'source': twin.id,
                        'target': ref['twin_id'],
                        'type': 'reference'
                    })
        
        return network