"""Migration script to add enterprise twin interconnection schema."""
import sqlite3
import os

DB_PATH = os.path.join('instance', 'business_simulator.db')

def migrate():
    print("=" * 60)
    print("MIGRATING DATABASE FOR TWIN INTERCONNECTION")
    print("=" * 60)
    
    if not os.path.exists(DB_PATH):
        print(f"[ERROR] Database not found at {DB_PATH}")
        return False
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Check current columns in custom_twins
    cursor.execute("PRAGMA table_info(custom_twins)")
    columns = [row[1] for row in cursor.fetchall()]
    print(f"\n[INFO] Current custom_twins columns: {columns}")
    
    # Add new columns if they don't exist
    new_columns = {
        'linked_entity_type': "VARCHAR(50) DEFAULT 'custom'",
        'linked_entity_id': 'INTEGER',
        'parent_twin_id': 'INTEGER',
        'cross_references': "TEXT DEFAULT '[]'",
        'automation_rules': "TEXT DEFAULT '[]'",
        'impact_config': "TEXT DEFAULT '{}'",
        'auto_sync': 'BOOLEAN DEFAULT 1',
        'sync_interval': 'INTEGER DEFAULT 0',
    }
    
    for col, col_type in new_columns.items():
        if col not in columns:
            print(f"  [ADD] Adding column: {col}")
            cursor.execute(f"ALTER TABLE custom_twins ADD COLUMN {col} {col_type}")
        else:
            print(f"  [SKIP] Column already exists: {col}")
    
    # Create twin_links table
    print("\n[INFO] Creating twin_links table...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS twin_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            source_twin_id INTEGER NOT NULL,
            source_record_id INTEGER NOT NULL,
            target_twin_id INTEGER NOT NULL,
            target_record_id INTEGER NOT NULL,
            link_type VARCHAR(50) DEFAULT 'related',
            metadata_json TEXT DEFAULT '{}',
            created_at DATETIME,
            created_by INTEGER,
            FOREIGN KEY (company_id) REFERENCES companies (id),
            FOREIGN KEY (source_twin_id) REFERENCES custom_twins (id),
            FOREIGN KEY (target_twin_id) REFERENCES custom_twins (id)
        )
    """)
    print("  [OK] twin_links table ready")
    
    # Create twin_audit_logs table
    print("[INFO] Creating twin_audit_logs table...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS twin_audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            twin_id INTEGER,
            record_id INTEGER,
            action VARCHAR(50) NOT NULL,
            entity_type VARCHAR(50) DEFAULT 'custom_twin',
            entity_id INTEGER,
            description TEXT,
            details TEXT DEFAULT '{}',
            created_at DATETIME,
            created_by INTEGER,
            FOREIGN KEY (company_id) REFERENCES companies (id),
            FOREIGN KEY (twin_id) REFERENCES custom_twins (id)
        )
    """)
    print("  [OK] twin_audit_logs table ready")
    
    conn.commit()
    
    # Verify
    cursor.execute("PRAGMA table_info(custom_twins)")
    new_cols = [row[1] for row in cursor.fetchall()]
    print(f"\n[INFO] Updated custom_twins columns: {new_cols}")
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('twin_links', 'twin_audit_logs')")
    tables = [row[0] for row in cursor.fetchall()]
    print(f"[INFO] New tables created: {tables}")
    
    conn.close()
    print("\n" + "=" * 60)
    print("MIGRATION COMPLETE")
    print("=" * 60)
    return True

if __name__ == '__main__':
    migrate()