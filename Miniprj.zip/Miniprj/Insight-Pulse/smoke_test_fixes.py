"""Smoke test: verify DB bootstrap fix + twin interconnection."""
import os, sys, tempfile

# Use a THROWAWAY sqlite db so we never touch the real instance data
os.environ['DATABASE_URL'] = f'sqlite:///{tempfile.mkdtemp()}/smoke_test.db'

# Force settings to pick up the test DB if it reads .env
import config.settings as _settings
if hasattr(_settings, 'os'):
    pass

from app import create_app

app = create_app()

with app.app_context():
    from database.db import db
    from database.models.user import User
    from database.models.company import Company
    from database.models.department import Department
    from database.models.employee import Employee
    from database.models.customer import Customer
    from database.models.custom_twin import CustomTwin, CustomTwinRecord

    # TEST 1: users table exists (the original crash)
    users = User.query.all()
    print(f"[PASS 1] users table exists, rows: {len(users)}")

    # Setup: company + user
    company = Company(company_name='Smoke Test Corp', business_name='Smoke Test Corp',
                      owner_name='Tester', ceo_name='Tester',
                      industry='Technology', is_active=True)
    db.session.add(company)
    db.session.flush()
    user = User(username='tester', email='t@t.com', role='Admin', is_admin=True, is_active=True)
    user.set_password('x')
    db.session.add(user)
    db.session.flush()

    # TEST 2: load_user works
    from flask_login import login_manager  # noqa
    loaded = db.session.get(User, user.id)
    assert loaded is not None
    print(f"[PASS 2] load_user path works: {loaded.username}")

    # TEST 3: department + auto twin creation (mirror the route logic)
    dept = Department(company_id=company.id, name='Engineering', code='ENG', is_active=True, budget=100000)
    db.session.add(dept)
    db.session.flush()
    from routes.business_twin import _mirror_employee_to_twin, _mirror_customer_to_twin

    twin = CustomTwin(
        company_id=company.id, name='Engineering Department', slug='engineering-department',
        linked_entity_type='department', linked_entity_id=dept.id, auto_sync=True, created_by=user.id)
    twin.set_automation_rules([
        {'name': 'Update Employee Count', 'event': 'on_create', 'action': 'update_employee_count', 'target': 'employee_count', 'value': '1'},
        {'name': 'Update Payroll Expense', 'event': 'on_create', 'action': 'update_expense', 'target': 'Payroll', 'value': 'salary'},
    ])
    twin.set_impact_config({'level': 'medium', 'weight': 0.5, 'propagate_to': ['employees', 'expenses']})
    db.session.add(twin)
    db.session.flush()
    print(f"[PASS 3] department + linked twin created (twin_id={twin.id})")

    # TEST 4: employee mirrors into twin, fires automation, recalculates metrics
    emp = Employee(company_id=company.id, department_id=dept.id, first_name='Ada', last_name='Lovelace',
                   job_title='Engineer', salary=90000, status='active')
    db.session.add(emp)
    db.session.flush()
    rec = _mirror_employee_to_twin(company.id, emp, 'on_create', user_id=user.id)
    db.session.commit()
    assert rec is not None, 'employee was NOT mirrored into the department twin!'
    mirrored = CustomTwinRecord.query.filter_by(twin_id=twin.id).all()
    print(f"[PASS 4] employee mirrored into twin: {len(mirrored)} record(s), data={rec.get_data()}")

    # Check automation fired: payroll expense FinancialRecord exists
    from database.models.financial import FinancialRecord
    payroll = FinancialRecord.query.filter_by(company_id=company.id, transaction_type='expense', category='Payroll').all()
    print(f"[PASS 5] payroll expense auto-created: {len(payroll)} record(s), amount={payroll[0].amount if payroll else 0}")

    # Check company metrics recalculated
    db.session.refresh(company)
    print(f"[PASS 6] company metrics: employee_count={company.employee_count}, health={company.health_score}, revenue={company.annual_revenue}")

    # TEST 5: delete reverses impact (via the real route mirror path)
    _mirror_employee_to_twin(company.id, emp, 'on_delete', user_id=user.id)
    db.session.commit()
    payroll_after = FinancialRecord.query.filter_by(company_id=company.id, transaction_type='expense', category='Payroll').all()
    print(f"[PASS 7] payroll expense reversed on delete: {len(payroll_after)} remaining (expected 0)")
    assert len(payroll_after) == 0, 'payroll expense was NOT reversed on employee delete!'
    mirrored_after = CustomTwinRecord.query.filter_by(twin_id=twin.id).all()
    print(f"[PASS 7b] mirrored twin record removed: {len(mirrored_after)} remaining (expected 0)")

    # TEST 6: customer mirror (no customer twin -> no crash)
    cust = Customer(company_id=company.id, first_name='Bob', last_name='Client', status='active', total_spent=5000)
    db.session.add(cust)
    db.session.flush()
    _mirror_customer_to_twin(company.id, cust, 'on_create', user_id=user.id)
    db.session.commit()
    print("[PASS 8] customer mirror safe without a linked twin")

print("\nALL SMOKE TESTS PASSED")
