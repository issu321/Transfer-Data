"""Test the enterprise twin interconnection system."""
import sys

def main():
    print("=" * 60)
    print("TWIN INTERCONNECTION SYSTEM TEST")
    print("=" * 60)
    
    from app import app
    from database.db import db
    from database.models.company import Company
    from database.models.custom_twin import CustomTwin, CustomTwinRecord, TwinLink, TwinAuditLog
    from services.twin_service import TwinService
    
    with app.app_context():
        # TEST 1: Database Schema
        print("\n[TEST 1] Database Schema")
        company = Company.query.first()
        assert company, "No company found"
        print(f"  [OK] Company: {company.company_name}")
        
        # TEST 2: Create a custom twin
        print("\n[TEST 2] Create Custom Twin")
        twin = CustomTwin(
            company_id=company.id,
            name="Test Assets",
            slug="test-assets",
            description="Test twin for verification",
            icon="fa-box",
            color="#00D4FF",
            linked_entity_type="custom",
            auto_sync=True
        )
        twin.set_field_definitions([
            {'name': 'asset_name', 'label': 'Asset Name', 'type': 'text', 'required': True, 'default': ''},
            {'name': 'value', 'label': 'Value', 'type': 'number', 'required': False, 'default': 0},
            {'name': 'status', 'label': 'Status', 'type': 'text', 'required': False, 'default': 'active'}
        ])
        twin.set_stats_config([
            {'name': 'total_assets', 'label': 'Total Assets', 'type': 'count', 'field': '', 'color': '#00D4FF'},
            {'name': 'total_value', 'label': 'Total Value', 'type': 'sum', 'field': 'value', 'color': '#10B981'}
        ])
        twin.set_automation_rules([{
            'name': 'Update Company Revenue',
            'event': 'on_create',
            'action': 'update_company_metric',
            'target': 'annual_revenue',
            'value': 'value'
        }])
        twin.set_impact_config({
            'level': 'medium',
            'weight': 0.5,
            'propagate_to': ['revenue']
        })
        db.session.add(twin)
        db.session.commit()
        print(f"  [OK] Created twin ID: {twin.id}")
        
        # TEST 3: Add records to twin
        print("\n[TEST 3] Add Records to Twin")
        record1 = CustomTwinRecord(twin_id=twin.id, company_id=company.id)
        record1.set_data({'asset_name': 'Laptop', 'value': 1500, 'status': 'active'})
        db.session.add(record1)
        db.session.commit()
        print(f"  [OK] Added record 1: {record1.get_data()}")
        
        results = TwinService.propagate_record(twin, record1, 'on_create', None)
        db.session.commit()
        print(f"  [OK] Propagation results: {len(results) if results else 0} actions")
        
        # TEST 4: Twin Health
        print("\n[TEST 4] Twin Health")
        health = TwinService.get_twin_health(twin)
        print(f"  [OK] Health: {health}")
        assert health['record_count'] >= 1
        assert health['health_score'] >= 50
        print(f"  [OK] Health score: {health['health_score']}/100 ({health['status']})")
        
        # TEST 5: Network
        print("\n[TEST 5] Twin Network")
        network = TwinService.get_company_twin_network(company.id)
        print(f"  [OK] Total twins: {network['total_twins']}")
        print(f"  [OK] Total records: {network['total_records']}")
        print(f"  [OK] Total automations: {network['total_automations']}")
        assert network['total_twins'] >= 1
        
        # TEST 6: Record Linking
        print("\n[TEST 6] Record Linking")
        record2 = CustomTwinRecord(twin_id=twin.id, company_id=company.id)
        record2.set_data({'asset_name': 'Desk', 'value': 500, 'status': 'active'})
        db.session.add(record2)
        db.session.commit()
        
        link = TwinService.link_records(
            company.id, twin.id, record1.id, twin.id, record2.id,
            link_type='related', metadata={'note': 'test link'}, user_id=None
        )
        db.session.commit()
        print(f"  [OK] Created link: {link.id if link else 'exists'}")
        
        links = TwinService.get_record_links(company.id, twin.id, record1.id)
        print(f"  [OK] Outgoing links: {len(links['outgoing'])}")
        print(f"  [OK] Incoming links: {len(links['incoming'])}")
        
        # TEST 7: Audit Logging
        print("\n[TEST 7] Audit Logging")
        TwinService.log_action(
            company_id=company.id,
            action='test',
            description='Test audit log entry',
            twin_id=twin.id,
            record_id=record1.id,
            details={'test': True}
        )
        db.session.commit()
        audit_count = TwinAuditLog.query.filter_by(company_id=company.id).count()
        print(f"  [OK] Audit log entries: {audit_count}")
        assert audit_count >= 1
        
        # TEST 8: Cleanup
        print("\n[TEST 8] Cleanup")
        TwinLink.query.filter_by(company_id=company.id).delete()
        TwinAuditLog.query.filter_by(company_id=company.id).delete()
        CustomTwinRecord.query.filter_by(twin_id=twin.id).delete()
        db.session.delete(twin)
        db.session.commit()
        print("  [OK] Test data cleaned up")
        
        print("\n" + "=" * 60)
        print("ALL TESTS PASSED!")
        print("=" * 60)
        return True

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f"\n[FAIL] Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)