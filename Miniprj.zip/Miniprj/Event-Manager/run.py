"""Entry point — start the application with `python run.py`."""

from app import create_app

app = create_app()

if __name__ == '__main__':
    # debug=True gives auto-reload during development.
    # Remember to set debug=False for a real deployment.
    app.run(debug=True)