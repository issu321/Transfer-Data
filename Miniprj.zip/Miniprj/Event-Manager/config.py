"""Application configuration.

Uses SQLite by default so the project works with zero database setup.
The database file is created automatically the first time the app runs
(or when you run seed.py).
"""

import os

# Project root directory (the folder containing this file)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Folder used for the SQLite database file
INSTANCE_DIR = os.path.join(BASE_DIR, 'instance')
if not os.path.exists(INSTANCE_DIR):
    os.makedirs(INSTANCE_DIR)


class Config:
    # Change this in production!
    SECRET_KEY = os.environ.get('SECRET_KEY', 'college-event-manager-secret-key')

    # SQLite database file stored inside the instance folder.
    # You can switch to MySQL later by setting DATABASE_URL:
    #   mysql+pymysql://username:password@localhost/event_management
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        'sqlite:///' + os.path.join(INSTANCE_DIR, 'event_management.db')
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False