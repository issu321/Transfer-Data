"""Seed script — creates all tables and fills them with realistic demo data.

Usage:
    python seed.py

Demo accounts created:
    Admin  -> admin@college.edu / admin123
    Student-> student@college.edu / student123
"""

import random
from datetime import date, datetime, timedelta

from faker import Faker
from werkzeug.security import generate_password_hash

from app import create_app, db
from app.models import Attendance, Event, Notification, Registration, User, Venue

fake = Faker()
Faker.seed(42)
random.seed(42)

ADMIN_EMAIL = 'admin@college.edu'
ADMIN_PASSWORD = 'admin123'
DEMO_STUDENT_EMAIL = 'student@college.edu'
DEMO_STUDENT_PASSWORD = 'student123'

EVENT_SEEDS = [
    ('Tech Fest', 'Technical', 'The annual flagship technical festival with project exhibitions, coding challenges and innovation stalls.'),
    ('Python Workshop', 'Workshop', 'Hands-on workshop covering Python fundamentals, functions, file handling and a mini project.'),
    ('Coding Competition', 'Competition', 'Inter-college competitive programming contest. Solve algorithmic problems and win prizes.'),
    ('Cultural Fest', 'Cultural', 'A vibrant celebration of music, dance, drama and fashion by student performers.'),
    ('Sports Meet', 'Sports', 'Annual inter-department sports meet with cricket, football, basketball and athletics.'),
    ('Web Development Workshop', 'Workshop', 'Learn HTML, CSS, JavaScript and Flask basics by building a complete website.'),
    ('AI Seminar', 'Seminar', 'Industry experts discuss the future of AI, machine learning careers and real-world applications.'),
    ('Robotics Competition', 'Competition', 'Build and race autonomous robots. Teams of up to three students.'),
    ('Music & Dance Night', 'Cultural', 'An evening of live music, band performances and dance showcases.'),
    ('Hackathon 2026', 'Technical', 'A 24-hour coding marathon to build creative solutions for real campus problems.'),
    ('Photography Contest', 'Competition', 'Showcase your photography skills. Themes: campus life, nature and portraits.'),
    ('Annual College Fest', 'Fest', 'The grand college fest with celebrity performances, food stalls and cultural programmes.'),
]
VENUE_SEEDS = [
    ('Main Auditorium', 'Block A, Ground Floor', 300, 'AC auditorium with stage and projector.'),
    ('Seminar Hall 1', 'Block B, First Floor', 120, 'AC seminar hall with whiteboard and projector.'),
    ('Seminar Hall 2', 'Block B, Second Floor', 100, 'Seminar hall with audio-visual facilities.'),
    ('Computer Lab 1', 'Block C, Ground Floor', 60, '60 systems with internet access.'),
    ('Computer Lab 2', 'Block C, First Floor', 60, '60 systems with latest software installed.'),
    ('Sports Ground', 'Main Campus', 500, 'Open ground for outdoor sports and large events.'),
    ('Mini Auditorium', 'Block A, First Floor', 150, 'Small auditorium for workshops and seminars.'),
    ('Open Air Theatre', 'Main Campus', 400, 'Open air stage for cultural performances.'),
]


def seed():
    app = create_app()
    with app.app_context():
        # Fresh start: drop and recreate all tables.
        db.drop_all()
        db.create_all()
        print('[*] Database tables created.')

        # ---------------- Admin ----------------
        admin = User(
            name='Event Coordinator',
            email=ADMIN_EMAIL,
            password_hash=generate_password_hash(ADMIN_PASSWORD),
            role='admin',
        )
        db.session.add(admin)

        # ---------------- Students ----------------
        students = [User(
            name='Demo Student',
            email=DEMO_STUDENT_EMAIL,
            password_hash=generate_password_hash(DEMO_STUDENT_PASSWORD),
            role='student',
        )]
        db.session.add_all(students)

        for _ in range(14):
            students.append(User(
                name=fake.name(),
                email=fake.unique.email(),
                password_hash=generate_password_hash(fake.password()),
                role='student',
            ))
        db.session.add_all(students)
        db.session.commit()
        print(f'[*] Created 1 admin and {len(students)} students.')

        # ---------------- Venues ----------------
        venues = [Venue(name=n, location=l, capacity=c, description=d)
                  for n, l, c, d in VENUE_SEEDS]
        db.session.add_all(venues)
        db.session.commit()
        print(f'[*] Created {len(venues)} venues.')

        student_ids = [s.id for s in students]

        # ---------------- Events ----------------
        events = []
        today = date.today()
        for index, (title, category, description) in enumerate(EVENT_SEEDS):
            days = -20 + index * 6 + random.randint(-2, 2)   # spreads past/future
            event_date = today + timedelta(days=days)
            if index == 3:          # one event today -> 'Ongoing'
                event_date = today

            if event_date < today:
                status = 'Completed'
            elif event_date == today:
                status = 'Ongoing'
            else:
                status = 'Upcoming'

            # Deadline is before the event date (usually in the future).
            deadline = event_date - timedelta(days=random.randint(1, 8))

            # Realistic event time window (e.g. 10:00 - 16:00).
            start_time = datetime.strptime(
                fake.time(pattern='%H:%M'), '%H:%M').time()
            end_limit = min(23, start_time.hour + random.randint(1, 4))
            end_time = start_time.replace(hour=end_limit)

            events.append(Event(
                title=title,
                description=description,
                event_date=event_date,
                start_time=start_time,
                end_time=end_time,
                venue_id=random.choice(venues).id,
                category=category,
                capacity=random.choice([40, 60, 80, 100, 150, 200]),
                registration_deadline=deadline,
                status='Cancelled' if index == 2 else status,   # one cancelled sample
            ))
        db.session.add_all(events)
        db.session.commit()
        print(f'[*] Created {len(events)} events.')


# ---------------- Registrations ----------------
        for event in events:
            if event.status == 'Cancelled':
                continue
            possible = list(student_ids)
            random.shuffle(possible)
            limit = min(event.capacity, random.randint(8, 40))
            for student_id in possible[:limit]:
                db.session.add(Registration(
                    event_id=event.id,
                    student_id=student_id,
                    status='Confirmed',
                ))
        db.session.commit()
        print('[*] Created sample registrations.')

        # ---------------- Attendance ----------------
        for event in events:
            if event.status in ('Completed', 'Ongoing'):
                for reg in Registration.query.filter_by(
                    event_id=event.id, status='Confirmed'
                ).all():
                    db.session.add(Attendance(
                        event_id=event.id,
                        student_id=reg.student_id,
                        status=random.choices(
                            ['Present', 'Absent'], weights=[85, 15]
                        )[0],
                    ))
        db.session.commit()
        print('[*] Created sample attendance records.')

        # ---------------- Notifications ----------------
        samples = [
            ('Venue Changed', 'Kindly note that the venue for this event has been changed. Check the event details page.'),
            ('Registration Deadline Extended', 'Good news! The registration deadline has been extended by a few days. Register soon.'),
            ('Event Starts Tomorrow', 'Reminder: this event starts tomorrow. Please reach the venue 15 minutes early.'),
            ('Event Postponed', 'Due to unavoidable reasons, this event has been postponed. New date will be announced soon.'),
            ("Don't Miss Out", 'Seats are filling fast. Register now to secure your spot!'),
        ]
        for event in events[:6]:
            title, message = random.choice(samples)
            db.session.add(Notification(
                event_id=event.id,
                title=title,
                message=message,
            ))
        db.session.commit()
        print('[*] Created sample notifications.')

        print()
        print('=' * 55)
        print('Seeding complete! Demo credentials:')
        print(f'  Admin   -> {ADMIN_EMAIL} / {ADMIN_PASSWORD}')
        print(f'  Student -> {DEMO_STUDENT_EMAIL} / {DEMO_STUDENT_PASSWORD}')
        print('=' * 55)


if __name__ == '__main__':
    seed()