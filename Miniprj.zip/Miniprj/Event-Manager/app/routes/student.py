"""Student dashboard, my-events and notifications routes."""

from flask import Blueprint, render_template
from flask_login import current_user, login_required

from app.models import Attendance, Event, Notification, Registration
from app.decorators import student_required

student_bp = Blueprint('student', __name__)


@student_bp.route('/student/dashboard')
@login_required
@student_required
def dashboard():
    upcoming = Event.query.filter(
        Event.status.in_(['Upcoming', 'Ongoing'])
    ).order_by(Event.event_date.asc()).limit(6).all()

    my_events = Event.query.join(Registration).filter(
        Registration.student_id == current_user.id,
        Registration.status == 'Confirmed',
    ).order_by(Event.event_date.asc()).all()

    total_registrations = Registration.query.filter_by(
        student_id=current_user.id, status='Confirmed'
    ).count()

    recent_notifications = Notification.query.order_by(
        Notification.created_at.desc()
    ).limit(5).all()

    registered_ids = {
        r.event_id for r in Registration.query.filter_by(
            student_id=current_user.id, status='Confirmed'
        ).all()
    }

    return render_template(
        'student/dashboard.html',
        upcoming=upcoming,
        my_events=my_events,
        total_registrations=total_registrations,
        notifications=recent_notifications,
        registered_ids=registered_ids,
    )


@student_bp.route('/student/my-events')
@login_required
@student_required
def my_events():
    """Registrations belonging to the logged-in student only."""
    registrations = Registration.query.filter_by(
        student_id=current_user.id
    ).order_by(Registration.registered_at.desc()).all()

    # Attendance status for each registration (may be None / not marked yet).
    attendance_map = {
        a.event_id: a.status for a in Attendance.query.filter_by(
            student_id=current_user.id
        ).all()
    }

    return render_template(
        'student/my_events.html',
        registrations=registrations,
        attendance_map=attendance_map,
    )


@student_bp.route('/student/notifications')
@login_required
@student_required
def notifications():
    notifications = Notification.query.order_by(
        Notification.created_at.desc()
    ).all()
    return render_template(
        'student/notifications.html', notifications=notifications
    )