"""Authentication routes: login, register, logout, profile."""

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user, logout_user
from werkzeug.security import check_password_hash, generate_password_hash

from app import db
from app.models import User

auth_bp = Blueprint('auth', __name__)


def dashboard_for(user):
    """Redirect users to the dashboard matching their role."""
    if user.is_admin():
        return redirect(url_for('admin.dashboard'))
    return redirect(url_for('student.dashboard'))


@auth_bp.route('/')
def index():
    """Guest visitors are sent to the login page."""
    if current_user.is_authenticated:
        return dashboard_for(current_user)
    return redirect(url_for('auth.login'))


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return dashboard_for(current_user)

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not email or not password:
            flash('Please enter your email and password.', 'warning')
            return render_template('login.html')

        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash(f'Welcome back, {user.name}!', 'success')
            return dashboard_for(user)

        flash('Invalid login credentials.', 'danger')

    return render_template('login.html')


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Student self registration. New users always get the 'student' role."""
    if current_user.is_authenticated:
        return dashboard_for(current_user)

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')

        if not name or not email or not password or not confirm:
            flash('All fields are required.', 'warning')
            return render_template('register.html')

        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('register.html')

        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return render_template('register.html')

        if User.query.filter_by(email=email).first():
            flash('An account with this email already exists.', 'danger')
            return render_template('register.html')

        user = User(
            name=name,
            email=email,
            password_hash=generate_password_hash(password),
            role='student',
        )
        db.session.add(user)
        db.session.commit()
        flash('Account created successfully! You can now login.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('register.html')


@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """Shared profile page for admins and students (update name / password)."""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        new_password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')

        if not name:
            flash('Name cannot be empty.', 'warning')
        else:
            current_user.name = name
            if new_password:
                if len(new_password) < 6:
                    flash('New password must be at least 6 characters long.', 'danger')
                    return render_template('profile.html')
                if new_password != confirm:
                    flash('New passwords do not match.', 'danger')
                    return render_template('profile.html')
                current_user.password_hash = generate_password_hash(new_password)
            db.session.commit()
            flash('Profile updated successfully.', 'success')
        return redirect(url_for('auth.profile'))

    return render_template('profile.html')