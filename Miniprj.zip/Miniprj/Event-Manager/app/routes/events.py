"""Student-facing event routes: browse events, view details, register/cancel."""

from datetime import date

from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app import db
from app.models import Attendance, Event, Registration

events_bp = Blueprint('events', __name__)

CATEGORIES = ['Technical', 'Cultural', 'Sports', 'Workshop', 'Seminar', 'Fest', 'Competition', 'Other']


@events_bp.route('/events')
@login_required
def event_list():
    """Upcoming events for students with search + category filter."""
    if current_user.is_admin():
        return redirect(url_for('admin.events'))

    query = request.args.get('q', '').strip()
    category = request.args.get('category', '').strip()

    events = Event.query.filter(Event.status.in_(['Upcoming', 'Ongoing']))
    if query:
        events = events.filter(Event.title.ilike(f'%{query}%'))
    if category:
        events = events.filter(Event.category == category)
    events = events.order_by(Event.event_date.asc()).all()

    # Sets used by the template to decide which button to show.
    registered_ids = {
        r.event_id for r in Registration.query.filter_by(
            student_id=current_user.id, status='Confirmed'
        ).all()
    }
    full_ids = {e.id for e in events if e.is_full()}
    closed_ids = {e.id for e in events if e.status == 'Cancelled' or e.deadline_passed()}

    return render_template(
        'student/events.html',
        events=events,
        categories=CATEGORIES,
        query=query,
        category=category,
        registered_ids=registered_ids,
        full_ids=full_ids,
        closed_ids=closed_ids,
    )


@events_bp.route('/events/<int:event_id>')
@login_required
def event_details(event_id):
    """Full public-style details page for a single event (student view)."""
    if current_user.is_admin():
        return redirect(url_for('admin.event_detail', event_id=event_id))

    event = Event.query.get_or_404(event_id)

    registration = Registration.query.filter_by(
        event_id=event.id, student_id=current_user.id
    ).first()
    registered = registration is not None and registration.status == 'Confirmed'

    my_attendance = Attendance.query.filter_by(
        event_id=event.id, student_id=current_user.id
    ).first()

    return render_template(
        'student/event_details.html',
        event=event,
        registered=registered,
        registration=registration,
        my_attendance=my_attendance,
    )


@events_bp.route('/events/<int:event_id>/register', methods=['POST'])
@login_required
def register_event(event_id):
    """Register the logged-in student for an event, with all checks."""
    if current_user.is_admin():
        abort(403)

    event = Event.query.get_or_404(event_id)
    existing = Registration.query.filter_by(
        event_id=event.id, student_id=current_user.id
    ).first()

    # 1. Already registered?
    if existing and existing.status == 'Confirmed':
        flash('You are already registered for this event.', 'warning')
        return redirect(url_for('events.event_details', event_id=event.id))

    if event.status in ('Completed', 'Cancelled'):
        flash('Registration is closed for this event.', 'danger')
    elif event.deadline_passed():
        flash('Registration deadline has passed.', 'danger')
    elif event.is_full():
        flash('Registration is full for this event.', 'danger')
    else:
        # 2. Re-register after cancel, or create a brand new registration.
        if existing:
            existing.status = 'Confirmed'
            flash('You have been re-registered for the event.', 'success')
        else:
            db.session.add(Registration(
                event_id=event.id, student_id=current_user.id, status='Confirmed'
            ))
            flash('Successfully registered for the event.', 'success')
        db.session.commit()
        return redirect(url_for('events.event_details', event_id=event.id))

    return redirect(url_for('events.event_details', event_id=event.id))


@events_bp.route('/events/<int:event_id>/cancel', methods=['POST'])
@login_required
def cancel_registration(event_id):
    """Let a student cancel their own registration."""
    if current_user.is_admin():
        abort(403)

    event = Event.query.get_or_404(event_id)
    registration = Registration.query.filter_by(
        event_id=event.id, student_id=current_user.id, status='Confirmed'
    ).first()

    if not registration:
        flash('No active registration found for this event.', 'warning')
    elif event.status in ('Completed', 'Cancelled'):
        flash('You cannot cancel registration for a completed or cancelled event.', 'danger')
    else:
        registration.status = 'Cancelled'
        db.session.commit()
        flash('Registration cancelled successfully.', 'success')

    return redirect(url_for('student.my_events'))