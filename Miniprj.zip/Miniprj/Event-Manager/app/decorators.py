"""Route protection helpers for role-based access control."""

from functools import wraps

from flask import abort, redirect, url_for
from flask_login import current_user


def admin_required(func):
    """Allow only logged-in admins/event coordinators."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if not current_user.is_admin():
            abort(403)
        return func(*args, **kwargs)
    return wrapper


def student_required(func):
    """Allow only logged-in students (never admins)."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if current_user.is_admin():
            abort(403)
        return func(*args, **kwargs)
    return wrapper