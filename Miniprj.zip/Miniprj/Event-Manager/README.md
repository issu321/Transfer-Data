# 🎓 College Event Management System

A simple, complete and fully functional web application for managing college
events — built with **Python Flask**, **Bootstrap 5**, **SQLAlchemy** and
**SQLite**. It is designed as an easy-to-understand academic (BCA) project that
can be explained confidently during a viva demonstration.

---

## 📌 Project Description

The system replaces the manual way of managing college events (notice boards,
paper forms, registers and spreadsheets) with one central web platform.

- **Admins / Event Coordinators** create and manage events, venues,
  registrations, participants, attendance and notifications, and generate reports.
- **Students** browse upcoming events, register online, cancel registrations,
  view notifications and check their own attendance.

---

## 🎯 Objectives

- Reduce paperwork and manual registers
- Avoid duplicate event registrations
- Keep organised participant records
- Make event information easily accessible
- Simplify event registration
- Track participation and attendance
- Improve communication through in-app notifications
- Generate useful event, participant and attendance reports

---

## ✨ Features

### Admin
- Dashboard with live statistics and **Plotly charts** (events by category,
  registrations per event — real database data)
- Create, edit, delete and view events
- Venue management (add, edit, delete)
- Registration management (view, cancel, restore, delete)
- Attendance management (mark Present/Absent, update later)
- Event notifications (create / delete)
- Reports with **CSV export**
- Student management (search, delete)
- Search + filters on events, registrations, students

### Student
- Register / login / logout
- Dashboard with upcoming events, my registered events and recent notifications
- Browse and search upcoming events with category filters
- Event details page with real-time registration status
- One-click event registration with automatic checks:
  - duplicate registration ✅ prevented
  - capacity full ✅ **"Registration Full"**
  - deadline passed ✅ **"Registration Closed"**
- Cancel own registration
- My Events page with registration + attendance status
- Notifications page

### Security
- Passwords **hashed** with Werkzeug (never stored in plaintext)
- Flask-Login sessions
- Role-based access control (admin vs student routes are protected)
- Students can only access their own registrations / attendance

---

## 🛠 Technology Stack

| Layer      | Technology                              |
|------------|-----------------------------------------|
| Backend    | Python, Flask                           |
| Database   | SQLite via SQLAlchemy ORM               |
| Auth       | Flask-Login + Werkzeug password hashing |
| Frontend   | HTML5, CSS3, Bootstrap 5, JavaScript    |
| Icons      | Font Awesome                            |
| Charts     | Plotly.js                               |
| Demo data  | Faker                                   |

> ⚙️ The app is **MySQL-ready**: set `DATABASE_URL` in `.env` to a
> `mysql+pymysql://user:pass@localhost/dbname` string and the same models will
> work against MySQL.

---

## 👥 User Roles

| Role   | Capabilities |
|--------|--------------|
| **Admin / Event Coordinator** | Full control of events, venues, registrations, attendance, notifications, reports and students |
| **Student**                  | View events, register, cancel, view notifications and own attendance |

---

## 🗄 Database Models

- **users** — name, email, password_hash, role (`admin` / `student`)
- **venues** — name, location, capacity, description
- **events** — title, description, date, times, venue, category, capacity,
  registration deadline, status
- **registrations** — event + student (unique together), status
- **attendance** — event + student (unique together), present/absent
- **notifications** — event, title, message

---

## 🚀 Installation & Running

### 1. Create and activate a virtual environment

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux / macOS
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Create the database and demo data

A SQLite database file is created automatically — no MySQL installation needed.

```bash
python seed.py
```

This creates all tables and fills them with demo records (events such as
**Tech Fest**, **Python Workshop**, **Coding Competition**, **Cultural Fest**,
**Sports Meet**, **Web Development Workshop**, **AI Seminar** …).

> To start with an empty database, simply skip `seed.py` (tables are created
> automatically on first run).

### 4. Run the application

```bash
python run.py
```

Open your browser at: **http://127.0.0.1:5000**

---

## 🔑 Demo Credentials

| Role    | Email                 | Password    |
|---------|-----------------------|-------------|
| Admin   | `admin@college.edu`   | `admin123`  |
| Student | `student@college.edu` | `student123`|

---

## 📂 Project Structure

```
college_event_management/
├── app/
│   ├── __init__.py         # app factory, db, login manager
│   ├── models.py           # SQLAlchemy models
│   ├── decorators.py       # admin_required / student_required
│   ├── routes/
│   │   ├── auth.py         # login, register, logout, profile
│   │   ├── events.py       # student event browsing + registration
│   │   ├── student.py      # student dashboard / my events / notifications
│   │   └── admin.py        # all admin modules
│   ├── templates/
│   │   ├── base.html
│   │   ├── login.html
│   │   ├── register.html
│   │   ├── profile.html
│   │   ├── partials/
│   │   ├── admin/          # dashboard, events, venues, attendance, reports...
│   │   ├── student/        # dashboard, events, my events, notifications
│   │   └── errors/         # 403, 404
│   └── static/
│       ├── css/style.css
│       └── js/app.js
├── instance/               # SQLite database lives here
├── seed.py                 # Faker demo data
├── config.py               # configuration (SQLite by default)
├── run.py                  # entry point
├── requirements.txt
└── README.md
```

---

## 🔮 Future Enhancements

- Email/SMS notifications
- Event feedback & ratings from students
- QR-code check-in for attendance
- Multiple coordinators per event
- Image uploads for events
- Deployment with Gunicorn + Nginx

---

## 📝 Notes

- No contact page or external website branding has been added — this is a
  focused academic project.
- All statistics and charts use **live database data**; nothing is hardcoded.
- Error pages (403 / 404) keep the same design and never expose raw Python
  errors.