/* ==========================================================================
   MindScan v2 — Interactive UI/UX & Theme Engine
   ========================================================================== */

(function () {
    'use strict';

    const html = document.documentElement;

    function getTheme() {
        return html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    }

    function applyThemeToPlotlyCharts(theme) {
        if (typeof Plotly === 'undefined') return;
        const isDark = theme === 'dark';
        const fontColor = isDark ? '#e0f2fe' : '#091424';
        const gridColor = isDark ? 'rgba(56, 189, 248, 0.16)' : 'rgba(14, 165, 233, 0.16)';

        document.querySelectorAll('.js-plotly-plot').forEach((plotEl) => {
            try {
                Plotly.relayout(plotEl, {
                    'font.color': fontColor,
                    'title.font.color': fontColor,
                    'paper_bgcolor': 'rgba(0,0,0,0)',
                    'plot_bgcolor': 'rgba(0,0,0,0)',
                    'xaxis.gridcolor': gridColor,
                    'yaxis.gridcolor': gridColor,
                    'xaxis.tickfont.color': fontColor,
                    'yaxis.tickfont.color': fontColor,
                    'polar.radialaxis.gridcolor': gridColor,
                    'polar.radialaxis.linecolor': gridColor,
                    'polar.radialaxis.tickfont.color': fontColor,
                    'polar.angularaxis.gridcolor': gridColor,
                    'polar.angularaxis.linecolor': gridColor,
                    'polar.angularaxis.tickfont.color': fontColor
                });
            } catch (e) {}
        });
    }

    function setTheme(theme, persistServer = true) {
        const next = theme === 'dark' ? 'dark' : 'light';
        html.setAttribute('data-theme', next);
        try { localStorage.setItem('mindscan-theme', next); } catch (e) {}

        document.querySelectorAll('input[name="theme"]').forEach((radio) => {
            radio.checked = radio.value === next;
        });

        applyThemeToPlotlyCharts(next);

        if (persistServer) {
            fetch('/api/theme', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ theme: next })
            }).catch(() => {});
        }
    }

    window.MindScanTheme = { getTheme, setTheme, applyThemeToPlotlyCharts };

    let loaderTimer = null;

    function formatBytes(bytes) {
        if (!bytes && bytes !== 0) return '';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / 1048576).toFixed(2) + ' MB';
    }

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, (m) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[m]));
    }

    function showLoader(options = {}) {
        const overlay = document.getElementById('global-loader');
        if (!overlay) return;

        const titleEl = document.getElementById('loader-title');
        const subEl = document.getElementById('loader-subtitle');
        const filesEl = document.getElementById('loader-files');
        const barEl = document.getElementById('loader-progress-bar');
        const pctEl = document.getElementById('loader-percent');
        const stepsWrap = document.getElementById('loader-steps');

        const stages = options.stages || [
            { text: 'Preparing secure workspace...', pct: 24, step: 0 },
            { text: 'Processing data...', pct: 62, step: 1 },
            { text: 'Finalizing view...', pct: 92, step: 3 }
        ];
        const files = options.files || [];

        if (titleEl) titleEl.textContent = options.title || 'Processing Request';
        if (stepsWrap) stepsWrap.style.display = options.showSteps === false ? 'none' : 'grid';

        if (filesEl) {
            if (files.length > 0) {
                filesEl.innerHTML = files
                    .map((f) => `<span class="loader-file-pill">${escapeHtml(f.name)} (${formatBytes(f.size)})</span>`)
                    .join('');
                filesEl.style.display = 'flex';
            } else {
                filesEl.innerHTML = '';
                filesEl.style.display = 'none';
            }
        }

        const stepEls = overlay.querySelectorAll('.loader-step');
        function applyStage(idx) {
            const st = stages[Math.min(idx, stages.length - 1)];
            if (subEl) subEl.textContent = st.text;
            if (barEl) barEl.style.width = st.pct + '%';
            if (pctEl) pctEl.textContent = st.pct + '%';
            stepEls.forEach((el, i) => {
                el.classList.remove('active', 'done');
                if (i < st.step) el.classList.add('done');
                else if (i === st.step) el.classList.add('active');
            });
        }

        overlay.classList.add('active');
        overlay.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';

        let stageIdx = 0;
        applyStage(0);
        if (loaderTimer) clearInterval(loaderTimer);
        loaderTimer = setInterval(() => {
            stageIdx += 1;
            if (stageIdx < stages.length) applyStage(stageIdx);
            else clearInterval(loaderTimer);
        }, options.intervalMs || 800);
    }

    function hideLoader() {
        const overlay = document.getElementById('global-loader');
        if (!overlay) return;
        overlay.classList.remove('active');
        overlay.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        if (loaderTimer) clearInterval(loaderTimer);
    }

    window.MindScanLoader = { show: showLoader, hide: hideLoader };

    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => applyThemeToPlotlyCharts(getTheme()), 120);

        const toggle = document.getElementById('theme-toggle');
        if (toggle) {
            toggle.addEventListener('click', () => {
                setTheme(getTheme() === 'light' ? 'dark' : 'light', true);
            });
        }

        // Mobile Sidebar Drawer (App Shell)
        const sidebar = document.getElementById('app-sidebar');
        const backdrop = document.getElementById('sidebar-backdrop');
        const openBtn = document.getElementById('sidebar-toggle');
        const closeBtn = document.getElementById('sidebar-close-btn');
        function setSidebar(open) {
            if (!sidebar || !backdrop) return;
            sidebar.classList.toggle('open', open);
            backdrop.classList.toggle('open', open);
        }
        if (openBtn) openBtn.addEventListener('click', () => setSidebar(true));
        if (closeBtn) closeBtn.addEventListener('click', () => setSidebar(false));
        if (backdrop) backdrop.addEventListener('click', () => setSidebar(false));

        // Mobile Public Navbar Drawer
        const mobileBtn = document.getElementById('mobile-menu-btn');
        const navLinks = document.getElementById('nav-links');
        if (mobileBtn && navLinks) {
            mobileBtn.addEventListener('click', () => {
                const open = navLinks.classList.toggle('open');
                mobileBtn.classList.toggle('open', open);
                mobileBtn.setAttribute('aria-expanded', String(open));
            });
            document.addEventListener('click', (e) => {
                if (!navLinks.contains(e.target) && !mobileBtn.contains(e.target)) {
                    navLinks.classList.remove('open');
                    mobileBtn.classList.remove('open');
                }
            });
        }

        // Flash Toasts
        document.querySelectorAll('.flash').forEach((flash) => {
            const btn = flash.querySelector('.flash-close');
            const dismiss = () => {
                flash.style.opacity = '0';
                setTimeout(() => flash.remove(), 250);
            };
            if (btn) btn.addEventListener('click', dismiss);
            setTimeout(dismiss, 6500);
        });

        // Subtle Card Cursor Sheen
        document.querySelectorAll('.glass-card, .clay-card').forEach((card) => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                card.style.setProperty('--mx', (e.clientX - rect.left) + 'px');
                card.style.setProperty('--my', (e.clientY - rect.top) + 'px');
            });
        });

        // Reveal Observer
        const revealEls = document.querySelectorAll('[data-reveal]');
        if ('IntersectionObserver' in window && revealEls.length) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        const delay = entry.target.getAttribute('data-reveal-delay') || '0';
                        entry.target.style.transitionDelay = delay + 'ms';
                        entry.target.classList.add('revealed');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.05 });
            revealEls.forEach((el) => observer.observe(el));
        } else {
            revealEls.forEach((el) => el.classList.add('revealed'));
        }

        // Count-up KPIs
        document.querySelectorAll('[data-countup]').forEach((el) => {
            const raw = parseFloat(el.getAttribute('data-countup'));
            if (isNaN(raw)) return;
            const isFloat = String(el.getAttribute('data-countup')).includes('.');
            const start = performance.now();
            function tick(now) {
                const p = Math.min((now - start) / 800, 1);
                const val = raw * (1 - Math.pow(1 - p, 3));
                el.textContent = isFloat ? val.toFixed(2) : Math.round(val);
                if (p < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
        });

        // Password Visibility Toggles
        document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const target = document.getElementById(btn.getAttribute('data-toggle-password'));
                if (!target) return;
                target.type = target.type === 'password' ? 'text' : 'password';
            });
        });

        // Password Strength Meter
        const regPass = document.getElementById('register-password');
        const strengthFill = document.getElementById('strength-fill');
        const strengthLabel = document.getElementById('strength-label');
        if (regPass && strengthFill && strengthLabel) {
            regPass.addEventListener('input', () => {
                const v = regPass.value;
                let s = 0;
                if (v.length >= 6) s++;
                if (v.length >= 10) s++;
                if (/[A-Z]/.test(v) && /[a-z]/.test(v)) s++;
                if (/\d/.test(v) || /[^A-Za-z0-9]/.test(v)) s++;
                const states = [
                    { w: '0%', c: 'transparent', t: 'Strength' },
                    { w: '28%', c: '#f43f5e', t: 'Weak' },
                    { w: '55%', c: '#f59e0b', t: 'Fair' },
                    { w: '80%', c: '#38bdf8', t: 'Good' },
                    { w: '100%', c: '#10b981', t: 'Strong' }
                ];
                strengthFill.style.width = states[s].w;
                strengthFill.style.background = states[s].c;
                strengthLabel.textContent = states[s].t;
            });
        }

        // Lightbox
        const lb = document.getElementById('image-lightbox');
        const lbImg = document.getElementById('lightbox-img');
        const lbCap = document.getElementById('lightbox-caption');
        const lbClose = document.getElementById('lightbox-close');
        if (lb && lbImg) {
            document.querySelectorAll('[data-lightbox]').forEach((img) => {
                img.addEventListener('click', () => {
                    lbImg.src = img.src;
                    if (lbCap) lbCap.textContent = img.getAttribute('data-lightbox') || img.alt || '';
                    lb.classList.add('active');
                    lb.setAttribute('aria-hidden', 'false');
                });
            });
            const closeLb = () => { lb.classList.remove('active'); lb.setAttribute('aria-hidden', 'true'); };
            if (lbClose) lbClose.addEventListener('click', closeLb);
            lb.addEventListener('click', (e) => { if (e.target === lb) closeLb(); });
            document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLb(); });
        }

        // Standard Form Blur Loader
        document.querySelectorAll('form[data-loader-title]').forEach((form) => {
            form.addEventListener('submit', () => {
                if (!form.checkValidity()) return;
                showLoader({
                    title: form.getAttribute('data-loader-title'),
                    showSteps: false,
                    stages: [
                        { text: form.getAttribute('data-loader-subtitle') || 'Processing...', pct: 35, step: 0 },
                        { text: 'Syncing with workspace...', pct: 78, step: 2 },
                        { text: 'Almost ready...', pct: 95, step: 3 }
                    ],
                    intervalMs: 650
                });
            });
        });

        window.addEventListener('pageshow', (e) => { if (e.persisted) hideLoader(); });
    });
})();
