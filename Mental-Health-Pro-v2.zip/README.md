# 🧠 MindScan - Mental Health Analysis from Social Media Text

A production-ready NLP-powered web application that analyzes social media text and identifies potential mental wellness indicators using real natural language processing.

## ⚠️ Disclaimer

**Results are informational and educational only and do not provide medical diagnosis or treatment recommendations.**

---

## ✨ Features

- **Real NLP Processing** — Tokenization, lemmatization, stopword removal, sentiment analysis
- **Mental Wellness Scoring** — Stress, anxiety, depression, and positive wellness indicators
- **Emotion Detection** — Happiness, sadness, anger, fear, surprise, neutrality
- **Interactive Visualizations** — Plotly-powered charts and trend analysis
- **Word Clouds** — Automatic generation of positive, negative, and general word clouds
- **Multi-File Support** — TXT, CSV, and multiple file uploads
- **Report Generation** — Export as HTML, JSON, and TXT
- **History Tracking** — Full analysis history with trend visualization
- **Dark/Light Themes** — Fully functional theme switching
- **User Authentication** — Secure registration and login with password hashing
- **JSON-Only Storage** — No database servers required

---

## 🛠️ Technology Stack

- **Backend:** Python 3.11+, Flask
- **NLP:** NLTK, TextBlob, Scikit-learn, WordCloud
- **Visualization:** Plotly
- **Frontend:** HTML5, CSS3, JavaScript
- **Storage:** JSON files only

---

## 📁 Project Structure

```
MindScan/
├── app.py                  # Flask application
├── analyzer.py             # NLP engine
├── utils.py                # JSON utilities & auth
├── requirements.txt
├── install.sh              # Linux installer
├── install.bat             # Windows installer
├── README.md
├── data/
│   ├── users.json
│   ├── history.json
│   ├── reports.json
│   ├── settings.json
│   └── contacts.json
├── uploads/                # Uploaded files
├── reports/                # Generated reports
├── templates/              # HTML templates
└── static/
    ├── css/style.css
    └── js/main.js
```

---

## 🚀 Installation

### Linux / macOS

```bash
chmod +x install.sh
./install.sh
source .venv/bin/activate
python app.py
```

### Windows

```powershell
.\install.bat
.venv\Scripts\activate
python app.py
```

Then open **http://localhost:5000** in your browser.

---

## 📖 Usage

1. **Register** a new account
2. **Login** to access the dashboard
3. Go to **Analyze** and input text or upload files
4. View **interactive charts**, **word clouds**, and **AI insights**
5. **Download reports** in HTML, JSON, or TXT format
6. Track trends on your **Dashboard**
7. Switch between **Light/Dark** themes in Profile

---

## 🔒 Privacy

All data is stored locally in JSON files. No external database is used. Your text and analysis results remain on your machine.

---

## ⚠️ Limitations

- This tool is **not a medical diagnostic device**
- Analysis is based on linguistic patterns and keyword lexicons
- Results should not replace professional mental health evaluation
- Requires internet connection for first-run NLTK data download

---

## 📄 License

This project is for educational and portfolio purposes.
