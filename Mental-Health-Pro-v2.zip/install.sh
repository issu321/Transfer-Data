#!/bin/bash
set -e

echo "=========================================="
echo "  MindScan - Linux Installer"
echo "=========================================="

if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed. Please install Python 3.11+ first."
    exit 1
fi

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
fi

source .venv/bin/activate
pip install --upgrade pip

if [ -f "requirements.txt" ]; then
    echo "Installing dependencies..."
    pip install -r requirements.txt
else
    echo "ERROR: requirements.txt not found!"
    exit 1
fi

echo "Initializing JSON data files..."
python3 -c "
import os, json
for d in ['data', 'uploads', 'reports', 'templates', 'static/css', 'static/js', 'static/assets']:
    os.makedirs(d, exist_ok=True)
for f, default in [('users.json', []), ('history.json', []), ('reports.json', []), ('settings.json', {}), ('contacts.json', [])]:
    p = os.path.join('data', f)
    if not os.path.exists(p):
        with open(p, 'w') as file:
            json.dump(default, file, indent=2)
"

echo ""
echo "Installation complete!"
echo ""
echo "To start the application:"
echo "  source .venv/bin/activate"
echo "  python app.py"
echo ""
echo "Then open http://localhost:5000 in your browser."
