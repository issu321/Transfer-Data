import os
import json
import uuid
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
from werkzeug.utils import secure_filename

from analyzer import MentalHealthAnalyzer
from utils import (
    ensure_dirs, init_json_files, add_user, verify_user, get_user_by_id,
    add_history, get_user_history, add_report, get_user_reports,
    get_user_settings, update_user_settings, add_contact
)

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

analyzer = MentalHealthAnalyzer()
ALLOWED = {'txt', 'csv'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED


def get_current_theme():
    if 'user_id' in session:
        settings = get_user_settings(session['user_id'])
        theme = settings.get('theme')
        if theme in ('light', 'dark'):
            return theme
    theme = session.get('theme', 'light')
    return theme if theme in ('light', 'dark') else 'light'


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


@app.before_request
def before_request():
    ensure_dirs()
    init_json_files()


@app.route('/')
def home():
    return render_template('home.html', theme=get_current_theme())


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')
        full_name = request.form.get('full_name', '').strip()

        if not username or not email or not password:
            flash('All fields are required.', 'danger')
            return redirect(url_for('register'))
        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return redirect(url_for('register'))
        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'danger')
            return redirect(url_for('register'))

        user = add_user(username, email, password, full_name)
        if not user:
            flash('Username or email already exists.', 'danger')
            return redirect(url_for('register'))

        session['user_id'] = user['id']
        session['username'] = user['username']
        if session.get('theme') in ('light', 'dark'):
            update_user_settings(user['id'], {'theme': session['theme']})
        flash('Account created successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('register.html', theme=get_current_theme())


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = verify_user(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            settings = get_user_settings(user['id'])
            session['theme'] = settings.get('theme', 'light')
            flash(f'Welcome back, {user["username"]}!', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid username or password.', 'danger')
    return render_template('login.html', theme=get_current_theme())


@app.route('/logout')
def logout():
    current_theme = get_current_theme()
    session.clear()
    session['theme'] = current_theme
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))


@app.route('/dashboard')
@login_required
def dashboard():
    uid = session['user_id']
    history = get_user_history(uid)
    reports = get_user_reports(uid)
    theme = get_current_theme()

    total = len(history)
    recent = reports[-5:] if reports else []
    sentiments = {'Positive': 0, 'Negative': 0, 'Neutral': 0}
    wellness_scores = []
    stress_trend = []
    dates = []

    for h in history:
        if 'result' not in h:
            continue
        r = h['result']
        sentiments[r['sentiment']['overall']] = sentiments.get(r['sentiment']['overall'], 0) + 1
        wellness_scores.append(r['wellness']['wellness'])
        stress_trend.append(r['wellness']['stress'])
        dates.append(h['timestamp'][:10])

    avg_wellness = round(sum(wellness_scores) / len(wellness_scores), 2) if wellness_scores else 0

    import plotly.graph_objects as go
    import plotly.utils
    trend_chart = None
    if dates and stress_trend:
        font_color = '#e0f2fe' if theme == 'dark' else '#0c192c'
        grid_color = 'rgba(56, 189, 248, 0.14)' if theme == 'dark' else 'rgba(14, 165, 233, 0.14)'
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=dates,
            y=stress_trend,
            mode='lines+markers',
            name='Stress Index',
            line=dict(color='#38bdf8', width=3, shape='spline'),
            marker=dict(size=8, color='#0ea5e9', line=dict(width=2, color='#ffffff')),
            fill='tozeroy',
            fillcolor='rgba(56, 189, 248, 0.16)'
        ))
        fig.update_layout(
            title=dict(text='Stress Trend Over Time', font=dict(size=16, color=font_color)),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(family='Plus Jakarta Sans, Inter, Segoe UI, sans-serif', color=font_color),
            margin=dict(l=40, r=20, t=50, b=40),
            xaxis=dict(gridcolor=grid_color, zeroline=False),
            yaxis=dict(gridcolor=grid_color, zeroline=False, range=[0, 1.05]),
            hovermode='x unified'
        )
        trend_chart = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

    return render_template('dashboard.html', total=total, recent=recent, sentiments=sentiments,
                           avg_wellness=avg_wellness, history=history[-10:], trend_chart=trend_chart, theme=theme)


@app.route('/analysis', methods=['GET', 'POST'])
@login_required
def analysis():
    uid = session['user_id']
    theme = get_current_theme()
    result = None
    charts = None
    wordclouds = None
    error = None

    if request.method == 'POST':
        analyzer.clear_state()
        input_type = request.form.get('input_type', 'text')
        text = request.form.get('text', '').strip()
        files = request.files.getlist('files')
        uploaded = []

        if input_type == 'text' and text:
            result = analyzer.analyze_text(text)
        elif files and any(f.filename for f in files):
            all_text = ""
            for file in files:
                if file and allowed_file(file.filename):
                    fname = secure_filename(file.filename)
                    fpath = os.path.join(app.config['UPLOAD_FOLDER'], f"{uid}_{uuid.uuid4()}_{fname}")
                    file.save(fpath)
                    uploaded.append(fname)
                    res, err = analyzer.analyze_file(fpath)
                    if err:
                        error = err
                        break
                    all_text += res.get('preview', '') + " "
            if not error and all_text.strip():
                result = analyzer.analyze_text(all_text)
            elif not error:
                error = "No valid text found in uploaded files."
        else:
            error = "Please provide text or upload a valid file."

        if result and not error:
            charts = analyzer.generate_charts(result, theme=theme)
            wordclouds = {}
            if result['words']['positive']:
                wordclouds['positive'] = analyzer.generate_wordcloud(result['words']['positive'])
            if result['words']['negative']:
                wordclouds['negative'] = analyzer.generate_wordcloud(result['words']['negative'])
            if result['words']['frequent']:
                words = [w for w, c in result['words']['frequent']]
                wordclouds['general'] = analyzer.generate_wordcloud(words)

            add_history(uid, {
                'input_type': input_type,
                'uploaded_files': uploaded,
                'result': result,
                'charts': charts,
                'wordclouds': wordclouds
            })

            rid = str(uuid.uuid4())
            rdir = os.path.join('reports', uid)
            os.makedirs(rdir, exist_ok=True)

            html_path = os.path.join(rdir, f"{rid}.html")
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(render_template('report_template.html', result=result, charts=charts, wordclouds=wordclouds))

            json_path = os.path.join(rdir, f"{rid}.json")
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2)

            txt_path = os.path.join(rdir, f"{rid}.txt")
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write("MENTAL HEALTH ANALYSIS REPORT\n")
                f.write(f"Generated: {datetime.now().isoformat()}\n")
                f.write("DISCLAIMER: Results are informational and educational only and do not provide medical diagnosis or treatment recommendations.\n\n")
                f.write(f"Sentiment: {result['sentiment']['overall']} (Polarity: {result['sentiment']['polarity']})\n")
                f.write(f"Stress: {result['wellness']['stress']} | Anxiety: {result['wellness']['anxiety']} | Depression: {result['wellness']['depression']} | Wellness: {result['wellness']['wellness']}\n")
                f.write(f"Risk Level: {result['wellness']['risk_level']}\n\nInsights:\n")
                for ins in result['insights']:
                    f.write(f"- {ins}\n")

            add_report(uid, {'report_id': rid, 'files': {'html': html_path, 'json': json_path, 'txt': txt_path}})
            flash('Analysis complete! Reports generated.', 'success')

    return render_template('analysis.html', result=result, charts=charts, wordclouds=wordclouds, error=error, theme=theme)


@app.route('/reports')
@login_required
def reports():
    uid = session['user_id']
    return render_template('reports.html', reports=get_user_reports(uid), theme=get_current_theme())


@app.route('/download/<rid>/<ftype>')
@login_required
def download(rid, ftype):
    uid = session['user_id']
    for r in get_user_reports(uid):
        if r.get('report_id') == rid and ftype in r.get('files', {}):
            return send_file(r['files'][ftype], as_attachment=True)
    flash('Report not found.', 'danger')
    return redirect(url_for('reports'))


@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    uid = session['user_id']
    user = get_user_by_id(uid)
    settings = get_user_settings(uid)
    if request.method == 'POST':
        theme = request.form.get('theme', 'light')
        if theme not in ('light', 'dark'):
            theme = 'light'
        update_user_settings(uid, {'theme': theme})
        session['theme'] = theme
        flash('Settings updated!', 'success')
        return redirect(url_for('profile'))
    return render_template('profile.html', user=user, settings=settings, theme=get_current_theme())


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        subject = request.form.get('subject', '').strip()
        message = request.form.get('message', '').strip()
        if not name or not email or not message:
            flash('Name, email, and message are required.', 'danger')
            return redirect(url_for('contact'))
        add_contact(name, email, subject, message)
        flash('Thank you for your message! We will get back to you soon.', 'success')
        return redirect(url_for('contact'))
    return render_template('contact.html', theme=get_current_theme())


@app.route('/features')
def features():
    return render_template('features.html', theme=get_current_theme())


@app.route('/api/theme', methods=['POST'])
def api_theme():
    data = request.get_json(silent=True) or {}
    theme = data.get('theme', 'light')
    if theme not in ('light', 'dark'):
        theme = 'light'
    session['theme'] = theme
    if 'user_id' in session:
        update_user_settings(session['user_id'], {'theme': theme})
    return jsonify({'success': True, 'theme': theme})


if __name__ == '__main__':
    ensure_dirs()
    init_json_files()
    app.run(debug=True, host="0.0.0.0", port=5001)
