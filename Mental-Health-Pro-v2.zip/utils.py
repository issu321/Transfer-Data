import os
import json
import uuid
import threading
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

DATA_DIR = 'data'
UPLOADS_DIR = 'uploads'
REPORTS_DIR = 'reports'
STATIC_DIRS = ['templates', 'static/css', 'static/js', 'static/assets']

_file_lock = threading.Lock()

def ensure_dirs():
    for d in [DATA_DIR, UPLOADS_DIR, REPORTS_DIR] + STATIC_DIRS:
        os.makedirs(d, exist_ok=True)

def init_json_files():
    defaults = {
        'users.json': [],
        'history.json': [],
        'reports.json': [],
        'settings.json': {},
        'contacts.json': []
    }
    for fname, default in defaults.items():
        fpath = os.path.join(DATA_DIR, fname)
        if not os.path.exists(fpath):
            with open(fpath, 'w', encoding='utf-8') as f:
                json.dump(default, f, indent=2)

def _read_json(filename):
    fpath = os.path.join(DATA_DIR, filename)
    with _file_lock:
        with open(fpath, 'r', encoding='utf-8') as f:
            return json.load(f)

def _write_json(filename, data):
    fpath = os.path.join(DATA_DIR, filename)
    with _file_lock:
        with open(fpath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)

def add_user(username, email, password, full_name=""):
    users = _read_json('users.json')
    if any(u['username'] == username or u['email'] == email for u in users):
        return None
    user = {
        'id': str(uuid.uuid4()),
        'username': username,
        'email': email,
        'password': generate_password_hash(password),
        'full_name': full_name,
        'created_at': datetime.now().isoformat()
    }
    users.append(user)
    _write_json('users.json', users)
    return user

def verify_user(username, password):
    users = _read_json('users.json')
    for user in users:
        if user['username'] == username and check_password_hash(user['password'], password):
            return user
    return None

def get_user_by_id(user_id):
    users = _read_json('users.json')
    for user in users:
        if user['id'] == user_id:
            return user
    return None

def add_history(user_id, analysis_data):
    history = _read_json('history.json')
    entry = {
        'id': str(uuid.uuid4()),
        'user_id': user_id,
        'timestamp': datetime.now().isoformat(),
        **analysis_data
    }
    history.append(entry)
    _write_json('history.json', history)
    return entry

def get_user_history(user_id):
    history = _read_json('history.json')
    return [h for h in history if h['user_id'] == user_id]

def add_report(user_id, report_data):
    reports = _read_json('reports.json')
    report = {
        'id': str(uuid.uuid4()),
        'user_id': user_id,
        'created_at': datetime.now().isoformat(),
        **report_data
    }
    reports.append(report)
    _write_json('reports.json', reports)
    return report

def get_user_reports(user_id):
    reports = _read_json('reports.json')
    return [r for r in reports if r['user_id'] == user_id]

def get_user_settings(user_id):
    settings = _read_json('settings.json')
    return settings.get(user_id, {'theme': 'light'})

def update_user_settings(user_id, new_settings):
    settings = _read_json('settings.json')
    if user_id not in settings:
        settings[user_id] = {}
    settings[user_id].update(new_settings)
    _write_json('settings.json', settings)
    return settings[user_id]

def add_contact(name, email, subject, message):
    contacts = _read_json('contacts.json')
    contacts.append({
        'id': str(uuid.uuid4()),
        'name': name,
        'email': email,
        'subject': subject,
        'message': message,
        'created_at': datetime.now().isoformat()
    })
    _write_json('contacts.json', contacts)
