import re
import base64
import json
import random
from collections import Counter
from io import BytesIO

import numpy as np
import nltk
from textblob import TextBlob
from wordcloud import WordCloud
import plotly.graph_objects as go
import plotly.express as px
import plotly.utils

for pkg in ['punkt', 'stopwords', 'averaged_perceptron_tagger', 'wordnet', 'omw-1.4']:
    try:
        nltk.data.find(f'tokenizers/{pkg}' if pkg == 'punkt' else f'corpora/{pkg}')
    except LookupError:
        nltk.download(pkg, quiet=True)

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

STRESS = {'stress', 'stressed', 'pressure', 'overwhelmed', 'burnout', 'exhausted', 'tension', 'strain', 'burden', 'frazzled', 'hectic', 'chaotic', 'deadline', 'urgent', 'crisis'}
ANXIETY = {'anxiety', 'anxious', 'worry', 'worried', 'fear', 'afraid', 'scared', 'panic', 'nervous', 'tense', 'restless', 'uneasy', 'dread', 'terror', 'phobia', 'overthinking', 'rumination', 'catastrophizing'}
DEPRESSION = {'depressed', 'depression', 'sad', 'hopeless', 'empty', 'numb', 'lonely', 'isolated', 'worthless', 'guilty', 'suicide', 'suicidal', 'miserable', 'despair', 'gloomy', 'melancholy', 'tearful', 'fatigue', 'insomnia', 'withdrawn'}
POSITIVE = {'happy', 'joy', 'grateful', 'thankful', 'blessed', 'peaceful', 'calm', 'relaxed', 'content', 'optimistic', 'hopeful', 'confident', 'strong', 'resilient', 'healing', 'balanced', 'mindful', 'exercise', 'meditation', 'therapy', 'support', 'love', 'care'}
EMOTIONS = {
    'happiness': ['happy', 'joy', 'excited', 'cheerful', 'delighted', 'glad', 'elated', 'blissful', 'ecstatic'],
    'sadness': ['sad', 'unhappy', 'miserable', 'depressed', 'sorrowful', 'gloomy', 'melancholy', 'tearful', 'heartbroken'],
    'anger': ['angry', 'furious', 'irritated', 'annoyed', 'rage', 'hate', 'mad', 'frustrated', 'outraged'],
    'fear': ['afraid', 'scared', 'terrified', 'anxious', 'worried', 'nervous', 'panic', 'dread', 'frightened'],
    'surprise': ['surprised', 'amazed', 'shocked', 'astonished', 'stunned', 'unexpected', 'wow'],
    'neutrality': ['okay', 'fine', 'alright', 'neutral', 'average', 'normal', 'standard', 'usual']
}

SKY_PALETTE = ['#0ea5e9', '#38bdf8', '#0284c7', '#06b6d4', '#2563eb', '#0891b2', '#7dd3fc']


def _sky_color_func(word, font_size, position, orientation, random_state=None, **kwargs):
    return random.choice(SKY_PALETTE)


class MentalHealthAnalyzer:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        self.current_text = ""
        self.tokens = []
        self.result = {}

    def clear_state(self):
        self.current_text = ""
        self.tokens = []
        self.result = {}

    def preprocess(self, text):
        text = text.lower()
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        text = re.sub(r'@\w+|#', '', text)
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        tokens = word_tokenize(text)
        tokens = [self.lemmatizer.lemmatize(t) for t in tokens if t not in self.stop_words and len(t) > 2]
        return tokens

    def analyze_text(self, text):
        self.clear_state()
        self.current_text = text
        self.tokens = self.preprocess(text)

        if not self.tokens:
            return self._empty_result()

        word_count = len(text.split())
        char_count = len(text)
        unique_words = len(set(self.tokens))

        blob = TextBlob(text)
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity

        positive = max(0.0, polarity)
        negative = max(0.0, -polarity)
        neutral = max(0.0, 1.0 - abs(polarity))

        if polarity > 0.1:
            overall = 'Positive'
        elif polarity < -0.1:
            overall = 'Negative'
        else:
            overall = 'Neutral'

        stress_score = min(1.0, sum(1 for t in self.tokens if t in STRESS) / max(word_count * 0.05, 1))
        anxiety_score = min(1.0, sum(1 for t in self.tokens if t in ANXIETY) / max(word_count * 0.05, 1))
        depression_score = min(1.0, sum(1 for t in self.tokens if t in DEPRESSION) / max(word_count * 0.05, 1))
        wellness_score = min(1.0, sum(1 for t in self.tokens if t in POSITIVE) / max(word_count * 0.05, 1))

        tone = self._detect_tone()
        emotions = self._analyze_emotions()
        risk = self._calculate_risk(stress_score, anxiety_score, depression_score, wellness_score)

        word_freq = Counter(self.tokens).most_common(20)
        positive_words = [w for w in set(self.tokens) if TextBlob(w).sentiment.polarity > 0.1]
        negative_words = [w for w in set(self.tokens) if TextBlob(w).sentiment.polarity < -0.1]

        avg_len = np.mean([len(w) for w in self.tokens]) if self.tokens else 0
        complexity = min(1.0, avg_len / 10)

        insights = self._generate_insights(overall, stress_score, anxiety_score, depression_score, wellness_score, emotions, polarity)

        self.result = {
            'text_stats': {
                'word_count': word_count,
                'char_count': char_count,
                'unique_words': unique_words,
                'avg_word_length': round(float(avg_len), 2),
                'complexity_score': round(complexity, 2)
            },
            'sentiment': {
                'positive': round(positive, 2),
                'negative': round(negative, 2),
                'neutral': round(neutral, 2),
                'overall': overall,
                'polarity': round(polarity, 2),
                'subjectivity': round(subjectivity, 2)
            },
            'wellness': {
                'stress': round(stress_score, 2),
                'anxiety': round(anxiety_score, 2),
                'depression': round(depression_score, 2),
                'wellness': round(wellness_score, 2),
                'emotional_tone': tone,
                'confidence': round(min(1.0, (word_count / 50) * 0.5 + 0.5), 2),
                'risk_level': risk
            },
            'emotions': emotions,
            'words': {
                'frequent': word_freq,
                'positive': positive_words[:20],
                'negative': negative_words[:20],
                'wellness': [w for w in self.tokens if w in POSITIVE],
                'stress': [w for w in self.tokens if w in STRESS],
                'anxiety': [w for w in self.tokens if w in ANXIETY],
                'depression': [w for w in self.tokens if w in DEPRESSION]
            },
            'insights': insights,
            'preview': text[:200] + '...' if len(text) > 200 else text
        }
        return self.result

    def _empty_result(self):
        return {
            'text_stats': {'word_count': 0, 'char_count': 0, 'unique_words': 0, 'avg_word_length': 0, 'complexity_score': 0},
            'sentiment': {'positive': 0, 'negative': 0, 'neutral': 1, 'overall': 'Neutral', 'polarity': 0, 'subjectivity': 0},
            'wellness': {'stress': 0, 'anxiety': 0, 'depression': 0, 'wellness': 0, 'emotional_tone': 'Neutral', 'confidence': 0, 'risk_level': 'Low'},
            'emotions': {'happiness': 0, 'sadness': 0, 'anger': 0, 'fear': 0, 'surprise': 0, 'neutrality': 1},
            'words': {'frequent': [], 'positive': [], 'negative': [], 'wellness': [], 'stress': [], 'anxiety': [], 'depression': []},
            'insights': ['No analyzable text provided.'],
            'preview': ''
        }

    def _detect_tone(self):
        scores = {
            'Stressful': sum(1 for t in self.tokens if t in STRESS),
            'Anxious': sum(1 for t in self.tokens if t in ANXIETY),
            'Depressed': sum(1 for t in self.tokens if t in DEPRESSION),
            'Positive': sum(1 for t in self.tokens if t in POSITIVE)
        }
        if not any(scores.values()):
            return 'Neutral'
        return max(scores, key=scores.get)

    def _analyze_emotions(self):
        emotions = {k: 0 for k in EMOTIONS}
        for token in self.tokens:
            for emotion, words in EMOTIONS.items():
                if token in words:
                    emotions[emotion] += 1
        total = sum(emotions.values()) or 1
        return {k: round(v / total, 2) for k, v in emotions.items()}

    def _calculate_risk(self, stress, anxiety, depression, wellness):
        score = (stress + anxiety + depression) * 0.6 - wellness * 0.4
        if score > 0.5:
            return 'High'
        if score > 0.2:
            return 'Moderate'
        return 'Low'

    def _generate_insights(self, sentiment, stress, anxiety, depression, wellness, emotions, polarity):
        insights = []
        if sentiment == 'Negative' and polarity < -0.3:
            insights.append("Strong negative sentiment detected. Consider reaching out to a support network.")
        elif sentiment == 'Positive' and polarity > 0.3:
            insights.append("Positive emotional expression observed. Maintain these healthy patterns.")
        if stress > 0.5:
            insights.append("Elevated stress language detected. Stress-reduction techniques may be beneficial.")
        if anxiety > 0.5:
            insights.append("Anxiety-related patterns identified. Grounding exercises could help.")
        if depression > 0.5:
            insights.append("Depression-related expressions found. Speaking with a mental health professional is recommended.")
        if wellness > 0.5:
            insights.append("Strong wellness indicators present. You are expressing healthy coping mechanisms.")
        max_emo = max(emotions, key=emotions.get)
        if emotions[max_emo] > 0.3:
            insights.append(f"Predominant emotional state: {max_emo.capitalize()}.")
        if not insights:
            insights.append("Balanced emotional expression with no significant risk indicators.")
        return insights

    def generate_wordcloud(self, words, title="Word Cloud"):
        if not words:
            return None
        text = ' '.join(words)
        wc = WordCloud(
            width=800,
            height=400,
            background_color=None,
            mode='RGBA',
            color_func=_sky_color_func,
            max_words=100,
            prefer_horizontal=0.85
        ).generate(text)
        img = BytesIO()
        wc.to_image().save(img, format='PNG')
        img.seek(0)
        return base64.b64encode(img.read()).decode()

    def generate_charts(self, result, theme='light'):
        charts = {}
        font_color = '#e0f2fe' if theme == 'dark' else '#0c192c'
        grid_color = 'rgba(56, 189, 248, 0.16)' if theme == 'dark' else 'rgba(14, 165, 233, 0.16)'
        font_family = 'Plus Jakarta Sans, Inter, Segoe UI, sans-serif'

        s = result['sentiment']
        fig = go.Figure(data=[go.Pie(
            labels=['Positive', 'Negative', 'Neutral'],
            values=[s['positive'], s['negative'], s['neutral']],
            hole=0.52,
            marker=dict(
                colors=['#10b981', '#f43f5e', '#38bdf8'],
                line=dict(color='rgba(255,255,255,0.2)', width=2)
            ),
            textinfo='percent+label'
        )])
        fig.update_layout(
            title=dict(text="Sentiment Distribution", font=dict(size=16, color=font_color)),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(family=font_family, color=font_color),
            margin=dict(l=20, r=20, t=50, b=20),
            legend=dict(orientation='h', y=-0.1)
        )
        charts['sentiment_pie'] = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

        w = result['wellness']
        fig = go.Figure(data=go.Scatterpolar(
            r=[w['stress'], w['anxiety'], w['depression'], w['wellness'], w['stress']],
            theta=['Stress', 'Anxiety', 'Depression', 'Wellness', 'Stress'],
            fill='toself',
            fillcolor='rgba(56, 189, 248, 0.24)',
            line=dict(color='#38bdf8', width=2.5),
            marker=dict(size=7, color='#0ea5e9'),
            name='Wellness'
        ))
        fig.update_layout(
            polar=dict(
                bgcolor='rgba(0,0,0,0)',
                radialaxis=dict(visible=True, range=[0, 1], gridcolor=grid_color, linecolor=grid_color, tickfont=dict(color=font_color)),
                angularaxis=dict(gridcolor=grid_color, linecolor=grid_color, tickfont=dict(color=font_color))
            ),
            showlegend=False,
            title=dict(text="Wellness Radar", font=dict(size=16, color=font_color)),
            paper_bgcolor='rgba(0,0,0,0)',
            font=dict(family=font_family, color=font_color),
            margin=dict(l=40, r=40, t=55, b=35)
        )
        charts['wellness_radar'] = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

        e = result['emotions']
        fig = px.bar(
            x=[k.capitalize() for k in e.keys()],
            y=list(e.values()),
            labels={'x': 'Emotion', 'y': 'Intensity'},
            title="Emotion Distribution",
            color=list(e.values()),
            color_continuous_scale=[[0, '#bae6fd'], [0.5, '#38bdf8'], [1, '#0284c7']]
        )
        fig.update_traces(marker_line_width=0)
        fig.update_layout(
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            font=dict(family=font_family, color=font_color),
            title=dict(font=dict(size=16, color=font_color)),
            coloraxis_showscale=False,
            xaxis=dict(gridcolor=grid_color, zeroline=False),
            yaxis=dict(gridcolor=grid_color, zeroline=False),
            margin=dict(l=40, r=20, t=50, b=40)
        )
        charts['emotion_bar'] = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)

        freq = result['words']['frequent'][:10]
        if freq:
            words, counts = zip(*freq)
            fig = px.bar(
                x=list(words),
                y=list(counts),
                labels={'x': 'Word', 'y': 'Count'},
                title="Top Keywords",
                color=list(counts),
                color_continuous_scale=[[0, '#7dd3fc'], [0.6, '#0ea5e9'], [1, '#0369a1']]
            )
            fig.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                font=dict(family=font_family, color=font_color),
                title=dict(font=dict(size=16, color=font_color)),
                coloraxis_showscale=False,
                xaxis=dict(gridcolor=grid_color, zeroline=False),
                yaxis=dict(gridcolor=grid_color, zeroline=False),
                margin=dict(l=40, r=20, t=50, b=40)
            )
            charts['word_freq'] = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
        return charts

    def analyze_file(self, filepath):
        ext = filepath.split('.')[-1].lower()
        try:
            if ext == 'txt':
                with open(filepath, 'r', encoding='utf-8') as f:
                    return self.analyze_text(f.read()), None
            elif ext == 'csv':
                import csv
                text = ""
                with open(filepath, 'r', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    for row in reader:
                        text += ' '.join(row) + ' '
                return self.analyze_text(text), None
            else:
                return None, "Unsupported file format. Use .txt or .csv"
        except Exception as e:
            return None, str(e)
