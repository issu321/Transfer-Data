<?php

session_start();

if(!isset($_SESSION['admin_id'])){

    header("Location: auth/login.php");

    exit();
}

$adminName =
$_SESSION['admin_name'];

/* THEME */

$savedTheme = "";

if(isset($_COOKIE['eventsphere_admin_theme'])){

    $savedTheme =
    $_COOKIE['eventsphere_admin_theme'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
Admin Dashboard - EventSphere
</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{

display:flex;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;

animation:gradientBG 18s ease infinite;

overflow-x:hidden;

transition:0.4s;

}

/* DARK MODE */

body.dark{

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

background-size:500% 500%;

color:white;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

/* SIDEBAR */

.sidebar{

width:250px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.25);

backdrop-filter:blur(24px);

border-right:1px solid rgba(255,255,255,0.2);

transition:0.4s;

}

body.dark .sidebar{

background:rgba(17,34,64,0.88);

}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:28px;

color:#6C9BD2;

}

.menu{
display:flex;
flex-direction:column;
gap:10px;
}

.menu a{

text-decoration:none;

padding:13px 14px;

border-radius:14px;

font-weight:600;

color:inherit;

transition:0.3s;

font-size:15px;

}

.menu a:hover,
.menu a.active{

background:rgba(255,255,255,0.35);

transform:translateX(4px);

}

body.dark .menu a:hover,
body.dark .menu a.active{

background:rgba(76,201,240,0.15);

}

/* MAIN */

.main{

margin-left:250px;

width:calc(100% - 250px);

padding:24px;

}

/* TOPBAR */

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

gap:20px;

margin-bottom:22px;

flex-wrap:wrap;

}

/* PROFILE */

.profile{

display:flex;
align-items:center;
gap:15px;

}

.profile img{

width:50px;
height:50px;

border-radius:50%;

object-fit:cover;

border:2px solid #dbeafe;

}

/* THEME BUTTON */

.toggle-btn{

border:none;

padding:10px 16px;

border-radius:12px;

cursor:pointer;

background:rgba(255,255,255,0.35);

font-size:14px;

font-weight:600;

transition:0.3s;

}

.toggle-btn:hover{

transform:translateY(-2px);

}

body.dark .toggle-btn{

background:#223A5E;
color:white;

}

/* HERO */

.hero-card{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:24px;

border-radius:24px;

box-shadow:0 8px 25px rgba(0,0,0,0.05);

margin-bottom:22px;

transition:0.4s;

}

body.dark .hero-card{

background:rgba(22,32,51,0.72);

}

.hero-card h1{

font-size:32px;

margin-bottom:12px;

}

.hero-card p{

line-height:1.7;

opacity:0.85;

max-width:700px;

}

/* GRID */

.cards{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(220px,1fr));

gap:20px;

}

/* CARD */

.card{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:24px;

border-radius:24px;

box-shadow:0 8px 25px rgba(0,0,0,0.05);

transition:0.3s;

cursor:pointer;

}

body.dark .card{

background:rgba(22,32,51,0.72);

}

.card:hover{

transform:translateY(-5px);

}

.card h2{

font-size:36px;

margin-bottom:10px;

color:#6C9BD2;

}

.card p{

font-weight:600;

opacity:0.8;

margin-bottom:10px;

}

.card span{

font-size:14px;

opacity:0.7;

}

/* QUICK ACTIONS */

.quick-actions{

margin-top:25px;

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(240px,1fr));

gap:20px;

}

.action-box{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:22px;

border-radius:24px;

box-shadow:0 8px 25px rgba(0,0,0,0.05);

transition:0.3s;

cursor:pointer;

}

body.dark .action-box{

background:rgba(22,32,51,0.72);

}

.action-box:hover{

transform:translateY(-4px);

}

.action-box h3{

margin-bottom:10px;

color:#6C9BD2;

}

.action-box p{

line-height:1.6;

opacity:0.8;

}

/* RESPONSIVE */

@media(max-width:900px){

.sidebar{

width:100%;
height:auto;

position:relative;

}

.main{

margin-left:0;
width:100%;

}

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a class="active"
href="admin-dashboard.php">

🏠 Dashboard

</a>

<a href="admin/events-manage.php">

📅 Manage Events

</a>

<a href="admin/clubs-manage.php">

🎭 Manage Clubs

</a>

<a href="admin/notifications-manage.php">

🔔 Notifications

</a>

<a href="admin/certificates-manage.php">

📜 Certificates

</a>

<a href="admin/students-manage.php">

👨‍🎓 Students

</a>



<a href="admin/settings.php">

⚙ Settings

</a>

<a href="auth/logout.php">

🚪 Logout

</a>

</div>

</div>

<!-- MAIN -->

<div class="main">

<!-- TOPBAR -->

<div class="topbar">

<div>

<h1 style="font-size:32px; margin-bottom:8px;">

Welcome Admin,
<?php echo $adminName; ?> 👋

</h1>

<p style="opacity:0.75;">

Manage your smart campus ecosystem beautifully 💙

</p>

</div>

<div class="profile">

<button class="toggle-btn"
onclick="toggleTheme()"
id="themeBtn">

🌙 Dark

</button>

<img
src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png">

</div>

</div>

<!-- HERO -->

<div class="hero-card">

<h1>
🎯 Admin Control Center
</h1>

<p>

Manage events, clubs, students, certificates,
notifications and campus activities from one
centralized EventSphere admin ecosystem.

</p>

</div>

<!-- STATS -->

<div class="cards">

<div class="card"
onclick="window.location.href='admin/students-manage.php'">

<h2>120</h2>

<p>Total Students</p>

<span>
Active registered students in EventSphere
</span>

</div>

<div class="card"
onclick="window.location.href='admin/events-manage.php'">

<h2>18</h2>

<p>Total Events</p>

<span>
Upcoming and completed campus events
</span>

</div>

<div class="card"
onclick="window.location.href='admin/clubs-manage.php'">

<h2>9</h2>

<p>Campus Clubs</p>

<span>
Student clubs currently active
</span>

</div>

<div class="card"
onclick="window.location.href='admin/certificates-manage.php'">

<h2>42</h2>

<p>Certificates Issued</p>

<span>
Certificates uploaded for students
</span>

</div>

</div>

<!-- QUICK ACTIONS -->

<div class="quick-actions">

<div class="action-box"
onclick="window.location.href='admin/events-manage.php'">

<h3>
📅 Create New Event
</h3>

<p>
Add hackathons, competitions,
sports events and workshops.
</p>

</div>

<div class="action-box"
onclick="window.location.href='admin/notifications-manage.php'">

<h3>
🔔 Send Notifications
</h3>

<p>
Send announcements and updates
to all students instantly.
</p>

</div>

<div class="action-box"
onclick="window.location.href='admin/certificates-manage.php'">

<h3>
📜 Upload Certificates
</h3>

<p>
Manage student certificates
and downloadable PDFs.
</p>

</div>

<div class="action-box"
onclick="window.location.href='admin/analytics.php'">



</div>

</div>

</div>

<script>

/* THEME */

function toggleTheme(){

document.body.classList.toggle('dark');

let btn =
document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){

document.cookie =
"eventsphere_admin_theme=dark; path=/";

btn.innerHTML = "☀️ Light";

}
else{

document.cookie =
"eventsphere_admin_theme=light; path=/";

btn.innerHTML = "🌙 Dark";

}

}

/* LOAD THEME ICON */

window.onload = function(){

let btn =
document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){

btn.innerHTML = "☀️ Light";

}
else{

btn.innerHTML = "🌙 Dark";

}

}

</script>

</body>
</html>