<?php

session_start();

include("../includes/db.php");

if(!isset($_SESSION['admin_id'])){

    header("Location: ../auth/login.php");

    exit();
}

$adminName =
$_SESSION['admin_name'];

/* THEME */

$savedTheme = "";

if(isset($_COOKIE['eventsphere_admin_theme'])){

    $savedTheme =
    $_COOKIE['eventsphere_admin_theme'];
}

/* ADD CLUB */

$message = "";

if(isset($_POST['add_club'])){

    $club_name =
    trim($_POST['club_name']);

    $description =
    trim($_POST['description']);

    $faculty_head =
    trim($_POST['faculty_head']);

    $category =
    trim($_POST['category']);

    $imageName = "";

    if(isset($_FILES['image']) &&
    $_FILES['image']['name'] != ""){

        $imageName =
        time() . "_" .
        $_FILES['image']['name'];

        move_uploaded_file(

            $_FILES['image']['tmp_name'],

            "../assets/images/clubs/" .
            $imageName
        );
    }

    $conn->query("

    INSERT INTO clubs
    (club_name,description,
    faculty_head,category,image)

    VALUES(

    '$club_name',
    '$description',
    '$faculty_head',
    '$category',
    '$imageName'

    )

    ");

    $message =
    "✅ Club Added Successfully";
}

/* DELETE CLUB */

if(isset($_GET['delete'])){

    $delete_id =
    $_GET['delete'];

    $conn->query(
    "DELETE FROM clubs
    WHERE id='$delete_id'"
    );

    header("Location: clubs-manage.php");

    exit();
}

/* FETCH CLUBS */

$clubs =
$conn->query(

"SELECT * FROM clubs
ORDER BY id DESC"

);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
Manage Clubs - EventSphere
</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{

display:flex;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;

animation:gradientBG 18s ease infinite;

overflow-x:hidden;

transition:0.4s;

}

body.dark{

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

background-size:500% 500%;

color:white;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

/* SIDEBAR */

.sidebar{

width:250px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.25);

backdrop-filter:blur(24px);

border-right:1px solid rgba(255,255,255,0.2);

}

body.dark .sidebar{

background:rgba(17,34,64,0.88);

}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:28px;

color:#6C9BD2;

}

.menu{
display:flex;
flex-direction:column;
gap:10px;
}

.menu a{

text-decoration:none;

padding:13px 14px;

border-radius:14px;

font-weight:600;

color:inherit;

transition:0.3s;

}

.menu a:hover,
.menu a.active{

background:rgba(255,255,255,0.35);

transform:translateX(4px);

}

body.dark .menu a:hover,
body.dark .menu a.active{

background:rgba(76,201,240,0.15);

}

/* MAIN */

.main{

margin-left:250px;

width:calc(100% - 250px);

padding:24px;

}

/* TOPBAR */

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

margin-bottom:25px;

gap:20px;

flex-wrap:wrap;

}

.toggle-btn{

border:none;

padding:10px 16px;

border-radius:12px;

cursor:pointer;

background:rgba(255,255,255,0.35);

font-weight:600;

}

body.dark .toggle-btn{

background:#223A5E;
color:white;

}

/* FORM */

.form-box{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:24px;

border-radius:24px;

margin-bottom:25px;

}

body.dark .form-box{

background:rgba(22,32,51,0.72);

}

.form-grid{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(240px,1fr));

gap:15px;

}

.form-box input,
.form-box textarea{

width:100%;

padding:14px;

border:none;
outline:none;

border-radius:14px;

margin-top:12px;

background:rgba(255,255,255,0.45);

}

body.dark .form-box input,
body.dark .form-box textarea{

background:#101827;
color:white;

}

.form-box textarea{

height:120px;

resize:none;

}

.add-btn{

margin-top:18px;

padding:14px 20px;

border:none;

border-radius:14px;

background:#6C9BD2;

color:white;

font-weight:600;

cursor:pointer;

}

/* CLUBS */

.clubs-grid{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(280px,1fr));

gap:20px;

}

.club-card{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:18px;

border-radius:24px;

transition:0.3s;

}

body.dark .club-card{

background:rgba(22,32,51,0.72);

}

.club-card:hover{

transform:translateY(-5px);

}

.club-card img{

width:100%;
height:180px;

object-fit:cover;

border-radius:18px;

margin-bottom:15px;

}

.club-card h3{

margin-bottom:10px;

}

.club-card p{

opacity:0.8;

line-height:1.6;

margin-bottom:8px;

}

.delete-btn{

display:inline-block;

margin-top:12px;

padding:10px 14px;

border-radius:12px;

background:#ef4444;

color:white;

text-decoration:none;

font-weight:600;

}

/* MESSAGE */

.message{

margin-bottom:18px;

font-weight:600;

color:#16a34a;

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a href="../admin-dashboard.php">
🏠 Dashboard
</a>

<a href="events-manage.php">
📅 Manage Events
</a>

<a class="active"
href="clubs-manage.php">

🎭 Manage Clubs

</a>

<a href="notifications-manage.php">
🔔 Notifications
</a>

<a href="certificates-manage.php">
📜 Certificates
</a>

<a href="students-manage.php">
👨‍🎓 Students
</a>

<a href="analytics.php">
📊 Analytics
</a>

<a href="settings.php">
⚙ Settings
</a>

<a href="../auth/logout.php">
🚪 Logout
</a>

</div>

</div>

<!-- MAIN -->

<div class="main">

<!-- TOPBAR -->

<div class="topbar">

<div>

<h1>
🎭 Manage Clubs
</h1>

<p style="opacity:0.7;">
Create and manage campus clubs
</p>

</div>

<button class="toggle-btn"
onclick="toggleTheme()"
id="themeBtn">

🌙 Dark

</button>

</div>

<!-- MESSAGE -->

<?php if($message != ""): ?>

<div class="message">

<?php echo $message; ?>

</div>

<?php endif; ?>

<!-- FORM -->

<div class="form-box">

<form method="POST"
enctype="multipart/form-data">

<div class="form-grid">

<input
type="text"
name="club_name"
placeholder="Club Name"
required>

<input
type="text"
name="faculty_head"
placeholder="Faculty Head"
required>

<input
type="text"
name="category"
placeholder="Club Category"
required>

<input
type="file"
name="image"
required>

</div>

<textarea
name="description"
placeholder="Club Description"
required></textarea>

<button
class="add-btn"
name="add_club">

➕ Add Club

</button>

</form>

</div>

<!-- CLUBS -->

<div class="clubs-grid">

<?php while($row = $clubs->fetch_assoc()): ?>

<div class="club-card">

<img
src="../assets/images/clubs/<?php echo $row['image']; ?>">

<h3>
🎭 <?php echo $row['club_name']; ?>
</h3>

<p>
👨‍🏫 <?php echo $row['faculty_head']; ?>
</p>

<p>
🏷 <?php echo $row['category']; ?>
</p>

<p>
<?php echo $row['description']; ?>
</p>

<a class="delete-btn"
href="?delete=<?php echo $row['id']; ?>">

🗑 Delete

</a>

</div>

<?php endwhile; ?>

</div>

</div>

<script>

/* THEME */

function toggleTheme(){

document.body.classList.toggle('dark');

let btn =
document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){

document.cookie =
"eventsphere_admin_theme=dark; path=/";

btn.innerHTML = "☀️ Light";

}
else{

document.cookie =
"eventsphere_admin_theme=light; path=/";

btn.innerHTML = "🌙 Dark";

}

}

/* LOAD THEME */

window.onload = function(){

let btn =
document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){

btn.innerHTML = "☀️ Light";

}
else{

btn.innerHTML = "🌙 Dark";

}

}

</script>

</body>
</html>