<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: ../auth/login.php");
    exit();
}

/* FETCH EVENTS + CLUBS */
$events = $conn->query("SELECT id,title FROM events");
$clubs  = $conn->query("SELECT id,club_name FROM clubs");

$message = "";

if(isset($_POST['create'])){

    $title = $_POST['title'];
    $messageText = $_POST['message'];
    $type = $_POST['type'];
    $target = $_POST['target'];

    $event_id = $_POST['event_id'] ?? NULL;
    $club_id = $_POST['club_id'] ?? NULL;

    if($event_id == "") $event_id = NULL;
    if($club_id == "") $club_id = NULL;

    $conn->query("
        INSERT INTO notifications
        (title,message,type,event_id,club_id,target)
        VALUES
        ('$title','$messageText','$type','$event_id','$club_id','$target')
    ");

    $message = "✅ Notification Created Successfully";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Create Notification</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
<style>
body{
font-family:Segoe UI;
padding:30px;
background:#eef4ff;
}

.form{
max-width:600px;
padding:25px;
background:white;
border-radius:20px;
}

input, textarea, select{
width:100%;
padding:12px;
margin:10px 0;
border-radius:10px;
border:1px solid #ccc;
}

button{
padding:12px 18px;
background:#6C9BD2;
border:none;
color:white;
border-radius:12px;
cursor:pointer;
}
</style>
</head>

<body>

<h1>🔔 Create Notification</h1>

<?php if($message!="") echo "<p>$message</p>"; ?>

<div class="form">

<form method="POST">

<input type="text" name="title" placeholder="Notification Title" required>

<textarea name="message" placeholder="Message" required></textarea>

<select name="type">
<option value="general">General</option>
<option value="event">Event</option>
<option value="club">Club</option>
</select>

<select name="event_id">
<option value="">-- Link Event (optional) --</option>
<?php while($e=$events->fetch_assoc()): ?>
<option value="<?php echo $e['id']; ?>">
<?php echo $e['title']; ?>
</option>
<?php endwhile; ?>
</select>

<select name="club_id">
<option value="">-- Link Club (optional) --</option>
<?php while($c=$clubs->fetch_assoc()): ?>
<option value="<?php echo $c['id']; ?>">
<?php echo $c['club_name']; ?>
</option>
<?php endwhile; ?>
</select>

<select name="target">
<option value="all">All Students</option>
<option value="students">Only Students</option>
</select>

<button name="create">Create Notification</button>

</form>

</div>

</body>
</html>