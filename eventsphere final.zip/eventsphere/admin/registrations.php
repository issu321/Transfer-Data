<?php

session_start();

if(!isset($_SESSION['admin_id'])){

    header("Location: ../auth/login.php");

    exit();
}

include("../includes/db.php");

$adminName =
$_SESSION['admin_name'];

$savedTheme =
$_COOKIE['eventsphere_admin_theme']
?? "";

/* STATS */

$totalRegistrations =
$conn->query(
"SELECT * FROM registrations"
)->num_rows;

$activeRegistrations =
$conn->query(
"SELECT * FROM registrations
WHERE status='Registered'"
)->num_rows;

$cancelledRegistrations =
$conn->query(
"SELECT * FROM registrations
WHERE status='Cancelled'"
)->num_rows;

$totalEvents =
$conn->query(
"SELECT * FROM events"
)->num_rows;

/* FETCH REGISTRATIONS */

$query = $conn->query(

"SELECT registrations.id,
registrations.student_id,
registrations.status,
registrations.registered_at,

events.title,
events.category,
events.event_date

FROM registrations

JOIN events
ON registrations.event_id = events.id

ORDER BY registrations.id DESC"

);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
Admin Registrations - EventSphere
</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{

display:flex;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;

animation:gradientBG 18s ease infinite;

overflow-x:hidden;

transition:0.4s;

}

body.dark{

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

color:white;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

.sidebar{

width:250px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.25);

backdrop-filter:blur(24px);

border-right:1px solid rgba(255,255,255,0.2);

}

body.dark .sidebar{

background:rgba(17,34,64,0.88);

}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:28px;

color:#6C9BD2;

}

.menu{
display:flex;
flex-direction:column;
gap:10px;
}

.menu a{

text-decoration:none;

padding:13px 14px;

border-radius:14px;

font-weight:600;

color:inherit;

transition:0.3s;

font-size:15px;

}

.menu a:hover,
.menu a.active{

background:rgba(255,255,255,0.35);

transform:translateX(4px);

}

body.dark .menu a:hover,
body.dark .menu a.active{

background:rgba(76,201,240,0.15);

}

.main{

margin-left:250px;

width:calc(100% - 250px);

padding:24px;

}

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

gap:20px;

margin-bottom:22px;

flex-wrap:wrap;

}

.toggle-btn{

border:none;

padding:10px 16px;

border-radius:12px;

cursor:pointer;

background:rgba(255,255,255,0.35);

font-size:14px;

font-weight:600;

transition:0.3s;

}

body.dark .toggle-btn{

background:#223A5E;
color:white;

}

.hero-card{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:24px;

border-radius:24px;

margin-bottom:22px;

}

body.dark .hero-card{

background:rgba(22,32,51,0.72);

}

.cards{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(220px,1fr));

gap:20px;

margin-bottom:25px;

}

.card{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:24px;

border-radius:24px;

transition:0.3s;

}

body.dark .card{

background:rgba(22,32,51,0.72);

}

.card:hover{

transform:translateY(-5px);

}

.card h2{

font-size:34px;

margin-bottom:10px;

color:#6C9BD2;

}

.table-box{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:24px;

border-radius:24px;

overflow-x:auto;

}

body.dark .table-box{

background:rgba(22,32,51,0.72);

}

table{

width:100%;
border-collapse:collapse;

}

th,td{

padding:16px;
text-align:left;

}

th{

opacity:0.75;

}

tr{

border-bottom:1px solid rgba(255,255,255,0.15);

}

.status{

padding:7px 14px;

border-radius:20px;

font-size:13px;

font-weight:600;

color:white;

display:inline-block;

}

.registered{

background:linear-gradient(135deg,#22c55e,#16a34a);

}

.cancelled{

background:linear-gradient(135deg,#ef4444,#dc2626);

}

@media(max-width:900px){

.sidebar{

width:100%;
height:auto;

position:relative;

}

.main{

margin-left:0;
width:100%;

}

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a href="../admin-dashboard.php">
🏠 Dashboard
</a>

<a href="events-manage.php">
📅 Manage Events
</a>

<a href="clubs-manage.php">
🎭 Manage Clubs
</a>

<a class="active"
href="registrations.php">
📝 Registrations
</a>

<a href="notifications-manage.php">
🔔 Notifications
</a>

<a href="certificates-manage.php">
📜 Certificates
</a>

<a href="students-manage.php">
👨‍🎓 Students
</a>

<a href="analytics.php">
📊 Analytics
</a>

<a href="settings.php">
⚙ Settings
</a>

<a href="../auth/logout.php">
🚪 Logout
</a>

</div>
</div>

<div class="main">

<div class="topbar">

<div>

<h1 style="font-size:32px;">

📝 Registrations Overview

</h1>

<p style="opacity:0.75; margin-top:6px;">

Monitor student participation and event activity.

</p>

</div>

<button class="toggle-btn"
onclick="toggleTheme()"
id="themeBtn">

🌙 Dark

</button>

</div>

<div class="hero-card">

<h2>
🎟 Event Participation Management
</h2>

<p style="margin-top:10px; opacity:0.8;">

Track registrations, cancellations and event engagement across the campus ecosystem.

</p>

</div>

<div class="cards">

<div class="card">

<h2>
<?php echo $totalRegistrations; ?>
</h2>

<p>Total Registrations</p>

</div>

<div class="card">

<h2>
<?php echo $activeRegistrations; ?>
</h2>

<p>Active Participants</p>

</div>

<div class="card">

<h2>
<?php echo $cancelledRegistrations; ?>
</h2>

<p>Cancelled Registrations</p>

</div>

<div class="card">

<h2>
<?php echo $totalEvents; ?>
</h2>

<p>Total Events</p>

</div>

</div>

<div class="table-box">

<table>

<tr>

<th>Student ID</th>

<th>Event</th>

<th>Category</th>

<th>Event Date</th>

<th>Registered On</th>

<th>Status</th>

</tr>

<?php while($row = $query->fetch_assoc()): ?>

<tr>

<td>
<?php echo htmlspecialchars($row['student_id']); ?>
</td>

<td>
<?php echo htmlspecialchars($row['title']); ?>
</td>

<td>
<?php echo htmlspecialchars($row['category']); ?>
</td>

<td>
<?php echo htmlspecialchars($row['event_date']); ?>
</td>

<td>
<?php echo date(
"d M Y",
strtotime($row['registered_at'])
); ?>
</td>

<td>

<div class="status
<?php echo strtolower($row['status']); ?>">

<?php echo $row['status']; ?>

</div>

</td>

</tr>

<?php endwhile; ?>

</table>

</div>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle('dark');

let btn =
document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){

document.cookie =
"eventsphere_admin_theme=dark; path=/";

btn.innerHTML = "☀️ Light";

}
else{

document.cookie =
"eventsphere_admin_theme=light; path=/";

btn.innerHTML = "🌙 Dark";

}

}

window.onload = function(){

let btn =
document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){

btn.innerHTML = "☀️";

}
else{

btn.innerHTML = "🌙 ";

}

}

</script>

</body>
</html>