<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: ../auth/login.php");
    exit();
}

$adminName = $_SESSION['admin_name'];

/* THEME */
$savedTheme = $_COOKIE['eventsphere_admin_theme'] ?? "";

/* CREATE TABLE */
$conn->query("
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    message TEXT,
    type VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
");

/* ADD NOTIFICATION */
if(isset($_POST['add_notification'])){
    $title = $_POST['title'];
    $message = $_POST['message'];
    $type = $_POST['type'];

    $conn->query("
        INSERT INTO notifications(title,message,type)
        VALUES('$title','$message','$type')
    ");
}

/* DELETE */
if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    $conn->query("DELETE FROM notifications WHERE id='$id'");

    header("Location: notifications-manage.php");
    exit();
}

/* FETCH */
$notifications = $conn->query("
    SELECT * FROM notifications ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Notifications - EventSphere</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* BASE */
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
display:flex;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s infinite;
transition:0.4s;
}

body.dark{
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
color:white;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* SIDEBAR */
.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.30);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

body.dark .logo{
color:#4CC9F0;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
transition:0.3s;
font-weight:600;
color:inherit;
}

.menu a:hover,
.menu a.active{
background:rgba(76,201,240,0.18);
color:#4CC9F0;
transform:translateX(5px);
}

/* MAIN */
.main{
margin-left:260px;
width:calc(100% - 260px);
padding:30px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
}

.toggle-btn{
border:none;
padding:10px 14px;
border-radius:12px;
cursor:pointer;
background:rgba(255,255,255,0.35);
}

body.dark .toggle-btn{
background:#223A5E;
color:white;
}

/* FORM */
.form-box{
background:rgba(255,255,255,0.35);
backdrop-filter:blur(20px);
padding:25px;
border-radius:20px;
margin-bottom:25px;
}

body.dark .form-box{
background:rgba(22,32,51,0.75);
}

.form-box input,
.form-box textarea{
width:100%;
padding:14px;
margin-top:10px;
border:none;
outline:none;
border-radius:12px;
background:rgba(255,255,255,0.5);
}

body.dark .form-box input,
body.dark .form-box textarea{
background:#101827;
color:white;
}

.add-btn{
margin-top:15px;
padding:12px 18px;
border:none;
border-radius:12px;
background:#4CC9F0;
font-weight:600;
cursor:pointer;
}

/* NOTIFICATION CARD */
.noti-card{
background:rgba(255,255,255,0.35);
backdrop-filter:blur(20px);
padding:20px;
border-radius:18px;
margin-bottom:15px;
transition:0.3s;
}

body.dark .noti-card{
background:rgba(22,32,51,0.75);
}

.noti-card:hover{
transform:translateY(-5px);
}

.delete-btn{
display:inline-block;
margin-top:10px;
padding:10px 14px;
border-radius:12px;
background:#ef4444;
color:white;
text-decoration:none;
}

</style>
</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->
<div class="sidebar">

<div class="logo">🎉 EventSphere</div>

<div class="menu">

<a href="../admin-dashboard.php">🏠 Dashboard</a>
<a href="events-manage.php">📅 Manage Events</a>
<a href="clubs-manage.php">🎭 Manage Clubs</a>
<a class="active" href="notifications-manage.php">🔔 Notifications</a>
<a href="certificates-manage.php">📜 Certificates</a>
<a href="students-manage.php">👨‍🎓 Students</a>

<a href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>

</div>
</div>

<!-- MAIN -->
<div class="main">

<div class="topbar">

<h1>🔔 Manage Notifications</h1>

<button class="toggle-btn"
onclick="toggleTheme()">
🌙
</button>

</div>

<!-- FORM -->
<div class="form-box">

<form method="POST">

<input type="text" name="title" placeholder="Notification Title" required>

<input type="text" name="type" placeholder="Type (Event / Exam / Update)" required>

<textarea name="message" placeholder="Message" required></textarea>

<button class="add-btn" name="add_notification">
➕ Send Notification
</button>

</form>

</div>

<!-- LIST -->
<?php while($row = $notifications->fetch_assoc()): ?>

<div class="noti-card">

<h3><?php echo $row['title']; ?></h3>
<p><?php echo $row['message']; ?></p>
<small>🏷 <?php echo $row['type']; ?></small>

<br>

<a class="delete-btn"
href="?delete=<?php echo $row['id']; ?>"
onclick="return confirm('Delete this notification?')">
🗑 Delete
</a>

</div>

<?php endwhile; ?>

</div>

<script>

function toggleTheme(){
document.body.classList.toggle("dark");

let mode = document.body.classList.contains("dark") ? "dark" : "light";
document.cookie = "eventsphere_admin_theme="+mode+"; path=/";
}

</script>

</body>
</html>