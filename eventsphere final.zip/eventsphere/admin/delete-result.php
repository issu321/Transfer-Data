<?php

session_start();
include("../includes/db.php");

if(!isset($_SESSION['admin_name'])){
    header("Location: ../auth/login.php");
    exit();
}

if(isset($_GET['id'])){

    $id = $_GET['id'];

    $conn->query("
    DELETE FROM results
    WHERE id='$id'
    ");

}

header("Location: results-manage.php");
exit();

?>