<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['admin_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$adminName = $_SESSION['admin_name'];

/* THEME */

$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* ADD RESULT */

if(isset($_POST['publish'])){

    $eventId = $_POST['event_id'];
    $studentId = $_POST['student_id'];
    $position = $_POST['position'];
    $score = $_POST['score'];
    $status = $_POST['result_status'];

    $conn->query("

    INSERT INTO results
    (event_id, student_id, position, score, result_status)

    VALUES
    ('$eventId','$studentId','$position','$score','$status')

    ");

    header("Location: results-manage.php");
    exit();
}

/* FETCH EVENTS */

$events = $conn->query("
SELECT * FROM events ORDER BY id DESC
");

/* FETCH STUDENTS */

$students = $conn->query("
SELECT * FROM students ORDER BY name ASC
");

/* FETCH RESULTS */

$results = $conn->query("

SELECT results.*,
events.title AS event_title,
students.name AS student_name

FROM results

LEFT JOIN events
ON results.event_id = events.id

LEFT JOIN students
ON results.student_id = students.student_id

ORDER BY results.id DESC

");
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Results Management</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Segoe UI;
}

body{
display:flex;
transition:0.4s;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s infinite;
}

body.dark{
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
color:white;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* SIDEBAR */

.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.3);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
font-weight:600;
color:inherit;
transition:0.3s;
}

.menu a:hover,
.menu a.active{
background:rgba(76,201,240,0.18);
color:#4CC9F0;
transform:translateX(5px);
}

/* MAIN */

.main{
margin-left:260px;
width:calc(100% - 260px);
padding:25px;
}

/* TOPBAR */

.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:20px;
}

.mode-btn{
border:none;
width:40px;
height:40px;
border-radius:50%;
cursor:pointer;
background:#AFCBFF;
font-size:16px;
}

body.dark .mode-btn{
background:#4CC9F0;
}

/* CARD */

.card{
background:rgba(255,255,255,0.4);
padding:20px;
border-radius:20px;
margin-bottom:20px;
backdrop-filter:blur(18px);
}

body.dark .card{
background:rgba(22,32,51,0.82);
}

/* FORM */

input,
select,
button{
width:100%;
padding:12px;
margin-top:10px;
border:none;
border-radius:12px;
outline:none;
}

button{
background:#4CC9F0;
font-weight:bold;
cursor:pointer;
}

/* RESULT BOX */

.result-box{
padding:18px;
border-radius:18px;
margin-top:15px;
background:rgba(255,255,255,0.35);
}

body.dark .result-box{
background:rgba(255,255,255,0.05);
}

.delete-btn{
display:inline-block;
margin-top:12px;
padding:10px 14px;
border-radius:10px;
background:#ef4444;
color:white;
text-decoration:none;
font-weight:600;
}

</style>

</head>

<body class="<?php echo $savedTheme == 'dark' ? 'dark' : ''; ?>">

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
🎉 EventSphere ADMIN
</div>

<div class="menu">

<a href="../admin-dashboard.php">🏠 Dashboard</a>

<a href="events-manage.php">📅 Manage Events</a>

<a href="clubs-manage.php">🎭 Manage Clubs</a>

<a href="results-manage.php" class="active">🏆 Results</a>

<a href="notifications-manage.php">🔔 Notifications</a>

<a href="certificates-manage.php">📜 Certificates</a>

<a href="students-manage.php">👨‍🎓 Students</a>

<a href="../auth/logout.php">🚪 Logout</a>

</div>

</div>

<!-- MAIN -->

<div class="main">

<div class="topbar">

<h2>🏆 Results Management</h2>

<button class="mode-btn"
onclick="toggleTheme()">

🌙

</button>

</div>

<!-- ADD RESULT -->

<div class="card">

<h3>Publish Result</h3>

<form method="POST">

<select name="event_id" required>

<option value="">
Select Event
</option>

<?php while($e = $events->fetch_assoc()): ?>

<option value="<?php echo $e['id']; ?>">

<?php echo $e['title']; ?>

</option>

<?php endwhile; ?>

</select>

<select name="student_id" required>

<option value="">
Select Student
</option>

<?php while($s = $students->fetch_assoc()): ?>

<option value="<?php echo $s['student_id']; ?>">

<?php echo $s['name']; ?>
(<?php echo $s['student_id']; ?>)

</option>

<?php endwhile; ?>

</select>

<input
type="text"
name="position"
placeholder="Position (Winner / Runner Up / Top 5)"
required>

<input
type="text"
name="score"
placeholder="Score (95% / 450 Points)"
required>

<input
type="text"
name="result_status"
placeholder="Status (Excellent / Qualified)"
required>

<button type="submit" name="publish">

Publish Result

</button>

</form>

</div>

<!-- RESULTS LIST -->

<div class="card">

<h3>Published Results</h3>

<?php while($r = $results->fetch_assoc()): ?>

<div class="result-box">

<h2>
🏆 <?php echo $r['event_title']; ?>
</h2>

<p>
👨‍🎓 Student:
<?php echo $r['student_name']; ?>
</p>

<p>
🥇 Position:
<?php echo $r['position']; ?>
</p>

<p>
📊 Score:
<?php echo $r['score']; ?>
</p>

<p>
⭐ Status:
<?php echo $r['result_status']; ?>
</p>

<a
class="delete-btn"
href="delete-result.php?id=<?php echo $r['id']; ?>"
onclick="return confirm('Delete Result?')">

Delete

</a>

</div>

<?php endwhile; ?>

</div>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle("dark");

document.cookie =
"eventsphere_theme=" +
(document.body.classList.contains("dark")
? "dark"
: "light")
+ "; path=/";

}

</script>

</body>
</html>