<?php

session_start();
include("../includes/db.php");

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$adminName = $_SESSION['admin_name'];

/* THEME */
$savedTheme = "";
if (isset($_COOKIE['eventsphere_admin_theme'])) {
    $savedTheme = $_COOKIE['eventsphere_admin_theme'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Settings - EventSphere</title>

<style>

/* SAME GLOBAL STYLE */
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
display:flex;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:gradientBG 18s ease infinite;
transition:0.4s;
}

body.dark{
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
color:white;
}

@keyframes gradientBG{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* SIDEBAR (SAME AS EVENTS) */
.sidebar{
width:250px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.25);
backdrop-filter:blur(24px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(17,34,64,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:28px;
color:#6C9BD2;
}

.menu{
display:flex;
flex-direction:column;
gap:10px;
}

.menu a{
text-decoration:none;
padding:13px 14px;
border-radius:14px;
font-weight:600;
color:inherit;
transition:0.3s;
}

.menu a:hover,
.menu a.active{
background:rgba(255,255,255,0.35);
transform:translateX(4px);
}

body.dark .menu a:hover,
body.dark .menu a.active{
background:rgba(76,201,240,0.15);
}

/* MAIN */
.main{
margin-left:250px;
width:calc(100% - 250px);
padding:24px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
flex-wrap:wrap;
}

.toggle-btn{
border:none;
padding:10px 16px;
border-radius:12px;
cursor:pointer;
background:rgba(255,255,255,0.35);
font-weight:600;
}

body.dark .toggle-btn{
background:#223A5E;
color:white;
}

/* CARDS */
.card{
background:rgba(255,255,255,0.28);
backdrop-filter:blur(22px);
padding:22px;
border-radius:24px;
margin-bottom:20px;
}

body.dark .card{
background:rgba(22,32,51,0.72);
}

/* INPUTS */
input{
width:100%;
padding:14px;
border:none;
outline:none;
border-radius:14px;
margin-top:10px;
margin-bottom:15px;
background:rgba(255,255,255,0.45);
}

body.dark input{
background:#101827;
color:white;
}

button{
padding:12px 18px;
border:none;
border-radius:14px;
background:#6C9BD2;
color:white;
font-weight:600;
cursor:pointer;
}

.logout{
background:#ef4444;
}

</style>
</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR (SAME STRUCTURE) -->
<div class="sidebar">

<div class="logo">🎉 EventSphere</div>

<div class="menu">

<a href="../admin-dashboard.php">🏠 Dashboard</a>
<a href="events-manage.php">📅 Manage Events</a>
<a href="clubs-manage.php">🎭 Manage Clubs</a>
<a href="notifications-manage.php">🔔 Notifications</a>
<a href="certificates-manage.php">📜 Certificates</a>
<a href="students-manage.php">👨‍🎓 Students</a>
<a class="active" href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>

</div>
</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">

<div>
<h1>⚙ Settings</h1>
<p style="opacity:0.7;">Manage your admin account</p>
</div>

<button class="toggle-btn" onclick="toggleTheme()" id="themeBtn">
🌙 Dark
</button>

</div>

<!-- PROFILE -->
<div class="card">

<h2>👤 Admin Profile</h2>

<br>

<p><b>Name:</b> <?php echo $adminName; ?></p>
<p><b>Role:</b> Admin</p>

</div>

<!-- PASSWORD -->
<div class="card">

<h2>🔐 Change Password</h2>

<form method="POST" action="update_password.php">

<label>Current Password</label>
<input type="password" name="current_password" required>

<label>New Password</label>
<input type="password" name="new_password" required>

<label>Confirm Password</label>
<input type="password" name="confirm_password" required>

<button type="submit">Update Password</button>

</form>

</div>

<!-- LOGOUT -->
<div class="card">

<h2>🚪 Logout</h2>

<a href="../auth/logout.php">
<button class="logout">Logout</button>
</a>

</div>

</div>

<script>

/* THEME SYSTEM (SAME AS EVENTS) */

function toggleTheme(){

document.body.classList.toggle('dark');

let btn = document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){

document.cookie = "eventsphere_admin_theme=dark; path=/";
btn.innerHTML = "☀️ Light";

}else{

document.cookie = "eventsphere_admin_theme=light; path=/";
btn.innerHTML = "🌙 Dark";

}

}

window.onload = function(){

let btn = document.getElementById("themeBtn");

if(document.body.classList.contains('dark')){
btn.innerHTML = "☀️ Light";
}else{
btn.innerHTML = "🌙 Dark";
}

}

</script>

</body>
</html>