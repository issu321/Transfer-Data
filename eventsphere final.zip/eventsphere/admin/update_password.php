<?php

session_start();
include("../includes/db.php");

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

/* GET DATA */
$current_password = $_POST['current_password'];
$new_password = $_POST['new_password'];
$confirm_password = $_POST['confirm_password'];

/* FETCH ADMIN */
$result = $conn->query("SELECT * FROM admins WHERE id='$admin_id'");
$admin = $result->fetch_assoc();

/* CHECK IF ADMIN EXISTS */
if (!$admin) {
    echo "Admin not found!";
    exit();
}

/* VERIFY CURRENT PASSWORD */
if (!password_verify($current_password, $admin['password'])) {
    echo "❌ Current password is wrong!";
    exit();
}

/* CHECK NEW PASSWORD MATCH */
if ($new_password !== $confirm_password) {
    echo "❌ New passwords do not match!";
    exit();
}

/* HASH NEW PASSWORD */
$hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

/* UPDATE PASSWORD */
$conn->query("
    UPDATE admins 
    SET password='$hashedPassword' 
    WHERE id='$admin_id'
");

echo "✅ Password updated successfully!";
echo "<br><a href='settings.php'>Go back</a>";

?>