<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['admin_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$adminName = $_SESSION['admin_name'];

/* THEME */
$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* SEARCH */
$search = $_GET['search'] ?? "";
$search = strtolower(trim($search));

/* FETCH STUDENTS */
$students = $conn->query("SELECT * FROM users WHERE role='student' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Students Manage</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* BASE */
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Segoe UI;
}

body{
display:flex;
transition:0.4s;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s infinite;
}

body.dark{
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
color:white;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* SIDEBAR */
.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.3);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

body.dark .logo{
color:#4CC9F0;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
font-weight:600;
color:inherit;
transition:0.3s;
}

.menu a:hover,
.menu a.active{
background:rgba(76,201,240,0.18);
color:#4CC9F0;
transform:translateX(5px);
}

body.dark .menu a:hover,
body.dark .menu a.active{
background:#4CC9F0;
color:black;
}

/* MAIN */
.main{
margin-left:260px;
width:calc(100% - 260px);
padding:25px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:20px;
}

/* SEARCH */
.search-box{
position:relative;
flex:1;
max-width:400px;
}

.search-box input{
width:100%;
padding:12px 40px;
border:none;
border-radius:14px;
outline:none;
background:rgba(255,255,255,0.4);
}

body.dark .search-box input{
background:rgba(255,255,255,0.08);
color:white;
}

.search-box i{
position:absolute;
left:14px;
top:12px;
opacity:0.6;
}

/* THEME BUTTON */
.mode-btn{
border:none;
width:38px;
height:38px;
border-radius:50%;
cursor:pointer;
background:#AFCBFF;
display:flex;
align-items:center;
justify-content:center;
}

body.dark .mode-btn{
background:#4CC9F0;
}

/* CARDS */
.card{
background:rgba(255,255,255,0.4);
padding:20px;
border-radius:18px;
margin-bottom:15px;
backdrop-filter:blur(18px);
}

body.dark .card{
background:rgba(22,32,51,0.82);
}

/* STUDENT TABLE STYLE */
.student-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
gap:20px;
}

.student-card{
padding:18px;
border-radius:18px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
transition:0.3s;
}

body.dark .student-card{
background:rgba(22,32,51,0.82);
}

.student-card:hover{
transform:translateY(-6px);
}

.student-name{
font-size:20px;
font-weight:700;
margin-bottom:8px;
}

.student-info{
opacity:0.8;
margin-bottom:5px;
font-size:14px;
}

.actions{
margin-top:12px;
display:flex;
gap:10px;
}

.btn{
padding:8px 12px;
border-radius:10px;
text-decoration:none;
font-weight:600;
font-size:13px;
}

.view{
background:#4CC9F0;
color:black;
}

.delete{
background:#ef4444;
color:white;
}

</style>
</head>

<body class="<?php echo $savedTheme == 'dark' ? 'dark' : ''; ?>">

<!-- SIDEBAR -->
<div class="sidebar">

<div class="logo">🎉 EventSphere ADMIN</div>

<div class="menu">

<a href="../admin-dashboard.php">🏠 Dashboard</a>

<a href="events-manage.php">📅 Manage Events</a>
<a href="clubs-manage.php">🎭 Manage Clubs</a>
<a href="notifications-manage.php">🔔 Notifications</a>
<a href="certificates-manage.php">📜 Certificates</a>
<a href="students-manage.php" class="active">👨‍🎓 Students</a>

<a href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>

</div>
</div>

<!-- MAIN -->
<div class="main">

<div class="topbar">

<h2>👨‍🎓 Students Management</h2>

<button class="mode-btn" onclick="toggleTheme()">🌙</button>

</div>

<!-- SEARCH -->
<div class="card">

<div class="search-box">
<i class="fa fa-search"></i>
<input type="text" id="searchInput" placeholder="Search students...">
</div>

</div>

<!-- STUDENTS -->
<div class="student-grid">

<?php while($s = $students->fetch_assoc()): ?>

<div class="student-card">

<div class="student-name">
👨‍🎓 <?php echo $s['user_id']; ?>
</div>

<div class="student-info">
ID: <?php echo $s['id']; ?>
</div>

<div class="student-info">
Role: <?php echo $s['role']; ?>
</div>

<div class="actions">

<a href="#" class="btn view">View</a>
<a href="#" class="btn delete" onclick="return confirm('Remove student?')">Remove</a>

</div>

</div>

<?php endwhile; ?>

</div>

</div>

<script>

/* THEME */
function toggleTheme(){
document.body.classList.toggle("dark");

let mode = document.body.classList.contains("dark") ? "dark" : "light";
document.cookie = "eventsphere_theme="+mode+"; path=/";
}

/* SEARCH */
document.getElementById("searchInput").addEventListener("input",function(){
let val=this.value.toLowerCase();

document.querySelectorAll(".student-card").forEach(card=>{
card.style.display = card.innerText.toLowerCase().includes(val)
? "block"
: "none";
});
});

</script>

</body>
</html>