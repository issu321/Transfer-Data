<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['admin_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$adminName = $_SESSION['admin_name'];

/* THEME */
$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* UPLOAD CERTIFICATE */
if(isset($_POST['upload'])){

    $student = $_POST['student_id'];

    $title = $_POST['title'];

    $date = $_POST['issued_date'];

    $fileName = $_FILES['file']['name'];

    $tmp = $_FILES['file']['tmp_name'];

    $folder = "../uploads/certificates/";

    if(!is_dir($folder)){
        mkdir($folder, 0777, true);
    }

    move_uploaded_file($tmp, $folder.$fileName);

    $conn->query("
        INSERT INTO certificates
        (student_id,title,file,issued_date)

        VALUES

        ('$student','$title','$fileName','$date')
    ");

    header("Location: certificates-manage.php");

    exit();
}

/* FETCH */
$certificates =
$conn->query(
"SELECT * FROM certificates ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">

<title>
Certificates Manage
</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* BASE */

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Segoe UI;
}

body{
display:flex;
transition:0.4s;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;

animation:bg 18s infinite;
}

body.dark{

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

color:white;
}

@keyframes bg{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

/* SIDEBAR */

.sidebar{
width:260px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.3);

backdrop-filter:blur(20px);

border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

body.dark .logo{
color:#4CC9F0;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
font-weight:600;
color:inherit;
transition:0.3s;
}

.menu a:hover,
.menu a.active{

background:rgba(76,201,240,0.18);

color:#4CC9F0;

box-shadow:0 0 12px rgba(76,201,240,0.25);

transform:translateX(5px);
}

body.dark .menu a:hover,
body.dark .menu a.active{

background:#4CC9F0;
color:black;
}

/* MAIN */

.main{
margin-left:260px;
width:calc(100% - 260px);
padding:25px;
}

/* TOPBAR */

.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:20px;
}

/* THEME BUTTON */

.mode-btn{
border:none;
width:38px;
height:38px;
border-radius:50%;
cursor:pointer;
background:#AFCBFF;
display:flex;
align-items:center;
justify-content:center;
font-size:16px;
transition:0.3s;
}

body.dark .mode-btn{
background:#4CC9F0;
}

.mode-btn:hover{
transform:scale(1.1);
}

/* CARDS */

.card{

background:rgba(255,255,255,0.4);

padding:20px;

border-radius:18px;

margin-bottom:15px;

backdrop-filter:blur(18px);
}

body.dark .card{
background:rgba(22,32,51,0.82);
}

/* FORM */

input,
button{

padding:10px;

margin:5px 0;

width:100%;

border:none;

border-radius:10px;

outline:none;
}

button{

background:#4CC9F0;

font-weight:bold;

cursor:pointer;
}

.cert-actions{

margin-top:10px;
}

.cert-actions a{

text-decoration:none;

font-weight:600;

margin-right:10px;

color:#4CC9F0;
}

</style>
</head>

<body class="<?php echo $savedTheme == 'dark' ? 'dark' : ''; ?>">

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
🎉 EventSphere ADMIN
</div>

<div class="menu">

<a href="../admin-dashboard.php">
🏠 Dashboard
</a>

<a href="events-manage.php">
📅 Manage Events
</a>

<a href="clubs-manage.php">
🎭 Manage Clubs
</a>

<a href="notifications-manage.php">
🔔 Notifications
</a>

<a href="certificates-manage.php"
class="active">
📜 Certificates
</a>

<a href="students-manage.php">
👨‍🎓 Students
</a>

<a href="registrations.php">
📝 Registrations
</a>

<a href="settings.php">
⚙ Settings
</a>

<a href="../auth/logout.php">
🚪 Logout
</a>

</div>
</div>

<!-- MAIN -->

<div class="main">

<div class="topbar">

<h2>
📜 Certificates Management
</h2>

<button class="mode-btn"
onclick="toggleTheme()">

🌙

</button>

</div>

<!-- UPLOAD -->

<div class="card">

<h3>
Upload Certificate
</h3>

<form method="POST"
enctype="multipart/form-data">

<input
type="text"
name="student_id"
placeholder="Student ID"
required>

<input
type="text"
name="title"
placeholder="Certificate Title"
required>

<input
type="date"
name="issued_date"
required>

<input
type="file"
name="file"
required>

<button type="submit"
name="upload">

Upload Certificate

</button>

</form>

</div>

<!-- LIST -->

<?php while($c = $certificates->fetch_assoc()): ?>

<div class="card">

<h3>
<?php echo $c['title']; ?>
</h3>

<p>

👨‍🎓 Student ID:

<?php echo $c['student_id']; ?>

</p>

<p>

📅 Issued Date:

<?php echo $c['issued_date']; ?>

</p>

<div class="cert-actions">

<a href="../uploads/certificates/<?php echo $c['file']; ?>"
target="_blank">

View

</a>

<a href="delete-certificate.php?id=<?php echo $c['id']; ?>"
onclick="return confirm('Delete?')">

Delete

</a>

</div>

</div>

<?php endwhile; ?>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle("dark");

document.cookie =

"eventsphere_theme=" +

(document.body.classList.contains("dark")
? "dark"
: "light")

+ "; path=/";

}

</script>

</body>
</html>