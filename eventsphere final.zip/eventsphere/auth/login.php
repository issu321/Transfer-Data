<?php
session_start();
include("../includes/db.php");

$error = "";

if(isset($_POST['student_login'])){

    $student_id =
    trim($_POST['student_id']);

    $password =
    $_POST['password'];

    $result = $conn->query(

        "SELECT * FROM students

        WHERE student_id='$student_id'"
    );

    if($result->num_rows == 1){

        $row =
        $result->fetch_assoc();

        if(
            password_verify(
                $password,
                $row['password']
            )
        ){

            $_SESSION['student_name']
            = $row['name'];

            $_SESSION['student_id']
            = $row['student_id'];

            header(
            "Location: ../dashboard/student-dashboard.php"
            );

            exit();

        }else{

            $error =
            "❌ Wrong Password";
        }

    }else{

        $error =
        "❌ Student Not Found";
    }
}

/* ---------------- ADMIN LOGIN ---------------- */

if(isset($_POST['admin_login'])){

    $admin_name =
    trim($_POST['admin_name']);

    $password =
    $_POST['admin_password'];

    $result = $conn->query(

        "SELECT * FROM admins

        WHERE name='$admin_name'"
    );

    if($result->num_rows == 1){

        $row =
        $result->fetch_assoc();

        if(
            password_verify(
                $password,
                $row['password']
            )
        ){

            $_SESSION['admin_name']
            = $row['name'];

            $_SESSION['admin_id']
            = $row['id'];

            header(
            "Location: ../admin-dashboard.php"
            );

            exit();

        }else{

            $error =
            "❌ Wrong Password";
        }

    }else{

        $error =
        "❌ Admin Not Found";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>EventSphere Login</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* SAME CSS */

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
height:100vh;
display:flex;
justify-content:center;
align-items:center;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s ease infinite;
overflow:hidden;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

.card{
width:430px;
padding:35px;
background:rgba(255,255,255,0.30);
backdrop-filter:blur(20px);
border-radius:28px;
box-shadow:0 8px 32px rgba(31,38,135,0.12);
border:1px solid rgba(255,255,255,0.2);
}

.logo{
font-size:30px;
font-weight:700;
text-align:center;
margin-bottom:10px;
color:#6C9BD2;
}

.subtitle{
text-align:center;
opacity:0.7;
margin-bottom:25px;
}

.robot{
width:110px;
display:block;
margin:0 auto 18px;
animation:float 3s ease-in-out infinite;
}

@keyframes float{
0%,100%{transform:translateY(0);}
50%{transform:translateY(-10px);}
}

.select-box{
margin-bottom:18px;
}

.select-box select{
width:100%;
padding:14px;
border:none;
outline:none;
border-radius:16px;
background:rgba(255,255,255,0.45);
font-size:15px;
}

.input-box{
position:relative;
margin-bottom:18px;
}

.input-box i{
position:absolute;
left:15px;
top:15px;
opacity:0.6;
}

.input-box input{
width:100%;
padding:14px 18px 14px 45px;
border:none;
outline:none;
border-radius:16px;
background:rgba(255,255,255,0.45);
font-size:15px;
}

.btn{
width:100%;
padding:14px;
border:none;
border-radius:16px;
background:#6C9BD2;
color:white;
font-weight:600;
font-size:15px;
cursor:pointer;
transition:0.3s;
}

.error{
margin-top:15px;
text-align:center;
color:red;
font-weight:600;
}

.bottom-link{
margin-top:20px;
text-align:center;
}

.bottom-link a{
text-decoration:none;
color:#6C9BD2;
font-weight:600;
}

#adminLogin{
display:none;
}

</style>

</head>

<body>

<div class="card">

<img class="robot"
src="https://cdn-icons-png.flaticon.com/512/4712/4712109.png">

<div class="logo">
🎉 EventSphere
</div>

<p class="subtitle">
Welcome Back 👋
</p>

<div class="select-box">

<select id="loginType">

<option value="student">
Student Login
</option>

<option value="admin">
Admin Login
</option>

</select>

</div>

<!-- STUDENT LOGIN -->

<form method="POST" id="studentLogin">

<div class="input-box">
<i class="fa-solid fa-id-card"></i>

<input type="text"
name="student_id"
placeholder="Student ID"
required>
</div>

<div class="input-box">
<i class="fa-solid fa-lock"></i>

<input type="password"
name="password"
placeholder="Password"
required>
</div>

<button class="btn" name="student_login">
Student Login
</button>

</form>

<!-- ADMIN LOGIN -->

<form method="POST" id="adminLogin">

<div class="input-box">
<i class="fa-solid fa-user-shield"></i>

<input type="text"
name="admin_name"
placeholder="Admin Name">
</div>

<div class="input-box">
<i class="fa-solid fa-lock"></i>

<input type="password"
name="admin_password"
placeholder="Password">
</div>

<button class="btn" name="admin_login">
Admin Login
</button>

</form>

<div class="error">
<?php echo $error; ?>
</div>

<div class="bottom-link">

Don't have an account?

<a href="register.php">
Register
</a>

</div>

</div>

<script>

const loginType =
document.getElementById("loginType");

const studentLogin =
document.getElementById("studentLogin");

const adminLogin =
document.getElementById("adminLogin");

loginType.addEventListener(
"change",
function(){

if(this.value == "admin"){

adminLogin.style.display = "block";

studentLogin.style.display = "none";

}else{

studentLogin.style.display = "block";

adminLogin.style.display = "none";

}

}
);

</script>

</body>
</html>