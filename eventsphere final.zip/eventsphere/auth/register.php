<?php
include("../includes/db.php");

$message = "";

if(isset($_POST['register'])){

    $role = $_POST['role'];

    /* ---------------- STUDENT REGISTER ---------------- */

    if($role == "student"){

        $student_id = trim($_POST['student_id']);

        $name = trim($_POST['name']);

        $email = trim($_POST['email']);

        $password = password_hash(
            $_POST['password'],
            PASSWORD_DEFAULT
        );

        $check = $conn->query(

            "SELECT * FROM students

            WHERE student_id='$student_id'

            OR email='$email'"
        );

        if($check->num_rows > 0){

            $message =
            "⚠️ Student already exists";

        }else{

            $conn->query(

                "INSERT INTO students
                (
                student_id,
                name,
                email,
                password
                )

                VALUES
                (
                '$student_id',
                '$name',
                '$email',
                '$password'
                )"
            );

            $message =
            "✅ Student Registration Successful";
        }
    }

    /* ---------------- ADMIN REGISTER ---------------- */

    if($role == "admin"){

        $name = trim($_POST['admin_name']);

        $email = trim($_POST['admin_email']);

        $password = password_hash(
            $_POST['admin_password'],
            PASSWORD_DEFAULT
        );

        $check = $conn->query(

            "SELECT * FROM admins

            WHERE name='$name'

            OR email='$email'"
        );

        if($check->num_rows > 0){

            $message =
            "⚠️ Admin already exists";

        }else{

            $conn->query(

                "INSERT INTO admins
                (
                name,
                email,
                password
                )

                VALUES
                (
                '$name',
                '$email',
                '$password'
                )"
            );

            $message =
            "✅ Admin Registration Successful";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>EventSphere Register</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
height:100vh;
display:flex;
justify-content:center;
align-items:center;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s ease infinite;
overflow:hidden;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

.card{
width:430px;
padding:35px;
background:rgba(255,255,255,0.30);
backdrop-filter:blur(20px);
border-radius:28px;
box-shadow:0 8px 32px rgba(31,38,135,0.12);
border:1px solid rgba(255,255,255,0.2);
}

.logo{
font-size:30px;
font-weight:700;
text-align:center;
margin-bottom:10px;
color:#6C9BD2;
}

.subtitle{
text-align:center;
opacity:0.7;
margin-bottom:25px;
}

.robot{
width:110px;
display:block;
margin:0 auto 18px;
animation:float 3s ease-in-out infinite;
}

@keyframes float{
0%,100%{transform:translateY(0);}
50%{transform:translateY(-10px);}
}

.select-box{
margin-bottom:18px;
}

.select-box select{
width:100%;
padding:14px;
border:none;
outline:none;
border-radius:16px;
background:rgba(255,255,255,0.45);
font-size:15px;
}

.input-box{
position:relative;
margin-bottom:18px;
}

.input-box i{
position:absolute;
left:15px;
top:15px;
opacity:0.6;
}

.input-box input{
width:100%;
padding:14px 18px 14px 45px;
border:none;
outline:none;
border-radius:16px;
background:rgba(255,255,255,0.45);
font-size:15px;
}

.btn{
width:100%;
padding:14px;
border:none;
border-radius:16px;
background:#6C9BD2;
color:white;
font-weight:600;
font-size:15px;
cursor:pointer;
transition:0.3s;
}

.btn:hover{
transform:translateY(-2px);
}

.message{
margin-top:15px;
text-align:center;
font-weight:600;
}

.bottom-link{
margin-top:20px;
text-align:center;
}

.bottom-link a{
text-decoration:none;
color:#6C9BD2;
font-weight:600;
}

#adminFields{
display:none;
}

</style>

</head>

<body>

<div class="card">

<img class="robot"
src="https://cdn-icons-png.flaticon.com/512/4712/4712109.png">

<div class="logo">
🎉 EventSphere
</div>

<p class="subtitle">
Create your account 💙
</p>

<form method="POST">

<div class="select-box">

<select name="role" id="roleSelect">

<option value="student">
Register as Student
</option>

<option value="admin">
Register as Admin
</option>

</select>

</div>

<!-- STUDENT FIELDS -->

<div id="studentFields">

<div class="input-box">
<i class="fa-solid fa-id-card"></i>

<input type="text"
name="student_id"
placeholder="Student ID">
</div>

<div class="input-box">
<i class="fa-solid fa-user"></i>

<input type="text"
name="name"
placeholder="Student Name">
</div>

<div class="input-box">
<i class="fa-solid fa-envelope"></i>

<input type="email"
name="email"
placeholder="Email">
</div>

<div class="input-box">
<i class="fa-solid fa-lock"></i>

<input type="password"
name="password"
placeholder="Password">
</div>

</div>

<!-- ADMIN FIELDS -->

<div id="adminFields">

<div class="input-box">
<i class="fa-solid fa-user-shield"></i>

<input type="text"
name="admin_name"
placeholder="Admin Name">
</div>

<div class="input-box">
<i class="fa-solid fa-envelope"></i>

<input type="email"
name="admin_email"
placeholder="Admin Email">
</div>

<div class="input-box">
<i class="fa-solid fa-lock"></i>

<input type="password"
name="admin_password"
placeholder="Password">
</div>

</div>

<button class="btn" name="register">
Create Account
</button>

</form>

<div class="message">
<?php echo $message; ?>
</div>

<div class="bottom-link">

Already have account?

<a href="login.php">
Login
</a>

</div>

</div>

<script>

const roleSelect =
document.getElementById("roleSelect");

const studentFields =
document.getElementById("studentFields");

const adminFields =
document.getElementById("adminFields");

roleSelect.addEventListener(
"change",
function(){

if(this.value == "admin"){

adminFields.style.display = "block";

studentFields.style.display = "none";

}else{

studentFields.style.display = "block";

adminFields.style.display = "none";

}

}
);

</script>

</body>
</html>