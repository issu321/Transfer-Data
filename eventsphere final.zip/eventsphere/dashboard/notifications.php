<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentName = $_SESSION['student_name'];

/* THEME */
$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* FETCH NOTIFICATIONS */
$notifications = $conn->query("
    SELECT * FROM notifications
    ORDER BY id DESC
");

/* SEARCH */
$search = strtolower(trim($_GET['search'] ?? ""));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications - EventSphere</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* BASE */
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
display:flex;
transition:0.4s;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s infinite;
}

body.dark{
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
color:white;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* SIDEBAR (same style as your student pages) */
.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.3);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

body.dark .logo{
color:#4CC9F0;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
transition:0.3s;
font-weight:600;
color:inherit;
}

.menu a.active,
.menu a:hover{
background:#AFCBFF;
transform:translateX(5px);
}

body.dark .menu a.active,
body.dark .menu a:hover{
background:#4CC9F0;
color:black;
}

/* MAIN */
.main{
margin-left:260px;
width:calc(100% - 260px);
padding:30px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
gap:20px;
flex-wrap:wrap;
margin-bottom:25px;
}

.search-box{
flex:1;
position:relative;
}

.search-box input{
width:100%;
padding:14px 18px 14px 45px;
border:none;
outline:none;
border-radius:18px;
background:rgba(255,255,255,0.4);
}

body.dark .search-box input{
background:rgba(255,255,255,0.08);
color:white;
}

.search-box i{
position:absolute;
left:16px;
top:15px;
opacity:0.6;
}

/* PROFILE */
.profile{
display:flex;
align-items:center;
gap:15px;
}

.toggle-btn{
border:none;
padding:10px 14px;
border-radius:12px;
cursor:pointer;
background:#AFCBFF;
}

body.dark .toggle-btn{
background:#4CC9F0;
}

/* TITLE */
.header-card{
padding:30px;
border-radius:25px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
margin-bottom:25px;
}

body.dark .header-card{
background:rgba(22,32,51,0.82);
}

/* NOTIFICATION CARD */
.notif-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
gap:20px;
}

.notif-card{
padding:20px;
border-radius:20px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
transition:0.3s;
}

body.dark .notif-card{
background:rgba(22,32,51,0.82);
}

.notif-card:hover{
transform:translateY(-6px);
}

.type{
display:inline-block;
padding:6px 12px;
border-radius:20px;
background:#dbeafe;
font-size:12px;
margin-bottom:10px;
}

body.dark .type{
background:#223A5E;
}

</style>
</head>

<body class="<?php echo $savedTheme == 'dark' ? 'dark' : ''; ?>">

<!-- SIDEBAR -->
<div class="sidebar">

<div class="logo">🎉 EventSphere</div>

<div class="menu">

<a href="student-dashboard.php">🏠 Dashboard</a>
<a href="clubs.php">🎭 Clubs</a>
<a href="events.php">📅 Events</a>
<a href="registrations.php">📝 Registrations</a>
<a class="active" href="notifications.php">🔔 Notifications</a>
<a href="certificates.php">📜 Certificates</a>
<a href="navigation.php">🗺 Campus Navigation</a>
<a href="ai-assistant.php">🤖 AI Assistant</a>
<a href="profile.php">👤 Profile</a>
<a href="../auth/logout.php">🚪 Logout</a>

</div>
</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">

<form class="search-box">
<i class="fa fa-search"></i>
<input type="text" id="searchInput" placeholder="Search notifications...">
</form>

<div class="profile">

<button class="toggle-btn" onclick="toggleTheme()">🌙</button>

<div>
<h3><?php echo $studentName; ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>

</div>

</div>

<!-- HEADER -->
<div class="header-card">
<h1>🔔 Notifications</h1>
<p>Latest updates from your college and admin team.</p>
</div>

<!-- LIST -->
<div class="notif-grid">

<?php while($row = $notifications->fetch_assoc()):

if(
$search == "" ||
strpos(strtolower($row['title']), $search) !== false ||
strpos(strtolower($row['message']), $search) !== false ||
strpos(strtolower($row['type']), $search) !== false
):
?>

<div class="notif-card">

<div class="type">
<?php echo $row['type']; ?>
</div>

<h3><?php echo $row['title']; ?></h3>

<p style="opacity:0.85; margin-top:10px;">
<?php echo $row['message']; ?>
</p>

<small style="opacity:0.6;">
<?php echo $row['created_at']; ?>
</small>

</div>

<?php endif; endwhile; ?>

</div>

</div>

<script>

function toggleTheme(){
document.body.classList.toggle("dark");

let mode = document.body.classList.contains("dark") ? "dark" : "light";
document.cookie = "eventsphere_theme="+mode+"; path=/";
}

/* SEARCH */
document.getElementById("searchInput").addEventListener("input",function(){
let val=this.value.toLowerCase();
document.querySelectorAll(".notif-card").forEach(card=>{
card.style.display = card.innerText.toLowerCase().includes(val) ? "block" : "none";
});
});

</script>

</body>
</html>