<?php
session_start();

if(!isset($_SESSION['student_id'])){

    header("Location: ../auth/login.php");

    exit();
}

$studentName =
$_SESSION['student_name'];
/* THEME */

$savedTheme = "";

if(isset($_COOKIE['eventsphere_theme'])){
    $savedTheme = $_COOKIE['eventsphere_theme'];
}

/* PROFILE IMAGE */

$defaultProfile =
"https://cdn-icons-png.flaticon.com/512/3135/3135715.png";

if(
!isset($_SESSION['student_image']) ||
$_SESSION['student_image'] == ""
){
    $_SESSION['student_image'] = $defaultProfile;
}

/* AI ASSISTANT */

$aiReply = "";

if(isset($_POST['ask_ai'])){

    $question =
    strtolower(trim($_POST['question']));

    if(
    strpos($question,"hackathon") !== false ||
    strpos($question,"coding") !== false
    ){

        $aiReply =
        "💻 Hackathon 2026 is happening in IT Block Room 305. Registrations are open now 🚀";

    }

    elseif(
    strpos($question,"sports") !== false
    ){

        $aiReply =
        "⚽ Sports Tournament starts on June 28 at Main Ground 🏆";

    }

    elseif(
    strpos($question,"debate") !== false
    ){

        $aiReply =
        "🗣 Debate Competition begins at 10:00 AM in Seminar Hall ✨";

    }

    elseif(
    strpos($question,"certificate") !== false
    ){

        $aiReply =
        "📜 Certificates are available in the Certificates Module.";

    }

    elseif(
    strpos($question,"club") !== false
    ){

        $aiReply =
        "🎭 Clubs help students improve creativity, teamwork and leadership 💫";

    }

    elseif(
    strpos($question,"stress") !== false ||
    strpos($question,"sad") !== false ||
    strpos($question,"tired") !== false
    ){

        $aiReply =
        "🌸 You're doing well, $studentName. Take proper rest and don't pressure yourself too much 💙";

    }

    elseif(
    strpos($question,"hello") !== false ||
    strpos($question,"hi") !== false
    ){

        $aiReply =
        "👋 Hello $studentName! I'm your EventSphere AI assistant 💙";

    }

    else{

        $aiReply =
        "🤖 I'm here to help you with events, studies, clubs and campus activities 💙";

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>EventSphere Dashboard</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{

display:flex;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;

animation:gradientBG 18s ease infinite;

transition:0.4s;

overflow-x:hidden;

}

body.dark{

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

background-size:500% 500%;

color:white;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

/* SIDEBAR */

.sidebar{

width:250px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.25);

backdrop-filter:blur(24px);

border-right:1px solid rgba(255,255,255,0.2);

}

body.dark .sidebar{
background:rgba(17,34,64,0.88);
}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:28px;

color:#6C9BD2;

}

.menu{
display:flex;
flex-direction:column;
gap:10px;
}

.menu a{

text-decoration:none;

padding:13px 14px;

border-radius:14px;

font-weight:600;

color:inherit;

transition:0.3s;

font-size:15px;

}

.menu a:hover,
.menu a.active{

background:rgba(255,255,255,0.35);

transform:translateX(4px);

}

body.dark .menu a:hover,
body.dark .menu a.active{

background:rgba(76,201,240,0.15);

}

/* MAIN */

.main{

margin-left:250px;

width:calc(100% - 250px);

padding:24px;

}

/* TOPBAR */

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

gap:20px;

margin-bottom:22px;

flex-wrap:wrap;

}

/* SEARCH */

.search-box{

flex:1;

min-width:260px;

position:relative;

}

.search-box input{

width:100%;

padding:14px 18px;
padding-left:45px;

border:none;
outline:none;

border-radius:18px;

background:rgba(255,255,255,0.35);

backdrop-filter:blur(14px);

font-size:15px;

box-shadow:0 4px 12px rgba(0,0,0,0.05);

}

body.dark .search-box input{

background:rgba(255,255,255,0.08);

color:white;

}

.search-box i{

position:absolute;

left:16px;
top:15px;

opacity:0.6;

}

/* SEARCH RESULTS */

#searchResults{

position:absolute;

top:60px;
left:0;

width:100%;

background:rgba(255,255,255,0.95);

backdrop-filter:blur(20px);

border-radius:18px;

overflow:hidden;

display:none;

z-index:999;

box-shadow:0 8px 30px rgba(0,0,0,0.12);

}

body.dark #searchResults{

background:#1B263B;
color:white;

}

.search-item{

padding:14px 18px;

cursor:pointer;

transition:0.3s;

border-bottom:1px solid rgba(0,0,0,0.05);

}

.search-item:hover{

background:#dbeafe;

}

body.dark .search-item:hover{

background:#223A5E;

}

/* PROFILE */

.profile{

display:flex;
align-items:center;
gap:16px;

}

.profile-dropdown{
position:relative;
}

.profile-dropdown img{

width:45px;
height:45px;

border-radius:50%;

object-fit:cover;

cursor:pointer;

border:2px solid #dbeafe;

}

.profile-menu{

position:absolute;

right:0;
top:60px;

width:240px;

background:white;

padding:18px;

border-radius:18px;

display:none;

z-index:999;

box-shadow:0 8px 30px rgba(0,0,0,0.15);

}

body.dark .profile-menu{

background:#1B263B;
color:white;

}

.profile-menu a{

display:block;

padding:12px;

border-radius:12px;

text-decoration:none;

color:inherit;

margin-top:8px;

}

.profile-menu a:hover{

background:#dbeafe;

}

body.dark .profile-menu a:hover{

background:#223A5E;

}

/* BUTTON */

.toggle-btn{

border:none;

padding:10px 14px;

border-radius:12px;

cursor:pointer;

background:rgba(255,255,255,0.35);

font-size:15px;

}

body.dark .toggle-btn{

background:#223A5E;
color:white;

}

/* HERO */

.hero{

display:grid;
grid-template-columns:1.5fr 1fr;

gap:20px;

margin-bottom:22px;

align-items:start;

}

.hero-card{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:24px;

border-radius:24px;

box-shadow:0 8px 25px rgba(0,0,0,0.05);

}

body.dark .hero-card{
background:rgba(22,32,51,0.72);
}

/* WELCOME CARD */

.welcome-card{

min-height:200px;

display:flex;
flex-direction:column;
justify-content:center;

}

.welcome-card h1{

font-size:32px;

margin-bottom:12px;

}

.welcome-card p{

line-height:1.7;

opacity:0.85;

max-width:500px;

}

.hero-buttons{

display:flex;
gap:14px;

margin-top:20px;

flex-wrap:wrap;

}

.btn{

padding:12px 18px;

border:none;

border-radius:14px;

cursor:pointer;

font-weight:600;

transition:0.3s;

}

.btn:hover{
transform:translateY(-2px);
}

.primary-btn{
background:#bfd7ff;
}

.secondary-btn{
background:#dbeafe;
}

/* CALENDAR */

.calendar-box{

padding:20px;

border-radius:18px;

background:linear-gradient(
135deg,
#dbeafe,
#e9d5ff
);

line-height:2;

font-weight:600;

margin-top:15px;

}

/* GRID */

.grid{

display:grid;
grid-template-columns:2fr 1fr;

gap:20px;

}

/* SECTION CARD */

.section-card{

background:rgba(255,255,255,0.28);

backdrop-filter:blur(22px);

padding:20px;

border-radius:24px;

margin-bottom:20px;

box-shadow:0 8px 25px rgba(0,0,0,0.05);

}

body.dark .section-card{
background:rgba(22,32,51,0.72);
}

.section-title{

display:flex;
justify-content:space-between;
align-items:center;

margin-bottom:18px;

}

.section-title p{

cursor:pointer;
font-weight:600;

}

/* EVENTS */

.events{

display:grid;
grid-template-columns:repeat(auto-fit,minmax(180px,1fr));

gap:15px;

}

.event-card{

background:rgba(255,255,255,0.42);

padding:14px;

border-radius:18px;

cursor:pointer;

transition:0.3s;

}

.event-card:hover{
transform:translateY(-5px);
}

body.dark .event-card{
background:#1e2b44;
}

.event-card img{

width:100%;
height:120px;

object-fit:cover;

border-radius:14px;

margin-bottom:10px;

}

.event-card h4{
margin-bottom:6px;
}

.event-card p{
font-size:14px;
opacity:0.8;
}

/* CLUBS */

.club-list{

display:grid;
grid-template-columns:repeat(auto-fit,minmax(130px,1fr));

gap:14px;

}

.club{

padding:18px 12px;

border-radius:18px;

text-align:center;

background:rgba(255,255,255,0.42);

font-weight:600;

cursor:pointer;

transition:0.3s;

}

.club:hover{
transform:translateY(-4px);
}

body.dark .club{
background:#1e2b44;
}

/* NOTIFICATIONS */

.notify{

padding:14px;

border-radius:14px;

margin-bottom:14px;

background:rgba(255,255,255,0.35);

cursor:pointer;

transition:0.3s;

}

.notify:hover{
transform:translateX(3px);
}

body.dark .notify{
background:#1e2b44;
}

/* AI BOX */

.ai-box textarea{

width:100%;
height:90px;

border:none;
outline:none;

border-radius:14px;

padding:15px;

resize:none;

background:rgba(255,255,255,0.35);

margin-top:10px;

}

body.dark .ai-box textarea{

background:#101827;
color:white;

}

.ai-response{

margin-top:15px;

padding:15px;

border-radius:14px;

background:#dbeafe;

color:#2B2B2B;

font-weight:600;

line-height:1.7;

}

@media(max-width:1100px){

.hero{
grid-template-columns:1fr;
}

.grid{
grid-template-columns:1fr;
}

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a class="active" href="student-dashboard.php">🏠 Dashboard</a>
<a href="clubs.php">🎭 Clubs</a>
<a href="events.php">📅 Events</a>
<a href="registrations.php">📝 Registrations</a>
<a href="results.php">🏆 Results</a>
<a href="certificates.php">📜 Certificates</a>
<a href="navigation.php">🗺 Campus Navigation</a>
<a href="ai-assistant.php">🤖 AI Assistant</a>
<a href="notifications.php">🔔 Notifications</a>
<a href="profile.php">👤 Profile</a>
<a href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>

</div>

</div>

<!-- MAIN -->

<div class="main">

<!-- TOPBAR -->

<div class="topbar">

<form class="search-box"
onsubmit="return false;">

<i class="fa-solid fa-magnifying-glass"></i>

<input
type="text"
id="searchInput"
placeholder="Search events, clubs, AI..."
onkeyup="searchFeature()"
autocomplete="off">

<div id="searchResults"></div>

</form>

<div class="profile">

<i class="fa-solid fa-bell fa-lg"
style="cursor:pointer;"
onclick="window.location.href='notifications.php'"></i>

<button class="toggle-btn"
onclick="toggleTheme()">

🌙

</button>

<div class="profile-dropdown">

<img
src="<?php echo $_SESSION['student_image']; ?>"
onclick="toggleProfileMenu()">

<div class="profile-menu"
id="profileMenu">

<h3><?php echo $studentName; ?></h3>

<p style="opacity:0.7;font-size:13px;">
Student
</p>

<a href="profile.php">
👤 My Profile
</a>

<a href="settings.php">
⚙ Settings
</a>

<a href="../auth/logout.php">
🚪 Logout
</a>

</div>

</div>

</div>

</div>

<!-- HERO -->

<div class="hero">

<div class="hero-card welcome-card">

<h1>
Welcome back,
<?php echo $studentName; ?> 👋
</h1>

<p>
Discover amazing events, register competitions and explore your campus ecosystem beautifully.
</p>

<div class="hero-buttons">

<a href="events.php">
<button class="btn primary-btn">
Explore Events
</button>
</a>

<a href="registrations.php">
<button class="btn secondary-btn">
My Registrations
</button>
</a>

</div>

</div>

<div class="hero-card">

<h3>📅 Event Calendar</h3>

<div class="calendar-box">

💻 Hackathon — June 15 <br>

🗣 Debate Competition — June 20 <br>

⚽ Sports Fest — June 28

</div>

</div>

</div>

<!-- GRID -->

<div class="grid">

<!-- LEFT -->

<div>

<!-- EVENTS -->

<div class="section-card">

<div class="section-title">

<h2>🔥 Upcoming Events</h2>

<p onclick="window.location.href='events.php'">
View All →
</p>

</div>

<div class="events">

<div class="event-card"
onclick="window.location.href='events.php'">

<img src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f">

<h4>🎤 Singing Competition</h4>

<p>Auditorium Hall</p>

</div>

<div class="event-card"
onclick="window.location.href='events.php'">

<img src="https://images.unsplash.com/photo-1515879218367-8466d910aaa4">

<h4>💻 Hackathon 2026</h4>

<p>IT Block Room 305</p>

</div>

<div class="event-card"
onclick="window.location.href='events.php'">

<img src="https://images.unsplash.com/photo-1547347298-4074fc3086f0">

<h4>⚽ Sports Tournament</h4>

<p>Main Ground</p>

</div>

</div>

</div>

<!-- CLUBS -->

<div class="section-card">

<div class="section-title">

<h2>🎭 Our Clubs</h2>

<p onclick="window.location.href='clubs.php'">
View All →
</p>

</div>

<div class="club-list">

<div class="club"
onclick="window.location.href='clubs.php'">
🎤 DISHA
</div>

<div class="club"
onclick="window.location.href='clubs.php'">
💻 IT CLUB
</div>

<div class="club"
onclick="window.location.href='clubs.php'">
🌱 NSS
</div>

</div>

</div>

</div>

<!-- RIGHT -->

<div>

<!-- NOTIFICATIONS -->

<div class="section-card">

<div class="section-title">

<h2>🔔 Notifications</h2>

<p onclick="window.location.href='notifications.php'">
View All →
</p>

</div>

<div class="notify"
onclick="window.location.href='notifications.php'">

📢 Hackathon registrations closing soon

</div>

<div class="notify"
onclick="window.location.href='notifications.php'">

🏆 Debate results announced

</div>

<div class="notify"
onclick="window.location.href='notifications.php'">

📜 NSS certificates uploaded successfully

</div>

</div>

<!-- AI -->

<div class="section-card ai-box">

<h2>🤖 Ask AI Assistant</h2>

<form method="POST">

<textarea
name="question"
placeholder="Ask me about events, studies, clubs..."
required></textarea>

<button
class="btn primary-btn"
name="ask_ai"
style="margin-top:15px;width:100%;">

Ask AI

</button>

</form>

<?php if($aiReply != ""): ?>

<div class="ai-response">

<?php echo $aiReply; ?>

</div>

<?php endif; ?>

</div>

</div>

</div>

</div>

<script>

/* THEME */

function toggleTheme(){

document.body.classList.toggle('dark');

if(document.body.classList.contains('dark')){

document.cookie =
"eventsphere_theme=dark; path=/";

}
else{

document.cookie =
"eventsphere_theme=light; path=/";

}

}

/* PROFILE MENU */

function toggleProfileMenu(){

let menu =
document.getElementById("profileMenu");

if(menu.style.display === "block"){
menu.style.display = "none";
}
else{
menu.style.display = "block";
}

}

/* CLOSE PROFILE MENU */

window.onclick = function(e){

if(
!e.target.matches('.profile-dropdown img')
){

let menu =
document.getElementById("profileMenu");

if(menu){
menu.style.display = "none";
}

}

}

/* SEARCH */

function searchFeature(){

let input =
document.getElementById("searchInput")
.value
.toLowerCase()
.trim();

let resultsBox =
document.getElementById("searchResults");

if(input === ""){

resultsBox.style.display = "none";

return;

}

let data = [

{
name:"🎤 Singing Competition",
page:"events.php"
},

{
name:"💻 Hackathon 2026",
page:"events.php"
},

{
name:"⚽ Sports Tournament",
page:"events.php"
},

{
name:"🎭 DISHA",
page:"clubs.php"
},

{
name:"💻 IT CLUB",
page:"clubs.php"
},

{
name:"🌱 NSS",
page:"clubs.php"
},

{
name:"📜 Certificates",
page:"certificates.php"
},

{
name:"📝 Registrations",
page:"registrations.php"
},

{
name:"🏆 Results",
page:"results.php"
},

{
name:"🤖 AI Assistant",
page:"ai-assistant.php"
},

{
name:"🔔 Notifications",
page:"notifications.php"
},

{
name:"⚙ Settings",
page:"settings.php"
},

{
name:"👤 Profile",
page:"profile.php"
},

{
name:"🗺 Campus Navigation",
page:"navigation.php"
}

];

let filtered =
data.filter(item =>
item.name.toLowerCase().includes(input)
);

if(filtered.length > 0){

resultsBox.innerHTML = "";

filtered.forEach(item => {

resultsBox.innerHTML += `

<div class="search-item"
onclick="window.location.href='${item.page}'">

${item.name}

</div>

`;

});

resultsBox.style.display = "block";

}
else{

resultsBox.innerHTML = `

<div class="search-item">

😅 No matching result found

</div>

`;

resultsBox.style.display = "block";

}

}

/* CLOSE SEARCH */

window.addEventListener("click", function(e){

let searchBox =
document.querySelector(".search-box");

let results =
document.getElementById("searchResults");

if(!searchBox.contains(e.target)){

results.style.display = "none";

}

});

</script>

</body>
</html>