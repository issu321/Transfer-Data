<?php
session_start();
if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Achievements</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
</head>

<body>

<div class="dashboard">

<?php include("../includes/sidebar.php"); ?>

<div class="main-content">

<div class="hero">
<h1>🏆 Achievements</h1>
<p>Your rewards & progress</p>
</div>

<div class="glass-card">

<div class="achievement-card">
<h3>🏅 Gold Badge</h3>
<p>Completed Hackathon</p>
</div>

<div class="achievement-card">
<h3>🥈 Silver Badge</h3>
<p>2 Events Participated</p>
</div>

<div class="achievement-card">
<h3>🎖️ Participation Badge</h3>
<p>Joined Clubs Activities</p>
</div>

</div>

</div>

</div>

</body>
</html>