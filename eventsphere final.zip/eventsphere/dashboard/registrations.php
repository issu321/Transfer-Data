<?php
session_start();

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

include("../includes/db.php");

$studentName = $_SESSION['student_name'];
$studentId = $_SESSION['student_id'];

$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* CANCEL REGISTRATION */

if(isset($_GET['cancel'])){

    $registrationId = intval($_GET['cancel']);

    /* GET EVENT ID */

    $getEvent = $conn->query(
    "SELECT event_id
     FROM registrations
     WHERE id='$registrationId'
     AND student_id='$studentId'"
    );

    if($getEvent->num_rows > 0){

        $eventData = $getEvent->fetch_assoc();

        $eventId = $eventData['event_id'];

        /* CANCEL */

        $conn->query(
        "UPDATE registrations
         SET status='Cancelled'
         WHERE id='$registrationId'"
        );

        /* RETURN SEAT */

        $conn->query(
        "UPDATE events
         SET available_seats =
         available_seats + 1
         WHERE id='$eventId'"
        );
    }

    header("Location: registrations.php");
    exit();
}

/* FETCH REGISTRATIONS */

$query = $conn->query(

"SELECT registrations.id AS reg_id,
registrations.status,
registrations.registered_at,

events.title,
events.event_date,
events.location,
events.image,
events.category

FROM registrations

JOIN events
ON registrations.event_id = events.id

WHERE registrations.student_id='$studentId'

ORDER BY registrations.id DESC"

);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Registrations</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Segoe UI;
}

body{
display:flex;
transition:0.4s;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s infinite;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

body.dark{
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
color:white;
}

.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.3);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

body.dark .logo{
color:#4CC9F0;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
transition:0.3s;
font-weight:600;
color:inherit;
}

.menu a.active{
background:rgba(76,201,240,0.18);
color:#4CC9F0;
box-shadow:0 0 12px rgba(76,201,240,0.25);
}

.menu a:hover{
background:rgba(76,201,240,0.08);
transform:translateX(5px);
}

.main{
margin-left:260px;
width:calc(100% - 260px);
padding:30px;
}

.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
flex-wrap:wrap;
gap:20px;
}

.profile{
display:flex;
align-items:center;
gap:12px;
}

.mode-btn{
border:none;
padding:10px 14px;
border-radius:12px;
cursor:pointer;
background:rgba(255,255,255,0.35);
}

body.dark .mode-btn{
background:#223A5E;
color:white;
}

.header-card{
padding:30px;
border-radius:25px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
margin-bottom:25px;
}

body.dark .header-card{
background:rgba(22,32,51,0.82);
}

.reg-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
gap:22px;
}

.reg-card{
border-radius:22px;
overflow:hidden;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
transition:0.3s;
}

body.dark .reg-card{
background:rgba(22,32,51,0.82);
}

.reg-card:hover{
transform:translateY(-8px) scale(1.02);
}

.reg-card img{
width:100%;
height:200px;
object-fit:cover;
}

.reg-content{
padding:18px;
}

.event-type{
display:inline-block;
padding:6px 12px;
border-radius:20px;
font-size:12px;
background:#dbeafe;
margin-bottom:10px;
}

body.dark .event-type{
background:#223A5E;
}

.status{
display:inline-block;
padding:8px 14px;
border-radius:20px;
font-weight:600;
margin-top:12px;
color:white;
}

.registered{
background:linear-gradient(135deg,#22c55e,#16a34a);
}

.cancelled{
background:linear-gradient(135deg,#ef4444,#dc2626);
}

.btn{
display:inline-block;
padding:10px 14px;
border-radius:12px;
text-decoration:none;
font-weight:600;
margin-top:12px;
background:#ef4444;
color:white;
}

.empty{
padding:40px;
text-align:center;
border-radius:22px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
}

body.dark .empty{
background:rgba(22,32,51,0.82);
}

</style>
</head>

<body class="<?php echo $savedTheme == 'dark' ? 'dark' : ''; ?>">

<div class="sidebar">

<div class="logo">🎉 EventSphere</div>

<div class="menu">

<a href="student-dashboard.php">🏠 Dashboard</a>

<a href="clubs.php">🎭 Clubs</a>

<a href="events.php">📅 Events</a>

<a class="active" href="registrations.php">
📝 Registrations
</a>

<a href="results.php">🏆 Results</a>

<a href="certificates.php">📜 Certificates</a>

<a href="navigation.php">🗺 Navigation</a>

<a href="ai-assistant.php">🤖 AI Assistant</a>

<a href="notifications.php">🔔 Notifications</a>

<a href="../auth/logout.php">🚪 Logout</a>

</div>
</div>

<div class="main">

<div class="topbar">

<div>
<h1>📝 My Registrations</h1>
<p>Track all your registered events.</p>
</div>

<div class="profile">

<button class="mode-btn"
onclick="toggleTheme()">🌙</button>

<div>
<h3><?php echo htmlspecialchars($studentName); ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>

</div>
</div>

<div class="header-card">
<h2>🎟 Your Event Activity</h2>
<p>
Manage your registered campus events easily.
</p>
</div>

<?php if($query->num_rows > 0): ?>

<div class="reg-grid">

<?php while($row = $query->fetch_assoc()): ?>

<div class="reg-card">

<img src="../assets/images/events/<?php echo $row['image']; ?>">

<div class="reg-content">

<div class="event-type">
<?php echo htmlspecialchars($row['category']); ?>
</div>

<h2>
🎉 <?php echo htmlspecialchars($row['title']); ?>
</h2>

<p>
📅 <?php echo htmlspecialchars($row['event_date']); ?>
</p>

<p>
📍 <?php echo htmlspecialchars($row['location']); ?>
</p>

<p>
🕒 Registered:
<?php echo date("d M Y",
strtotime($row['registered_at'])); ?>
</p>

<div class="status
<?php echo strtolower($row['status']); ?>">

<?php echo $row['status']; ?>

</div>

<?php if($row['status'] == 'Registered'): ?>

<br>

<a class="btn"
href="?cancel=<?php echo $row['reg_id']; ?>">

Cancel Registration

</a>

<?php endif; ?>

</div>
</div>

<?php endwhile; ?>

</div>

<?php else: ?>

<div class="empty">

<h2>😶 No Registrations Yet</h2>

<p style="margin-top:10px;">
Register for events to see them here.
</p>

</div>

<?php endif; ?>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle("dark");

let mode =
document.body.classList.contains("dark")
? "dark"
: "light";

document.cookie =
"eventsphere_theme="+mode+"; path=/";
}

</script>

</body>
</html>