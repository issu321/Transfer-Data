<?php
session_start();

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentName = $_SESSION['student_name'];

/* THEME */
$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* REGISTERED SYSTEM */
if(!isset($_SESSION['registered_events'])){
    $_SESSION['registered_events'] = [];
}

/* DATABASE */
include("../includes/db.php");

if(!isset($conn) || !$conn){
    die("Database connection failed");
}

/* REGISTER EVENT */

if(isset($_GET['register'])){

    $eventId = intval($_GET['register']);

    $studentId = $_SESSION['student_id'];

    /* CHECK DUPLICATE */

    $check = $conn->query(
    "SELECT * FROM registrations
     WHERE student_id='$studentId'
     AND event_id='$eventId'
     AND status='Registered'"
    );

    if($check->num_rows == 0){

        /* CHECK SEATS */

        $seatCheck = $conn->query(
        "SELECT available_seats
         FROM events
         WHERE id='$eventId'"
        );

        $seatData = $seatCheck->fetch_assoc();

        if($seatData['available_seats'] > 0){

            /* INSERT REGISTRATION */

            $conn->query(
            "INSERT INTO registrations
            (student_id,event_id)
            VALUES
            ('$studentId','$eventId')"
            );

            /* UPDATE SEATS */

            $conn->query(
            "UPDATE events
             SET available_seats =
             available_seats - 1
             WHERE id='$eventId'"
            );
        }
    }

    header("Location: events.php");
    exit();
}

/* EVENTS */

$eventsQuery =
$conn->query(
"SELECT * FROM events ORDER BY id DESC"
);

/* SEARCH */
$search = strtolower(trim($_GET['search'] ?? ""));

/* REGISTER (SAFE FIX - prevents duplicate reload spam) */
if(isset($_GET['register'])){
    $eventName = $_GET['register'];

    if(!in_array($eventName, $_SESSION['registered_events'])){
        $_SESSION['registered_events'][] = $eventName;
    }

    // prevent re-submission on refresh
    header("Location: events.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EventSphere Events</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>
/* (UNCHANGED UI - YOUR ORIGINAL CSS KEPT EXACTLY) */
*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI;}

body{
display:flex;
transition:0.4s;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:bg 18s infinite;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

body.dark{
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
color:white;
}

.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.3);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

body.dark .logo{color:#4CC9F0;}

.menu{display:flex;flex-direction:column;gap:12px;}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
transition:0.3s;
font-weight:600;
color:inherit;
}

.menu a.active{
background:rgba(76,201,240,0.18);
color:#4CC9F0;
box-shadow:0 0 12px rgba(76,201,240,0.25);
}

.menu a:hover{
background:rgba(76,201,240,0.08);
transform:translateX(5px);
}

.main{margin-left:260px;width:calc(100% - 260px);padding:30px;}

.topbar{
display:flex;
justify-content:space-between;
align-items:center;
gap:20px;
flex-wrap:wrap;
margin-bottom:25px;
}

.search-box{flex:1;position:relative;}

.search-box input{
width:100%;
padding:14px 40px;
border:none;
border-radius:18px;
background:rgba(255,255,255,0.4);
outline:none;
}

body.dark .search-box input{background:rgba(255,255,255,0.08);color:white;}

.profile{display:flex;align-items:center;gap:12px;}

.mode-btn{
border:none;
padding:10px 14px;
border-radius:12px;
cursor:pointer;
background:rgba(255,255,255,0.35);
}

body.dark .mode-btn{background:#223A5E;color:white;}

.header-card{
padding:30px;
border-radius:25px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
margin-bottom:25px;
}

body.dark .header-card{background:rgba(22,32,51,0.82);}

.events-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
gap:22px;
}

.event-card{
border-radius:22px;
overflow:hidden;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
transition:0.3s;
}

body.dark .event-card{background:rgba(22,32,51,0.82);}

.event-card:hover{transform:translateY(-8px) scale(1.02);}

.event-card img{
width:100%;
height:200px;
object-fit:cover;
}

.event-content{padding:18px;}

.event-type{
display:inline-block;
padding:6px 12px;
border-radius:20px;
font-size:12px;
background:#dbeafe;
margin-bottom:10px;
}

body.dark .event-type{background:#223A5E;}

.registered{
display:inline-block;
padding:8px 14px;
border-radius:20px;
background:linear-gradient(135deg,#22c55e,#16a34a);
color:white;
font-weight:600;
margin-top:10px;
box-shadow:0 0 12px rgba(34,197,94,0.3);
}

.btn{
display:inline-block;
padding:10px 14px;
border-radius:12px;
text-decoration:none;
font-weight:600;
margin-top:10px;
}

.primary{background:#4CC9F0;color:black;}
.secondary{background:#AFCBFF;color:black;}
</style>
</head>

<body class="<?php echo $savedTheme == 'dark' ? 'dark' : ''; ?>">

<div class="sidebar">
<div class="logo">🎉 EventSphere</div>

<div class="menu">
<a href="student-dashboard.php">🏠 Dashboard</a>
<a href="clubs.php">🎭 Clubs</a>
<a class="active" href="events.php">📅 Events</a>
<a href="registrations.php">📝 Registrations</a>
<a href="results.php">🏆 Results</a>
<a href="certificates.php">📜 Certificates</a>
<a href="navigation.php">🗺 Navigation</a>
<a href="ai-assistant.php">🤖 AI Assistant</a>
<a href="notifications.php">🔔 Notifications</a>
<a href="../auth/logout.php">🚪 Logout</a>
</div>
</div>

<div class="main">

<div class="topbar">
<form class="search-box">
<i class="fa fa-search" style="position:absolute;left:14px;top:14px;opacity:0.6;"></i>
<input id="searchInput" type="text" placeholder="Search events...">
</form>

<div class="profile">
<button class="mode-btn" onclick="toggleTheme()">🌙</button>
<div>
<h3><?php echo htmlspecialchars($studentName); ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>
</div>
</div>

<div class="header-card">
<h1>📅 Explore Events</h1>
<p>Join campus activities, competitions and workshops.</p>
</div>

<div class="events-grid">

<?php while($event = $eventsQuery->fetch_assoc()): 

$studentId = $_SESSION['student_id'];

$checkRegistered = $conn->query(
"SELECT * FROM registrations
WHERE student_id='$studentId'
AND event_id='{$event['id']}'
AND status='Registered'"
);

$registered =
$checkRegistered->num_rows > 0;
if($search == "" || strpos(strtolower($event['title']),$search) !== false):
?>

<div class="event-card">

<img src="../assets/images/events/<?php echo $event['image']; ?>">

<div class="event-content">

<div class="event-type">
<?php echo htmlspecialchars($event['category']); ?>
</div>

<h2>🎉 <?php echo htmlspecialchars($event['title']); ?></h2>

<p>📅 <?php echo htmlspecialchars($event['event_date']); ?></p>
<p>📍 <?php echo htmlspecialchars($event['location']); ?></p>
<p>
🎟 Seats Left:
<?php echo $event['available_seats']; ?>
</p>

<?php if($registered): ?>
<div class="registered">✅ Registered</div>
<?php else: ?>
<a class="btn primary" href="?register=<?php echo $event['id']; ?>"
Register
</a>
<?php endif; ?>

<a class="btn secondary"
href="event-details.php?event=<?php echo urlencode($event['title']); ?>">
View Details
</a>

</div>
</div>

<?php endif; endwhile; ?>

</div>

</div>

<script>
function toggleTheme(){
document.body.classList.toggle("dark");
let mode = document.body.classList.contains("dark") ? "dark" : "light";
document.cookie = "eventsphere_theme="+mode+"; path=/";
}

document.getElementById("searchInput").addEventListener("input",function(){
let val=this.value.toLowerCase();
document.querySelectorAll(".event-card").forEach(card=>{
card.style.display=card.innerText.toLowerCase().includes(val)?"block":"none";
});
});
</script>

</body>
</html>