<?php
session_start();

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}
$studentName = $_SESSION['student_name'];

/* ---------------- THEME ---------------- */

$savedTheme = "";

if(isset($_COOKIE['eventsphere_theme'])){
    $savedTheme = $_COOKIE['eventsphere_theme'];
}

/* ---------------- SEARCH ---------------- */

$search = "";

if(isset($_GET['search'])){
    $search = strtolower(trim($_GET['search']));
}

/* ---------------- CAMPUS PLACES + EVENTS ---------------- */

$places = [

[
"title"=>"Library",
"emoji"=>"📚",
"desc"=>"Quiet study area with books, digital resources and WiFi access.",
"type"=>"Study Zone",
"location"=>"Block A - Ground Floor",
"room"=>"L-101",
"event"=>"No ongoing event"
],

[
"title"=>"Canteen",
"emoji"=>"🍽️",
"desc"=>"Food court with snacks, meals and beverages for students.",
"type"=>"Food",
"location"=>"Central Block",
"room"=>"C-001",
"event"=>"Lunch Service Active"
],

[
"title"=>"Admin Block",
"emoji"=>"🏫",
"desc"=>"Main administrative office for college work and documentation.",
"type"=>"Office",
"location"=>"Block B - First Floor",
"room"=>"A-210",
"event"=>"Staff Meeting (Restricted Area)"
],

[
"title"=>"Computer Lab",
"emoji"=>"💻",
"desc"=>"High-performance systems for programming and practical sessions.",
"type"=>"Lab",
"location"=>"Tech Block - 2nd Floor",
"room"=>"CL-3",
"event"=>"AI Lab Session - CSE 2nd Year"
],

[
"title"=>"Auditorium",
"emoji"=>"🎤",
"desc"=>"Venue for seminars, events, workshops and celebrations.",
"type"=>"Events",
"location"=>"Main Block",
"room"=>"AUD-1",
"event"=>"🔥 Hackathon 2026 Finals Happening"
],

[
"title"=>"Sports Ground",
"emoji"=>"🏀",
"desc"=>"Outdoor ground for sports, fitness and college tournaments.",
"type"=>"Sports",
"location"=>"Outdoor Campus Area",
"room"=>"Field-1",
"event"=>"Football Practice Session"
],

[
"title"=>"Seminar Hall",
"emoji"=>"🎓",
"desc"=>"Used for guest lectures, presentations and workshops.",
"type"=>"Events",
"location"=>"Block C - First Floor",
"room"=>"SH-2",
"event"=>"Debate Competition Ongoing"
]

];

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>EventSphere Campus Navigation</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* ---------------- THEME ---------------- */

:root{
--light-text:#2B2B2B;
--dark-text:#EAF4FF;
--glass-light:rgba(255,255,255,0.40);
--glass-dark:rgba(22,32,51,0.82);
--accent:#6C9BD2;
}

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
display:flex;
transition:0.4s;
color:var(--light-text);
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc);
background-size:500% 500%;
animation:moveBG 18s ease infinite;
}

body.dark{
color:var(--dark-text);
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033);
}

/* ---------------- SIDEBAR ---------------- */

.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.3);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:30px;
color:var(--accent);
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:14px;
border-radius:16px;
color:inherit;
font-weight:600;
transition:0.3s;
}

.menu a:hover,
.menu a.active{
background:#AFCBFF;
transform:translateX(5px);
}

body.dark .menu a:hover,
body.dark .menu a.active{
background:#4CC9F0;
color:black;
}

/* ---------------- MAIN ---------------- */

.main{
margin-left:260px;
width:calc(100% - 260px);
padding:30px;
}

/* ---------------- TOPBAR ---------------- */

.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
flex-wrap:wrap;
gap:15px;
}

.search-box{
flex:1;
position:relative;
}

.search-box input{
width:100%;
padding:14px 18px;
padding-left:45px;
border:none;
outline:none;
border-radius:18px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(14px);
}

body.dark .search-box input{
background:rgba(255,255,255,0.08);
color:white;
}

.search-box i{
position:absolute;
left:16px;
top:15px;
opacity:0.6;
}

/* ---------------- PROFILE ---------------- */

.profile{
display:flex;
align-items:center;
gap:12px;
}

.toggle-btn{
border:none;
padding:10px 14px;
border-radius:14px;
cursor:pointer;
background:#AFCBFF;
font-weight:600;
}

body.dark .toggle-btn{
background:#4CC9F0;
}

/* ---------------- HERO ---------------- */

.hero{
padding:30px;
border-radius:28px;
background:var(--glass-light);
backdrop-filter:blur(20px);
margin-bottom:25px;
}

body.dark .hero{
background:var(--glass-dark);
}

.hero h1{
font-size:34px;
margin-bottom:10px;
}

/* ---------------- GRID ---------------- */

.grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
gap:20px;
}

/* ---------------- CARD ---------------- */

.card{
padding:22px;
border-radius:25px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(18px);
transition:0.3s;
border:1px solid rgba(255,255,255,0.2);
}

body.dark .card{
background:rgba(22,32,51,0.82);
}

.card:hover{
transform:translateY(-6px);
}

.card h2{
margin-bottom:10px;
color:var(--accent);
}

.card p{
opacity:0.85;
line-height:1.6;
}

.tag{
display:inline-block;
padding:6px 12px;
border-radius:20px;
font-size:12px;
margin-bottom:10px;
background:#dbeafe;
}

body.dark .tag{
background:#223A5E;
}

/* ---------------- EVENT BADGE ---------------- */

.event{
margin-top:10px;
padding:10px;
border-radius:12px;
background:rgba(255,255,255,0.25);
font-size:14px;
font-weight:600;
}

body.dark .event{
background:rgba(0,0,0,0.25);
}

/* ---------------- EMPTY ---------------- */

.empty{
text-align:center;
padding:40px;
background:rgba(255,255,255,0.3);
border-radius:20px;
}

body.dark .empty{
background:rgba(22,32,51,0.8);
}

/* ---------------- ANIMATION ---------------- */

@keyframes moveBG{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* ---------------- RESPONSIVE ---------------- */

@media(max-width:850px){
.sidebar{width:90px;}
.main{margin-left:90px;width:calc(100% - 90px);}
}

</style>

</head>

<body class="<?php echo ($savedTheme=='dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->
<div class="sidebar">

<div class="logo">🎉 EventSphere</div>

<div class="menu">

<a href="student-dashboard.php">🏠 Dashboard</a>
<a href="clubs.php">🎭 Clubs</a>
<a href="events.php">📅 Events</a>
<a href="registrations.php">📝 Registrations</a>
<a href="results.php">🏆 Results</a>
<a href="certificates.php">📜 Certificates</a>
<a class="active" href="navigation.php">🗺 Campus Navigation</a>
<a href="ai-assistant.php">🤖 AI Assistant</a>
<a href="notifications.php">🔔 Notifications</a>
<a href="profile.php">👤 Profile</a>
<a href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>

</div>

</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">

<form class="search-box" method="GET">

<i class="fa-solid fa-magnifying-glass"></i>

<input type="text"
name="search"
placeholder="Search campus places..."
value="<?php echo htmlspecialchars($search); ?>">

</form>

<div class="profile">

<button class="toggle-btn" onclick="toggleTheme()">
<?php echo ($savedTheme=='dark') ? '☀️' : '🌙'; ?>
</button>

<div>
<h3><?php echo $studentName; ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>

</div>

</div>

<!-- HERO -->
<div class="hero">

<h1>🗺 Campus Navigation</h1>
<p>Find rooms, blocks, and live events happening across campus in real time.</p>

</div>

<!-- GRID -->
<div class="grid">

<?php

$found=false;

foreach($places as $place){

if(
$search=="" ||
strpos(strtolower($place['title']),$search)!==false ||
strpos(strtolower($place['type']),$search)!==false
){

$found=true;

?>

<div class="card">

<div class="tag"><?php echo $place['type']; ?></div>

<h2><?php echo $place['emoji']." ".$place['title']; ?></h2>

<p><?php echo $place['desc']; ?></p>

<br>

<p><b>📍 Location:</b> <?php echo $place['location']; ?></p>
<p><b>🚪 Room:</b> <?php echo $place['room']; ?></p>

<div class="event">
🎯 <?php echo $place['event']; ?>
</div>

</div>

<?php } } ?>

</div>

<?php if(!$found): ?>
<div class="empty">📭 No campus places found.</div>
<?php endif; ?>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle('dark');

if(document.body.classList.contains('dark')){
document.cookie="eventsphere_theme=dark; path=/";
}else{
document.cookie="eventsphere_theme=light; path=/";
}

}

</script>

</body>
</html>