<?php
session_start();

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

include("../includes/db.php");

$studentName = $_SESSION['student_name'];
$studentId = $_SESSION['student_id'];

/* ---------------- SEARCH ---------------- */

$search = "";

if(isset($_GET['search'])){
    $search = strtolower(trim($_GET['search']));
}

/* ---------------- THEME FIX ---------------- */

if(isset($_COOKIE['eventsphere_theme'])){
    $savedTheme = $_COOKIE['eventsphere_theme'];
}else{
    $savedTheme = "";
}

/* ---------------- RESULTS DATABASE ---------------- */

$resultsQuery = $conn->query("

SELECT results.*, 
events.title AS event_title,
events.category

FROM results

LEFT JOIN events
ON results.event_id = events.id

WHERE results.student_id='$studentId'

ORDER BY results.id DESC

");

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>EventSphere Results</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

:root{

--light-text:#2B2B2B;
--dark-text:#EAF4FF;

--glass-light:rgba(255,255,255,0.40);
--glass-dark:rgba(22,32,51,0.82);

--light-accent:#6C9BD2;
--dark-accent:#4CC9F0;

}

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{

display:flex;
transition:0.4s;
color:var(--light-text);

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;
animation:gradientBG 18s ease infinite;

overflow-x:hidden;

}

body.dark{

color:var(--dark-text);

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

background-size:500% 500%;
animation:gradientBG 18s ease infinite;

}

/* GLOW */

body::before{

content:"";

position:fixed;

width:450px;
height:450px;

background:rgba(173,216,255,0.25);

border-radius:50%;

top:-100px;
left:-100px;

filter:blur(90px);

animation:floatGlow 10s ease-in-out infinite;

z-index:-1;

}

body::after{

content:"";

position:fixed;

width:380px;
height:380px;

background:rgba(199,210,254,0.25);

border-radius:50%;

bottom:-80px;
right:-80px;

filter:blur(90px);

animation:floatGlow2 12s ease-in-out infinite;

z-index:-1;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

@keyframes floatGlow{

0%{
transform:translateY(0px);
}

50%{
transform:translateY(40px);
}

100%{
transform:translateY(0px);
}

}

@keyframes floatGlow2{

0%{
transform:translateX(0px);
}

50%{
transform:translateX(-40px);
}

100%{
transform:translateX(0px);
}

}

/* SIDEBAR */

.sidebar{

width:260px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.30);

backdrop-filter:blur(20px);

border-right:1px solid rgba(255,255,255,0.2);

}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:30px;

color:var(--light-accent);

}

body.dark .logo{
color:var(--dark-accent);
}

.menu{

display:flex;
flex-direction:column;
gap:12px;

}

.menu a{

text-decoration:none;

padding:14px;

border-radius:16px;

transition:0.3s;

font-weight:600;

color:inherit;

}

.menu a:hover,
.menu a.active{

background:#AFCBFF;

transform:translateX(5px);

box-shadow:0 8px 20px rgba(108,155,210,0.25);

}

body.dark .menu a:hover,
body.dark .menu a.active{

background:#4CC9F0;
color:black;

}

/* MAIN */

.main{

margin-left:260px;
width:calc(100% - 260px);

padding:30px;

}

/* TOPBAR */

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

gap:20px;
flex-wrap:wrap;

margin-bottom:30px;

}

.search-box{

flex:1;
position:relative;

}

.search-box input{

width:100%;

padding:14px 18px;
padding-left:45px;

border:none;
outline:none;

border-radius:18px;

background:rgba(255,255,255,0.40);

backdrop-filter:blur(14px);

font-size:15px;

}

body.dark .search-box input{

background:rgba(255,255,255,0.08);
color:white;

}

.search-box i{

position:absolute;
left:16px;
top:15px;

opacity:0.6;

}

.profile{

display:flex;
align-items:center;
gap:15px;

}

.toggle-btn{

border:none;

padding:10px 14px;

border-radius:14px;

cursor:pointer;

background:#AFCBFF;

font-weight:600;

transition:0.3s;

}

body.dark .toggle-btn{
background:#4CC9F0;
}

.toggle-btn:hover{
transform:translateY(-2px);
}

/* HERO */

.hero-card{

padding:35px;

border-radius:28px;

background:var(--glass-light);

backdrop-filter:blur(22px);

margin-bottom:30px;

box-shadow:0 10px 35px rgba(0,0,0,0.08);

}

body.dark .hero-card{
background:var(--glass-dark);
}

.hero-card h1{

font-size:38px;
margin-bottom:15px;

}

.hero-card p{

line-height:1.8;
opacity:0.85;

}

/* RESULTS GRID */

.results-grid{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(330px,1fr));

gap:25px;

}

/* RESULT CARD */

.result-card{

padding:28px;

border-radius:28px;

background:rgba(255,255,255,0.42);

backdrop-filter:blur(18px);

box-shadow:0 10px 25px rgba(0,0,0,0.08);

transition:0.4s;

}

body.dark .result-card{
background:rgba(22,32,51,0.82);
}

.result-card:hover{

transform:
translateY(-8px)
scale(1.02);

}

.badge{

display:inline-block;

padding:8px 16px;

border-radius:30px;

font-size:12px;
font-weight:700;

margin-bottom:15px;

background:#dbeafe;
color:#1e3a8a;

}

body.dark .badge{

background:#223A5E;
color:white;

}

.result-card h2{

font-size:28px;
margin-bottom:15px;

}

.info{

margin-bottom:10px;
opacity:0.82;

}

.score{

margin-top:18px;

padding:15px;

border-radius:18px;

background:rgba(108,155,210,0.12);

font-weight:700;

font-size:18px;

}

body.dark .score{

background:rgba(76,201,240,0.12);

}

/* BUTTONS */

.buttons{

display:flex;
gap:12px;

margin-top:22px;

flex-wrap:wrap;

}

.btn{

padding:12px 18px;

border:none;

border-radius:14px;

cursor:pointer;

font-weight:600;

transition:0.3s;

text-decoration:none;

}

.primary-btn{

background:#6C9BD2;
color:white;

}

.secondary-btn{

background:#AFCBFF;
color:#2B2B2B;

}

body.dark .primary-btn{

background:#4CC9F0;
color:black;

}

body.dark .secondary-btn{

background:#223A5E;
color:white;

}

.btn:hover{

transform:translateY(-2px);

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a href="student-dashboard.php">🏠 Dashboard</a>

<a href="clubs.php">🎭 Clubs</a>

<a href="events.php">📅 Events</a>

<a href="registrations.php">📝 Registrations</a>

<a class="active" href="results.php">🏆 Results</a>

<a href="certificates.php">📜 Certificates</a>

<a href="navigation.php">🗺 Campus Navigation</a>

<a href="ai-assistant.php">🤖 AI Assistant</a>

<a href="notifications.php">🔔 Notifications</a>

<a href="profile.php">👤 Profile</a>

<a href="settings.php">⚙ Settings</a>

<a href="../auth/logout.php">🚪 Logout</a>

</div>

</div>

<div class="main">

<div class="topbar">

<form class="search-box" method="GET">

<i class="fa-solid fa-magnifying-glass"></i>

<input
type="text"
name="search"
placeholder="Search results..."
value="<?php echo htmlspecialchars($search); ?>">

</form>

<div class="profile">

<button class="toggle-btn"
onclick="toggleTheme()">

🌙

</button>

<div>
<h3><?php echo $studentName; ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>

</div>

</div>

<div class="hero-card">

<h1>🏆 Event Results</h1>

<p>
View your competition rankings,
performance scores,
achievements and campus event results beautifully in one place.
</p>

</div>

<div class="results-grid">

<?php

while($result = $resultsQuery->fetch_assoc()):

if(

$search == "" ||

strpos(strtolower($result['event_title']), $search) !== false ||

strpos(strtolower($result['category']), $search) !== false ||

strpos(strtolower($result['result_status']), $search) !== false ||

strpos(strtolower($result['position']), $search) !== false

):

?>

<div class="result-card">

<div class="badge">

<?php echo $result['result_status']; ?>

</div>

<h2>

🏆

<?php echo $result['event_title']; ?>

</h2>

<div class="info">
🏅 Position:
<?php echo $result['position']; ?>
</div>

<div class="info">
👥 Category:
<?php echo $result['category']; ?>
</div>

<div class="score">
📊 Score:
<?php echo $result['score']; ?>
</div>

<div class="buttons">

<a
href="certificates.php"
class="btn primary-btn">

View Certificate

</a>

<a
href="events.php"
class="btn secondary-btn">

View Event

</a>

</div>

</div>

<?php

endif;

endwhile;

?>

</div>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle('dark');

if(document.body.classList.contains('dark')){
document.cookie = "eventsphere_theme=dark; path=/";
}
else{
document.cookie = "eventsphere_theme=light; path=/";
}

}

</script>

</body>
</html>