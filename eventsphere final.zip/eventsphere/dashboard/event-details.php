<?php

session_start();

$eventName = "";

if(isset($_GET['event'])){
    $eventName = $_GET['event'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Event Details</title>

<style>

body{

font-family:'Segoe UI',sans-serif;

padding:40px;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:400% 400%;

animation:gradientBG 18s ease infinite;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

.card{

max-width:750px;

margin:auto;

padding:35px;

border-radius:28px;

background:rgba(255,255,255,0.45);

backdrop-filter:blur(18px);

box-shadow:0 10px 30px rgba(0,0,0,0.08);

}

h1{
margin-bottom:20px;
}

p{
line-height:1.8;
margin-bottom:15px;
}

.btn{

display:inline-block;

padding:14px 20px;

border-radius:14px;

text-decoration:none;

background:#6C9BD2;

color:white;

font-weight:600;

margin-top:20px;

}

</style>

</head>

<body>

<div class="card">

<h1>
🎉 <?php echo htmlspecialchars($eventName); ?>
</h1>

<p>
Welcome to the official event page of
<b><?php echo htmlspecialchars($eventName); ?></b>.
</p>

<p>
📅 View schedules, event timings,
venue details, guidelines and participation info.
</p>

<p>
✨ Register and participate through EventSphere.
</p>

<a href="registrations.php?event=<?php echo urlencode($eventName); ?>"
class="btn">

Register Now

</a>

</div>

</body>
</html>