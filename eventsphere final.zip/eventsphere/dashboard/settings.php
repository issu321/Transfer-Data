<?php
session_start();

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentName = $_SESSION['student_name'];

/* THEME */

if(isset($_COOKIE['eventsphere_theme'])){
    $savedTheme = $_COOKIE['eventsphere_theme'];
}else{
    $savedTheme = "";
}

/* DEFAULT SETTINGS */

if(!isset($_SESSION['notifications'])){
    $_SESSION['notifications'] = "ON";
}

if(!isset($_SESSION['email_alerts'])){
    $_SESSION['email_alerts'] = "ON";
}

if(!isset($_SESSION['darkmode'])){
    $_SESSION['darkmode'] = "OFF";
}

if(!isset($_SESSION['language'])){
    $_SESSION['language'] = "English";
}

if(!isset($_SESSION['privacy'])){
    $_SESSION['privacy'] = "Public";
}

$success = "";

/* SAVE SETTINGS */

if(isset($_POST['save_settings'])){

    $_SESSION['notifications'] =
    $_POST['notifications'];

    $_SESSION['email_alerts'] =
    $_POST['email_alerts'];

    $_SESSION['darkmode'] =
    $_POST['darkmode'];

    $_SESSION['language'] =
    $_POST['language'];

    $_SESSION['privacy'] =
    $_POST['privacy'];

    $success =
    "✅ Settings updated successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Settings - EventSphere</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{

display:flex;
transition:0.4s;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;
animation:gradientBG 18s ease infinite;

color:#2B2B2B;

overflow-x:hidden;

}

body.dark{

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

background-size:500% 500%;
animation:gradientBG 18s ease infinite;

color:#EAF4FF;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

/* SIDEBAR */

.sidebar{

width:260px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.30);

backdrop-filter:blur(20px);

border-right:1px solid rgba(255,255,255,0.2);

}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:30px;

color:#6C9BD2;

}

body.dark .logo{
color:#4CC9F0;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{

text-decoration:none;
padding:14px;

border-radius:16px;

transition:0.3s;

font-weight:600;

color:inherit;

}

.menu a:hover,
.menu a.active{

background:#AFCBFF;

transform:translateX(5px);

}

body.dark .menu a:hover,
body.dark .menu a.active{

background:#4CC9F0;
color:black;

}

/* MAIN */

.main{

margin-left:260px;
width:calc(100% - 260px);

padding:30px;

}

/* TOPBAR */

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

margin-bottom:30px;

gap:20px;
flex-wrap:wrap;

}

.search-box{

flex:1;
position:relative;

}

.search-box input{

width:100%;

padding:14px 18px;
padding-left:45px;

border:none;
outline:none;

border-radius:18px;

background:rgba(255,255,255,0.40);

backdrop-filter:blur(14px);

font-size:15px;

}

body.dark .search-box input{

background:rgba(255,255,255,0.08);
color:white;

}

.search-box i{

position:absolute;
left:16px;
top:15px;

opacity:0.6;

}

.profile-top{

display:flex;
align-items:center;
gap:15px;

}

.toggle-btn{

border:none;

padding:10px 14px;

border-radius:14px;

cursor:pointer;

background:#AFCBFF;

font-size:16px;

}

body.dark .toggle-btn{
background:#4CC9F0;
}

.profile-top img{

width:45px;
height:45px;

border-radius:50%;
object-fit:cover;

}

/* SETTINGS CARD */

.settings-card{

background:rgba(255,255,255,0.35);

backdrop-filter:blur(20px);

padding:30px;

border-radius:28px;

}

body.dark .settings-card{
background:rgba(22,32,51,0.82);
}

.settings-title{

margin-bottom:25px;

}

.settings-title h1{
font-size:34px;
margin-bottom:10px;
}

.settings-title p{
opacity:0.8;
}

/* FORM */

.form-grid{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(280px,1fr));

gap:20px;

}

.input-group{

display:flex;
flex-direction:column;
gap:8px;

}

.input-group label{
font-weight:600;
}

.input-group select{

padding:14px;

border:none;
outline:none;

border-radius:16px;

background:rgba(255,255,255,0.45);

font-size:15px;

}

body.dark .input-group select{

background:rgba(255,255,255,0.08);
color:white;

}

/* BUTTON */

.save-btn{

margin-top:25px;

padding:14px 22px;

border:none;

border-radius:16px;

background:#6C9BD2;

color:white;

font-size:16px;
font-weight:600;

cursor:pointer;

transition:0.3s;

}

.save-btn:hover{
transform:translateY(-2px);
}

body.dark .save-btn{
background:#4CC9F0;
color:black;
}

/* SUCCESS */

.success{

background:#dbeafe;

padding:14px;

border-radius:14px;

margin-bottom:20px;

font-weight:600;

}

/* MOBILE */

@media(max-width:850px){

.sidebar{
width:90px;
}

.logo{
font-size:20px;
}

.menu a{
font-size:12px;
padding:12px;
}

.main{
margin-left:90px;
width:calc(100% - 90px);
}

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a href="student-dashboard.php">🏠 Dashboard</a>

<a href="clubs.php">🎭 Clubs</a>

<a href="events.php">📅 Events</a>

<a href="registrations.php">📝 Registrations</a>

<a href="results.php">🏆 Results</a>

<a href="certificates.php">📜 Certificates</a>

<a href="navigation.php">🗺 Navigation</a>

<a href="ai-assistant.php">🤖 AI Assistant</a>

<a href="notifications.php">🔔 Notifications</a>

<a href="profile.php">👤 Profile</a>

<a class="active" href="settings.php">⚙ Settings</a>

<a href="../auth/logout.php">🚪 Logout</a>

</div>

</div>

<!-- MAIN -->

<div class="main">

<!-- TOPBAR -->

<div class="topbar">

<div class="search-box">

<i class="fa-solid fa-magnifying-glass"></i>

<input
type="text"
placeholder="Search settings...">

</div>

<div class="profile-top">

<button class="toggle-btn"
onclick="toggleTheme()">

🌙

</button>

<img src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png">

<div>
<h3><?php echo $studentName; ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>

</div>

</div>

<!-- SETTINGS -->

<div class="settings-card">

<div class="settings-title">

<h1>⚙ Settings</h1>

<p>
Customize your EventSphere experience beautifully 💙
</p>

</div>

<?php if($success!=""): ?>

<div class="success">

<?php echo $success; ?>

</div>

<?php endif; ?>

<form method="POST">

<div class="form-grid">

<div class="input-group">

<label>🔔 Notifications</label>

<select name="notifications">

<option
<?php if($_SESSION['notifications']=="ON") echo "selected"; ?>>
ON
</option>

<option
<?php if($_SESSION['notifications']=="OFF") echo "selected"; ?>>
OFF
</option>

</select>

</div>

<div class="input-group">

<label>📧 Email Alerts</label>

<select name="email_alerts">

<option
<?php if($_SESSION['email_alerts']=="ON") echo "selected"; ?>>
ON
</option>

<option
<?php if($_SESSION['email_alerts']=="OFF") echo "selected"; ?>>
OFF
</option>

</select>

</div>

<div class="input-group">

<label>🌙 Dark Mode</label>

<select name="darkmode">

<option
<?php if($_SESSION['darkmode']=="ON") echo "selected"; ?>>
ON
</option>

<option
<?php if($_SESSION['darkmode']=="OFF") echo "selected"; ?>>
OFF
</option>

</select>

</div>

<div class="input-group">

<label>🌐 Language</label>

<select name="language">

<option
<?php if($_SESSION['language']=="English") echo "selected"; ?>>
English
</option>

<option
<?php if($_SESSION['language']=="Hindi") echo "selected"; ?>>
Hindi
</option>

<option
<?php if($_SESSION['language']=="Urdu") echo "selected"; ?>>
Urdu
</option>

</select>

</div>

<div class="input-group">

<label>🔒 Privacy</label>

<select name="privacy">

<option
<?php if($_SESSION['privacy']=="Public") echo "selected"; ?>>
Public
</option>

<option
<?php if($_SESSION['privacy']=="Private") echo "selected"; ?>>
Private
</option>

</select>

</div>

</div>

<button class="save-btn"
name="save_settings">

💾 Save Settings

</button>

</form>

</div>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle('dark');

if(document.body.classList.contains('dark')){
document.cookie =
"eventsphere_theme=dark; path=/";
}
else{
document.cookie =
"eventsphere_theme=light; path=/";
}

}

</script>

</body>
</html>