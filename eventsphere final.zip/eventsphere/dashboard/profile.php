<?php
session_start();
include("../includes/db.php");

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentId = $_SESSION['student_id'];
$success = "";
$search = "";

/* SEARCH */
if(isset($_GET['search'])){
    $search = strtolower(trim($_GET['search']));
}

/* THEME */
$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* FETCH STUDENT DATA FROM DATABASE */
$getStudent = $conn->query("
SELECT * FROM students
WHERE student_id='$studentId'
");

$student = $getStudent->fetch_assoc();

/* DEFAULT VALUES */
$studentName = $student['name'];

$email =
$student['email'] ??
"student@eventsphere.com";

$course =
$student['course'] ??
"BCA";

$year =
$student['year'] ??
"1st Year";

$bio =
$student['bio'] ??
"Passionate student exploring campus life 🌸";

$studentImage =
$student['profile_image'] ?? "";

/* DEFAULT PROFILE IMAGE */
$defaultProfile =
"https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png";

/* SEARCH MESSAGE */
$searchMessage = "";

if($search != ""){

    if(
        strpos(
        "profile settings course year bio email picture image",
        $search
        ) !== false
        ||
        strpos(strtolower($studentName), $search) !== false
        ||
        strpos(strtolower($course), $search) !== false
        ||
        strpos(strtolower($year), $search) !== false
    ){

        $searchMessage =
        "✨ Showing results related to '$search'";

    }else{

        $searchMessage =
        "💡 Try searching: profile, course, year, bio";
    }
}

/* UPDATE PROFILE */
if(isset($_POST['save_profile'])){

    $name =
    mysqli_real_escape_string(
    $conn,
    $_POST['name']
    );

    $email =
    mysqli_real_escape_string(
    $conn,
    $_POST['email']
    );

    $course =
    mysqli_real_escape_string(
    $conn,
    $_POST['course']
    );

    $year =
    mysqli_real_escape_string(
    $conn,
    $_POST['year']
    );

    $bio =
    mysqli_real_escape_string(
    $conn,
    $_POST['bio']
    );

    $profileImage = $studentImage;

    /* IMAGE UPLOAD */
    if(
    isset($_FILES['profile_pic']) &&
    $_FILES['profile_pic']['name'] != ""
    ){

        $targetDir =
        "../assets/images/profile/";

        if(!is_dir($targetDir)){
            mkdir($targetDir, 0777, true);
        }

        $fileName =
        time() . "_" .
        basename($_FILES["profile_pic"]["name"]);

        $targetFile =
        $targetDir . $fileName;

        if(
        move_uploaded_file(
            $_FILES["profile_pic"]["tmp_name"],
            $targetFile
        )){
            $profileImage = $targetFile;
        }
    }

    /* UPDATE DATABASE */
    $conn->query("
    UPDATE students SET

    name='$name',
    email='$email',
    course='$course',
    year='$year',
    bio='$bio',
    profile_image='$profileImage'

    WHERE student_id='$studentId'
    ");

    /* UPDATE SESSION */
    $_SESSION['student_name'] = $name;

    /* REFRESH VALUES */
    $studentName = $name;
    $studentImage = $profileImage;

    $success =
    "✅ Profile updated successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Profile - EventSphere</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{

display:flex;
transition:0.4s;

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;
animation:gradientBG 18s ease infinite;

color:#2B2B2B;
overflow-x:hidden;
}

body.dark{

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

background-size:500% 500%;
animation:gradientBG 18s ease infinite;

color:#EAF4FF;
}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

/* SIDEBAR */

.sidebar{

width:260px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.30);

backdrop-filter:blur(20px);

border-right:1px solid rgba(255,255,255,0.2);

}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:30px;

color:#6C9BD2;
}

body.dark .logo{
color:#4CC9F0;
}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{

text-decoration:none;
padding:14px;

border-radius:16px;

transition:0.3s;

font-weight:600;

color:inherit;
}

.menu a:hover,
.menu a.active{

background:#AFCBFF;
transform:translateX(5px);
}

body.dark .menu a:hover,
body.dark .menu a.active{

background:#4CC9F0;
color:black;
}

/* MAIN */

.main{

margin-left:260px;
width:calc(100% - 260px);

padding:30px;
}

/* TOPBAR */

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

margin-bottom:30px;

gap:20px;
flex-wrap:wrap;
}

.search-box{

flex:1;
position:relative;
}

.search-box input{

width:100%;

padding:14px 18px;
padding-left:45px;

border:none;
outline:none;

border-radius:18px;

background:rgba(255,255,255,0.40);

backdrop-filter:blur(14px);

font-size:15px;
}

body.dark .search-box input{

background:rgba(255,255,255,0.08);
color:white;
}

.search-box i{

position:absolute;
left:16px;
top:15px;

opacity:0.6;
}

.profile-top{

display:flex;
align-items:center;
gap:15px;
}

.toggle-btn{

border:none;

padding:10px 14px;

border-radius:14px;

cursor:pointer;

background:#AFCBFF;

font-size:16px;
}

body.dark .toggle-btn{
background:#4CC9F0;
}

.profile-top img{

width:45px;
height:45px;

border-radius:50%;
object-fit:cover;
}

/* PROFILE CARD */

.profile-card{

background:rgba(255,255,255,0.35);

backdrop-filter:blur(20px);

padding:30px;

border-radius:28px;

margin-bottom:25px;
}

body.dark .profile-card{
background:rgba(22,32,51,0.82);
}

.profile-header{

display:flex;
align-items:center;
gap:25px;

flex-wrap:wrap;

margin-bottom:25px;
}

.profile-header img{

width:120px;
height:120px;

border-radius:50%;
object-fit:cover;

border:4px solid #dbeafe;
}

.profile-info h1{
font-size:34px;
margin-bottom:10px;
}

.profile-info p{
opacity:0.8;
line-height:1.7;
}

/* FORM */

.form-grid{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(280px,1fr));

gap:20px;
}

.input-group{
display:flex;
flex-direction:column;
gap:8px;
}

.input-group label{
font-weight:600;
}

.input-group input,
.input-group textarea{

padding:14px;

border:none;
outline:none;

border-radius:16px;

background:rgba(255,255,255,0.45);

font-size:15px;
}

body.dark .input-group input,
body.dark .input-group textarea{

background:rgba(255,255,255,0.08);
color:white;
}

textarea{
resize:none;
height:120px;
}

.save-btn{

margin-top:25px;

padding:14px 22px;

border:none;

border-radius:16px;

background:#6C9BD2;

color:white;

font-size:16px;
font-weight:600;

cursor:pointer;

transition:0.3s;
}

.save-btn:hover{
transform:translateY(-2px);
}

body.dark .save-btn{
background:#4CC9F0;
color:black;
}

/* SEARCH MESSAGE */

.search-message{

background:rgba(255,255,255,0.45);

padding:14px;

border-radius:16px;

margin-bottom:20px;

font-weight:600;
}

/* STATS */

.stats{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(220px,1fr));

gap:20px;

margin-top:25px;
}

.stat-card{

padding:22px;

border-radius:24px;

background:rgba(255,255,255,0.35);

backdrop-filter:blur(18px);

text-align:center;
}

body.dark .stat-card{
background:rgba(22,32,51,0.82);
}

.stat-card h2{
font-size:34px;
margin-bottom:10px;
}

/* MOBILE */

@media(max-width:850px){

.sidebar{
width:90px;
}

.logo{
font-size:20px;
}

.menu a{
font-size:12px;
padding:12px;
}

.main{
margin-left:90px;
width:calc(100% - 90px);
}

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a href="student-dashboard.php">🏠 Dashboard</a>

<a href="clubs.php">🎭 Clubs</a>

<a href="events.php">📅 Events</a>

<a href="registrations.php">📝 Registrations</a>

<a href="results.php">🏆 Results</a>

<a href="certificates.php">📜 Certificates</a>

<a href="navigation.php">🗺 Navigation</a>

<a href="ai-assistant.php">🤖 AI Assistant</a>

<a href="notifications.php">🔔 Notifications</a>

<a class="active" href="profile.php">👤 Profile</a>

<a href="settings.php">⚙ Settings</a>

<a href="../auth/logout.php">🚪 Logout</a>

</div>

</div>

<div class="main">

<div class="topbar">

<form class="search-box" method="GET">

<i class="fa-solid fa-magnifying-glass"></i>

<input
type="text"
name="search"
placeholder="Search profile settings..."
value="<?php echo htmlspecialchars($search); ?>">

</form>

<div class="profile-top">

<button class="toggle-btn"
onclick="toggleTheme()">

🌙

</button>

<img src="<?php echo (!empty($studentImage) ? $studentImage : $defaultProfile); ?>">

<div>
<h3><?php echo $studentName; ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>

</div>

</div>

<?php if($searchMessage != ""): ?>

<div class="search-message">

<?php echo $searchMessage; ?>

</div>

<?php endif; ?>

<div class="profile-card">

<div class="profile-header">

<img src="<?php echo (!empty($studentImage) ? $studentImage : $defaultProfile); ?>">

<div class="profile-info">

<h1><?php echo $studentName; ?></h1>

<p>
<?php echo $bio; ?>
</p>

</div>

</div>

<?php if($success!=""): ?>

<div style="
background:#dbeafe;
padding:14px;
border-radius:14px;
margin-bottom:20px;
font-weight:600;
">

<?php echo $success; ?>

</div>

<?php endif; ?>

<form method="POST"
enctype="multipart/form-data">

<div class="form-grid">

<div class="input-group">

<label>👤 Full Name</label>

<input type="text"
name="name"
value="<?php echo $studentName; ?>"
required>

</div>

<div class="input-group">

<label>📧 Email</label>

<input type="email"
name="email"
value="<?php echo $email; ?>"
required>

</div>

<div class="input-group">

<label>🎓 Course</label>

<input type="text"
name="course"
value="<?php echo $course; ?>">

</div>

<div class="input-group">

<label>📚 Year</label>

<input type="text"
name="year"
value="<?php echo $year; ?>">

</div>

<div class="input-group"
style="grid-column:1/-1;">

<label>🌸 Bio</label>

<textarea name="bio"><?php echo $bio; ?></textarea>

</div>

<div class="input-group"
style="grid-column:1/-1;">

<label>🖼 Change Profile Picture</label>

<input type="file"
name="profile_pic">

</div>

</div>

<button class="save-btn"
name="save_profile">

💾 Save Changes

</button>

</form>

<div class="stats">

<div class="stat-card">
<h2>12</h2>
<p>📅 Events Joined</p>
</div>

<div class="stat-card">
<h2>5</h2>
<p>🏆 Achievements</p>
</div>

<div class="stat-card">
<h2>8</h2>
<p>📜 Certificates</p>
</div>

</div>

</div>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle('dark');

if(document.body.classList.contains('dark')){
document.cookie =
"eventsphere_theme=dark; path=/";
}
else{
document.cookie =
"eventsphere_theme=light; path=/";
}

}

</script>

</body>
</html>