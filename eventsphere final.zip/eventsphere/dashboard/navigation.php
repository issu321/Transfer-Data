<?php
session_start();

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentName = $_SESSION['student_name'];

$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* CAMPUS PLACES */
$places = [
["name"=>"Main Library","emoji"=>"📚","type"=>"Academic Block","desc"=>"Central library with digital + physical books","block"=>"Block A","room"=>"L1"],
["name"=>"Computer Lab","emoji"=>"💻","type"=>"Lab","desc"=>"High performance systems for coding & projects","block"=>"Block B","room"=>"B201"],
["name"=>"Admin Block","emoji"=>"🏢","type"=>"Office","desc"=>"Admission, fees and official work","block"=>"Block C","room"=>"C101"],
["name"=>"Canteen","emoji"=>"🍽️","type"=>"Food Court","desc"=>"Food hub for students and staff","block"=>"Block D","room"=>"GF-01"],
["name"=>"Sports Ground","emoji"=>"⚽","type"=>"Sports","desc"=>"Football, cricket and athletics ground","block"=>"Ground Area","room"=>"Field-1"],
["name"=>"Auditorium","emoji"=>"🎤","type"=>"Events","desc"=>"Events, seminars and cultural programs","block"=>"Block E","room"=>"E-Hall"],
["name"=>"Science Block","emoji"=>"🧪","type"=>"Academic Block","desc"=>"Physics, Chemistry and Biology labs","block"=>"Block F","room"=>"F305"],
["name"=>"Girls Hostel","emoji"=>"🏠","type"=>"Hostel","desc"=>"Safe residential facility for students","block"=>"Hostel Zone","room"=>"H-Block"]
];

/* EVENTS */
$events = [
["title"=>"Hackathon 2026","emoji"=>"💻","venue"=>"Computer Lab","time"=>"10:00 AM","club"=>"IT Club","block"=>"Block B","room"=>"B201"],
["title"=>"Debate Finals","emoji"=>"🗣️","venue"=>"Auditorium","time"=>"1:00 PM","club"=>"Speak Up Society","block"=>"Block E","room"=>"E-Hall"],
["title"=>"Sports Championship","emoji"=>"⚽","venue"=>"Sports Ground","time"=>"4:00 PM","club"=>"Sports Club","block"=>"Ground Area","room"=>"Field-1"],
["title"=>"Science Expo","emoji"=>"🧪","venue"=>"Science Block","time"=>"11:00 AM","club"=>"Science Club","block"=>"Block F","room"=>"F305"]
];

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EventSphere Navigation</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* THEME */
:root{
--light-text:#2B2B2B;
--dark-text:#EAF4FF;
--glass-light:rgba(255,255,255,0.40);
--glass-dark:rgba(22,32,51,0.82);
--light-accent:#6C9BD2;
--dark-accent:#4CC9F0;
}

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

/* BODY */
body{
display:flex;
transition:0.4s;
color:var(--light-text);
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:gradientBG 18s ease infinite;
}

body.dark{
color:var(--dark-text);
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
}

/* SIDEBAR */
.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.30);
backdrop-filter:blur(20px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:30px;
color:var(--light-accent);
}

body.dark .logo{ color:var(--dark-accent); }

/* MENU */
.menu a{
display:block;
padding:14px;
border-radius:16px;
text-decoration:none;
color:inherit;
font-weight:600;
margin-bottom:10px;
transition:0.3s;
}

.menu a:hover,
.menu a.active{
background:#AFCBFF;
transform:translateX(5px);
}

body.dark .menu a:hover,
body.dark .menu a.active{
background:#4CC9F0;
color:black;
}

/* MAIN */
.main{
margin-left:260px;
width:calc(100% - 260px);
padding:30px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
gap:15px;
flex-wrap:wrap;
margin-bottom:25px;
}

.search-box{
flex:1;
position:relative;
}

.search-box input{
width:100%;
padding:14px 18px 14px 45px;
border:none;
border-radius:18px;
background:rgba(255,255,255,0.4);
backdrop-filter:blur(12px);
outline:none;
}

.search-box i{
position:absolute;
left:15px;
top:14px;
opacity:0.6;
}

.toggle-btn{
padding:10px 14px;
border:none;
border-radius:14px;
cursor:pointer;
background:#AFCBFF;
font-weight:600;
}

/* HERO */
.hero{
padding:30px;
border-radius:28px;
background:var(--glass-light);
backdrop-filter:blur(20px);
margin-bottom:25px;
}

body.dark .hero{
background:var(--glass-dark);
}

.hero h1{
font-size:34px;
margin-bottom:10px;
}

/* GRID */
.grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
gap:20px;
}

/* CARD */
.card{
padding:22px;
border-radius:24px;
background:rgba(255,255,255,0.45);
backdrop-filter:blur(18px);
transition:0.3s;
border:1px solid rgba(255,255,255,0.2);
}

body.dark .card{
background:rgba(22,32,51,0.82);
}

.card:hover{
transform:translateY(-6px);
}

.card h2{
margin-bottom:10px;
font-size:22px;
}

.tag{
display:inline-block;
padding:6px 12px;
border-radius:20px;
background:#dbeafe;
font-size:12px;
margin-bottom:10px;
}

body.dark .tag{
background:#223A5E;
}

/* BUTTON */
button{
padding:10px 14px;
border:none;
border-radius:10px;
background:#6C9BD2;
color:white;
cursor:pointer;
margin-top:10px;
}

.place-card{
transition:0.3s;
}

</style>
</head>

<body class="<?php echo ($savedTheme=='dark')?'dark':''; ?>">

<!-- SIDEBAR -->
<div class="sidebar">
<div class="logo">🎉 EventSphere</div>

<div class="menu">
<a href="student-dashboard.php">🏠 Dashboard</a>
<a href="clubs.php">🎭 Clubs</a>
<a href="events.php">📅 Events</a>
<a href="registrations.php">📝 Registrations</a>
<a href="results.php">🏆 Results</a>
<a href="certificates.php">📜 Certificates</a>
<a class="active" href="navigation.php">🗺 Campus Navigation</a>
<a href="ai-assistant.php">🤖 AI Assistant</a>
<a href="notifications.php">🔔 Notifications</a>
<a href="profile.php">👤 Profile</a>
<a href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>
</div>
</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">

<div class="search-box">
<i class="fa fa-search"></i>
<input type="text" placeholder="Search places, rooms, blocks, events...">
</div>

<button class="toggle-btn" onclick="toggleTheme()">
<?php echo ($savedTheme=='dark')?'☀️':'🌙'; ?>
</button>

</div>

<!-- HERO -->
<div class="hero">
<h1>🗺 Smart Campus Navigation</h1>
<p>Search anything: places, rooms, blocks, or events instantly.</p>
</div>

<!-- EVENTS -->
<div class="hero">
<h2>🎪 Today’s Events</h2>
</div>

<div class="grid">

<?php foreach($events as $e){ ?>

<div class="card">

<div class="tag"><?php echo $e['club']; ?></div>

<h2><?php echo $e['emoji']." ".$e['title']; ?></h2>

<p>📍 <?php echo $e['venue']; ?></p>
<p>🏢 Block: <?php echo $e['block']; ?></p>
<p>🚪 Room: <?php echo $e['room']; ?></p>
<p>⏰ <?php echo $e['time']; ?></p>

<button onclick="highlightPlace('<?php echo $e['venue']; ?>')">
📌 Locate
</button>

</div>

<?php } ?>

</div>

<!-- PLACES -->
<div class="hero">
<h2>🏫 Campus Places</h2>
</div>

<div class="grid">

<?php foreach($places as $p){ ?>

<div class="card place-card" data-name="<?php echo $p['name']; ?>">

<div class="tag"><?php echo $p['type']; ?></div>

<h2><?php echo $p['emoji']." ".$p['name']; ?></h2>

<p><?php echo $p['desc']; ?></p>
<p>🏢 Block: <?php echo $p['block']; ?></p>
<p>🚪 Room: <?php echo $p['room']; ?></p>

</div>

<?php } ?>

</div>

</div>

<script>

/* THEME */
function toggleTheme(){
document.body.classList.toggle("dark");
document.cookie =
"eventsphere_theme=" +
(document.body.classList.contains("dark") ? "dark":"light")
+ "; path=/";
}

/* SMART HIGHLIGHT */
function highlightPlace(placeName){

let cards = document.querySelectorAll(".place-card");

cards.forEach(card => {
card.style.outline = "none";

if(card.dataset.name === placeName){
card.style.outline = "3px solid #4CC9F0";
card.scrollIntoView({behavior:"smooth", block:"center"});
}
});

}

/* SMART SEARCH */
const input = document.querySelector(".search-box input");

input.addEventListener("input", function(){

let value = this.value.toLowerCase().trim();
let cards = document.querySelectorAll(".card");

cards.forEach(card => {

let text = card.innerText.toLowerCase();

if(text.includes(value)){
card.style.display = "block";
} else {
card.style.display = "none";
}

});

});

</script>

</body>
</html>