<?php
session_start();

include("../includes/db.php");

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentName = $_SESSION['student_name'];

/* THEME */
$savedTheme = "";

if(isset($_COOKIE['eventsphere_theme'])){
    $savedTheme = $_COOKIE['eventsphere_theme'];
}

/* FETCH CLUBS */
$clubs =
$conn->query(
"SELECT * FROM clubs ORDER BY id DESC"
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EventSphere Clubs</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* ===== YOUR ORIGINAL DESIGN (UNCHANGED) ===== */

:root{
--light-text:#2B2B2B;
--dark-text:#EAF4FF;
--glass-light:rgba(255,255,255,0.40);
--glass-dark:rgba(22,32,51,0.82);
}

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

body{
display:flex;
transition:0.4s;
color:var(--light-text);
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:gradientBG 20s ease infinite;
overflow-x:hidden;
}

body.dark{
color:var(--dark-text);
background:linear-gradient(-45deg,#0A0F1C,#112240,#1B263B,#162033,#223A5E);
}

@keyframes gradientBG{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* SIDEBAR */
.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.30);
backdrop-filter:blur(22px);
border-right:1px solid rgba(255,255,255,0.18);
}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{
font-size:28px;
font-weight:700;
margin-bottom:25px;
color:#6C9BD2;
}

body.dark .logo{color:#4CC9F0;}

.menu{
display:flex;
flex-direction:column;
gap:12px;
}

.menu a{
text-decoration:none;
padding:13px;
border-radius:14px;
font-weight:600;
color:inherit;
transition:0.3s;
}

.menu a.active{
background:rgba(76,201,240,0.18);
color:#4CC9F0;
box-shadow:0 0 12px rgba(76,201,240,0.25);
}

.menu a:hover{
transform:translateX(6px);
background:rgba(76,201,240,0.08);
}

/* MAIN */
.main{
margin-left:260px;
width:calc(100% - 260px);
padding:28px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
flex-wrap:wrap;
gap:20px;
margin-bottom:25px;
}

/* SEARCH */
.search-box{
flex:1;
min-width:250px;
position:relative;
}

.search-box input{
width:100%;
padding:14px 18px 14px 45px;
border:none;
outline:none;
border-radius:18px;
background:rgba(255,255,255,0.35);
}

body.dark .search-box input{
background:rgba(255,255,255,0.08);
color:white;
}

.search-box i{
position:absolute;
left:16px;
top:15px;
opacity:0.6;
}

/* MODE BUTTON */
.mode-btn{
border:none;
padding:10px 14px;
border-radius:12px;
cursor:pointer;
background:rgba(255,255,255,0.35);
font-size:16px;
}

body.dark .mode-btn{
background:#223A5E;
color:white;
}

/* TITLE */
.title-card{
padding:28px;
border-radius:26px;
background:var(--glass-light);
backdrop-filter:blur(20px);
margin-bottom:30px;
box-shadow:0 10px 25px rgba(0,0,0,0.06);
}

body.dark .title-card{
background:var(--glass-dark);
}

.title-card h1{
font-size:34px;
margin-bottom:10px;
}

.title-card p{
opacity:0.8;
line-height:1.7;
}

/* GRID */
.club-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
gap:22px;
}

/* CARD */
.club-card{
border-radius:22px;
overflow:hidden;
background:rgba(255,255,255,0.40);
backdrop-filter:blur(18px);
transition:0.35s;
box-shadow:0 8px 20px rgba(0,0,0,0.05);
border:1px solid rgba(255,255,255,0.25);
}

body.dark .club-card{
background:rgba(22,32,51,0.82);
border:1px solid rgba(255,255,255,0.06);
}

.club-card:hover{
transform:translateY(-10px) scale(1.02);
}

/* IMAGE */
.club-card img{
width:100%;
height:220px;
object-fit:cover;
}

/* CONTENT */
.club-content{
padding:20px;
}

/* CATEGORY */
.club-category{
display:inline-block;
padding:6px 12px;
border-radius:20px;
background:#dbeafe;
font-size:12px;
font-weight:600;
margin-bottom:12px;
}

body.dark .club-category{
background:#223A5E;
color:white;
}

.club-btn{
display:inline-block;
padding:10px 16px;
border-radius:12px;
text-decoration:none;
font-weight:600;
background:#4CC9F0;
color:black;
margin-top:10px;
}

</style>
</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->
<div class="sidebar">

<div class="logo">🎉 EventSphere</div>

<div class="menu">
<a href="student-dashboard.php">🏠 Dashboard</a>
<a class="active" href="clubs.php">🎭 Clubs</a>
<a href="events.php">📅 Events</a>
<a href="registrations.php">📝 Registrations</a>
<a href="results.php">🏆 Results</a>
<a href="certificates.php">📜 Certificates</a>
<a href="navigation.php">🗺 Campus Navigation</a>
<a href="ai-assistant.php">🤖 AI Assistant</a>
<a href="notifications.php">🔔 Notifications</a>
<a href="profile.php">👤 Profile</a>
<a href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>
</div>

</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR (FIXED RESTORED SECTION) -->
<div class="topbar">

<form class="search-box" onsubmit="return false;">
<i class="fa-solid fa-magnifying-glass"></i>
<input type="text" placeholder="Search clubs..." onkeyup="searchFeature()">
</form>

<!-- ✅ RESTORED: MODE + STUDENT INFO -->
<div style="display:flex;align-items:center;gap:15px;">

<button class="mode-btn" onclick="toggleTheme()">🌙</button>

<div>
<h3><?php echo $studentName; ?> 👋</h3>
<p style="opacity:0.7;">Student</p>
</div>

</div>

</div>

<!-- TITLE -->
<div class="title-card">
<h1>🎭 Explore Student Clubs</h1>
<p>Join clubs, explore skills, and participate in campus activities.</p>
</div>

<!-- CLUBS -->
<div class="club-grid">

<?php while($row = $clubs->fetch_assoc()): ?>

<div class="club-card">

<img src="../assets/images/clubs/<?php echo !empty($row['image']) ? $row['image'] : 'default.png'; ?>">

<div class="club-content">

<div class="club-category">
<?php echo htmlspecialchars($row['category']); ?>
</div>

<h2>🎭 <?php echo htmlspecialchars($row['club_name']); ?></h2>

<p><?php echo htmlspecialchars($row['description']); ?></p>

<p>👨‍🏫 <?php echo htmlspecialchars($row['faculty_head']); ?></p>

<a class="club-btn" href="events.php">View Club</a>

</div>

</div>

<?php endwhile; ?>

</div>

</div>

<script>
function toggleTheme(){
document.body.classList.toggle("dark");

let mode = document.body.classList.contains("dark") ? "dark" : "light";
document.cookie = "eventsphere_theme=" + mode + "; path=/";
}

function searchFeature(){
let input = document.querySelector("input").value.toLowerCase();

document.querySelectorAll(".club-card").forEach(card=>{
card.style.display = card.innerText.toLowerCase().includes(input) ? "block" : "none";
});
}
</script>

</body>
</html>