<?php
session_start();

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentName = $_SESSION['student_name'];

/* THEME */
$savedTheme = $_COOKIE['eventsphere_theme'] ?? "";

/* CHAT MEMORY */
if(!isset($_SESSION['chat_history'])){
    $_SESSION['chat_history'] = [];
}

$aiReply = "";
$userQuestion = "";

if(isset($_POST['ask_ai'])){

    $userQuestion = trim($_POST['question']);
    $question = strtolower($userQuestion);

    $_SESSION['chat_history'][] = [
        "q" => $userQuestion,
        "time" => date("H:i")
    ];

    $aiReply = "🤖 Hey $studentName 💙 I'm here for you! Ask me anything about studies, stress, clubs or events.";

    if(strpos($question,"hackathon") !== false){
        $aiReply = "💻 Hackathon happens in IT Block Room 305. It's a great opportunity to build real projects 🚀";
    }
    elseif(strpos($question,"club") !== false){
        $aiReply = "🎭 Clubs like IT, DSA, NSS, Sports and Speak Up help you grow skills and confidence 💙";
    }
    elseif(strpos($question,"stress") !== false){
        $aiReply = "🌿 Take it slow. One step at a time is enough. You're doing better than you think 💙";
    }
    elseif(strpos($question,"study") !== false){
        $aiReply = "📚 Study in 25–30 min focus blocks. Short breaks improve memory and concentration.";
    }
    elseif(strpos($question,"motivat") !== false){
        $aiReply = "🚀 You are capable of amazing things. Keep going — your effort matters 💙";
    }
    elseif(strpos($question,"library") !== false){
        $aiReply = "📖 Library is in Academic Block — quiet and perfect for studying.";
    }
    elseif(strpos($question,"sports") !== false){
        $aiReply = "⚽ Sports events happen in the Main Ground. Great for fitness and teamwork!";
    }
    elseif(strpos($question,"certificate") !== false){
        $aiReply = "📜 Certificates appear after event completion in the Certificates section.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EventSphere AI Assistant</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

/* BASE */
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

/* BODY */
body{
display:flex;
transition:0.4s;
background:linear-gradient(-45deg,#eef4ff,#dbeafe,#e0e7ff,#f8fafc,#c7d2fe);
background-size:500% 500%;
animation:gradientBG 20s ease infinite;
color:#2B2B2B;
}

body.dark{
background:#0A0F1C;
color:#EAF4FF;
}

@keyframes gradientBG{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

/* SIDEBAR */
.sidebar{
width:260px;
height:100vh;
position:fixed;
left:0;
top:0;
padding:20px;
overflow-y:auto;
background:rgba(255,255,255,0.28);
backdrop-filter:blur(22px);
border-right:1px solid rgba(255,255,255,0.2);
}

body.dark .sidebar{
background:rgba(27,38,59,0.85);
}

/* MENU */
.menu a{
display:block;
padding:14px;
border-radius:14px;
text-decoration:none;
color:inherit;
font-weight:600;
margin-bottom:10px;
transition:0.3s;
}

.menu a:hover,
.menu a.active{
background:rgba(76,201,240,0.18);
color:#4CC9F0;
transform:translateX(5px);
}

/* MAIN */
.main{
margin-left:260px;
width:calc(100% - 260px);
padding:25px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:20px;
}

/* PROFILE (LIKE CLUBS STYLE) */
.profile-box{
display:flex;
align-items:center;
gap:12px;
font-weight:600;
}

.profile-icon{
width:40px;
height:40px;
border-radius:50%;
display:flex;
align-items:center;
justify-content:center;
background:rgba(76,201,240,0.18);
color:#4CC9F0;
font-weight:700;
}

/* MODE */
.mode-btn{
border:none;
padding:10px 14px;
border-radius:12px;
cursor:pointer;
background:rgba(255,255,255,0.35);
font-size:16px;
}

body.dark .mode-btn{
background:#223A5E;
color:white;
}

/* HERO */
.hero{
padding:22px;
border-radius:20px;
background:rgba(255,255,255,0.3);
backdrop-filter:blur(20px);
margin-bottom:20px;
}

body.dark .hero{
background:rgba(255,255,255,0.05);
}

/* CHAT BOX */
.chat-box{
display:flex;
gap:20px;
align-items:flex-start;
background:rgba(255,255,255,0.3);
padding:20px;
border-radius:20px;
backdrop-filter:blur(20px);
}

body.dark .chat-box{
background:rgba(255,255,255,0.05);
}

/* TEXTAREA */
textarea{
width:100%;
height:90px;
padding:12px;
border:none;
border-radius:12px;
outline:none;
margin-top:10px;
resize:none;
}

/* BUTTON */
.btn{
width:100%;
margin-top:10px;
padding:12px;
border:none;
border-radius:12px;
background:#4CC9F0;
color:black;
font-weight:600;
cursor:pointer;
}

/* CHAT DISPLAY */
.chat-display{
margin-top:15px;
display:flex;
flex-direction:column;
gap:10px;
}

/* USER QUESTION */
.user-msg{
align-self:flex-end;
background:#dbeafe;
padding:10px 14px;
border-radius:12px;
max-width:80%;
font-weight:600;
}

/* AI RESPONSE */
.ai-msg{
align-self:flex-start;
background:#4CC9F0;
color:black;
padding:10px 14px;
border-radius:12px;
max-width:80%;
font-weight:600;
}

/* ROBOT */
.robot{
width:120px;
animation:float 3s ease-in-out infinite;
}

@keyframes float{
0%,100%{transform:translateY(0);}
50%{transform:translateY(-10px);}
}

</style>
</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<!-- SIDEBAR -->
<div class="sidebar">

<div style="font-size:24px;font-weight:700;margin-bottom:20px;">
🎉 EventSphere
</div>

<div class="menu">
<a href="student-dashboard.php">🏠 Dashboard</a>
<a href="clubs.php">🎭 Clubs</a>
<a href="events.php">📅 Events</a>
<a href="registrations.php">📝 Registrations</a>
<a href="results.php">🏆 Results</a>
<a href="certificates.php">📜 Certificates</a>
<a href="navigation.php">🗺 Navigation</a>
<a class="active" href="ai-assistant.php">🤖 AI Assistant</a>
<a href="notifications.php">🔔 Notifications</a>
<a href="profile.php">👤 Profile</a>
<a href="settings.php">⚙ Settings</a>
<a href="../auth/logout.php">🚪 Logout</a>
</div>

</div>

<!-- MAIN -->
<div class="main">

<!-- TOPBAR -->
<div class="topbar">

<div class="profile-box">
<div class="profile-icon">
<?php echo strtoupper(substr($studentName,0,1)); ?>
</div>
<div>
<?php echo $studentName; ?>
<p style="font-size:12px;opacity:0.7;">Student</p>
</div>
</div>

<button class="mode-btn" onclick="toggleTheme()">🌙</button>

</div>

<!-- HERO -->
<div class="hero">
<h1>🤖 AI Assistant</h1>
<p>Your friendly campus buddy 💙</p>
</div>

<!-- CHAT -->
<div class="chat-box">

<div style="flex:1;">

<form method="POST">

<textarea name="question" placeholder="Ask anything..." required></textarea>

<button class="btn" name="ask_ai">Ask AI</button>

</form>

<!-- FIX: QUESTION + ANSWER BOTH SHOWN -->
<div class="chat-display">

<?php if($userQuestion != ""): ?>
<div class="user-msg">
<?php echo $userQuestion; ?>
</div>
<?php endif; ?>

<?php if($aiReply != ""): ?>
<div class="ai-msg">
<?php echo $aiReply; ?>
</div>
<?php endif; ?>

</div>

</div>

<div>
<img class="robot" src="https://cdn-icons-png.flaticon.com/512/4712/4712109.png">
</div>

</div>

</div>

<script>
function toggleTheme(){
document.body.classList.toggle("dark");
document.cookie = "eventsphere_theme=" + (document.body.classList.contains("dark") ? "dark" : "light") + "; path=/";
}
</script>

</body>
</html>