<?php
session_start();

include("../includes/db.php");

if(!isset($_SESSION['student_name'])){
    header("Location: ../auth/login.php");
    exit();
}

$studentName = $_SESSION['student_name'];

$studentId = $_SESSION['student_id'];

/* ---------------- THEME FIX ---------------- */

$savedTheme = "";

if(isset($_COOKIE['eventsphere_theme'])){
    $savedTheme = $_COOKIE['eventsphere_theme'];
}

/* ---------------- SEARCH ---------------- */

$search = "";

if(isset($_GET['search'])){
    $search = strtolower(trim($_GET['search']));
}

/* ---------------- REAL CERTIFICATES ---------------- */

$query = "

SELECT *

FROM certificates

WHERE student_id='$studentId'

ORDER BY id DESC

";

$result = $conn->query($query);

$certificates = [];

while($row = $result->fetch_assoc()){

    $certificates[] = [

        "title" => $row['title'],

        "emoji" => "📜",

        "club" => "EventSphere Achievement",

        "date" => $row['issued_date'],

        "type" => "Certificate",

        "file" =>
        "../uploads/certificates/" . $row['file']

    ];

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>EventSphere Certificates</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

<style>

:root{

--light-text:#2B2B2B;
--dark-text:#EAF4FF;

--glass-light:rgba(255,255,255,0.40);
--glass-dark:rgba(22,32,51,0.82);

--light-accent:#6C9BD2;
--dark-accent:#4CC9F0;

}

/* RESET */

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Segoe UI',sans-serif;
}

/* BODY */

body{

display:flex;

transition:0.4s;

color:var(--light-text);

background:
linear-gradient(
-45deg,
#eef4ff,
#dbeafe,
#e0e7ff,
#f8fafc,
#c7d2fe
);

background-size:500% 500%;

animation:gradientBG 18s ease infinite;

overflow-x:hidden;

}

body.dark{

color:var(--dark-text);

background:
linear-gradient(
-45deg,
#0A0F1C,
#112240,
#1B263B,
#162033,
#223A5E
);

background-size:500% 500%;

animation:gradientBG 18s ease infinite;

}

/* FLOATING GLOW */

body::before{

content:"";

position:fixed;

width:450px;
height:450px;

background:rgba(173,216,255,0.25);

border-radius:50%;

top:-100px;
left:-100px;

filter:blur(90px);

animation:floatGlow 10s ease-in-out infinite;

z-index:-1;

}

body::after{

content:"";

position:fixed;

width:380px;
height:380px;

background:rgba(199,210,254,0.25);

border-radius:50%;

bottom:-80px;
right:-80px;

filter:blur(90px);

animation:floatGlow2 12s ease-in-out infinite;

z-index:-1;

}

@keyframes gradientBG{

0%{
background-position:0% 50%;
}

50%{
background-position:100% 50%;
}

100%{
background-position:0% 50%;
}

}

@keyframes floatGlow{

0%{
transform:translateY(0px);
}

50%{
transform:translateY(40px);
}

100%{
transform:translateY(0px);
}

}

@keyframes floatGlow2{

0%{
transform:translateX(0px);
}

50%{
transform:translateX(-40px);
}

100%{
transform:translateX(0px);
}

}

/* SIDEBAR */

.sidebar{

width:260px;
height:100vh;

position:fixed;
left:0;
top:0;

padding:20px;

overflow-y:auto;

background:rgba(255,255,255,0.30);

backdrop-filter:blur(20px);

border-right:1px solid rgba(255,255,255,0.2);

}

body.dark .sidebar{
background:rgba(22,32,51,0.88);
}

.logo{

font-size:28px;
font-weight:700;

margin-bottom:30px;

color:var(--light-accent);

}

body.dark .logo{
color:var(--dark-accent);
}

.menu{

display:flex;
flex-direction:column;
gap:12px;

}

.menu a{

text-decoration:none;

padding:14px;

border-radius:16px;

transition:0.3s;

font-weight:600;

color:inherit;

}

.menu a:hover,
.menu a.active{

background:#AFCBFF;

transform:translateX(5px);

box-shadow:0 8px 20px rgba(108,155,210,0.25);

}

body.dark .menu a:hover,
body.dark .menu a.active{

background:#4CC9F0;
color:black;

}

/* MAIN */

.main{

margin-left:260px;

width:calc(100% - 260px);

padding:30px;

}

/* TOPBAR */

.topbar{

display:flex;
justify-content:space-between;
align-items:center;

gap:20px;

flex-wrap:wrap;

margin-bottom:30px;

}

/* SEARCH */

.search-box{

flex:1;

position:relative;

}

.search-box input{

width:100%;

padding:14px 18px;
padding-left:45px;

border:none;
outline:none;

border-radius:18px;

background:rgba(255,255,255,0.40);

backdrop-filter:blur(14px);

font-size:15px;

box-shadow:0 8px 20px rgba(0,0,0,0.05);

}

body.dark .search-box input{

background:rgba(255,255,255,0.08);

color:white;

}

.search-box i{

position:absolute;

left:16px;
top:15px;

opacity:0.6;

}

/* PROFILE */

.profile{

display:flex;
align-items:center;
gap:15px;

}

/* THEME BUTTON */

.toggle-btn{

border:none;

padding:10px 14px;

border-radius:14px;

cursor:pointer;

background:#AFCBFF;

font-weight:600;

transition:0.3s;

}

.toggle-btn:hover{
transform:translateY(-2px);
}

body.dark .toggle-btn{

background:#4CC9F0;

}

/* HERO */

.hero-card{

padding:35px;

border-radius:28px;

background:var(--glass-light);

backdrop-filter:blur(22px);

margin-bottom:30px;

box-shadow:0 10px 35px rgba(0,0,0,0.08);

border:1px solid rgba(255,255,255,0.25);

}

body.dark .hero-card{
background:var(--glass-dark);
}

.hero-card h1{

font-size:36px;

margin-bottom:14px;

}

.hero-card p{

line-height:1.8;

opacity:0.85;

}

/* GRID */

.certificates-grid{

display:grid;

grid-template-columns:
repeat(auto-fit,minmax(340px,1fr));

gap:25px;

}

/* CARD */

.certificate-card{

padding:25px;

border-radius:28px;

background:rgba(255,255,255,0.42);

backdrop-filter:blur(18px);

box-shadow:0 10px 25px rgba(0,0,0,0.08);

transition:0.4s;

border:1px solid rgba(255,255,255,0.2);

}

body.dark .certificate-card{
background:rgba(22,32,51,0.82);
}

.certificate-card:hover{

transform:
translateY(-8px)
scale(1.02);

box-shadow:0 18px 40px rgba(108,155,210,0.20);

}

.badge{

display:inline-block;

padding:8px 16px;

border-radius:30px;

font-size:12px;
font-weight:700;

margin-bottom:15px;

background:#dbeafe;

}

body.dark .badge{

background:#223A5E;

color:white;

}

.certificate-card h2{

font-size:25px;

margin-bottom:14px;

}

.info{

margin-bottom:10px;

opacity:0.82;

}

/* BUTTONS */

.buttons{

display:flex;

gap:12px;

margin-top:22px;

flex-wrap:wrap;

}

.btn{

padding:12px 18px;

border:none;

border-radius:14px;

cursor:pointer;

font-weight:600;

transition:0.3s;

text-decoration:none;

display:inline-flex;
align-items:center;
gap:8px;

}

.primary-btn{

background:#6C9BD2;

color:white;

}

.secondary-btn{

background:#AFCBFF;

color:#2B2B2B;

}

.download-btn{

background:#22c55e;

color:white;

}

body.dark .primary-btn{

background:#4CC9F0;

color:black;

}

body.dark .secondary-btn{

background:#223A5E;

color:white;

}

body.dark .download-btn{

background:#16a34a;

}

.btn:hover{

transform:translateY(-2px);

}

/* EMPTY */

.empty-box{

padding:40px;

border-radius:24px;

text-align:center;

background:rgba(255,255,255,0.35);

backdrop-filter:blur(14px);

font-size:18px;

}

body.dark .empty-box{

background:rgba(22,32,51,0.82);

}

/* RESPONSIVE */

@media(max-width:850px){

.sidebar{
width:90px;
}

.logo{
font-size:20px;
}

.menu a{
font-size:12px;
padding:12px;
}

.main{
margin-left:90px;
width:calc(100% - 90px);
}

}

</style>

</head>

<body class="<?php echo ($savedTheme == 'dark') ? 'dark' : ''; ?>">

<div class="sidebar">

<div class="logo">
🎉 EventSphere
</div>

<div class="menu">

<a href="student-dashboard.php">🏠 Dashboard</a>

<a href="clubs.php">🎭 Clubs</a>

<a href="events.php">📅 Events</a>

<a href="registrations.php">📝 Registrations</a>

<a href="results.php">🏆 Results</a>

<a class="active" href="certificates.php">📜 Certificates</a>

<a href="navigation.php">🗺 Campus Navigation</a>

<a href="ai-assistant.php">🤖 AI Assistant</a>

<a href="notifications.php">🔔 Notifications</a>

<a href="profile.php">👤 Profile</a>

<a href="settings.php">⚙ Settings</a>

<a href="../auth/logout.php">🚪 Logout</a>

</div>

</div>

<div class="main">

<div class="topbar">

<form class="search-box" method="GET">

<i class="fa-solid fa-magnifying-glass"></i>

<input
type="text"
name="search"
placeholder="Search certificates..."
value="<?php echo htmlspecialchars($search); ?>">

</form>

<div class="profile">

<button
class="toggle-btn"
id="themeToggle"
onclick="toggleTheme()">

<?php echo ($savedTheme == 'dark') ? '☀️' : '🌙'; ?>

</button>

<div>

<h3><?php echo $studentName; ?> 👋</h3>

<p style="opacity:0.7;">Student</p>

</div>

</div>

</div>

<div class="hero-card">

<h1>📜 My Certificates</h1>

<p>
View and download all your uploaded certificates and achievements.
</p>

</div>

<div class="certificates-grid">

<?php

$found = false;

foreach($certificates as $certificate){

if(

$search == "" ||

strpos(strtolower($certificate['title']),$search) !== false ||

strpos(strtolower($certificate['type']),$search) !== false

){

$found = true;

?>

<div class="certificate-card">

<div class="badge">

<?php echo $certificate['type']; ?>

</div>

<h2>

<?php echo $certificate['emoji']; ?>

<?php echo $certificate['title']; ?>

</h2>

<div class="info">
🏆 <?php echo $certificate['club']; ?>
</div>

<div class="info">
📅 <?php echo $certificate['date']; ?>
</div>

<div class="buttons">

<a
href="<?php echo $certificate['file']; ?>"
target="_blank"
class="btn primary-btn">

<i class="fa-solid fa-eye"></i>

View PDF

</a>

<a
href="<?php echo $certificate['file']; ?>"
download
class="btn download-btn">

<i class="fa-solid fa-download"></i>

Download

</a>

</div>

</div>

<?php

}

}

?>

</div>

<?php if(!$found): ?>

<div class="empty-box">

📭 No certificates found.

</div>

<?php endif; ?>

</div>

<script>

function toggleTheme(){

document.body.classList.toggle('dark');

let themeBtn =
document.getElementById('themeToggle');

if(document.body.classList.contains('dark')){

document.cookie =
"eventsphere_theme=dark; path=/";

themeBtn.innerHTML = "☀️";

}
else{

document.cookie =
"eventsphere_theme=light; path=/";

themeBtn.innerHTML = "🌙";

}

}

</script>

</body>
</html>